import re
from typing import List, Tuple
import pickle


# phrase_hasher.py
def hash_phrase(phrase: str) -> int:
    """Division Chain hash - fast, low collision"""
    h = 2
    for char in phrase:
        h = (h + ord(char)) * 33
    return h % 0xFFFFFF  # 24-bit address

def collision_step(phrase: str) -> int:
    """XOR Shift for collision resolution"""
    h = len(phrase)
    return (h ^ (h << 3)) & 0xFF


# vocab_builder.py
class Vocab:
    def __init__(self):
        self.table = {}  # addr -> phrase
        self.reverse = {}  # phrase -> addr
    
    def add(self, phrase: str) -> int:
        # Check if already exists
        if phrase in self.reverse:
            return self.reverse[phrase]
            
        addr = hash_phrase(phrase)
        step = collision_step(phrase)
        
        # Collision resolution
        probes = 0
        while addr in self.table and self.table[addr] != phrase:
            addr = (addr + step) % 0xFFFFFF
            probes += 1
            if probes > 10000:
                raise Exception(f"Too many collisions for phrase: {phrase}")
            
        self.table[addr] = phrase
        self.reverse[phrase] = addr
        return addr
    
    def get(self, addr: int) -> str:
        return self.table.get(addr)
    
    def save(self, path: str):
        with open(path, 'wb') as f:
            pickle.dump(self.table, f)
    
    def load(self, path: str):
        with open(path, 'rb') as f:
            self.table = pickle.load(f)
            self.reverse = {v: k for k, v in self.table.items()}


def parse_smart(text: str) -> List[str]:
    """Overlapping extraction, then deduplicate by frequency"""
    from collections import Counter
    
    words = text.split()
    all_phrases = []
    
    # Extract all overlapping n-grams (1 to 4 words)
    for n in range(1, 5):
        for i in range(len(words) - n + 1):
            phrase = ' '.join(words[i:i+n]).lower()
            all_phrases.append(phrase)
    
    # Count frequencies
    freq = Counter(all_phrases)
    
    # Return only phrases that appear 2+ times
    # OR are needed for coverage
    used = set()
    result = []
    
    for i in range(len(words)):
        # Try to match longest phrase first
        for n in range(4, 0, -1):
            if i + n > len(words):
                continue
            phrase = ' '.join(words[i:i+n]).lower()
            if phrase not in used and freq[phrase] >= 2:
                result.append(phrase)
                used.add(phrase)
                break
    
    return result

# compressor.py
def compress_text(text: str, vocab: Vocab) -> bytes:
    """Text → 3-byte addresses"""
    phrases = parse_smart(text)
    addresses = []
    
    for phrase in phrases:
        addr = vocab.add(phrase)  # add() returns addr, handles duplicates
        addresses.append(addr)
    
    # Pack as 3 bytes each
    return b''.join(addr.to_bytes(3, 'big') for addr in addresses)


def decompress(data: bytes, vocab: Vocab) -> str:
    """Improved decompression that preserves word order"""
    addresses = [int.from_bytes(data[i:i+3], 'big') 
                 for i in range(0, len(data), 3)]
    
    phrases = [vocab.get(addr) for addr in addresses]
    
    # DON'T just join with spaces - smart merge
    result = []
    for phrase in phrases:
        if phrase:
            words = phrase.split()
            result.extend(words)
    
    return ' '.join(result)

# MAIN DEMO
if __name__ == "__main__":
    vocab = Vocab()
    
    # Build vocab from corpus
    try:
        with open('bible.txt', 'r', encoding='utf-8') as f:
            text = f.read()
    except FileNotFoundError:
        # Fallback test text
        text = """
        The cat is an animal. The cat has fur. The cat has whiskers.
        Dogs are animals. Dogs have tails. Dogs have fur.
        The sky is blue. The grass is green.
        """ * 100  # Repeat for testing
    
    print("Compressing text...")
    compressed = compress_text(text, vocab)
    original_size = len(text.encode())
    compressed_size = len(compressed)
    
    print(f"\n=== COMPRESSION RESULTS ===")
    print(f"Original: {original_size:,} bytes")
    print(f"Compressed: {compressed_size:,} bytes")
    print(f"Ratio: {original_size / compressed_size:.1f}:1")
    print(f"Vocab size: {len(vocab.table):,} phrases")
    print(f"Avg phrase length: {original_size / len(vocab.table):.1f} chars")
    
    print("\nDecompressing...")
    decompressed = decompress(compressed, vocab)
    
    print("\n=== SAMPLE OUTPUT ===")
    print("Original (first 200 chars):")
    print(text[:200])
    print("\nDecompressed (first 200 chars):")
    print(decompressed[:200])
    
    # Verify lossiness
    match_ratio = len(set(text.lower().split()) & set(decompressed.split())) / len(set(text.lower().split()))
    print(f"\nWord overlap: {match_ratio*100:.1f}%")
    
    # Save vocab for reuse
    vocab.save('vocab_test.pkl')
    print("\nVocab saved to vocab_test.pkl")