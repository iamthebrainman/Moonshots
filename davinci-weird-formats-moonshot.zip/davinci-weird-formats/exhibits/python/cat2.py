import re
from typing import List, Tuple
import pickle
from relational_system import Relations  # ← THE KEY IMPORT


def hash_phrase(phrase: str) -> int:
    """Division Chain hash - fast, low collision"""
    h = 2
    for char in phrase:
        h = (h + ord(char)) * 33
    return h % 0xFFFFFF

def collision_step(phrase: str) -> int:
    """XOR Shift for collision resolution"""
    h = len(phrase)
    return (h ^ (h << 3)) & 0xFF


class Vocab:
    def __init__(self):
        self.table = {}
        self.reverse = {}
    
    def add(self, phrase: str) -> int:
        if phrase in self.reverse:
            return self.reverse[phrase]
            
        addr = hash_phrase(phrase)
        step = collision_step(phrase)
        
        probes = 0
        while addr in self.table and self.table[addr] != phrase:
            addr = (addr + step) % 0xFFFFFF
            probes += 1
            if probes > 10000:
                raise Exception(f"Too many collisions for phrase: {phrase}")
            
        self.table[addr] = phrase
        self.reverse[phrase] = addr
        return addr
    
    def get(self, addr: int) -> str:
        return self.table.get(addr)


def parse_triples(text: str) -> List[str]:
    """Use Relations parser to extract semantic units"""
    
    # Initialize parser
    r = Relations()
    
    # Tokenize
    tokens = text.split()
    positions = list(range(len(tokens)))
    
    # Extract relations
    r.extract_from_tokens(tokens, positions)
    
    # Convert to phrases
    phrases = []
    for subj, rel, obj, pos, mods in r.triples:
        # Store each component separately for semantic matching
        if subj:
            phrases.append(subj)
        if rel:
            phrases.append(rel)
        if obj:
            phrases.append(obj)
    
    return phrases


def compress_text(text: str, vocab: Vocab) -> bytes:
    """Text → 3-byte addresses"""
    phrases = parse_triples(text)
    addresses = []
    
    for phrase in phrases:
        addr = vocab.add(phrase)
        addresses.append(addr)
    
    return b''.join(addr.to_bytes(3, 'big') for addr in addresses)


def decompress(data: bytes, vocab: Vocab) -> str:
    """3-byte addresses → text"""
    addresses = [int.from_bytes(data[i:i+3], 'big') 
                 for i in range(0, len(data), 3)]
    phrases = [vocab.get(addr) for addr in addresses]
    return ' '.join(p for p in phrases if p is not None)


# MAIN
if __name__ == "__main__":
    vocab = Vocab()
    
    try:
        with open('bible.txt', 'r', encoding='utf-8') as f:
            text = f.read()
    except FileNotFoundError:
        text = "In the beginning God created the heavens and the earth." * 100
    
    print("Parsing with Relations system...")
    compressed = compress_text(text, vocab)
    
    original_size = len(text.encode())
    compressed_size = len(compressed)
    
    print(f"\n=== RESULTS ===")
    print(f"Original: {original_size:,} bytes")
    print(f"Compressed: {compressed_size:,} bytes")
    print(f"Ratio: {original_size / compressed_size:.1f}:1")
    print(f"Vocab size: {len(vocab.table):,} phrases")
    
    # Show sample phrases
    print(f"\n=== SAMPLE PHRASES ===")
    for i, (addr, phrase) in enumerate(list(vocab.table.items())[:20]):
        print(f"{addr:06x}: {phrase}")
    
    vocab.save('vocab_relational.pkl')