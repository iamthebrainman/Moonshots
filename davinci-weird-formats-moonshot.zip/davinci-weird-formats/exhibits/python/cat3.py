import re
from typing import List
import pickle
from relational_system import Relations  # Your production parser


def hash_phrase(phrase: str) -> int:
    """Division Chain hash - fast, low collision"""
    h = 2
    for char in phrase:
        h = (h + ord(char)) * 33
    return h % 0xFFFFFF


def collision_step(phrase: str) -> int:
    """XOR Shift for collision resolution"""
    h = len(phrase)
    return (h ^ (h << 3)) & 0xFF


class Vocab:
    def __init__(self):
        self.table = {}
        self.reverse = {}
    
    def add(self, phrase: str) -> int:
        if phrase in self.reverse:
            return self.reverse[phrase]
            
        addr = hash_phrase(phrase)
        step = collision_step(phrase)
        
        probes = 0
        while addr in self.table and self.table[addr] != phrase:
            addr = (addr + step) % 0xFFFFFF
            probes += 1
            if probes > 10000:
                raise Exception(f"Too many collisions: {phrase}")
            
        self.table[addr] = phrase
        self.reverse[phrase] = addr
        return addr
    
    def get(self, addr: int) -> str:
        return self.table.get(addr)


def parse_with_relations(text: str) -> List[str]:
    """Use Relations parser to extract semantic phrases"""
    r = Relations()
    
    tokens = text.split()
    positions = list(range(len(tokens)))
    
    r.extract_from_tokens(tokens, positions)
    
    phrases = []
    for subj, rel, obj, pos, mods in r.triples:
        # Store subject, relation, object separately
        if subj and subj.strip():
            phrases.append(subj.strip())
        if obj and obj.strip():
            phrases.append(obj.strip())
    
    return phrases


def compress_text(text: str, vocab: Vocab) -> bytes:
    phrases = parse_with_relations(text)
    addresses = [vocab.add(p) for p in phrases]
    return b''.join(addr.to_bytes(3, 'big') for addr in addresses)


def decompress(data: bytes, vocab: Vocab) -> str:
    addresses = [int.from_bytes(data[i:i+3], 'big') 
                 for i in range(0, len(data), 3)]
    phrases = [vocab.get(addr) for addr in addresses if vocab.get(addr)]
    return ' '.join(phrases)


if __name__ == "__main__":
    vocab = Vocab()
    
    with open('bible.txt', 'r', encoding='utf-8') as f:
        text = f.read()
    
    print("Compressing with Relations parser...")
    compressed = compress_text(text, vocab)
    
    print(f"\nOriginal: {len(text):,} bytes")
    print(f"Compressed: {len(compressed):,} bytes")
    print(f"Ratio: {len(text) / len(compressed):.1f}:1")
    print(f"Vocab: {len(vocab.table):,} phrases")
    
    print("\nDecompressing...")
    decompressed = decompress(compressed, vocab)
    
    print("\nOriginal (first 200):")
    print(text[:200])
    print("\nDecompressed (first 200):")
    print(decompressed[:200])
    
    # Word overlap
    orig_words = set(text.lower().split())
    decomp_words = set(decompressed.lower().split())
    overlap = len(orig_words & decomp_words) / len(orig_words) * 100
    print(f"\nWord overlap: {overlap:.1f}%")