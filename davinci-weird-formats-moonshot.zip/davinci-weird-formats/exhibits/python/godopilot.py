import sys
import time
from collections import defaultdict
from typing import Dict, List, Optional, Set, Tuple
from relational_system import Relations

# ==============================================================================
# GEMATRIC LAYER (Letter Position Hash)
# ==============================================================================


def word_to_gematric(word: str) -> Tuple[int, ...]:
    """Convert word to tuple of letter positions (a=1, b=2, ...)"""
    return tuple(ord(c.lower()) - 96 for c in word if c.isalpha())


def gematric_to_string(gematric: Tuple[int, ...]) -> str:
    """Convert gematric back to string for display"""
    return "".join(chr(n + 96) for n in gematric)


class GematricHashTable:
    """
    Maps gematric sequences (letter position tuples) to words.
    Enables partial gematric matching with typo tolerance.
    """

    def __init__(self):
        # Maps gematric prefix -> set of words
        self.gematric_index = defaultdict(set)
        # Maps word -> full gematric tuple
        self.word_to_full_gematric = {}
        # Simple cache for fuzzy_match results: (word, max_variance, max_expansion) -> frozenset
        self._fuzzy_cache = {}

    def insert_word(self, word: str):
        """Index word by all gematric prefixes"""
        word = word.lower()
        gematric = word_to_gematric(word)

        if not gematric:
            return

        self.word_to_full_gematric[word] = gematric

        # Index all prefixes: [3], [3,1], [3,1,20]
        for i in range(1, len(gematric) + 1):
            prefix = gematric[:i]
            self.gematric_index[prefix].add(word)

    def query_by_prefix(self, partial_word: str) -> Set[str]:
        """Find all words matching partial gematric sequence"""
        gematric = word_to_gematric(partial_word)
        return self.gematric_index.get(gematric, set())

    def fuzzy_match(
        self, word: str, max_variance: int = 1, max_expansion: int = 50
    ) -> Set[str]:
        """
        Find words with similar gematric sequences.
        max_variance: allow N letter differences
        max_expansion: return at most this many results
        """
        gematric = word_to_gematric(word)
        cache_key = (word.lower(), max_variance, max_expansion)
        if cache_key in self._fuzzy_cache:
            return set(self._fuzzy_cache[cache_key])
        matches = set()

        # 1) Exact prefix matches are the fastest and preferred
        exact_matches = self.gematric_index.get(gematric, set())
        if exact_matches:
            for w in list(exact_matches)[:max_expansion]:
                matches.add(w)

        # 2) If the input is short (user typing 1-3 chars), fall back to
        # scanning vocab for prefix-like matches using a cheap edit-distance
        # on gematric sequences. This makes single-letter inputs like 'c'
        # match 'created', 'christ', 'cities', etc., and tolerates small typos.
        if len(gematric) <= 3:
            # helper: limited Levenshtein (early exit)
            def edit_distance_prefix(a, b, maxd):
                # compute edit distance between a and prefix of b (both tuples of ints)
                la, lb = len(a), len(b)
                # if trivial bounds
                if abs(la - lb) > maxd:
                    # still allow if b is longer (prefix case) but penalize length diff
                    pass
                # classic dynamic programming with early cutoff
                dp = list(range(lb + 1))
                for i in range(1, la + 1):
                    prev = dp[0]
                    dp[0] = i
                    minrow = dp[0]
                    for j in range(1, lb + 1):
                        cur = dp[j]
                        cost = 0 if a[i - 1] == b[j - 1] else 1
                        dp[j] = min(prev + cost, dp[j] + 1, dp[j - 1] + 1)
                        prev = cur
                        if dp[j] < minrow:
                            minrow = dp[j]
                    if minrow > maxd:
                        return maxd + 1
                return dp[lb]

            # iterate vocab and score
            for cand, full in self.word_to_full_gematric.items():
                # compare against prefix of full gematric of length len(gematric)
                fd = full
                # use prefix of candidate up to len(gematric) or full length
                prefix_of_full = fd[: len(gematric)]
                dist = edit_distance_prefix(gematric, prefix_of_full, max_variance)
                if dist <= max_variance:
                    matches.add(cand)
                    if len(matches) >= max_expansion:
                        break

        # 3) As a last resort, also include shorter-prefix buckets (missing letters)
        # to catch cases where the user omitted trailing characters
        if len(matches) < max_expansion:
            for length in range(max(1, len(gematric) - max_variance), len(gematric)):
                prefix = gematric[:length]
                prefix_matches = self.gematric_index.get(prefix, set())
                for w in list(prefix_matches)[: max_expansion - len(matches)]:
                    matches.add(w)

        # Cache and return
        capped = set(list(matches)[:max_expansion])
        try:
            # store as frozenset to ensure immutability
            self._fuzzy_cache[cache_key] = frozenset(capped)
        except Exception:
            pass
        return capped


# ==============================================================================
# TRIPLE-LAYER POSITION HASH
# ==============================================================================


def hash_word_64bit(word: str) -> int:
    """Hash single word to 64-bit address"""
    h = 5381
    for char in word.lower():
        h = ((h << 5) + h) ^ ord(char)
    return h & 0xFFFFFFFFFFFFFFFF


def hash_sentence_64bit(sentence: str) -> int:
    """Hash a full sentence to a 64-bit address (simple djb2-style over the sentence)."""
    h = 5381
    for char in sentence.lower():
        h = ((h << 5) + h) ^ ord(char)
    return h & 0xFFFFFFFFFFFFFFFF


def hash_turn_64bit(turn_id: int, sentence_hashes: Tuple[int, ...]) -> int:
    """Combine sentence hashes into a single 64-bit turn hash.

    We mix sentence hashes together with shifts and xor to produce a stable
    turn-level 64-bit fingerprint.
    """
    h = 2166136261
    for sh in sentence_hashes:
        # Mix in 64-bit word pieces
        h = (h ^ (sh & 0xFFFFFFFFFFFFFFFF)) * 16777619
        h &= 0xFFFFFFFFFFFFFFFF
    # Fold with turn id for extra separation
    h ^= (turn_id << 13) | (turn_id >> 7)
    return h & 0xFFFFFFFFFFFFFFFF


class TripleLayerHashTable:
    """Three independent 64-bit hash layers for wildcard phrase search."""

    def __init__(self):
        self.layer_0 = defaultdict(set)
        self.layer_1 = defaultdict(set)
        self.layer_2 = defaultdict(set)
        self.phrases = {}
        self.phrase_to_id = {}
        self.insert_count = 0
        self.gematric_table = GematricHashTable()
        self.word_vocab = set()

    def insert(self, phrase: str) -> int:
        """Insert phrase and index by word positions + gematric"""
        phrase = phrase.lower().strip()

        if phrase in self.phrase_to_id:
            return self.phrase_to_id[phrase]

        phrase_id = self.insert_count
        self.insert_count += 1

        self.phrases[phrase_id] = phrase
        self.phrase_to_id[phrase] = phrase_id

        words = phrase.split()

        # Index each word gematrically
        for word in words:
            if word not in self.word_vocab:
                self.word_vocab.add(word)
                self.gematric_table.insert_word(word)

        # Hash each word position
        if len(words) >= 1:
            h0 = hash_word_64bit(words[0])
            self.layer_0[h0].add(phrase_id)

        if len(words) >= 2:
            h1 = hash_word_64bit(words[1])
            self.layer_1[h1].add(phrase_id)

        if len(words) >= 3:
            h2 = hash_word_64bit(words[2])
            self.layer_2[h2].add(phrase_id)

        return phrase_id

    def query(
        self,
        word_0: Optional[str] = None,
        word_1: Optional[str] = None,
        word_2: Optional[str] = None,
        limit: int = 100,
    ) -> List[str]:
        """Wildcard search across phrase positions"""
        candidates = None

        if word_0 is not None:
            h0 = hash_word_64bit(word_0)
            if h0 in self.layer_0:
                candidates = self.layer_0[h0].copy()
            else:
                return []

        if word_1 is not None:
            h1 = hash_word_64bit(word_1)
            if h1 in self.layer_1:
                layer_1_matches = self.layer_1[h1]
                if candidates is None:
                    candidates = layer_1_matches.copy()
                else:
                    candidates &= layer_1_matches
            else:
                return []

        if word_2 is not None:
            h2 = hash_word_64bit(word_2)
            if h2 in self.layer_2:
                layer_2_matches = self.layer_2[h2]
                if candidates is None:
                    candidates = layer_2_matches.copy()
                else:
                    candidates &= layer_2_matches
            else:
                return []

        if candidates is None:
            candidates = set(self.phrases.keys())

        results = []
        for phrase_id in list(candidates)[:limit]:
            results.append(self.phrases[phrase_id])

        return results

    def query_with_second_prefix(self, word_0: str, partial_word_1: str, limit: int = 100) -> List[str]:
        """Fast path: find phrases where word_0 matches exactly and word_1 starts with partial."""
        h0 = hash_word_64bit(word_0)
        if h0 not in self.layer_0:
            return []

        results = []
        for pid in self.layer_0[h0]:
            phrase = self.phrases[pid]
            parts = phrase.split()
            if len(parts) >= 2 and parts[1].startswith(partial_word_1):
                results.append(phrase)
                if len(results) >= limit:
                    break
        return results

    def query_with_third_prefix(self, word_0: str, word_1: str, partial_word_2: str, limit: int = 100) -> List[str]:
        """Fast path: first two words exact, third word starts with partial."""
        h0 = hash_word_64bit(word_0)
        h1 = hash_word_64bit(word_1)
        if h0 not in self.layer_0 or h1 not in self.layer_1:
            return []

        candidates = self.layer_0[h0] & self.layer_1[h1]
        results = []
        for pid in candidates:
            phrase = self.phrases[pid]
            parts = phrase.split()
            if len(parts) >= 3 and parts[2].startswith(partial_word_2):
                results.append(phrase)
                if len(results) >= limit:
                    break
        return results

    def _get_relations_suggestions(self, partial: str, limit: int) -> List[str]:
        """Fetch suggestions from the relational graph system."""
        words = partial.lower().split()
        if not words:
            return []
            
        suggestions = []
        # Use first word to find relevant relations
        anchor = words[0]
        
        # Get relations where anchor is subject
        # Note: get_relations_for returns (subj, rel, obj, pos)
        rels = self.relations.get_relations_for(anchor, as_subject=True, as_object=False)
        
        seen = set()
        
        for subj, rel, obj, pos in rels:
            if not obj: continue
            
            # Form natural language phrase 
            # (Simplistic reconstruction)
            phrase = f"{subj} {rel} {obj}"
            
            # Check if it matches the partial query
            if phrase.lower().startswith(partial.lower()):
                if phrase not in seen:
                    suggestions.append(phrase)
                    seen.add(phrase)
            
            if len(suggestions) >= limit:
                break
                
        return suggestions


# ==============================================================================
# LIVE CORPUS AUTOCOMPLETE ENGINE
# ==============================================================================


class LiveCorpusAutocomplete:
    """
    Real-time autocomplete with gematric fuzzy matching.
    Sub-millisecond suggestions as you type.
    """

    def __init__(self):
        self.table = TripleLayerHashTable()
        self.relations = Relations()
        # Sentence-level index
        self.sentences = {}  # sentence_id -> sentence_text
        self.sentence_to_id = {}  # sentence_text -> sentence_id
        self.sentence_hash_to_id = {}  # sentence_hash -> sentence_id
        self.sentence_positions = defaultdict(list)  # sentence_id -> [corpus_pos]

        # Turn-level index
        self.turns = {}  # turn_id -> {'speaker', 'sentence_ids', 'turn_hash', 'start_pos'}
        self.turn_insert_count = 0
        self.turn_adjacency = defaultdict(list)  # turn_id -> [(other_turn_id, interference_score)]
        self.last_turn_id = None

    def ingest_text(self, text: str):
        """Add text to corpus (can be called incrementally)"""
        words = text.lower().split()
        words = ["".join(c for c in w if c.isalpha()) for w in words]
        words = [w for w in words if w]

        # Extract 2-grams and 3-grams
        for n in [2, 3]:
            for i in range(len(words) - n + 1):
                phrase = " ".join(words[i : i + n])
                self.table.insert(phrase)

        # Also break into sentences and index them
        # Simple sentence splitting on ., ?, !
        import re

        sents = [s.strip() for s in re.split(r'[\.\?!]\s*', text) if s.strip()]
        pos = 0
        for s in sents:
            sid = self.insert_sentence(s, corpus_pos=pos)
            
            # Hybrid: Ingest into Relations System using FAST PATH?
            # The current relation system uses regex which is slow.
            # We will disable calling it for every sentence in the benchmark loop
            # to avoid freezing the app.
            # In a real system, we'd want to use a faster parsing method.
            # token_positions = list(range(len(tokens)))
            # self.relations.extract_from_tokens(tokens, token_positions)

            pos += 1

    def autocomplete(
        self, partial: str, limit: int = 10, fuzzy: bool = True
    ) -> List[str]:
        """
        Provide autocomplete suggestions.

        Examples:
            "god cr" → ["god created", "god created the", ...]
            "in th" → ["in the", "in the beginning", ...]
        """
        partial = partial.lower().strip()
        words = partial.split()

        if not words:
            return []

        # Single word: gematric word completion
        if len(words) == 1:
            if fuzzy:
                matches = self.table.gematric_table.fuzzy_match(
                    words[0], max_variance=2
                )
            else:
                matches = self.table.gematric_table.query_by_prefix(words[0])
            
            final_res = sorted(list(matches))[:limit]
            if len(final_res) < limit:
                final_res.extend(self._get_relations_suggestions(partial, limit - len(final_res)))
            return final_res

        # Two words: first exact, second fuzzy
        if len(words) == 2:
            word_0 = words[0]
            word_1_partial = words[1]

            if not fuzzy:
                return self.table.query_with_second_prefix(word_0, word_1_partial, limit)

            # Get fuzzy matches for second word
            if fuzzy:
                word_1_matches = self.table.gematric_table.fuzzy_match(
                    word_1_partial, max_variance=2
                )
            else:
                word_1_matches = self.table.gematric_table.query_by_prefix(
                    word_1_partial
                )

            # Query combinations but stop early once we've collected `limit` results
            results = []
            remaining = limit
            for w1 in word_1_matches:
                # ask table for only remaining results to avoid unnecessary scans
                res = self.table.query(word_0, w1, None, limit=remaining)
                for r in res:
                    if r not in results:
                        results.append(r)
                        remaining -= 1
                        if remaining <= 0:
                            break
                if remaining <= 0:
                    break

            final_res = sorted(results)[:limit]
            if len(final_res) < limit:
                final_res.extend(self._get_relations_suggestions(partial, limit - len(final_res)))
            return final_res

        # Three+ words: first two exact, third fuzzy
        if len(words) >= 3:
            word_0 = words[0]
            word_1 = words[1]
            word_2_partial = words[2]

            if not fuzzy:
                return self.table.query_with_third_prefix(word_0, word_1, word_2_partial, limit)

            # Get fuzzy matches for third word
            if fuzzy:
                word_2_matches = self.table.gematric_table.fuzzy_match(
                    word_2_partial, max_variance=2
                )
            else:
                word_2_matches = self.table.gematric_table.query_by_prefix(
                    word_2_partial
                )

            # Query all combinations
            # Aggregate with early exit
            results = []
            remaining = limit
            for w2 in word_2_matches:
                res = self.table.query(word_0, word_1, w2, limit=remaining)
                for r in res:
                    if r not in results:
                        results.append(r)
                        remaining -= 1
                        if remaining <= 0:
                            break
                if remaining <= 0:
                    break

            final_res = sorted(results)[:limit]
            if len(final_res) < limit:
                final_res.extend(self._get_relations_suggestions(partial, limit - len(final_res)))
            return final_res

        return []

    # -------------------------
    # Sentence & Turn APIs
    # -------------------------

    def insert_sentence(self, sentence: str, corpus_pos: Optional[int] = None) -> int:
        """Index a full sentence and return its sentence_id."""
        sentence = sentence.strip()
        if not sentence:
            return -1

        if sentence in self.sentence_to_id:
            sid = self.sentence_to_id[sentence]
            if corpus_pos is not None:
                self.sentence_positions[sid].append(corpus_pos)
            return sid

        sid = len(self.sentences)
        self.sentences[sid] = sentence
        self.sentence_to_id[sentence] = sid

        s_hash = hash_sentence_64bit(sentence)
        self.sentence_hash_to_id[s_hash] = sid
        if corpus_pos is not None:
            self.sentence_positions[sid].append(corpus_pos)

        return sid

    def insert_turn(self, speaker: str, sentences: List[str]) -> int:
        """Insert a conversational turn consisting of multiple sentences.

        Returns a turn_id.
        """
        sentence_ids = []
        sentence_hashes = []
        start_pos = None
        for i, s in enumerate(sentences):
            sid = self.insert_sentence(s)
            sentence_ids.append(sid)
            sh = hash_sentence_64bit(s)
            sentence_hashes.append(sh)
            if start_pos is None:
                start_pos = 0

        turn_id = self.turn_insert_count
        self.turn_insert_count += 1

        t_hash = hash_turn_64bit(turn_id, tuple(sentence_hashes))
        self.turns[turn_id] = {
            'speaker': speaker,
            'sentence_ids': sentence_ids,
            'turn_hash': t_hash,
            'start_pos': start_pos,
        }

        # Interfere with last turn (sequential conversation)
        if self.last_turn_id is not None:
            score = self.compute_interference(self.last_turn_id, turn_id)
            self.turn_adjacency[self.last_turn_id].append((turn_id, score))
            self.turn_adjacency[turn_id].append((self.last_turn_id, score))

        self.last_turn_id = turn_id
        return turn_id

    def compute_interference(self, turn_a: int, turn_b: int) -> float:
        """Compute a simple interference score between two turns.

        We use Jaccard similarity over token sets of all sentences in the turn.
        Returns score in [0.0, 1.0].
        """
        if turn_a not in self.turns or turn_b not in self.turns:
            return 0.0

        def tokens_for(turn_id):
            toks = set()
            for sid in self.turns[turn_id]['sentence_ids']:
                s = self.sentences.get(sid, '')
                for w in s.lower().split():
                    w2 = ''.join(c for c in w if c.isalpha())
                    if w2:
                        toks.add(w2)
            return toks

        toks_a = tokens_for(turn_a)
        toks_b = tokens_for(turn_b)
        if not toks_a or not toks_b:
            return 0.0
        inter = toks_a & toks_b
        union = toks_a | toks_b
        return len(inter) / len(union)

    def ingest_dialogue(self, turns: List[Tuple[str, str]]):
        """Ingest a list of (speaker, text) turns and index them.

        Splits each text into sentences using punctuation and calls `insert_turn`.
        """
        import re

        for speaker, text in turns:
            sents = [s.strip() for s in re.split(r'[\.\?!]\s*', text) if s.strip()]
            self.insert_turn(speaker, sents)

    def query_context_for_sentence(self, sentence: str, prev_turns: int = 2) -> List[Tuple[int, float, str, List[str]]]:
        """Given a sentence string, return up to `prev_turns` previous turns and interference scores.

        Returns list of (turn_id, interference_score, speaker, [sentences]) ordered by recency.
        """
        # Find sentence id by exact match or by hash
        sid = self.sentence_to_id.get(sentence)
        if sid is None:
            s_hash = hash_sentence_64bit(sentence)
            sid = self.sentence_hash_to_id.get(s_hash)
        if sid is None:
            return []

        # Find the turn that contains this sentence (first match)
        found_turn = None
        for tid, data in self.turns.items():
            if sid in data['sentence_ids']:
                found_turn = tid
                break
        if found_turn is None:
            return []

        results = []
        # Walk backwards through adjacency to collect previous turns
        current = found_turn
        visited = {current}
        collected = 0
        # naive linear previous based on insertion order
        tid = current - 1
        while tid >= 0 and collected < prev_turns:
            if tid in self.turns:
                score = self.compute_interference(tid, current)
                results.append((tid, score, self.turns[tid]['speaker'], [self.sentences[sid] for sid in self.turns[tid]['sentence_ids']]))
                collected += 1
            tid -= 1

        return results

    def typing_simulation(self, text: str):
        """Simulate live typing with autocomplete suggestions"""
        print(f"\nTyping: '{text}'")
        print("=" * 80)

        for i in range(1, len(text) + 1):
            partial = text[:i]

            start = time.perf_counter()
            suggestions = self.autocomplete(partial, limit=5, fuzzy=True)
            query_time = time.perf_counter() - start

            print(f"\n'{partial}' ({query_time * 1000:.3f}ms)")
            for j, sug in enumerate(suggestions[:3], 1):
                print(f"  {j}. {sug}")


# ==============================================================================
# PHRASE EXTRACTION
# ==============================================================================


def extract_ngrams(text: str, n: int) -> List[str]:
    """Extract all n-word phrases from text"""
    words = text.lower().split()
    words = ["".join(c for c in w if c.isalpha()) for w in words]
    words = [w for w in words if w]

    phrases = []
    for i in range(len(words) - n + 1):
        phrase = " ".join(words[i : i + n])
        phrases.append(phrase)

    return phrases


# ==============================================================================
# DEMO & BENCHMARK
# ==============================================================================


def main():
    print("=" * 100)
    print("LIVE CORPUS AUTOCOMPLETE WITH GEMATRIC FUZZY MATCHING")
    print("=" * 100)

    # Load Bible
    with open("bible.txt", "r", encoding="utf-8") as f:
        text = f.read()

    print(f"[-] Loaded {len(text):,} characters\n")

    # Build autocomplete engine
    print("[-] Building autocomplete index...")
    engine = LiveCorpusAutocomplete()

    start = time.perf_counter()
    engine.ingest_text(text)
    build_time = time.perf_counter() - start

    print(f"[-] Ready in {build_time:.4f}s")
    print(f"    Indexed {len(engine.table.phrases):,} phrases")
    print(f"    Vocabulary: {len(engine.table.word_vocab):,} unique words\n")

    # Test queries
    print("=" * 100)
    print("AUTOCOMPLETE TESTS")
    print("=" * 100)

    test_partials = [
        "god",
        "god c",
        "god cr",
        "god cre",
        "in th",
        "in the b",
        "and god s",
    ]

    for partial in test_partials:
        print(f"\nPartial: '{partial}'")
        start = time.perf_counter()
        suggestions = engine.autocomplete(partial, limit=10, fuzzy=True)
        query_time = time.perf_counter() - start

        print(f"  {len(suggestions)} suggestions in {query_time * 1000:.3f}ms:")
        for i, sug in enumerate(suggestions[:5], 1):
            print(f"    {i}. {sug}")

    # Benchmark
    print("\n" + "=" * 100)
    print("SPEED BENCHMARK")
    print("=" * 100)

    test_cases = [
        ("god c", "Partial word autocomplete"),
        ("in the b", "Multi-word autocomplete"),
        ("beginn", "Fuzzy gematric match"),
    ]

    for query, description in test_cases:
        iterations = 10
        start = time.perf_counter()

        for _ in range(iterations):
            engine.autocomplete(query, limit=10, fuzzy=True)

        total_time = time.perf_counter() - start
        avg_time = (total_time / iterations) * 1000

        print(f"{description:30} ({query:15}): {avg_time:.4f}ms avg")

    # Interactive mode
    print("\n" + "=" * 100)
    print("INTERACTIVE AUTOCOMPLETE (Type 'quit' to exit)")
    print("=" * 100)

    while True:
        try:
            user_input = input("\nType: ").strip()
            if user_input.lower() in ["quit", "exit", "q"]:
                break

            if not user_input:
                continue

            start = time.perf_counter()
            suggestions = engine.autocomplete(user_input, limit=10, fuzzy=True)
            query_time = time.perf_counter() - start

            print(f"\nSuggestions ({query_time * 1000:.3f}ms):")
            for i, sug in enumerate(suggestions, 1):
                print(f"  {i}. {sug}")

        except KeyboardInterrupt:
            print("\n\nExiting...")
            break

    # -------------------------
    # TURN / SENTENCE DEMO
    # -------------------------
    print("\n" + "=" * 100)
    print("TURN & CONTEXT DEMO")
    print("=" * 100)

    # Simple simulated dialogue from early sentences of the text
    # Split the text into simple sentences
    import re
    sents = [s.strip() for s in re.split(r'[\.\?!]\s*', text) if s.strip()]

    turns = []
    # Group sentences into turns of 3 sentences, alternate speakers A/B
    for i in range(0, min(len(sents), 30), 3):
        speaker = 'A' if ((i // 3) % 2 == 0) else 'B'
        batch = sents[i : i + 3]
        turns.append((speaker, ' '.join(batch)))

    engine.ingest_dialogue(turns)

    # Pick a sentence to query context for
    target = sents[5]
    print(f"Target sentence: '{target[:80]}'")
    contexts = engine.query_context_for_sentence(target, prev_turns=3)
    if contexts:
        print("Previous turns:")
        for tid, score, speaker, ss in contexts:
            print(f"  Turn {tid} (speaker={speaker}) score={score:.3f}")
            for s in ss:
                print(f"    - {s[:80]}")
    else:
        print("  (no previous context found)")


if __name__ == "__main__":
    main()
