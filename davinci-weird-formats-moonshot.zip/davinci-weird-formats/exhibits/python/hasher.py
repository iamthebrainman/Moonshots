import re
from typing import List, Tuple
import pickle


# phrase_hasher.py
def hash_phrase(phrase: str) -> int:
    """Division Chain hash - fast, low collision"""
    h = 2
    for char in phrase:
        h = (h + ord(char)) * 33
    return h % 0xFFFFFF  # 24-bit address

def collision_step(phrase: str) -> int:
    """XOR Shift for collision resolution"""
    h = len(phrase)
    return (h ^ (h << 3)) & 0xFF

# vocab_builder.py
class Vocab:
    def __init__(self):
        self.table = {}  # addr -> phrase
        self.reverse = {}  # phrase -> addr
    
    def add(self, phrase: str) -> int:
        addr = hash_phrase(phrase)
        step = collision_step(phrase)
        
        # Collision resolution
        while addr in self.table and self.table[addr] != phrase:
            addr = (addr + step) % 0xFFFFFF
            
        self.table[addr] = phrase
        self.reverse[phrase] = addr
        return addr
    
    def get(self, addr: int) -> str:
        return self.table.get(addr)
    
    def save(self, path: str):
        with open(path, 'wb') as f:
            pickle.dump(self.table, f)
    
    def load(self, path: str):
        with open(path, 'rb') as f:
            self.table = pickle.load(f)
            self.reverse = {v: k for k, v in self.table.items()}

# compressor.py
def compress_text(text: str, vocab: Vocab) -> bytes:
    """Text → 3-byte addresses"""
    phrases = parse_triples(text)  # Simple split for now
    addresses = []
    
    for phrase in phrases:
        if phrase not in vocab.reverse:
            vocab.add(phrase)
        addresses.append(vocab.reverse[phrase])
    
    # Pack as 3 bytes each
    return b''.join(addr.to_bytes(3, 'big') for addr in addresses)

def decompress(data: bytes, vocab: Vocab) -> str:
    """3-byte addresses → text"""
    addresses = [int.from_bytes(data[i:i+3], 'big') 
                 for i in range(0, len(data), 3)]
    phrases = [vocab.get(addr) for addr in addresses]
    return ' '.join(phrases)
# phrase_parser.py
def parse_triples(text: str) -> List[Tuple[str, str, str]]:
    """Extract (subject, relation, object) from text"""
    # Simple pattern matching to start
    patterns = [
        r'(\w+)\s+is\s+(?:a|an)\s+(\w+)',  # "cat is an animal"
        r'(\w+)\s+has\s+(\w+)',             # "cat has fur"
        r'(\w+)\s+causes\s+(\w+)',          # "fire causes heat"
    ]
    
    triples = []
    for pattern in patterns:
        matches = re.finditer(pattern, text.lower())
        for m in matches:
            subj, obj = m.groups()
            rel = "IS_A" if "is" in m.group() else \
                  "HAS" if "has" in m.group() else "CAUSES"
            triples.append((subj, rel, obj))
    
    return triples

# Build vocab from corpus
with open('bible.txt') as f:
    text = f.read()
    
# Compress
compressed = compress_text(text, Vocab)
original_size = len(text.encode())
compressed_size = len(compressed)

print(f"Original: {original_size:,} bytes")
print(f"Compressed: {compressed_size:,} bytes")
print(f"Ratio: {original_size / compressed_size:.1f}:1")

# Verify
decompressed = decompress(compressed, vocab)
assert decompressed == text  # Must match!