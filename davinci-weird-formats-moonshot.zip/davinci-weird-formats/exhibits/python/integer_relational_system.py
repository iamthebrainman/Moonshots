"""
Integer-Based Relational System - Pure Mathematical Knowledge Graph

This system operates entirely on integers:
1. Each relation phrase (is a, has a, was a, etc.) → integer rel_id
2. Each word/concept → integer node_id  
3. All knowledge → triples of integers: (subject_id, relation_id, object_id)
4. Word positions in corpus → positional chains per word

Only translate to/from language at system boundaries.
"""

import re
import json
from collections import defaultdict
from typing import List, Tuple, Set, Dict, Optional


class IntegerRelationalSystem:
    """
    Pure integer-based knowledge graph.
    
    Core Components:
    - Relation ID mapping (rel_phrase -> rel_id)
    - Node ID mapping (word -> node_id)
    - Triple storage as (subj_id, rel_id, obj_id)
    - Positional chains (node_id -> [pos1, pos2, ...])
    """
    
    # Fixed relation script - these are the fundamental operators
    RELATION_SCRIPT = [
        # IDENTITY
        'AM_A', 'IS_A', 'ARE_A', 'AM', 'IS', 'ARE',
        
        # TEMPORAL (past/future)
        'WAS_A', 'WERE_A', 'WAS', 'WERE', 'HAD', 'HAD_BEEN',
        'WILL_BE', 'WOULD_BE', 'WILL', 'WOULD', 
        'USED_TO_BE', 'USED_TO',
        
        # POSSESSION
        'HAVE_A', 'HAS_A', 'HAVE', 'HAS', 'OWNS',
        
        # CAPABILITY
        'CAN', 'COULD', 'AM_ABLE_TO', 'IS_ABLE_TO', 'ARE_ABLE_TO',
        
        # OBLIGATION/POSSIBILITY
        'MUST', 'SHALL', 'SHOULD', 'MAY', 'MIGHT',
        
        # DESIRE/PREFERENCE
        'WANT_TO', 'WANT', 'NEED_TO', 'NEED',
        'LIKE_TO', 'LIKE', 'LOVE_TO', 'LOVE', 'HATE', 'PREFER',
        
        # NEGATION
        'AM_NOT_A', 'IS_NOT_A', 'ARE_NOT_A', 'AM_NOT', 'IS_NOT', 'ARE_NOT',
        'WANT_NOT', 'LIKE_NOT', 'HAS_NOT', 'CAN_NOT', 'COULD_NOT',
        'WILL_NOT', 'WOULD_NOT',
        
        # ACTIONS
        'MAKE', 'GIVE', 'TAKE', 'GET', 'HELP', 'DO', 'DOES',
        'MADE', 'STRUCK',
        
        # RELATIONSHIPS
        'KNOWS', 'AM_WITH', 'IS_WITH', 'ARE_WITH',
        
        # SPATIAL
        'AM_IN', 'IS_IN', 'ARE_IN', 
        'AM_AT', 'IS_AT', 'ARE_AT',
        'AM_FROM', 'IS_FROM', 'ARE_FROM',
        'AT_LOCATION', 'FROM_LOCATION',
        'CONTAINS',
        
        # COMPLEX IDENTITY
        'IS_KIND_OF', 'MADE_OF', 'USED_FOR', 'CAN_BE_USED_FOR',
        'IS_CALLED', 'PART_OF', 'CREATED_BY', 'BUILT_AS',
        
        # FUTURE INTENT
        'AM_GOING_TO', 'IS_GOING_TO', 'ARE_GOING_TO',
    ]
    
    def __init__(self):
        # Relation mapping: phrase -> id
        self.rel_to_id: Dict[str, int] = {}
        self.id_to_rel: Dict[int, str] = {}
        self._initialize_relations()
        
        # Node mapping: word -> id
        self.node_to_id: Dict[str, int] = {}
        self.id_to_node: Dict[int, str] = {}
        self.next_node_id = 0
        
        # Triple storage: list of (subj_id, rel_id, obj_id)
        self.triples: List[Tuple[int, int, int]] = []
        
        # Positional chains: node_id -> {corpus_id: [positions]}
        # Example: node_id=42 ("the") -> {1: [1, 2, 35, 69, 222], 2: [18, 369, 420]}
        self.positions: Dict[int, Dict[int, List[int]]] = defaultdict(lambda: defaultdict(list))
        
        # Reverse index: (subj_id, rel_id) -> [obj_ids]
        self.index_sr: Dict[Tuple[int, int], List[int]] = defaultdict(list)
        
        # Reverse index: (obj_id, rel_id) -> [subj_ids]
        self.index_or: Dict[Tuple[int, int], List[int]] = defaultdict(list)
    
    def _initialize_relations(self):
        """Assign stable integer IDs to all relation phrases."""
        for idx, rel_phrase in enumerate(self.RELATION_SCRIPT):
            self.rel_to_id[rel_phrase] = idx
            self.id_to_rel[idx] = rel_phrase
    
    def get_or_create_node_id(self, word: str) -> int:
        """Get node_id for word, creating if necessary."""
        word = word.lower().strip()
        if word in self.node_to_id:
            return self.node_to_id[word]
        
        node_id = self.next_node_id
        self.next_node_id += 1
        self.node_to_id[word] = node_id
        self.id_to_node[node_id] = word
        return node_id
    
    def get_node_id(self, word: str) -> Optional[int]:
        """Get node_id for word (returns None if not exists)."""
        return self.node_to_id.get(word.lower().strip())
    
    def get_relation_id(self, rel_phrase: str) -> Optional[int]:
        """Get relation_id for phrase (returns None if not exists)."""
        return self.rel_to_id.get(rel_phrase.upper())
    
    def add_triple(self, subject: str, relation: str, obj: str) -> bool:
        """
        Add a triple to the knowledge graph.
        
        Args:
            subject: Subject word/phrase
            relation: Relation phrase (must be in RELATION_SCRIPT)
            obj: Object word/phrase
            
        Returns:
            True if added, False if relation invalid
        """
        rel_id = self.get_relation_id(relation)
        if rel_id is None:
            return False
        
        subj_id = self.get_or_create_node_id(subject)
        obj_id = self.get_or_create_node_id(obj)
        
        triple = (subj_id, rel_id, obj_id)
        self.triples.append(triple)
        
        # Update indices
        self.index_sr[(subj_id, rel_id)].append(obj_id)
        self.index_or[(obj_id, rel_id)].append(subj_id)
        
        return True
    
    def add_triple_by_id(self, subj_id: int, rel_id: int, obj_id: int):
        """Add triple directly using IDs (for internal use)."""
        triple = (subj_id, rel_id, obj_id)
        self.triples.append(triple)
        self.index_sr[(subj_id, rel_id)].append(obj_id)
        self.index_or[(obj_id, rel_id)].append(subj_id)
    
    def add_position(self, word: str, corpus_id: int, position: int):
        """
        Track word position in a corpus.
        
        Args:
            word: The word
            corpus_id: Which corpus (e.g., 1=Genesis, 2=Matthew, etc.)
            position: Position index in that corpus
        """
        node_id = self.get_or_create_node_id(word)
        self.positions[node_id][corpus_id].append(position)
    
    def get_positions(self, word: str, corpus_id: Optional[int] = None) -> Dict[int, List[int]]:
        """
        Get positional chains for a word.
        
        Args:
            word: The word to lookup
            corpus_id: Optional - specific corpus to query
            
        Returns:
            {corpus_id: [positions]} or single corpus positions
        """
        node_id = self.get_node_id(word)
        if node_id is None:
            return {}
        
        if corpus_id is not None:
            return {corpus_id: self.positions[node_id].get(corpus_id, [])}
        
        return dict(self.positions[node_id])
    
    def query_objects(self, subject: str, relation: str) -> List[str]:
        """
        Query: What objects does this subject have with this relation?
        Example: query_objects("dog", "IS_A") -> ["animal", "pet"]
        
        Returns:
            List of object words
        """
        subj_id = self.get_node_id(subject)
        rel_id = self.get_relation_id(relation)
        
        if subj_id is None or rel_id is None:
            return []
        
        obj_ids = self.index_sr.get((subj_id, rel_id), [])
        return [self.id_to_node[oid] for oid in obj_ids]
    
    def query_subjects(self, obj: str, relation: str) -> List[str]:
        """
        Query: What subjects have this relation to this object?
        Example: query_subjects("animal", "IS_A") -> ["dog", "cat", "bird"]
        
        Returns:
            List of subject words
        """
        obj_id = self.get_node_id(obj)
        rel_id = self.get_relation_id(relation)
        
        if obj_id is None or rel_id is None:
            return []
        
        subj_ids = self.index_or.get((obj_id, rel_id), [])
        return [self.id_to_node[sid] for sid in subj_ids]
    
    def query_all_relations(self, subject: str) -> List[Tuple[str, str]]:
        """
        Get all (relation, object) pairs for a subject.
        Example: query_all_relations("dog") -> [("IS_A", "animal"), ("HAS", "tail")]
        
        Returns:
            List of (relation_phrase, object_word) tuples
        """
        subj_id = self.get_node_id(subject)
        if subj_id is None:
            return []
        
        results = []
        for (sid, rid), obj_ids in self.index_sr.items():
            if sid == subj_id:
                rel_phrase = self.id_to_rel[rid]
                for oid in obj_ids:
                    results.append((rel_phrase, self.id_to_node[oid]))
        
        return results
    
    def get_triple_count(self) -> int:
        """Return total number of triples."""
        return len(self.triples)
    
    def get_node_count(self) -> int:
        """Return total number of unique nodes."""
        return self.next_node_id
    
    def get_relation_count(self) -> int:
        """Return total number of relations in script."""
        return len(self.RELATION_SCRIPT)
    
    def dump_triples_as_integers(self, limit: int = 10) -> List[Tuple[int, int, int]]:
        """
        Dump raw integer triples (for debugging/inspection).
        
        Args:
            limit: Max triples to return
            
        Returns:
            List of (subj_id, rel_id, obj_id) tuples
        """
        return self.triples[:limit]
    
    def dump_triples_as_text(self, limit: int = 10) -> List[Tuple[str, str, str]]:
        """
        Dump triples as text (for human reading).
        
        Args:
            limit: Max triples to return
            
        Returns:
            List of (subject, relation, object) tuples
        """
        results = []
        for subj_id, rel_id, obj_id in self.triples[:limit]:
            subject = self.id_to_node.get(subj_id, f"NODE_{subj_id}")
            relation = self.id_to_rel.get(rel_id, f"REL_{rel_id}")
            obj = self.id_to_node.get(obj_id, f"NODE_{obj_id}")
            results.append((subject, relation, obj))
        return results
    
    def save(self, filepath: str):
        """Save system to JSON."""
        data = {
            'rel_to_id': self.rel_to_id,
            'id_to_rel': {str(k): v for k, v in self.id_to_rel.items()},
            'node_to_id': self.node_to_id,
            'id_to_node': {str(k): v for k, v in self.id_to_node.items()},
            'next_node_id': self.next_node_id,
            'triples': self.triples,
            'positions': {
                str(node_id): {
                    str(corpus_id): positions 
                    for corpus_id, positions in corpora.items()
                }
                for node_id, corpora in self.positions.items()
            }
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load(self, filepath: str):
        """Load system from JSON."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        self.rel_to_id = data['rel_to_id']
        self.id_to_rel = {int(k): v for k, v in data['id_to_rel'].items()}
        self.node_to_id = data['node_to_id']
        self.id_to_node = {int(k): v for k, v in data['id_to_node'].items()}
        self.next_node_id = data['next_node_id']
        self.triples = [tuple(t) for t in data['triples']]
        
        # Rebuild positions
        self.positions = defaultdict(lambda: defaultdict(list))
        for node_id_str, corpora in data['positions'].items():
            node_id = int(node_id_str)
            for corpus_id_str, positions in corpora.items():
                corpus_id = int(corpus_id_str)
                self.positions[node_id][corpus_id] = positions
        
        # Rebuild indices
        self._rebuild_indices()
    
    def _rebuild_indices(self):
        """Rebuild reverse indices from triples."""
        self.index_sr = defaultdict(list)
        self.index_or = defaultdict(list)
        
        for subj_id, rel_id, obj_id in self.triples:
            self.index_sr[(subj_id, rel_id)].append(obj_id)
            self.index_or[(obj_id, rel_id)].append(subj_id)
    
    def print_stats(self):
        """Print system statistics."""
        print(f"=== Integer Relational System Stats ===")
        print(f"Relations: {self.get_relation_count()}")
        print(f"Nodes: {self.get_node_count()}")
        print(f"Triples: {self.get_triple_count()}")
        print(f"Tracked words with positions: {len(self.positions)}")
    
    def print_relation_map(self):
        """Print relation ID mapping."""
        print(f"\n=== Relation ID Map ===")
        for idx, rel_phrase in enumerate(self.RELATION_SCRIPT):
            print(f"{idx:3d} -> {rel_phrase}")


class IntegerSynsets:
    """
    Synset support for integer relational system.
    Maps synonym groups to shared node_ids.
    """
    
    def __init__(self, system: IntegerRelationalSystem):
        self.system = system
        
        # Synset mapping: synset_id -> {node_ids}
        self.synset_to_nodes: Dict[int, Set[int]] = defaultdict(set)
        
        # Node to synset: node_id -> synset_id
        self.node_to_synset: Dict[int, int] = {}
        
        self.next_synset_id = 0
    
    def add_synset_group(self, words: List[str]) -> int:
        """
        Add a synonym group, creating shared synset_id.
        
        Args:
            words: List of synonym words
            
        Returns:
            synset_id for this group
        """
        words = [w.lower().strip() for w in words if w.strip()]
        if len(words) < 2:
            return -1
        
        # Create synset
        synset_id = self.next_synset_id
        self.next_synset_id += 1
        
        # Add all words to this synset
        for word in words:
            node_id = self.system.get_or_create_node_id(word)
            
            # Don't overwrite existing synset membership
            if node_id not in self.node_to_synset:
                self.node_to_synset[node_id] = synset_id
                self.synset_to_nodes[synset_id].add(node_id)
        
        return synset_id
    
    def get_synonyms(self, word: str) -> Set[str]:
        """Get all synonym words for a given word."""
        node_id = self.system.get_node_id(word)
        if node_id is None or node_id not in self.node_to_synset:
            return {word.lower()}
        
        synset_id = self.node_to_synset[node_id]
        synonym_node_ids = self.synset_to_nodes[synset_id]
        
        return {self.system.id_to_node[nid] for nid in synonym_node_ids}
    
    def get_synonym_ids(self, node_id: int) -> Set[int]:
        """Get all synonym node_ids for a given node_id."""
        if node_id not in self.node_to_synset:
            return {node_id}
        
        synset_id = self.node_to_synset[node_id]
        return self.synset_to_nodes[synset_id]
    
    def expand_query(self, word: str, relation: str) -> List[str]:
        """
        Query with synonym expansion.
        Example: "dog" expands to ["dog", "canine", "puppy"]
        """
        synonyms = self.get_synonyms(word)
        results = []
        
        for syn_word in synonyms:
            results.extend(self.system.query_objects(syn_word, relation))
        
        return list(set(results))  # Dedupe
    
    def import_from_synsets(self, synsets_obj):
        """
        Import synsets from relational_system.Synsets object.
        
        Args:
            synsets_obj: Instance of relational_system.Synsets
        """
        # Import each synset group
        for synset_id, words in synsets_obj.synset_to_words.items():
            self.add_synset_group(list(words))
        
        print(f"Imported {len(synsets_obj.synset_to_words)} synset groups")


class RelationsBridge:
    """
    Bridge between relational_system.Relations and IntegerRelationalSystem.
    Imports triples and synsets into pure integer format.
    """
    
    def __init__(self, int_system: IntegerRelationalSystem):
        self.int_system = int_system
        self.synsets = IntegerSynsets(int_system)
    
    def import_relations(self, relations_obj):
        """
        Import triples from relational_system.Relations.
        
        Args:
            relations_obj: Instance of relational_system.Relations
            
        Returns:
            Number of triples imported
        """
        count = 0
        
        for subj, rel_type, obj, pos, mods in relations_obj.triples:
            # Skip if object is None or empty
            if not obj:
                continue
            
            # Map relation type (normalize)
            rel_normalized = rel_type.upper()
            
            # Add triple
            if self.int_system.add_triple(subj, rel_normalized, obj):
                count += 1
        
        print(f"Imported {count} triples from Relations")
        return count
    
    def import_synsets(self, relations_obj):
        """
        Import synsets from Relations.synsets.
        
        Args:
            relations_obj: Instance of relational_system.Relations
        """
        self.synsets.import_from_synsets(relations_obj.synsets)
    
    def full_import(self, relations_obj):
        """
        Full import: triples + synsets.
        
        Args:
            relations_obj: Instance of relational_system.Relations
            
        Returns:
            (triple_count, synset_count)
        """
        triple_count = self.import_relations(relations_obj)
        self.import_synsets(relations_obj)
        
        return triple_count, len(relations_obj.synsets.synset_to_words)


class CorpusIndexer:
    """
    Index corpus text and track word positions.
    
    Removes "the" and creates positional chains for each word.
    Example: "the:[1]1,2,35,69,222[2]18,369,420"
    """
    
    SKIP_WORDS = {'the'}  # Words to skip in positional tracking
    
    def __init__(self, system: IntegerRelationalSystem):
        self.system = system
    
    def index_corpus(self, text: str, corpus_id: int, max_words: Optional[int] = None):
        """
        Index a corpus and track word positions.
        
        Args:
            text: Corpus text
            corpus_id: Unique corpus identifier
            max_words: Optional limit on words to process
        """
        # Tokenize (simple word splitting)
        words = re.findall(r'\b\w+\b', text.lower())
        
        if max_words:
            words = words[:max_words]
        
        position = 0
        for word in words:
            if word not in self.SKIP_WORDS:
                self.system.add_position(word, corpus_id, position)
                position += 1
    
    def print_position_chain(self, word: str, max_positions: int = 20):
        """
        Print positional chain for a word.
        
        Example output:
        word "god": [1]1,15,42,88 [2]3,19,55
        """
        positions = self.system.get_positions(word)
        if not positions:
            print(f'Word "{word}" not found in corpus.')
            return
        
        parts = []
        for corpus_id, pos_list in sorted(positions.items()):
            pos_str = ','.join(str(p) for p in pos_list[:max_positions])
            if len(pos_list) > max_positions:
                pos_str += '...'
            parts.append(f'[{corpus_id}]{pos_str}')
        
        print(f'{word}: {" ".join(parts)}')


# ============================================================
# EXAMPLE USAGE
# ============================================================

def demo():
    """Demonstrate integer relational system."""
    
    print("=== Creating Integer Relational System ===\n")
    
    # Create system
    system = IntegerRelationalSystem()
    
    # Show relation map
    system.print_relation_map()
    
    # Add some triples (using text, converted to integers internally)
    print("\n=== Adding Triples ===")
    system.add_triple("dog", "IS_A", "animal")
    system.add_triple("dog", "HAS", "tail")
    system.add_triple("dog", "HAS", "fur")
    system.add_triple("cat", "IS_A", "animal")
    system.add_triple("cat", "HAS", "whiskers")
    system.add_triple("cat", "LIKES", "fish")
    system.add_triple("john", "OWNS", "dog")
    system.add_triple("john", "IS_FROM", "boston")
    
    # Show stats
    print()
    system.print_stats()
    
    # Dump as integers (pure math)
    print("\n=== Triples as Integers ===")
    for triple in system.dump_triples_as_integers():
        print(triple)
    
    # Dump as text (for humans)
    print("\n=== Triples as Text ===")
    for triple in system.dump_triples_as_text():
        print(f"{triple[0]:10s} --{triple[1]:15s}--> {triple[2]}")
    
    # Query examples
    print("\n=== Queries ===")
    print(f"What is a dog? {system.query_objects('dog', 'IS_A')}")
    print(f"What does dog have? {system.query_objects('dog', 'HAS')}")
    print(f"What animals exist? {system.query_subjects('animal', 'IS_A')}")
    print(f"All relations for 'dog': {system.query_all_relations('dog')}")
    
    # Test synsets
    print("\n=== Adding Synsets ===")
    bridge = RelationsBridge(system)
    synsets = bridge.synsets
    
    # Add manual synset groups
    synsets.add_synset_group(["dog", "canine", "puppy", "hound"])
    synsets.add_synset_group(["cat", "feline", "kitten"])
    
    print("Synonyms of 'dog':", synsets.get_synonyms("dog"))
    print("Synonyms of 'puppy':", synsets.get_synonyms("puppy"))
    print("Synonyms of 'cat':", synsets.get_synonyms("cat"))
    
    # Add triples using synonyms
    system.add_triple("puppy", "IS_A", "young_animal")
    system.add_triple("canine", "HAS", "paws")
    
    # Query with synonym expansion
    print("\n=== Queries with Synonym Expansion ===")
    print(f"What is 'dog' (expanded)? {synsets.expand_query('dog', 'IS_A')}")
    print(f"What does 'dog' have (expanded)? {synsets.expand_query('dog', 'HAS')}")
    
    # Index corpus
    print("\n=== Indexing Corpus ===")
    sample_text = """
    In the beginning God created the heaven and the earth.
    And the earth was without form, and void; and darkness was upon the face of the deep.
    And the Spirit of God moved upon the face of the waters.
    """
    
    indexer = CorpusIndexer(system)
    indexer.index_corpus(sample_text, corpus_id=1, max_words=1000)
    
    # Show position chains
    print("\n=== Position Chains ===")
    indexer.print_position_chain("god")
    indexer.print_position_chain("earth")
    indexer.print_position_chain("face")
    
    # Save/load test
    print("\n=== Saving System ===")
    system.save("integer_system.json")
    print("Saved to integer_system.json")


def demo_bridge():
    """Demonstrate bridge from relational_system.Relations."""
    
    print("=== BRIDGE DEMO: Import from Relations ===\n")
    
    # Import Relations
    try:
        from relational_system import Relations
    except ImportError:
        print("Error: relational_system.py not found")
        return
    
    # Create Relations and extract some triples
    print("Creating Relations and extracting triples...")
    relations = Relations()
    
    # Sample text - tokenize manually
    text = """
    I am a human. I have two hands. I have two feet.
    Dogs are animals. Dogs have tails. Dogs have fur.
    Cats are animals. Cats have whiskers. Cats like fish.
    A puppy is a young dog. A kitten is a young cat.
    John owns a dog. Mary owns a cat.
    """
    
    # Simple tokenization
    import re
    tokens = re.findall(r'\b\w+\b', text.lower())
    positions = list(range(len(tokens)))
    
    relations.extract_from_tokens(tokens, positions)
    print(f"Extracted {len(relations.triples)} triples from Relations")
    
    # Add some synsets to Relations
    print("\nAdding synsets to Relations...")
    relations.synsets.add_group(["dog", "canine", "puppy", "hound"])
    relations.synsets.add_group(["cat", "feline", "kitten"])
    relations.synsets.add_group(["human", "person", "individual"])
    
    # Create integer system and bridge
    print("\nCreating IntegerRelationalSystem...")
    int_system = IntegerRelationalSystem()
    bridge = RelationsBridge(int_system)
    
    # Import everything
    print("\nImporting via bridge...")
    triple_count, synset_count = bridge.full_import(relations)
    
    # Show stats
    print()
    int_system.print_stats()
    
    # Show some triples as integers
    print("\n=== Sample Triples (as integers) ===")
    for triple in int_system.dump_triples_as_integers(limit=10):
        print(triple)
    
    # Show same triples as text
    print("\n=== Sample Triples (as text) ===")
    for triple in int_system.dump_triples_as_text(limit=10):
        print(f"{triple[0]:15s} --{triple[1]:15s}--> {triple[2]}")
    
    # Test synonym queries
    print("\n=== Synonym Queries ===")
    print(f"Synonyms of 'dog': {bridge.synsets.get_synonyms('dog')}")
    print(f"Synonyms of 'cat': {bridge.synsets.get_synonyms('cat')}")
    print(f"What is 'dog'? {int_system.query_objects('dog', 'IS_A')}")
    print(f"What is 'dog' (expanded)? {bridge.synsets.expand_query('dog', 'ARE_A')}")
    
    # Save the integer system
    print("\n=== Saving Integer System ===")
    int_system.save("integer_system_from_relations.json")
    print("Saved to integer_system_from_relations.json")
    
    print(f"\nBridge complete: {triple_count} triples, {synset_count} synsets imported")


if __name__ == "__main__":
    # Run basic demo
    demo()
    
    print("\n" + "="*70 + "\n")
    
    # Run bridge demo
    demo_bridge()
