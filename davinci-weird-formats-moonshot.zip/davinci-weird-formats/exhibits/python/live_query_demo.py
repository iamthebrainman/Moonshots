"""
Live Query Demo - Real-time autocomplete and query prediction.

Features:
- Ingest multiple corpus types (text files, Bible books, etc.)
- Type query and get instant predictions on every keystroke
- Uses integer relational system for fast lookups
- Shows positional chains and synonym-expanded results
"""

import os
import re
import json
from pathlib import Path
from integer_relational_system import (
    IntegerRelationalSystem, 
    RelationsBridge, 
    CorpusIndexer,
    IntegerSynsets
)
from relational_system import Relations


class LiveQueryEngine:
    """Real-time query engine with keystroke-level prediction."""
    
    def __init__(self):
        self.int_system = IntegerRelationalSystem()
        self.bridge = RelationsBridge(self.int_system)
        self.indexer = CorpusIndexer(self.int_system)
        
        # Corpus registry
        self.corpora = {}  # corpus_id -> {name, word_count, file}
        self.next_corpus_id = 1
        
        # Query cache for speed
        self.query_cache = {}
    
    def ingest_text_file(self, filepath: str, corpus_name: str = None, max_words: int = None):
        """
        Ingest a text file as a corpus.
        
        Args:
            filepath: Path to text file
            corpus_name: Optional name (defaults to filename)
            max_words: Optional word limit
            
        Returns:
            corpus_id
        """
        if not os.path.exists(filepath):
            print(f"Error: File not found: {filepath}")
            return None
        
        if corpus_name is None:
            corpus_name = Path(filepath).stem
        
        # Read file
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()
        
        # Index corpus
        corpus_id = self.next_corpus_id
        self.next_corpus_id += 1
        
        print(f"Ingesting '{corpus_name}' as corpus #{corpus_id}...")
        self.indexer.index_corpus(text, corpus_id, max_words)
        
        # Count words
        words = re.findall(r'\b\w+\b', text.lower())
        if max_words:
            words = words[:max_words]
        
        self.corpora[corpus_id] = {
            'name': corpus_name,
            'word_count': len(words),
            'file': filepath
        }
        
        print(f"  -> Indexed {len(words)} words")
        return corpus_id
    
    def ingest_bible_book(self, book_name: str, bible_dir: str = "bible"):
        """
        Ingest a Bible book from the bible/ directory.
        
        Args:
            book_name: Name of the book file (e.g., 'genesis.txt', 'matthew.txt')
            bible_dir: Directory containing Bible books
            
        Returns:
            corpus_id
        """
        filepath = os.path.join(bible_dir, book_name)
        return self.ingest_text_file(filepath, corpus_name=f"Bible:{book_name}")
    
    def extract_relations_from_text(self, text: str):
        """Extract relations from text and add to system."""
        # Use Relations to extract triples
        relations = Relations()
        tokens = re.findall(r'\b\w+\b', text.lower())
        positions = list(range(len(tokens)))
        
        relations.extract_from_tokens(tokens, positions)
        
        # Import to integer system
        count, _ = self.bridge.full_import(relations)
        return count
    
    def predict_query(self, partial_query: str):
        """
        Predict results based on partial query (every keystroke).
        
        Args:
            partial_query: What user has typed so far
            
        Returns:
            Dictionary with predictions
        """
        partial_query = partial_query.lower().strip()
        
        if not partial_query:
            return {
                'suggestions': [],
                'positions': {},
                'triples': [],
                'status': 'Empty query'
            }
        
        # Check cache
        if partial_query in self.query_cache:
            return self.query_cache[partial_query]
        
        results = {
            'suggestions': [],
            'positions': {},
            'triples': [],
            'status': 'OK'
        }
        
        # Parse query type
        words = partial_query.split()
        
        # If single word, show position chains
        if len(words) == 1:
            word = words[0]
            positions = self.int_system.get_positions(word)
            
            if positions:
                results['positions'] = positions
                results['suggestions'].append(f"Word '{word}' found in {len(positions)} corpus/corpora")
                
                # Show total occurrences
                total = sum(len(pos_list) for pos_list in positions.values())
                results['suggestions'].append(f"Total occurrences: {total}")
        
        # If query pattern detected: "what is X" or "X is"
        elif len(words) >= 2:
            # Try to detect relation queries
            if words[0] == 'what':
                if len(words) >= 3 and words[1] in ['is', 'are', 'has', 'does']:
                    # "what is dog" -> query_objects("dog", "IS_A")
                    subject = ' '.join(words[2:])
                    rel_map = {'is': 'IS_A', 'are': 'ARE_A', 'has': 'HAS', 'does': 'DOES'}
                    relation = rel_map.get(words[1], 'IS_A')
                    
                    objects = self.int_system.query_objects(subject, relation)
                    if objects:
                        results['suggestions'] = [f"{subject} -> {obj}" for obj in objects[:5]]
                        results['triples'] = [(subject, relation, obj) for obj in objects[:5]]
            
            # Pattern: "dog is" -> show what dog is
            elif len(words) == 2 and words[1] in ['is', 'are', 'has', 'was', 'were']:
                subject = words[0]
                rel_map = {
                    'is': 'IS_A', 'are': 'ARE_A', 'has': 'HAS', 
                    'was': 'WAS', 'were': 'WERE'
                }
                relation = rel_map.get(words[1], 'IS_A')
                
                objects = self.int_system.query_objects(subject, relation)
                if objects:
                    results['suggestions'] = [f"{subject} {words[1]} {obj}" for obj in objects[:5]]
                    results['triples'] = [(subject, relation, obj) for obj in objects[:5]]
        
        # Cache result
        self.query_cache[partial_query] = results
        return results
    
    def print_status(self):
        """Print system status."""
        print("\n=== System Status ===")
        print(f"Corpora: {len(self.corpora)}")
        for cid, info in self.corpora.items():
            print(f"  [{cid}] {info['name']}: {info['word_count']} words")
        print(f"\nTriples: {self.int_system.get_triple_count()}")
        print(f"Unique nodes: {self.int_system.get_node_count()}")
        print(f"Synsets: {len(self.bridge.synsets.synset_to_nodes)}")


def demo_live_query():
    """Interactive demo with live query prediction."""
    
    print("="*70)
    print("LIVE QUERY DEMO - Real-time Corpus Query System")
    print("="*70)
    
    engine = LiveQueryEngine()
    
    # Ingest some corpora
    print("\n=== Ingesting Corpora ===")
    
    # Check for Bible books
    if os.path.exists("bible/genesis.txt"):
        engine.ingest_bible_book("genesis.txt")
    
    if os.path.exists("bibleGENESIS.txt"):
        engine.ingest_text_file("bibleGENESIS.txt", "Genesis", max_words=5000)
    
    # Check for any .txt files in current dir
    for txtfile in Path(".").glob("*.txt"):
        if txtfile.stem not in ['bibleGENESIS', 'bible']:
            engine.ingest_text_file(str(txtfile), max_words=1000)
    
    # Extract some relations
    print("\n=== Extracting Relations ===")
    sample_knowledge = """
    God is creator. God created heaven. God created earth.
    Dogs are animals. Cats are animals. Fish are animals.
    Dogs have tails. Cats have whiskers. Fish have fins.
    """
    count = engine.extract_relations_from_text(sample_knowledge)
    print(f"Extracted {count} triples from sample knowledge")
    
    # Add synsets
    print("\n=== Adding Synsets ===")
    engine.bridge.synsets.add_synset_group(["god", "lord", "creator", "almighty"])
    engine.bridge.synsets.add_synset_group(["earth", "world", "ground"])
    engine.bridge.synsets.add_synset_group(["heaven", "sky", "firmament"])
    print("Added 3 synset groups")
    
    # Show status
    engine.print_status()
    
    # Interactive query loop with live prediction
    print("\n" + "="*70)
    print("INTERACTIVE QUERY MODE")
    print("="*70)
    print("Type queries to see live predictions. Examples:")
    print("  - 'god' (shows positions)")
    print("  - 'what is god'")
    print("  - 'dog is'")
    print("  - Type 'status' to see system info")
    print("  - Type 'quit' to exit")
    print()
    
    try:
        while True:
            query = input("Query> ").strip()
            
            if not query:
                continue
            
            if query.lower() == 'quit':
                break
            
            if query.lower() == 'status':
                engine.print_status()
                continue
            
            # Live prediction
            print("\n--- Live Prediction ---")
            results = engine.predict_query(query)
            
            # Show positions
            if results['positions']:
                print("\nPositional Chains:")
                for corpus_id, pos_list in results['positions'].items():
                    corpus_name = engine.corpora.get(corpus_id, {}).get('name', f'Corpus {corpus_id}')
                    pos_str = ','.join(str(p) for p in pos_list[:20])
                    if len(pos_list) > 20:
                        pos_str += '...'
                    print(f"  [{corpus_name}] {pos_str}")
            
            # Show suggestions
            if results['suggestions']:
                print("\nSuggestions:")
                for sugg in results['suggestions']:
                    print(f"  - {sugg}")
            
            # Show triples
            if results['triples']:
                print("\nMatching Triples:")
                for subj, rel, obj in results['triples']:
                    print(f"  {subj} --{rel}--> {obj}")
            
            if not results['positions'] and not results['suggestions'] and not results['triples']:
                print("No results found.")
            
            print()
    
    except KeyboardInterrupt:
        print("\n\nExiting...")
    
    print("\n=== Final Stats ===")
    engine.print_status()


def demo_batch_query():
    """Batch demo showing multiple queries."""
    
    print("="*70)
    print("BATCH QUERY DEMO")
    print("="*70)
    
    engine = LiveQueryEngine()
    
    # Quick ingest
    print("\n=== Quick Ingest ===")
    if os.path.exists("bibleGENESIS.txt"):
        engine.ingest_text_file("bibleGENESIS.txt", "Genesis", max_words=1000)
    
    # Extract relations
    knowledge = """
    God is creator. God is almighty. God created heaven and earth.
    Adam was first man. Eve was first woman.
    The serpent was crafty. The serpent deceived Eve.
    """
    engine.extract_relations_from_text(knowledge)
    
    # Test queries
    print("\n=== Testing Queries ===\n")
    
    test_queries = [
        "god",
        "g",
        "go",
        "what is god",
        "adam",
        "serpent",
        "heaven",
    ]
    
    for query in test_queries:
        print(f"\nQuery: '{query}'")
        print("-" * 40)
        results = engine.predict_query(query)
        
        if results['positions']:
            for corpus_id, pos_list in results['positions'].items():
                print(f"  Positions: {pos_list[:10]}")
        
        if results['suggestions']:
            for sugg in results['suggestions'][:3]:
                print(f"  > {sugg}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'batch':
        demo_batch_query()
    else:
        demo_live_query()
