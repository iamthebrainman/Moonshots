"""
Relational System - Semantic Triple Extraction & Knowledge Graph (V2)
MAJOR OVERHAUL: Support multi-word subjects, objects, AND relations.

Key improvements:
1. Multi-word phrase extraction (not just single tokens)
2. Flexible relation phrases ("is a", "is a kind of", "can be used to")
3. Better response synthesis (grammatically coherent output)
4. Clause-level extraction (not just regex patterns)
"""

import re
import json
from collections import defaultdict


class Synsets:
    """Simple synset/thesaurus for semantic expansion."""
    
    def __init__(self):
        self.word_to_synset = {}  # word -> synset_id
        self.synset_to_words = defaultdict(set)  # synset_id -> {words}
        self.next_id = 0
    
    def add_group(self, words):
        """Add a synonym group (creates independent synsets per group)."""
        words = [w.lower().strip() for w in words if w.strip()]
        if len(words) < 2:
            return
        
        # Always create a new synset for this group
        synset_id = self.next_id
        self.next_id += 1
        
        # Add all words to this synset
        # Note: If a word already has a synset, we DON'T move it
        # This keeps synsets independent and prevents megamerges
        for w in words:
            if w not in self.word_to_synset:
                self.word_to_synset[w] = synset_id
                self.synset_to_words[synset_id].add(w)
    
    def get_synonyms(self, word):
        """Get all synonyms of a word (including itself)."""
        word = word.lower()
        if word not in self.word_to_synset:
            return {word}
        synset_id = self.word_to_synset[word]
        return self.synset_to_words[synset_id]
    
    def expand_words(self, words):
        """Expand a list of words with their synonyms."""
        expanded = set()
        for w in words:
            expanded.update(self.get_synonyms(w.lower()))
        return expanded
    
    def load_from_file(self, filepath):
        """Load synsets from CSV/text file (comma-separated synonyms per line)."""
        count = 0
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                parts = [w.strip().lower() for w in line.split(',')]
                clean = [p for p in parts if p and len(p) > 1]
                if len(clean) >= 2:
                    self.add_group(clean)
                    count += 1
        return count
    
    def save(self, filepath):
        """Save synsets to JSON."""
        data = {
            'word_to_synset': self.word_to_synset,
            'synset_to_words': {k: list(v) for k, v in self.synset_to_words.items()},
            'next_id': self.next_id
        }
        with open(filepath, 'w') as f:
            json.dump(data, f)
    
    def load(self, filepath):
        """Load synsets from JSON."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        self.word_to_synset = data['word_to_synset']
        self.synset_to_words = defaultdict(set, {int(k): set(v) for k, v in data['synset_to_words'].items()})
        self.next_id = data['next_id']


class SynTree:
    """Minimal syntree for testing - just tracks IS_A hierarchy."""
    
    def __init__(self):
        self.tree = {}  # word -> {'parents': [], 'children': []}
    
    def build_from_relations(self, relations):
        """Extract IS_A relations."""
        count = 0
        for subj, rel_type, obj, pos, mods in relations.triples:
            if rel_type == 'IS_A' and obj:
                subj_lower = subj.lower()
                obj_lower = obj.lower()
                
                if subj_lower not in self.tree:
                    self.tree[subj_lower] = {'parents': [], 'children': []}
                if obj_lower not in self.tree:
                    self.tree[obj_lower] = {'parents': [], 'children': []}
                
                if obj_lower not in self.tree[subj_lower]['parents']:
                    self.tree[subj_lower]['parents'].append(obj_lower)
                if subj_lower not in self.tree[obj_lower]['children']:
                    self.tree[obj_lower]['children'].append(subj_lower)
                count += 1
        return count
    
    def get_closenyms(self, word, max_distance=2):
        """Get semantically close words with distances."""
        word = word.lower()
        if word not in self.tree:
            return [(word, 0, 'self')]
        
        results = [(word, 0, 'self')]
        visited = {word}
        
        # Distance 1: Parents + Children
        for parent in self.tree[word].get('parents', []):
            results.append((parent, 1.0, 'parent'))
            visited.add(parent)
        for child in self.tree[word].get('children', []):
            results.append((child, 1.0, 'child'))
            visited.add(child)
        
        if max_distance >= 2:
            # Distance 2: Siblings
            for parent in self.tree[word].get('parents', []):
                for sibling in self.tree[parent].get('children', []):
                    if sibling not in visited:
                        results.append((sibling, 2.0, 'sibling'))
                        visited.add(sibling)
        
        return results


class PronounExtractor:
    """Extract pronoun relations from parsed tokens."""
    
    # Pronoun type mappings
    SUBJECT_PRONOUNS = {
        'i': ('first_person_singular', 'I'),
        'you': ('second_person', 'you'),
        'he': ('third_person_singular_male', 'he'),
        'she': ('third_person_singular_female', 'she'),
        'it': ('third_person_singular_neutral', 'it'),
        'we': ('first_person_plural', 'we'),
        'they': ('third_person_plural', 'they')
    }
    
    OBJECT_PRONOUNS = {
        'me': ('first_person_singular', 'me'),
        'you': ('second_person', 'you'),
        'him': ('third_person_singular_male', 'him'),
        'her': ('third_person_singular_female', 'her'),
        'it': ('third_person_singular_neutral', 'it'),
        'us': ('first_person_plural', 'us'),
        'them': ('third_person_plural', 'them')
    }
    
    # Verb conjugation by pronoun type
    CONJUGATION_MAP = {
        'first_person_singular': {'be': 'am', 'have': 'have'},
        'second_person': {'be': 'are', 'have': 'have'},
        'third_person_singular_male': {'be': 'is', 'have': 'has'},
        'third_person_singular_female': {'be': 'is', 'have': 'has'},
        'third_person_singular_neutral': {'be': 'is', 'have': 'has'},
        'first_person_plural': {'be': 'are', 'have': 'have'},
        'third_person_plural': {'be': 'are', 'have': 'have'}
    }
    
    # Simple name-based gender inference
    FEMALE_NAMES = {'stephanie', 'jane', 'sarah', 'lisa', 'mary', 'emily', 'emma'}
    MALE_NAMES = {'john', 'dick', 'bob', 'mike', 'steve', 'tom', 'david', 'newton', 'number'}
    
    def infer_pronoun_from_entity(self, entity):
        """Infer pronoun type from entity name."""
        entity_lower = entity.lower()
        
        # Check if it's already a pronoun
        if entity_lower in self.SUBJECT_PRONOUNS:
            return self.SUBJECT_PRONOUNS[entity_lower]
        if entity_lower in self.OBJECT_PRONOUNS:
            return self.OBJECT_PRONOUNS[entity_lower]
        
        # Infer from name
        if entity_lower in self.FEMALE_NAMES:
            return ('third_person_singular_female', 'she')
        elif entity_lower in self.MALE_NAMES:
            return ('third_person_singular_male', 'he')
        
        # Default: neutral plural (safest)
        return ('third_person_plural', 'they')
    
    def get_conjugation(self, pronoun_type, verb_base):
        """Get correct verb conjugation for pronoun type."""
        if pronoun_type in self.CONJUGATION_MAP:
            return self.CONJUGATION_MAP[pronoun_type].get(verb_base, verb_base)
        return verb_base


class PerspectiveTranslator:
    """Translate perspective between speaker/listener."""
    
    # First-to-second person mappings
    FIRST_TO_SECOND = {
        'i': 'you',
        'me': 'you',
        'my': 'your',
        'mine': 'yours',
        'myself': 'yourself',
        'we': 'you',
        'us': 'you',
        'our': 'your',
        'am': 'are',
        'was': 'were',
        'have': 'have',
        'has': 'have'
    }
    
    # Second-to-first person mappings
    SECOND_TO_FIRST = {
        'you': 'i',
        'your': 'my',
        'yours': 'mine',
        'yourself': 'myself',
        'are': 'am',
        'were': 'was',
        'have': 'have'
    }
    
    # Third-to-second person (when talking ABOUT entity TO user)
    THIRD_TO_SECOND = {
        'he': 'you',
        'she': 'you',
        'it': 'you',
        'they': 'you',
        'him': 'you',
        'her': 'you',
        'them': 'you',
        'his': 'your',
        'hers': 'your',
        'their': 'your',
        'theirs': 'yours',
        'is': 'are',
        'was': 'were',
        'has': 'have'
    }
    
    def translate_sentence(self, sentence, from_perspective, to_perspective):
        """
        Translate sentence between perspectives.
        
        Args:
            sentence: Original sentence (e.g., "I am alive")
            from_perspective: 'FIRST', 'SECOND', or 'THIRD'
            to_perspective: 'FIRST', 'SECOND', or 'THIRD'
        
        Returns:
            Translated sentence (e.g., "You are alive")
        """
        words = sentence.split()
        translated = []
        
        for word in words:
            word_lower = word.lower()
            
            # Select translation map
            if from_perspective == 'FIRST' and to_perspective == 'SECOND':
                translated_word = self.FIRST_TO_SECOND.get(word_lower, word_lower)
            elif from_perspective == 'SECOND' and to_perspective == 'FIRST':
                translated_word = self.SECOND_TO_FIRST.get(word_lower, word_lower)
            elif from_perspective == 'THIRD' and to_perspective == 'SECOND':
                translated_word = self.THIRD_TO_SECOND.get(word_lower, word_lower)
            else:
                translated_word = word_lower
            
            # Preserve capitalization of first word
            if len(translated) == 0 and len(word) > 0 and word[0].isupper():
                translated_word = translated_word.capitalize()
            
            translated.append(translated_word)
        
        return ' '.join(translated)
    
    def detect_perspective(self, sentence):
        """
        Detect the perspective of a sentence.
        
        Args:
            sentence: Sentence to analyze
        
        Returns:
            'FIRST', 'SECOND', or 'THIRD'
        """
        words = set(word.lower() for word in sentence.split())
        
        # Check for first-person pronouns
        first_person = {'i', 'me', 'my', 'mine', 'myself', 'we', 'us', 'our', 'ours'}
        if words & first_person:
            return 'FIRST'
        
        # Check for second-person pronouns
        second_person = {'you', 'your', 'yours', 'yourself'}
        if words & second_person:
            return 'SECOND'
        
        # Default to third person
        return 'THIRD'


class RelationalChain:
    """Preserves full relational structure of a sentence.
    
    A chain captures the sequential flow of relations in a sentence,
    including inter-clause operators (BECAUSE, AND, BUT, etc.).
    """
    
    def __init__(self, sentence_text, sentence_id):
        self.text = sentence_text
        self.id = sentence_id
        self.nodes = []  # List of {'subj', 'rel', 'obj', 'pos'}
        self.operators = []  # List of {'op', 'left_idx', 'right_idx'}
        
    def add_node(self, subj, rel, obj, position):
        """Add a relation node to the chain."""
        self.nodes.append({
            'subj': subj,
            'rel': rel,
            'obj': obj,
            'pos': position
        })
        return len(self.nodes) - 1  # Return node index
    
    def add_operator(self, operator, left_idx, right_idx):
        """Link two nodes with an inter-clause operator."""
        self.operators.append({
            'op': operator,
            'left': left_idx,
            'right': right_idx
        })
    
    def get_words(self):
        """Extract all unique words from the chain."""
        words = set()
        for node in self.nodes:
            if node['subj']:
                words.update(node['subj'].lower().split())
            if node['obj']:
                words.update(node['obj'].lower().split())
        return words
    
    def __repr__(self):
        return f"Chain({self.id}): {self.text[:50]}..."


class Relations:
    """Directed predicate triples extracted from text - THE WORLD MAP.
    
    NOW SUPPORTS:
    - Multi-word subjects: "the large river"
    - Multi-word relations: "is a kind of"
    - Multi-word objects: "large flowing body of water"
    
    Categories:
    - IDENTITY: is, is_a, am, are (what things ARE)
    - TEMPORAL: was, were, will_be, used_to (past/future states)  
    - POSSESSION: has, have, had, owns (what things HAVE)
    - CAPABILITY: can, could, able_to (what things CAN do)
    - OBLIGATION: must, should, need, have_to (what things MUST do)
    - POSSIBILITY: may, might, could_be (what MIGHT happen)
    - DESIRE: want, like, love, need, prefer (what things WANT)
    - ACTION: does, did, will, going_to (what things DO)
    - RELATION: knows, loves, hates, with (relationships BETWEEN entities)
    """
    
    PRONOUNS = {
        'it', 'this', 'that', 'these', 'those',
        'they', 'them', 'he', 'she', 'him', 'her', 'i', 'you', 'we', 'me', 'us'
    }

    DETERMINERS = {'a', 'an', 'the', 'this', 'that', 'these', 'those'}
    
    # Auxiliary verbs (can't be subjects)
    AUXILIARIES = {
        'is', 'are', 'am', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did',
        'will', 'would', 'shall', 'should', 'can', 'could',
        'may', 'might', 'must', 'ought'
    }
    
    # Personal pronouns we DO want to track
    PERSONS = {'i', 'you', 'we', 'he', 'she', 'they', 'it'}
    
    # Function words that CANNOT be semantic subjects
    FUNCTION_WORDS = {
        'a', 'an', 'the', 'this', 'that', 'these', 'those',
        'is', 'are', 'am', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did',
        'will', 'would', 'shall', 'should', 'can', 'could',
        'may', 'might', 'must', 'ought',
    }
    
    # Adverbs (not valid as sole objects)
    ADVERBS = {
        'together', 'apart', 'away', 'back', 'here', 'there',
        'now', 'then', 'always', 'never', 'often', 'sometimes',
        'very', 'quite', 'too', 'really', 'actually', 'just',
        'only', 'also', 'even', 'still', 'already', 'yet'
    }
    
    # Query words
    QUERY_WORDS = {'who', 'what', 'where', 'when', 'why', 'how', 'which', 'whose'}
    
    # ============================================================
    # MULTI-WORD RELATION PATTERNS (ordered by specificity)
    # Each pattern: (compiled_regex, relation_type, subject_group, object_group)
    # ============================================================
    
    MULTIWORD_PATTERNS = None  # Compiled on first use
    
    @classmethod
    def _compile_patterns(cls):
        """Compile regex patterns for multi-word extraction."""
        if cls.MULTIWORD_PATTERNS is not None:
            return
        
        # Pattern format: (regex_string, relation_type)
        # Use named groups: (?P<subj>...) and (?P<obj>...)
        # Subject/object can be multi-word phrases
        
        # CRITICAL: Restricted patterns for subjects to prevent swallowing verbs!
        # Every word in the subject must NOT be an auxiliary verb.
        AUX_WORDS = r"(?:is|are|am|was|were|has|have|can|could|will|would|do|does|did|must|may|might)"
        WORD = rf"(?!{AUX_WORDS}\b)\w+"  # Fixed: was \\b, should be \b
        SUBJ = rf"\b{WORD}(?:\s+{WORD}){{0,3}}"  # Fixed: was \\b and \\s, should be \b and \s
        OBJ = r"\w+(?:\s+\w+)*"  # Object: 1+ words
        
        patterns = [
            # === PROPER NOUNS & LOCATIONS (require verb context) ===
            # "X made Y" / "X built Y" / "X created Y"
            (rf"(?P<subj>{SUBJ})\s+(?:made|built|created)\s+(?P<obj>{OBJ})", "MADE"),
            
            # "X struck Y" / "X hit Y"  
            (rf"(?P<subj>{SUBJ})\s+(?:struck|hit)\s+(?P<obj>{OBJ})", "STRUCK"),
            
            # Location patterns - require verb context to avoid over-matching
            # "built at Y" / "located at Y" / "works at Y"
            (rf"(?P<subj>{SUBJ})\s+(?:built|located|works|worked|lives|lived)\s+at\s+(?P<obj>{OBJ})", "AT_LOCATION"),
            
            # "am from Y" / "is from Y" / "came from Y"
            (rf"(?P<subj>{SUBJ})\s+(?:am|is|are|was|were|came|comes)\s+from\s+(?P<obj>{OBJ})", "FROM_LOCATION"),
            
            # "made by Y" / "created by Y" / "built by Y"  
            (rf"(?P<subj>{SUBJ})\s+(?:made|created|built|designed)\s+by\s+(?P<obj>{OBJ})", "CREATED_BY"),
            
            # "built as Y" / "designed as Y"
            (rf"(?P<subj>{SUBJ})\s+(?:built|designed|created)\s+as\s+(?:a|an)?\s*(?P<obj>{OBJ})", "BUILT_AS"),
            
            # "part of Y" / "one of Y" - keep simple
            (rf"(?P<subj>{SUBJ})\s+(?:part|one)\s+of\s+(?P<obj>{OBJ})", "PART_OF"),
            
            
            # === COMPLEX IDENTITY ===
            # "X is a kind of Y" / "X is a type of Y"
            (rf"(?P<subj>{SUBJ})\s+(?:is|are)\s+(?:a\s+)?(?:kind|type|form|sort)\s+of\s+(?P<obj>{OBJ})", "IS_KIND_OF"),
            
            # "X is made of Y"
            (rf"(?P<subj>{SUBJ})\s+(?:is|are)\s+made\s+(?:of|from)\s+(?P<obj>{OBJ})", "MADE_OF"),
            
            # "X is used to Y" / "X is used for Y"
            (rf"(?P<subj>{SUBJ})\s+(?:is|are)\s+used\s+(?:to|for)\s+(?P<obj>{OBJ})", "USED_FOR"),
            
            # "X can be used to Y"
            (rf"(?P<subj>{SUBJ})\s+can\s+be\s+used\s+(?:to|for)\s+(?P<obj>{OBJ})", "CAN_BE_USED_FOR"),
            
            # "X is called Y" / "X is known as Y"  
            (rf"(?P<subj>{SUBJ})\s+(?:is|are)\s+(?:called|known\s+as|named)\s+(?P<obj>{OBJ})", "IS_CALLED"),
            
            # "X is part of Y"
            (rf"(?P<subj>{SUBJ})\s+(?:is|are)\s+(?:a\s+)?part\s+of\s+(?P<obj>{OBJ})", "PART_OF"),
            
            # === NEGATED FORMS (must come before affirmative) ===
            # Split by person: AM (1st), IS (3rd sing), ARE (2nd/plural)
            (rf"(?P<subj>{SUBJ})\s+am\s+not\s+(?:a|an)\s+(?P<obj>{OBJ})", "AM_NOT_A"),
            (rf"(?P<subj>{SUBJ})\s+is\s+not\s+(?:a|an)\s+(?P<obj>{OBJ})", "IS_NOT_A"),
            (rf"(?P<subj>{SUBJ})\s+are\s+not\s+(?:a|an)\s+(?P<obj>{OBJ})", "ARE_NOT_A"),
            (rf"(?P<subj>{SUBJ})\s+am\s+not\s+(?P<obj>{OBJ})", "AM_NOT"),
            (rf"(?P<subj>{SUBJ})\s+is\s+not\s+(?P<obj>{OBJ})", "IS_NOT"),
            (rf"(?P<subj>{SUBJ})\s+are\s+not\s+(?P<obj>{OBJ})", "ARE_NOT"),
            (rf"(?P<subj>{SUBJ})\s+(?:do|does|did)\s+not\s+want\s+(?:to\s+)?(?P<obj>{OBJ})", "WANT_NOT"),
            (rf"(?P<subj>{SUBJ})\s+(?:do|does|did)\s+not\s+like\s+(?P<obj>{OBJ})", "LIKE_NOT"),
            (rf"(?P<subj>{SUBJ})\s+(?:do|does|did)\s+not\s+have\s+(?P<obj>{OBJ})", "HAS_NOT"),
            (rf"(?P<subj>{SUBJ})\s+can\s+not\s+(?P<obj>{OBJ})", "CAN_NOT"),
            (rf"(?P<subj>{SUBJ})\s+cannot\s+(?P<obj>{OBJ})", "CAN_NOT"),
            (rf"(?P<subj>{SUBJ})\s+could\s+not\s+(?P<obj>{OBJ})", "COULD_NOT"),
            (rf"(?P<subj>{SUBJ})\s+will\s+not\s+(?P<obj>{OBJ})", "WILL_NOT"),
            (rf"(?P<subj>{SUBJ})\s+would\s+not\s+(?P<obj>{OBJ})", "WOULD_NOT"),
            
            # === DESIRE / PREFERENCE ===
            (rf"(?P<subj>{SUBJ})\s+(?:want|wants|wanted)\s+to\s+(?P<obj>{OBJ})", "WANT_TO"),
            (rf"(?P<subj>{SUBJ})\s+(?:want|wants|wanted)\s+(?P<obj>{OBJ})", "WANT"),
            (rf"(?P<subj>{SUBJ})\s+(?:need|needs)\s+to\s+(?P<obj>{OBJ})", "NEED_TO"),
            (rf"(?P<subj>{SUBJ})\s+(?:need|needs)\s+(?P<obj>{OBJ})", "NEED"),
            (rf"(?P<subj>{SUBJ})\s+(?:like|likes)\s+to\s+(?P<obj>{OBJ})", "LIKE_TO"),
            (rf"(?P<subj>{SUBJ})\s+(?:like|likes)\s+(?P<obj>{OBJ})", "LIKE"),
            (rf"(?P<subj>{SUBJ})\s+(?:love|loves)\s+to\s+(?P<obj>{OBJ})", "LOVE_TO"),
            (rf"(?P<subj>{SUBJ})\s+(?:love|loves)\s+(?P<obj>{OBJ})", "LOVE"),
            (rf"(?P<subj>{SUBJ})\s+(?:hate|hates)\s+(?P<obj>{OBJ})", "HATE"),
            (rf"(?P<subj>{SUBJ})\s+(?:prefer|prefers)\s+(?P<obj>{OBJ})", "PREFER"),
            
            # === CAPABILITY - separate CAN/COULD ===
            (rf"(?P<subj>{SUBJ})\s+can\s+(?P<obj>{OBJ})", "CAN"),
            (rf"(?P<subj>{SUBJ})\s+could\s+(?P<obj>{OBJ})", "COULD"),
            (rf"(?P<subj>{SUBJ})\s+am\s+able\s+to\s+(?P<obj>{OBJ})", "AM_ABLE_TO"),
            (rf"(?P<subj>{SUBJ})\s+is\s+able\s+to\s+(?P<obj>{OBJ})", "IS_ABLE_TO"),
            (rf"(?P<subj>{SUBJ})\s+are\s+able\s+to\s+(?P<obj>{OBJ})", "ARE_ABLE_TO"),
            
            # === FUTURE - separate WILL/WOULD/SHALL/SHOULD ===
            (rf"(?P<subj>{SUBJ})\s+will\s+be\s+(?P<obj>{OBJ})", "WILL_BE"),
            (rf"(?P<subj>{SUBJ})\s+would\s+be\s+(?P<obj>{OBJ})", "WOULD_BE"),
            (rf"(?P<subj>{SUBJ})\s+will\s+(?P<obj>{OBJ})", "WILL"),
            (rf"(?P<subj>{SUBJ})\s+would\s+(?P<obj>{OBJ})", "WOULD"),
            (rf"(?P<subj>{SUBJ})\s+shall\s+(?P<obj>{OBJ})", "SHALL"),
            (rf"(?P<subj>{SUBJ})\s+should\s+(?P<obj>{OBJ})", "SHOULD"),
            (rf"(?P<subj>{SUBJ})\s+am\s+going\s+to\s+(?P<obj>{OBJ})", "AM_GOING_TO"),
            (rf"(?P<subj>{SUBJ})\s+is\s+going\s+to\s+(?P<obj>{OBJ})", "IS_GOING_TO"),
            (rf"(?P<subj>{SUBJ})\s+are\s+going\s+to\s+(?P<obj>{OBJ})", "ARE_GOING_TO"),
            
            # === OBLIGATION / POSSIBILITY ===
            (rf"(?P<subj>{SUBJ})\s+must\s+(?P<obj>{OBJ})", "MUST"),
            (rf"(?P<subj>{SUBJ})\s+may\s+(?P<obj>{OBJ})", "MAY"),
            (rf"(?P<subj>{SUBJ})\s+might\s+(?P<obj>{OBJ})", "MIGHT"),
            
            # === PAST / TEMPORAL - separate WAS/WERE ===
            (rf"(?P<subj>{SUBJ})\s+had\s+been\s+(?P<obj>{OBJ})", "HAD_BEEN"),
            (rf"(?P<subj>{SUBJ})\s+used\s+to\s+be\s+(?P<obj>{OBJ})", "USED_TO_BE"),
            (rf"(?P<subj>{SUBJ})\s+used\s+to\s+(?P<obj>{OBJ})", "USED_TO"),
            (rf"(?P<subj>{SUBJ})\s+was\s+(?:a|an)\s+(?P<obj>{OBJ})", "WAS_A"),
            (rf"(?P<subj>{SUBJ})\s+were\s+(?:a|an)\s+(?P<obj>{OBJ})", "WERE_A"),
            (rf"(?P<subj>{SUBJ})\s+was\s+(?P<obj>{OBJ})", "WAS"),
            (rf"(?P<subj>{SUBJ})\s+were\s+(?P<obj>{OBJ})", "WERE"),
            (rf"(?P<subj>{SUBJ})\s+had\s+(?P<obj>{OBJ})", "HAD"),
            
            # === IDENTITY - SPLIT AM/IS/ARE (core patterns - must come AFTER complex patterns) ===
            (rf"(?P<subj>{SUBJ})\s+am\s+(?:a|an)\s+(?P<obj>{OBJ})", "AM_A"),
            (rf"(?P<subj>{SUBJ})\s+is\s+(?:a|an)\s+(?P<obj>{OBJ})", "IS_A"),
            (rf"(?P<subj>{SUBJ})\s+are\s+(?:a|an)\s+(?P<obj>{OBJ})", "ARE_A"),
            (rf"(?P<subj>{SUBJ})\s+am\s+(?P<obj>{OBJ})", "AM"),
            (rf"(?P<subj>{SUBJ})\s+is\s+(?P<obj>{OBJ})", "IS"),
            (rf"(?P<subj>{SUBJ})\s+are\s+(?P<obj>{OBJ})", "ARE"),
            
            # === POSSESSION - SPLIT HAVE/HAS ===
            (rf"(?P<subj>{SUBJ})\s+have\s+(?:a|an)\s+(?P<obj>{OBJ})", "HAVE_A"),
            (rf"(?P<subj>{SUBJ})\s+has\s+(?:a|an)\s+(?P<obj>{OBJ})", "HAS_A"),
            (rf"(?P<subj>{SUBJ})\s+have\s+(?P<obj>{OBJ})", "HAVE"),
            (rf"(?P<subj>{SUBJ})\s+has\s+(?P<obj>{OBJ})", "HAS"),
            (rf"(?P<subj>{SUBJ})\s+(?:own|owns)\s+(?P<obj>{OBJ})", "OWNS"),
            
            # === RELATIONSHIPS ===
            (rf"(?P<subj>{SUBJ})\s+(?:know|knows)\s+(?P<obj>{OBJ})", "KNOWS"),
            (rf"(?P<subj>{SUBJ})\s+am\s+with\s+(?P<obj>{OBJ})", "AM_WITH"),
            (rf"(?P<subj>{SUBJ})\s+is\s+with\s+(?P<obj>{OBJ})", "IS_WITH"),
            (rf"(?P<subj>{SUBJ})\s+are\s+with\s+(?P<obj>{OBJ})", "ARE_WITH"),
            
            # === ACTIONS ===
            (rf"(?P<subj>{SUBJ})\s+(?:make|makes)\s+(?P<obj>{OBJ})", "MAKE"),
            (rf"(?P<subj>{SUBJ})\s+(?:give|gives)\s+(?P<obj>{OBJ})", "GIVE"),
            (rf"(?P<subj>{SUBJ})\s+(?:take|takes)\s+(?P<obj>{OBJ})", "TAKE"),
            (rf"(?P<subj>{SUBJ})\s+(?:get|gets)\s+(?P<obj>{OBJ})", "GET"),
            (rf"(?P<subj>{SUBJ})\s+(?:help|helps)\s+(?P<obj>{OBJ})", "HELP"),
            (rf"(?P<subj>{SUBJ})\s+do\s+(?P<obj>{OBJ})", "DO"),
            (rf"(?P<subj>{SUBJ})\s+does\s+(?P<obj>{OBJ})", "DOES"),
            
            # === SPATIAL - SPLIT AM/IS/ARE ===
            (rf"(?P<subj>{SUBJ})\s+(?:contain|contains)\s+(?P<obj>{OBJ})", "CONTAINS"),
            (rf"(?P<subj>{SUBJ})\s+am\s+in\s+(?P<obj>{OBJ})", "AM_IN"),
            (rf"(?P<subj>{SUBJ})\s+is\s+in\s+(?P<obj>{OBJ})", "IS_IN"),
            (rf"(?P<subj>{SUBJ})\s+are\s+in\s+(?P<obj>{OBJ})", "ARE_IN"),
            (rf"(?P<subj>{SUBJ})\s+am\s+at\s+(?P<obj>{OBJ})", "AM_AT"),
            (rf"(?P<subj>{SUBJ})\s+is\s+at\s+(?P<obj>{OBJ})", "IS_AT"),
            (rf"(?P<subj>{SUBJ})\s+are\s+at\s+(?P<obj>{OBJ})", "ARE_AT"),
            (rf"(?P<subj>{SUBJ})\s+am\s+from\s+(?P<obj>{OBJ})", "AM_FROM"),
            (rf"(?P<subj>{SUBJ})\s+is\s+from\s+(?P<obj>{OBJ})", "IS_FROM"),
            (rf"(?P<subj>{SUBJ})\s+are\s+from\s+(?P<obj>{OBJ})", "ARE_FROM"),
        ]
        
        # Compile all patterns
        cls.MULTIWORD_PATTERNS = []
        for pattern_str, rel_type in patterns:
            try:
                compiled = re.compile(pattern_str, re.IGNORECASE)
                cls.MULTIWORD_PATTERNS.append((compiled, rel_type))
            except re.error as e:
                print(f"Warning: Failed to compile pattern for {rel_type}: {e}")
    
    def __init__(self):
        # Compile patterns on first instantiation
        Relations._compile_patterns()
        
        # List of (subject, relation_type, object, position, modifiers)
        # NOW: subject and object can be multi-word phrases!
        self.triples = []
        
        # Index: subject -> [(relation_type, object, position, modifiers), ...]
        self.by_subject = defaultdict(list)
        # Index: object -> [(subject, relation_type, position, modifiers), ...]
        self.by_object = defaultdict(list)
        # Index: relation_type -> [(subject, object, position, modifiers), ...]
        self.by_relation = defaultdict(list)
        # Index: modifier -> [(subject, relation_type, object, position), ...]
        self.by_modifier = defaultdict(list)
        
        # Also index by CANONICAL subject (first meaningful word) for faster lookup
        self.by_subject_head = defaultdict(list)
        
        # Meta-relational graph
        self.meta_relations = []
        self.meta_relations_by_target = defaultdict(list)
        self.deprecated = set()
        
        # Position-based index
        self.by_position = []
        
        # === CHAIN-PRESERVING ARCHITECTURE ===
        # Store full relational chains per sentence
        self.chains = []  # List of RelationalChain objects
        self.chain_by_id = {}  # chain_id -> RelationalChain (O(1))
        
        # Hash table indexes for O(1) chain lookups
        self.chains_by_operator = defaultdict(list)  # 'BECAUSE' -> [chain_ids]
        self.chains_by_start_node = defaultdict(list)  # 'i' -> [chain_ids]
        self.chains_by_end_node = defaultdict(list)  # 'health' -> [chain_ids]
        self.chains_by_word = defaultdict(list)  # 'run' -> [chain_ids]
        
        # === SEMANTIC EXPANSION ===
        # Synonym groups and IS_A hierarchy
        self.synsets = Synsets()
        self.syntree = SynTree()
        
        # === PRONOUN SYSTEM ===
        # Pronoun extraction and entity-to-pronoun mapping
        self.pronoun_extractor = PronounExtractor()
        self.entity_pronouns = {}  # entity → (pronoun_type, pronoun_word)
        self.perspective_translator = PerspectiveTranslator()
        
        # === WORD TRACKING (Data Integrity) ===
        # Track ALL words from input to ensure nothing is lost
        self.all_input_words = set()  # Every word ever seen in input
        self.extracted_words = set()  # Words that made it into relations
        self.dropped_words = set()  # Words that were NOT extracted
    
    def _clean_phrase(self, phrase: str) -> str:
        """Clean and normalize a phrase: strip punctuation, extra spaces."""
        if not phrase:
            return ""
        # Remove leading/trailing punctuation and whitespace
        phrase = re.sub(r'^[\s.,!?;:\'"]+|[\s.,!?;:\'"]+$', '', phrase)
        # Collapse internal whitespace
        phrase = ' '.join(phrase.split())
        return phrase.lower()
    
    def _get_head_word(self, phrase: str) -> str:
        """Extract the 'head' (first content word) from a phrase."""
        words = phrase.split()
        for w in words:
            w_clean = w.strip().lower()
            if w_clean not in self.DETERMINERS and w_clean not in self.AUXILIARIES:
                if len(w_clean) >= 2:
                    return w_clean
        # Fallback: return first word if available
        return words[0].lower() if words else ""
    
    def _validate_subject(self, subj: str) -> bool:
        """Check if subject is valid - PERMISSIVE filtering to prevent data loss."""
        if not subj or len(subj.strip()) < 1:
            return False
        
        # Allow longer subjects to capture proper nouns, names, etc.
        if len(subj) > 50:  # Increased from 20
            return False
        
        words = subj.split()
        
        # Allow up to 4 words for multi-word entities like "Newton Crosby"
        if len(words) > 4:
            return False
        
        first_word = words[0].lower()
        
        # Only reject if starts with CLEARLY invalid words
        BAD_STARTS = {
            # Question words
            'who', 'what', 'where', 'when', 'why', 'how', 'which',
            # Conjunctions (these should be operators, not subjects)
            'and', 'but', 'because', 'since', 'although', 'though',
            'however', 'therefore', 'thus', 'hence', 'so', 'yet',
            'for', 'nor', 'while', 'whereas', 'unless', 'until'
        }
        if first_word in BAD_STARTS:
            return False
        
        # Accept everything else - proper nouns, numbers, etc.
        return True
    
    def _validate_object(self, obj: str) -> bool:
        """Check if object is valid - PERMISSIVE to capture all data."""
        if not obj or len(obj.strip()) < 1:
            return False
        # Allow long objects for complex phrases like "what it means to exist"
        if len(obj) > 100:
            return False
        return True
    
    def _find_answer_boundary(self, text: str) -> int:
        """
        Find where the 'answer' portion of a Q&A line starts.
        
        For lines like "are you alive number 5 is alive", we want to find
        where "number 5 is alive" starts (the answer portion).
        
        Heuristic: Look for patterns like:
        - Subject + "is/are/am" that follows a question word sequence
        - Named entities (capitalized in original, or "number 5", "i am", etc.)
        - After common answer starters: "yes", "no", "affirmative", "negative"
        
        Returns character offset where answer begins, or 0 if no split needed.
        """
        words = text.lower().split()
        if not words:
            return 0
        
        # If doesn't start with question word or aux, no split needed
        first = words[0]
        if first not in self.QUERY_WORDS and first not in self.AUXILIARIES:
            return 0
        
        # Look for answer boundary markers
        BOUNDARY_MARKERS = {
            'yes', 'no', 'affirmative', 'negative', 'i', 'number', 
            'he', 'she', 'it', 'they', 'we', 'my', 'the', 'a', 'an'
        }
        
        # Calculate character offsets for each word
        offsets = []
        char_pos = 0
        for w in text.split():
            offsets.append(char_pos)
            char_pos += len(w) + 1  # +1 for space
        
        # Scan forward looking for boundary
        # Skip past question words and auxiliary verbs
        words_split = text.split()
        for i in range(1, len(words)):
            w = words[i]
            # Skip if still in question portion
            if w in self.QUERY_WORDS or w in self.AUXILIARIES:
                continue
            # Found potential boundary marker?
            if w in BOUNDARY_MARKERS and i > 1:
                return offsets[i] if i < len(offsets) else 0
            # Found a proper noun pattern (like "number 5")?
            if i > 2 and words_split[i][0].isupper() if i < len(words_split) else False:
                return offsets[i] if i < len(offsets) else 0
        
        return 0
    
    def get_related_words(self, word: str) -> set:
        """Get semantically related words via IS/IS_A/SIMILAR_TO relations."""
        related = set()
        word = word.lower()
        
        # Check by subject head
        if word in self.by_subject_head:
            for rel_type, obj, _, _ in self.by_subject_head[word]:
                if rel_type in {'IS', 'IS_A', 'SIMILAR_TO', 'SAME_AS'}:
                    if obj:
                        # Add head word of object
                        related.add(self._get_head_word(obj))
        
        # Also check if word appears in any object
        for obj, entries in self.by_object.items():
            if word in obj.lower():
                for subj, rel_type, _, _ in entries:
                    if rel_type in {'IS', 'IS_A', 'SIMILAR_TO', 'SAME_AS'}:
                        related.add(self._get_head_word(subj))
                    
        return related
    
    def extract_from_tokens(self, tokens, positions, is_query_context=False, raw_text=None):
        """Extract relations from token sequence.
        
        Args:
            tokens: List of word tokens
            positions: List of corpus positions
            is_query_context: If True, parsing a query; if False, ingesting knowledge
            raw_text: Optional original text for modal detection
            
        Returns:
            Number of relations extracted
        """
        text = ' '.join(tokens)
        total_count = 0
        
        # Track input words for data integrity checking
        input_words = set(word.lower() for word in tokens if word.strip())
        self.all_input_words.update(input_words)
        
        # Split on clause boundaries (conjunctions) to process each clause separately
        # This prevents "robot i am alive" from capturing "robot i" as subject
        CLAUSE_BOUNDARIES = r'\b(and|but|because|since|although|though|however|therefore|so|yet|while|whereas|or)\b'
        clauses = re.split(CLAUSE_BOUNDARIES, text, flags=re.IGNORECASE)
        
        # Filter out the conjunctions themselves (they appear as captured groups)
        clauses = [c.strip() for c in clauses if c and c.strip() and c.lower() not in 
                   {'and', 'but', 'because', 'since', 'although', 'though', 'however', 
                    'therefore', 'so', 'yet', 'while', 'whereas', 'or'}]
        
        for clause in clauses:
            count = self._extract_from_clause(clause, positions)
            total_count += count
        
        return total_count
    
    def _extract_from_clause(self, text, positions):
        """Extract relations from a single clause."""
        count = 0
        tokens = text.split()  # Tokenize the clause
        
        # Skip if clause is too short (likely just a conjunction fragment)
        if len(tokens) < 2:
            return 0
        
        # Detect Q&A boundary and focus on answer portion
        answer_offset = self._find_answer_boundary(text)
        if answer_offset > 0:
            text = text[answer_offset:].strip()
            tokens = text.split()
        
        # Extract relations using multi-word patterns
        # Track used character spans to prevent overlapping matches
        # More specific patterns come first, so they get priority
        used_spans = []  # List of (start, end) tuples that have been matched
        seen_triples = set()  # Dedupe by (subj, rel, obj)
        
        def span_overlaps(start, end):
            """Check if a span overlaps with any used span."""
            for used_start, used_end in used_spans:
                # Check for overlap (not just containment)
                if start < used_end and end > used_start:
                    return True
            return False
        
        for compiled_pattern, rel_type in self.MULTIWORD_PATTERNS:
            for match in compiled_pattern.finditer(text):
                
                # Check if this match overlaps with already-used spans
                match_start = match.start()
                match_end = match.end()
                if span_overlaps(match_start, match_end):
                    continue  # Skip - more specific pattern already matched this
                
                try:
                    subj = self._clean_phrase(match.group('subj'))
                    obj = self._clean_phrase(match.group('obj'))
                except IndexError:
                    continue
                
                # Validate subject and object
                if not self._validate_subject(subj):
                    continue
                if obj and not self._validate_object(obj):
                    continue
                
                # Calculate position based on where match starts
                try:
                    # Find the token closest to match start
                    match_start_char = match.start()
                    char_count = 0
                    token_idx = 0
                    for i, t in enumerate(tokens):
                        if char_count >= match_start_char:
                            token_idx = i
                            break
                        char_count += len(t) + 1  # +1 for space
                    pos = positions[token_idx] if token_idx < len(positions) else positions[0]
                except (ValueError, IndexError):
                    pos = positions[0] if positions else 0
                
                # Dedupe check
                key = (subj, rel_type, obj)
                if key in seen_triples:
                    continue
                seen_triples.add(key)
                
                # Mark this span as used
                used_spans.append((match_start, match_end))
                
                # Add the triple!
                self._add_triple(subj, rel_type, obj, pos, [])
                count += 1
        
        return count
    
    def _detect_mode(self, tokens, has_question):
        """Detect if input is QUERY or ASSERT."""
        if not tokens:
            return 'ASSERT'
        
        first = tokens[0].lower()
        
        if has_question:
            return 'QUERY'
        
        if first in self.QUERY_WORDS:
            return 'QUERY'
        
        # Inversion check: "Is X Y?" starts with auxiliary
        if first in self.AUXILIARIES:
            if len(tokens) > 1 and tokens[1].lower() not in {'not', "n't"}:
                return 'QUERY'
        
        return 'ASSERT'
    
    def _add_triple(self, subject, relation, obj, position, modifiers=None):
        """Add a triple to all indices."""
        if modifiers is None:
            modifiers = []
        
        triple = (subject, relation, obj, position, modifiers)
        self.triples.append(triple)
        
        # Track extracted words for data integrity
        if subject:
            self.extracted_words.update(word.lower() for word in subject.split())
        if obj:
            self.extracted_words.update(word.lower() for word in obj.split())
        
        self.by_subject[subject].append((relation, obj, position, modifiers))
        
        if obj:
            self.by_object[obj].append((subject, relation, position, modifiers))
        
        self.by_relation[relation].append((subject, obj, position, modifiers))
        
        for mod in modifiers:
            base_mod = mod.split(':')[0]
            self.by_modifier[base_mod].append((subject, relation, obj, position))
        
        # Index by head word for fast lookup
        head = self._get_head_word(subject)
        if head:
            self.by_subject_head[head].append((relation, obj, position, modifiers))
        
        # Index by position
        import bisect
        triple_idx = len(self.triples) - 1
        bisect.insort(self.by_position, (position, triple_idx))
    

    def build_chains_from_triples(self, sentence_window=20):
        """Build RelationalChain objects from existing triples.
        
        Groups triples by proximity (position) to form sentence-level chains.
        
        Args:
            sentence_window: Max position distance to group triples into same chain
        """
        if not self.triples:
            return
        
        # Group triples by position proximity
        sorted_triples = sorted(self.triples, key=lambda t: t[3])  # Sort by position
        
        chains_data = []
        current_chain_triples = []
        last_position = -sentence_window - 1
        
        for triple in sorted_triples:
            subj, rel, obj, pos, mods = triple
            
            # If position is far from last, start new chain
            if pos - last_position > sentence_window:
                if current_chain_triples:
                    chains_data.append(current_chain_triples)
                current_chain_triples = [triple]
            else:
                current_chain_triples.append(triple)
            
            last_position = pos
        
        # Don't forget last chain
        if current_chain_triples:
            chains_data.append(current_chain_triples)
        
        # Build RelationalChain objects
        for chain_id, triples_group in enumerate(chains_data):
            # Reconstruct sentence text from triples (approximate)
            words = set()
            for subj, rel, obj, pos, mods in triples_group:
                if subj:
                    words.update(subj.split())
                if obj:
                    words.update(obj.split())
            sentence_text = ' '.join(sorted(words))  # Approximate
            
            chain = RelationalChain(sentence_text, chain_id)
            
            # Add nodes from triples
            for subj, rel, obj, pos, mods in triples_group:
                chain.add_node(subj, rel, obj, pos)
            
            # Store and index chain
            self.chains.append(chain)
            self._index_chain(chain)
        
        # Extract pronoun information for all entities
        self._extract_pronoun_info()
    
    def _index_chain(self, chain):
        """Index a chain in all hash tables for O(1) lookups."""
        chain_id = chain.id
        
        # Index by chain ID
        self.chain_by_id[chain_id] = chain
        
        # Index by operators
        for op_info in chain.operators:
            self.chains_by_operator[op_info['op']].append(chain_id)
        
        # Index by start/end nodes
        if chain.nodes:
            first_node = chain.nodes[0]
            last_node = chain.nodes[-1]
            if first_node['subj']:
                self.chains_by_start_node[first_node['subj'].lower()].append(chain_id)
            if last_node['obj']:
                self.chains_by_end_node[last_node['obj'].lower()].append(chain_id)
        
        # Index by all words in chain
        for word in chain.get_words():
            self.chains_by_word[word].append(chain_id)
    
    def _extract_pronoun_info(self):
        """Extract and store pronoun information for all entities."""
        for subj, rel, obj, pos, mods in self.triples:
            # Store pronoun info for subject
            if subj and subj not in self.entity_pronouns:
                pronoun_type, pronoun_word = self.pronoun_extractor.infer_pronoun_from_entity(subj)
                self.entity_pronouns[subj] = (pronoun_type, pronoun_word)
                
                # Store as relation too for querying
                self._add_triple(subj, 'HAS_PRONOUN', pronoun_word, pos, [])
                self._add_triple(subj, 'PRONOUN_TYPE', pronoun_type, pos, [])
            
            # Store pronoun info for object (if it's a valid entity)
            if obj and obj not in self.entity_pronouns:
                # Only extract pronouns for objects that look like entities (not adjectives/states)
                # Skip if object is very short or looks like a state/property
                if len(obj.split()) <= 2 and obj[0].isalpha():
                    pronoun_type, pronoun_word = self.pronoun_extractor.infer_pronoun_from_entity(obj)
                    self.entity_pronouns[obj] = (pronoun_type, pronoun_word)
                    
                    # Store as relation too for querying
                    self._add_triple(obj, 'HAS_PRONOUN', pronoun_word, pos, [])
                    self._add_triple(obj, 'PRONOUN_TYPE', pronoun_type, pos, [])
    
    def query_chains(self, query_words, operator=None):
        """Query chains by words and/or operator. O(1) + O(k) where k = matching chains.
        
        Args:
            query_words: List of words to search for
            operator: Optional operator to filter by (e.g., 'BECAUSE')
        
        Returns:
            List of matching RelationalChain objects
        """
        # Start with operator filter if provided (most selective)
        if operator:
            candidate_ids = set(self.chains_by_operator.get(operator, []))
        else:
            candidate_ids = set(range(len(self.chains)))
        
        # Filter by words
        for word in query_words:
            word_chain_ids = set(self.chains_by_word.get(word.lower(), []))
            candidate_ids &= word_chain_ids  # Intersection
            if not candidate_ids:
                break  # Early exit if no matches
        
        # Return chain objects
        return [self.chain_by_id[cid] for cid in candidate_ids if cid in self.chain_by_id]
    
    def grow_synsets_from_corpus(self, min_cooccur=2):
        """
        Extract synsets from IS_A relations in the corpus.
        
        Builds transitive closure of identity relations:
        If A IS_A B and B IS_A C, then A, B, C are all synonymous.
        
        Skips state words and pronouns that shouldn't merge.
        
        Returns count of synsets created.
        """
        added = 0
        
        # Stopwords that indicate temporary states, not true identity
        state_words = {'happy', 'sad', 'angry', 'tired', 'hungry', 'scared', 'alive', 
                       'dead', 'awake', 'asleep', 'ready', 'busy', 'free', 'full',
                       'empty', 'hot', 'cold', 'warm', 'cool', 'clean', 'dirty',
                       'wet', 'dry', 'open', 'closed', 'broken', 'fixed', 'lost',
                       'found', 'here', 'there', 'present', 'absent', 'available',
                       'unavailable', 'online', 'offline', 'active', 'inactive'}
        
        # Personal pronouns that shouldn't merge (I ≠ you ≠ he)
        pronouns = {'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 
                    'her', 'us', 'them', 'my', 'your', 'his', 'their', 'our'}
        
        # Pattern 1: IS/IS_A chains - transitive identity relations
        identity_chains = defaultdict(set)
        
        for subj, rel_type, obj, pos, modifiers in self.triples:
            if obj is None:  # Skip existence verbs with no object
                continue
            if rel_type in ['IS_A', 'EQUALS']:  # Only strong taxonomy, NOT general IS
                subj_lower = subj.lower()
                obj_lower = obj.lower()
                
                # Skip if either is a state word or pronoun
                if obj_lower in state_words or subj_lower in state_words:
                    continue
                if obj_lower in pronouns or subj_lower in pronouns:
                    continue
                
                # Forward and backward - both directions are synonymous
                identity_chains[subj_lower].add(obj_lower)
                identity_chains[obj_lower].add(subj_lower)
        
        # Transitive closure - if A IS_A B and B IS_A C, then A, B, C are all synonymous
        # Limited to 3 hops to prevent runaway merging
        max_closure_iterations = 3
        for iteration in range(max_closure_iterations):
            changed = False
            for word in list(identity_chains.keys()):
                original_size = len(identity_chains[word])
                # Union with all connected words' connections
                for connected in list(identity_chains[word]):
                    identity_chains[word].update(identity_chains[connected])
                if len(identity_chains[word]) > original_size:
                    changed = True
            if not changed:
                break
        
        # Create synsets from identity chains (only if chain has multiple members)
        # Max size limit to prevent mega-synsets
        max_synset_size = 20
        seen_chains = set()
        for word, chain in identity_chains.items():
            if 2 <= len(chain) <= max_synset_size:
                # Normalize chain to canonical form to avoid duplicates
                chain_key = tuple(sorted(chain))
                if chain_key not in seen_chains:
                    seen_chains.add(chain_key)
                    self.synsets.add_group(list(chain))
                    added += 1
        
        # Pattern 2: Shared predicate objects
        # Find words that are objects of the same subject-predicate pairs
        # e.g., X WANTS [freedom, peace, liberty] → these are related
        subject_predicates = defaultdict(list)
        for subj, rel_type, obj, pos, modifiers in self.triples:
            if obj is None:  # Skip existence verbs with no object
                continue
            key = (subj.lower(), rel_type)
            subject_predicates[key].append(obj.lower())
        
        # Create synsets from objects that share subject-predicate
        for (subj, rel_type), objects in subject_predicates.items():
            # Filter to objects appearing min_cooccur times
            obj_counts = defaultdict(int)
            for obj in objects:
                obj_counts[obj] += 1
            
            frequent_objects = [obj for obj, count in obj_counts.items() if count >= min_cooccur]
            if 2 <= len(frequent_objects) <= max_synset_size:
                self.synsets.add_group(frequent_objects)
                added += 1
        
        # Pattern 3: Shared subject patterns
        # Find predicates-objects appearing with multiple subjects
        # e.g., [system, entity, mind] all HAS [consciousness, awareness]
        predicate_objects = defaultdict(list)
        for subj, rel_type, obj, pos, modifiers in self.triples:
            if obj is None:  # Skip existence verbs with no object
                continue
            key = (rel_type, obj.lower())
            predicate_objects[key].append(subj.lower())
        
        # Create synsets from subjects that share predicate-object
        for (rel_type, obj), subjects in predicate_objects.items():
            # Filter to subjects appearing min_cooccur times
            subj_counts = defaultdict(int)
            for subj in subjects:
                subj_counts[subj] += 1
            
            frequent_subjects = [subj for subj, count in subj_counts.items() if count >= min_cooccur]
            if 2 <= len(frequent_subjects) <= max_synset_size:
                self.synsets.add_group(frequent_subjects)
                added += 1
        
        return added
    
    def build_semantic_indices(self):
        """Build synsets and syntree after ingestion (call after build_chains_from_triples)."""
        
        # Build IS_A hierarchy
        tree_count = self.syntree.build_from_relations(self)
        
        # Auto-generate synsets from corpus patterns
        synset_count = self.grow_synsets_from_corpus(min_cooccur=2)
        
        print(f"  SynTree: {tree_count} IS_A relations indexed.")
        print(f"  Synsets: {synset_count} groups auto-generated.")
        
        # Optionally load manual synsets
        try:
            manual_count = self.synsets.load_from_file('training/synsets.txt')
            print(f"  Manual synsets: {manual_count} groups loaded.")
        except FileNotFoundError:
            pass  # No manual synsets, that's fine

    def get_relations_for(self, word, as_subject=True, as_object=True):
        """Get all relations involving a word (checks head words)."""
        results = []
        word = word.lower()
        
        if as_subject:
            # Direct match on full subject
            results.extend([(subj, r, o, p) 
                          for subj in self.by_subject 
                          for r, o, p, m in self.by_subject[subj]
                          if word in subj.lower()])
            
            # Also check head word index
            if word in self.by_subject_head:
                for r, o, p, m in self.by_subject_head[word]:
                    # Find the full subject
                    for subj, entries in self.by_subject.items():
                        if self._get_head_word(subj) == word:
                            results.append((subj, r, o, p))
                            break
        
        if as_object:
            for obj, entries in self.by_object.items():
                if word in obj.lower():
                    for s, r, p, m in entries:
                        results.append((s, r, obj, p))
        
        return results
    
    def get_entity_profile(self, entity):
        """Get complete profile for an entity organized by category."""
        entity = entity.lower()
        profile = {
            'identity': [], 'was': [], 'has': [], 'wants': [],
            'can': [], 'must': [], 'might': [], 'will': [],
            'relationships': [], 'actions': [], 'location': [],
        }
        
        category_map = {
            'IS': 'identity', 'IS_A': 'identity', 'IS_NOT': 'identity',
            'IS_KIND_OF': 'identity', 'IS_CALLED': 'identity',
            'WAS': 'was', 'WAS_A': 'was', 'HAD': 'was',
            'HAS': 'has', 'HAS_A': 'has', 'OWNS': 'has',
            'WANT': 'wants', 'LIKE': 'wants', 'LOVE': 'wants',
            'CAN': 'can', 'ABLE_TO': 'can',
            'WILL': 'will', 'GOING_TO': 'will',
            'KNOWS': 'relationships', 'WITH': 'relationships',
            'MAKE': 'actions', 'GIVE': 'actions', 'TAKE': 'actions',
            'HELP': 'actions', 'DO': 'actions',
            'IN': 'location', 'AT': 'location', 'FROM': 'location',
            'MADE_OF': 'has', 'USED_FOR': 'can', 'PART_OF': 'identity',
        }
        
        # Check by subject and subject head
        for subj in self.by_subject:
            if entity in subj.lower():
                for rel, obj, pos, mods in self.by_subject[subj]:
                    category = category_map.get(rel, 'actions')
                    profile[category].append((rel, obj, pos, 'subject'))
        
        for obj_key in self.by_object:
            if entity in obj_key.lower():
                for subj, rel, pos, mods in self.by_object[obj_key]:
                    category = category_map.get(rel, 'actions')
                    profile[category].append((rel, subj, pos, 'object'))
        
        return profile
    
    def synthesize_response(self, query_words: list, max_facts: int = 3) -> str:
        """
        Generate a grammatically coherent response based on stored knowledge.
        
        This is the key improvement: instead of dumping raw triples,
        we synthesize proper English sentences.
        """
        if not query_words or not self.triples:
            return ""
        
        # Find relevant triples
        relevant = []
        query_set = set(w.lower() for w in query_words)
        
        for subj, rel, obj, pos, mods in self.triples:
            subj_words = set(subj.lower().split())
            obj_words = set(obj.lower().split()) if obj else set()
            
            # Check for overlap with query
            if query_set & subj_words or query_set & obj_words:
                score = len(query_set & (subj_words | obj_words))
                relevant.append((score, subj, rel, obj))
        
        if not relevant:
            return ""
        
        # Sort by relevance (most matching words first)
        relevant.sort(key=lambda x: x[0], reverse=True)
        
        # Take top facts and synthesize
        sentences = []
        seen_subjects = set()
        
        for score, subj, rel, obj in relevant[:max_facts]:
            # Avoid repeating the same subject
            subj_head = self._get_head_word(subj)
            if subj_head in seen_subjects:
                continue
            seen_subjects.add(subj_head)
            
            sentence = self._triple_to_sentence(subj, rel, obj)
            if sentence:
                # Apply perspective translation
                # Detect corpus perspective
                corpus_perspective = self.perspective_translator.detect_perspective(sentence)
                
                # NOTE: Perspective shift disabled. 
                # The bot should speak based on its stored identity (I am X).
                # Only translate if explicitly needed for user-directed speech.
                if False and corpus_perspective == 'FIRST':
                    sentence = self.perspective_translator.translate_sentence(
                        sentence, 
                        'FIRST', 
                        'SECOND'
                    )
                
                sentences.append(sentence)
        
        # Join sentences
        if sentences:
            return ' '.join(sentences)
        return ""
    
    def _triple_to_sentence(self, subj: str, rel: str, obj: str) -> str:
        """Convert a single triple to a grammatically correct sentence."""
        if not subj:
            return ""
        
        # Capitalize first letter of subject
        subj_cap = subj[0].upper() + subj[1:] if subj else ""
        
        # Map relation types to natural language
        rel_map = {
            'IS': 'is',
            'IS_A': 'is a',
            'AM': 'am',
            'AM_A': 'am a',
            'ARE': 'are',
            'ARE_A': 'are a',
            'IS_KIND_OF': 'is a kind of',
            'IS_CALLED': 'is called',
            'IS_NOT': 'is not',
            'IS_NOT_A': 'is not a',
            'WAS': 'was',
            'WAS_A': 'was a',
            'WERE': 'were',
            'WERE_A': 'were a',
            'HAS': 'has',
            'HAS_A': 'has a',
            'HAVE': 'have',
            'HAVE_A': 'have a',
            'CAN': 'can',
            'CAN_BE_USED_FOR': 'can be used for',
            'ABLE_TO': 'is able to',
            'WILL': 'will',
            'WILL_BE': 'will be',
            'WANT': 'wants',
            'WANT_TO': 'wants to',
            'LIKE': 'likes',
            'LOVE': 'loves',
            'KNOW': 'knows',
            'KNOWS': 'knows',
            'HELP': 'helps',
            'MAKE': 'makes',
            'DO': 'does',
            'MADE_OF': 'is made of',
            'USED_FOR': 'is used for',
            'PART_OF': 'is part of',
            'IN': 'is in',
            'AT': 'is at',
            'FROM': 'is from',
        }
        
        rel_phrase = rel_map.get(rel, rel.lower().replace('_', ' '))
        
        if obj:
            return f"{subj_cap} {rel_phrase} {obj}."
        else:
            return f"{subj_cap} {rel_phrase}."
    
    def stats(self):
        """Return relation statistics."""
        return {
            'total_triples': len(self.triples),
            'unique_subjects': len(self.by_subject),
            'unique_objects': len(self.by_object),
            'relation_types': len(self.by_relation),
            'chains': len(self.chains)
        }
    
    def get_word_coverage_report(self):
        """
        Generate comprehensive word coverage report showing data integrity.
        
        This identifies ANY words that were in input but not extracted into relations.
        **CRITICAL**: If dropped_words is non-empty, we have DATA LOSS!
        
        Returns:
            dict with coverage statistics and lists of dropped words
        """
        # Update dropped words
        self.update_dropped_words()
        
        total_input = len(self.all_input_words)
        total_extracted = len(self.extracted_words)
        total_dropped = len(self.dropped_words)
        
        coverage_pct = (total_extracted / total_input * 100) if total_input > 0 else 0
        
        # Sort dropped words for easier reading
        dropped_sorted = sorted(self.dropped_words)
        
        report = {
            'total_input_words': total_input,
            'total_extracted_words': total_extracted,
            'total_dropped_words': total_dropped,
            'coverage_percentage': coverage_pct,
            'dropped_words': dropped_sorted,
            'status': 'COMPLETE' if total_dropped == 0 else 'DATA_LOSS',
            'severity': 'CRITICAL' if total_dropped > 0 else 'OK'
        }
        
        return report
    
    def get_dropped_words(self):
        """
        Get list of words that were in input but NOT extracted intorelations.
        **This should ALWAYS be empty!**
        
        Returns:
            set of dropped words
        """
        self.update_dropped_words()
        return self.dropped_words
    
    def update_dropped_words(self):
        """Update the set of dropped words by comparing input vs extracted."""
        self.dropped_words = self.all_input_words - self.extracted_words
    
    def print_word_coverage_report(self):
        """Print human-readable word coverage report to console."""
        report = self.get_word_coverage_report()
        
        print("=" * 70)
        print("WORD COVERAGE REPORT (Data Integrity Check)")
        print("=" * 70)
        print(f"Total input words: {report['total_input_words']}")
        print(f"Extracted words: {report['total_extracted_words']}")
        print(f"Dropped words: {report['total_dropped_words']}")
        print(f"Coverage: {report['coverage_percentage']:.1f}%")
        print(f"Status: {report['status']}")
        print()
        
        if report['severity'] == 'CRITICAL':
            print("⚠️  CRITICAL: DATA LOSS DETECTED!")
            print("=" * 70)
            print("The following words were IN the input but NOT extracted:")
            print("-" * 70)
            
            # Group by first letter for easier reading
            from collections import defaultdict
            by_letter = defaultdict(list)
            for word in report['dropped_words']:
                first_char = word[0] if word else '?'
                by_letter[first_char].append(word)
            
            for letter in sorted(by_letter.keys()):
                words = by_letter[letter]
                print(f"{letter.upper()}: {', '.join(words)}")
            
            print()
            print("⚠️  These words must be captured! Investigate extraction patterns.")
        else:
            print("✓ ALL WORDS EXTRACTED - No data loss!")
        
        print("=" * 70)
    
    def save(self, filepath):
        """Save relations to JSON."""
        data = {
            'version': 4,  # Version bump for multi-word support
            'triples': self.triples,
            'meta_relations': self.meta_relations,
            'deprecated': list(self.deprecated)
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load(self, filepath):
        """Load relations from JSON."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        self.triples = []
        self.by_subject = defaultdict(list)
        self.by_object = defaultdict(list)
        self.by_relation = defaultdict(list)
        self.by_modifier = defaultdict(list)
        self.by_subject_head = defaultdict(list)
        
        for triple in data.get('triples', []):
            if len(triple) == 4:
                subj, rel, obj, pos = triple
                modifiers = []
            else:
                subj, rel, obj, pos, modifiers = triple
            
            self._add_triple(subj, rel, obj, pos, modifiers)
        
        self.meta_relations = data.get('meta_relations', [])
        self.deprecated = set(data.get('deprecated', []))
