import math
from typing import List, Tuple, Dict
from collections import defaultdict

# ==============================================================================
# GOLDEN RATIO HASH (Your "God Mode" Algorithm)
# ==============================================================================

PHI = 1.6180339887498948482

def is_prime(n):
    if n <= 1: return False
    if n <= 3: return True
    if n % 2 == 0 or n % 3 == 0: return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

def next_prime(n):
    if n % 2 == 0: n += 1
    while not is_prime(n):
        n += 2
    return n

def hash_division_xor(key, table_size):
    """Primary hash: Division-XOR chain"""
    h = 5381
    for char in key:
        h = ((h << 5) + h) ^ ord(char)
    return (h & 0xFFFFFFFF) % table_size

def step_golden_ratio(key, table_size):
    """Collision step: Golden ratio fractional entropy"""
    h = 0
    for c in key: h = (h * 31) + ord(c)
    val = h * PHI
    fraction = val % 1
    step = int(fraction * table_size)
    if step == 0: step = 1
    if step % 2 == 0: step += 1
    return step

# ==============================================================================
# POSITION-HASH INTERFERENCE ENGINE
# ==============================================================================

class PositionHashEngine:
    def __init__(self, corpus_size=10000, window=20):
        self.window = window
        self.table_size = next_prime(corpus_size)
        self.corpus = []  # List of tokens
        self.positions = defaultdict(list)  # word -> [positions]

    def ingest(self, text: str):
        """Add text to corpus and track positions"""
        tokens = text.lower().split()
        start_pos = len(self.corpus)

        for i, token in enumerate(tokens):
            pos = start_pos + i
            self.corpus.append(token)
            self.positions[token].append(pos)

    def calculate_interference(self, words: List[str]) -> Dict:
        """
        Calculate position-hash interference for multiple words.
        Returns positions where ALL words co-occur within window.
        """
        if not words:
            return {'peaks': [], 'amplitude': 0.0}

        # Get all positions for each word
        word_positions = {}
        for word in words:
            if word not in self.positions:
                return {'peaks': [], 'amplitude': 0.0}
            word_positions[word] = self.positions[word]

        # Find interference peaks (where all words co-occur)
        peaks = []

        # For each position of the first word
        first_word = words[0]
        for anchor_pos in word_positions[first_word]:
            # Check if ALL other words appear within window
            window_start = max(0, anchor_pos - self.window)
            window_end = anchor_pos + self.window

            all_present = True
            distances = {first_word: 0}

            for word in words[1:]:
                # Find closest occurrence within window
                closest_dist = float('inf')
                for pos in word_positions[word]:
                    if window_start <= pos <= window_end:
                        dist = abs(pos - anchor_pos)
                        if dist < closest_dist:
                            closest_dist = dist

                if closest_dist == float('inf'):
                    all_present = False
                    break

                distances[word] = closest_dist

            if all_present:
                # Calculate amplitude (wave interference)
                avg_distance = sum(distances.values()) / len(distances)
                amplitude = math.cos(math.pi * avg_distance / self.window)

                peaks.append({
                    'position': anchor_pos,
                    'amplitude': amplitude,
                    'distances': distances
                })

        # Return best peak
        if peaks:
            best_peak = max(peaks, key=lambda p: p['amplitude'])
            return {
                'peaks': peaks,
                'best_position': best_peak['position'],
                'best_amplitude': best_peak['amplitude'],
                'peak_count': len(peaks)
            }

        return {'peaks': [], 'amplitude': 0.0}

    def hash_phrase(self, phrase: str) -> int:
        """Get position hash for phrase"""
        words = phrase.lower().split()
        result = self.calculate_interference(words)

        if result.get('best_position') is not None:
            # Use best position as hash
            return result['best_position']

        # Fallback: use division-XOR
        return hash_division_xor(phrase, self.table_size)

    def compare_phrases(self, phrase1: str, phrase2: str) -> Dict:
        """Compare two phrases via position-hash interference"""
        words1 = phrase1.lower().split()
        words2 = phrase2.lower().split()

        result1 = self.calculate_interference(words1)
        result2 = self.calculate_interference(words2)

        # Check for overlapping peaks
        if not result1.get('peaks') or not result2.get('peaks'):
            return {'similarity': 0.0, 'overlap': False}

        pos1 = result1['best_position']
        pos2 = result2['best_position']

        # Calculate position distance
        pos_distance = abs(pos1 - pos2)

        # Similarity based on position proximity + amplitude
        similarity = 0.0
        if pos_distance <= self.window:
            # Within same window = high similarity
            avg_amplitude = (result1['best_amplitude'] + result2['best_amplitude']) / 2
            distance_factor = 1.0 - (pos_distance / self.window)
            similarity = avg_amplitude * distance_factor

        return {
            'phrase1': phrase1,
            'phrase2': phrase2,
            'pos1': pos1,
            'pos2': pos2,
            'amplitude1': result1['best_amplitude'],
            'amplitude2': result2['best_amplitude'],
            'distance': pos_distance,
            'similarity': similarity,
            'overlap': pos_distance <= self.window
        }

# ==============================================================================
# CLUSTERING TEST
# ==============================================================================

def test_phrase_clustering():
    """Test your hypothesis: overlapping phrases cluster together"""

    # Initialize engine
    engine = PositionHashEngine(corpus_size=1000, window=20)

    # Build a small corpus with the test phrases
    corpus_text = """
    I like you very much
    I love you so much
    I love youtube videos
    I love pizza and pasta
    fuck all this noise
    fuck you asshole
    fuck me please
    fuck me harder now
    I really like cats
    I truly love dogs
    Pizza is great
    Youtube has videos
    """

    # Ingest multiple times to create stronger patterns
    for _ in range(10):
        engine.ingest(corpus_text)

    # Test phrases
    test_phrases = [
        "I like you",
        "I love you",
        "I love youtube",
        "I love pizza",
        "fuck all this",
        "fuck you",
        "fuck me",
        "fuck me harder",
    ]

    print("=" * 100)
    print("POSITION-HASH INTERFERENCE CLUSTERING TEST")
    print("=" * 100)
    print(f"Corpus size: {len(engine.corpus)} tokens")
    print(f"Window size: {engine.window} tokens")
    print(f"Unique words: {len(engine.positions)}")
    print()

    # Get position hashes for all phrases
    print("=" * 100)
    print("PHRASE POSITION HASHES")
    print("=" * 100)

    phrase_data = {}
    for phrase in test_phrases:
        result = engine.calculate_interference(phrase.lower().split())
        if result.get('best_position') is not None:
            phrase_data[phrase] = {
                'position': result['best_position'],
                'amplitude': result['best_amplitude'],
                'peak_count': result['peak_count']
            }
            print(f"{phrase:20} → Position: {result['best_position']:5} | Amplitude: {result['best_amplitude']:.3f} | Peaks: {result['peak_count']}")
        else:
            print(f"{phrase:20} → NOT FOUND IN CORPUS")

    print()

    # Pairwise similarity matrix
    print("=" * 100)
    print("PAIRWISE SIMILARITY MATRIX")
    print("=" * 100)

    clusters = defaultdict(list)

    for i, phrase1 in enumerate(test_phrases):
        for phrase2 in test_phrases[i+1:]:
            comp = engine.compare_phrases(phrase1, phrase2)

            if comp['similarity'] > 0.5:  # Threshold for clustering
                print(f"{phrase1:20} ↔ {phrase2:20} | Sim: {comp['similarity']:.3f} | Dist: {comp['distance']:3} | {'CLUSTER' if comp['overlap'] else 'SEPARATE'}")

                # Group into clusters
                if comp['overlap']:
                    found = False
                    for cluster_id, members in clusters.items():
                        if phrase1 in members or phrase2 in members:
                            members.add(phrase1)
                            members.add(phrase2)
                            found = True
                            break
                    if not found:
                        cluster_id = len(clusters)
                        clusters[cluster_id] = {phrase1, phrase2}

    print()
    print("=" * 100)
    print("DISCOVERED CLUSTERS")
    print("=" * 100)

    for cluster_id, members in clusters.items():
        print(f"\nCluster {cluster_id}:")
        for phrase in members:
            if phrase in phrase_data:
                print(f"  - {phrase:20} (pos: {phrase_data[phrase]['position']:5}, amp: {phrase_data[phrase]['amplitude']:.3f})")

    print()
    print("=" * 100)

if __name__ == "__main__":
    test_phrase_clustering()
