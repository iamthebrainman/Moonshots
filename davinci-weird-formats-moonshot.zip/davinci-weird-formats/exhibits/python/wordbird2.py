import math
from typing import List, Tuple, Dict
from collections import defaultdict

# ==============================================================================
# UNIVERSAL 3-BYTE HASH (16M Address Space)
# ==============================================================================

PHI = 1.6180339887498948482
UNIVERSE_SIZE = 0xFFFFFF  # 16,777,215 (24-bit address space)

def hash_phrase(phrase: str) -> int:
    """Division Chain hash - 3-byte universal address"""
    h = 5381
    for char in phrase:
        h = ((h << 5) + h) ^ ord(char)
    return (h & 0xFFFFFFFF) % UNIVERSE_SIZE

def collision_step(phrase: str) -> int:
    """Golden ratio step for collision resolution"""
    h = 0
    for c in phrase:
        h = (h * 31) + ord(c)
    val = h * PHI
    fraction = val % 1
    step = int(fraction * UNIVERSE_SIZE)
    if step == 0: step = 1
    if step % 2 == 0: step += 1
    return step

# ==============================================================================
# POSITION-HASH INTERFERENCE ENGINE (3-BYTE UNIVERSE)
# ==============================================================================

class UniversalPositionHash:
    def __init__(self, window=20):
        self.window = window
        self.corpus_positions = {}  # phrase_hash -> [corpus_positions]
        self.phrase_to_hash = {}    # phrase -> hash
        self.hash_to_phrase = {}    # hash -> phrase
        self.corpus = []            # Linear corpus for position tracking
        
    def ingest(self, text: str):
        """Ingest text and track phrase positions in corpus"""
        tokens = text.lower().split()
        start_pos = len(self.corpus)
        
        # Add tokens to corpus
        self.corpus.extend(tokens)
        
        # Extract 1-grams, 2-grams, 3-grams and hash them
        for n in range(1, 4):  # 1-word, 2-word, 3-word phrases
            for i in range(len(tokens) - n + 1):
                phrase = " ".join(tokens[i:i+n])
                corpus_pos = start_pos + i
                
                # Hash the phrase to 3-byte address
                phrase_hash = hash_phrase(phrase)
                
                # Track phrase <-> hash mapping
                self.phrase_to_hash[phrase] = phrase_hash
                self.hash_to_phrase[phrase_hash] = phrase
                
                # Track corpus positions for this phrase hash
                if phrase_hash not in self.corpus_positions:
                    self.corpus_positions[phrase_hash] = []
                self.corpus_positions[phrase_hash].append(corpus_pos)
    
    def get_hash(self, phrase: str) -> int:
        """Get 3-byte hash for phrase"""
        return self.phrase_to_hash.get(phrase.lower(), hash_phrase(phrase.lower()))
    
    def get_positions(self, phrase: str) -> List[int]:
        """Get all corpus positions where phrase appears"""
        phrase_hash = self.get_hash(phrase)
        return self.corpus_positions.get(phrase_hash, [])
    
    def calculate_interference(self, phrase: str) -> Dict:
        """
        Calculate interference pattern for a phrase.
        Returns hash, positions, and amplitude scores.
        """
        positions = self.get_positions(phrase)
        phrase_hash = self.get_hash(phrase)
        
        if not positions:
            return {
                'phrase': phrase,
                'hash': phrase_hash,
                'positions': [],
                'amplitude': 0.0,
                'occurrences': 0
            }
        
        # Calculate average amplitude based on position density
        total_amplitude = 0.0
        for i, pos in enumerate(positions):
            # Find neighbors within window
            neighbors = 0
            for other_pos in positions:
                if other_pos != pos and abs(other_pos - pos) <= self.window:
                    dist = abs(other_pos - pos)
                    # Wave interference formula
                    amplitude = math.cos(math.pi * dist / self.window)
                    total_amplitude += amplitude
                    neighbors += 1
        
        avg_amplitude = total_amplitude / len(positions) if positions else 0.0
        
        return {
            'phrase': phrase,
            'hash': phrase_hash,
            'positions': positions,
            'amplitude': avg_amplitude,
            'occurrences': len(positions)
        }
    
    def compare_phrases(self, phrase1: str, phrase2: str) -> Dict:
        """
        Compare two phrases via:
        1. Hash distance (3-byte address space)
        2. Position overlap (corpus co-occurrence)
        3. Interference amplitude
        """
        hash1 = self.get_hash(phrase1)
        hash2 = self.get_hash(phrase2)
        
        pos1 = self.get_positions(phrase1)
        pos2 = self.get_positions(phrase2)
        
        # Hash distance in 3-byte space
        hash_distance = abs(hash1 - hash2)
        # Handle wraparound
        if hash_distance > UNIVERSE_SIZE // 2:
            hash_distance = UNIVERSE_SIZE - hash_distance
        
        # Position overlap (do they appear near each other in corpus?)
        overlaps = 0
        min_corpus_distance = float('inf')
        
        for p1 in pos1:
            for p2 in pos2:
                dist = abs(p1 - p2)
                if dist <= self.window:
                    overlaps += 1
                if dist < min_corpus_distance:
                    min_corpus_distance = dist
        
        # Calculate similarity
        hash_similarity = 1.0 - (hash_distance / UNIVERSE_SIZE)
        
        corpus_similarity = 0.0
        if min_corpus_distance < float('inf') and min_corpus_distance <= self.window:
            corpus_similarity = math.cos(math.pi * min_corpus_distance / self.window)
        
        # Combined similarity (weighted)
        combined_similarity = (hash_similarity * 0.3) + (corpus_similarity * 0.7)
        
        return {
            'phrase1': phrase1,
            'phrase2': phrase2,
            'hash1': f"0x{hash1:06X}",
            'hash2': f"0x{hash2:06X}",
            'hash_distance': hash_distance,
            'hash_similarity': hash_similarity,
            'corpus_overlaps': overlaps,
            'min_corpus_distance': min_corpus_distance if min_corpus_distance < float('inf') else None,
            'corpus_similarity': corpus_similarity,
            'combined_similarity': combined_similarity
        }

# ==============================================================================
# CLUSTERING TEST
# ==============================================================================

def test_3byte_clustering():
    """Test phrase clustering in 3-byte universal hash space"""
    
    engine = UniversalPositionHash(window=20)
    
    # Build corpus with test phrases (repeated for stronger patterns)
    corpus_text = """
    I like you very much
    I love you so much
    I love youtube videos
    I love pizza and pasta
    fuck all this noise
    fuck you asshole
    fuck me please
    fuck me harder now
    """
    
    for _ in range(50):  # Repeat for stronger position patterns
        engine.ingest(corpus_text)
    
    # Test phrases
    test_phrases = [
        "I like you",
        "I love you",
        "I love youtube",
        "I love pizza",
        "fuck all this",
        "fuck you",
        "fuck me",
        "fuck me harder",
    ]
    
    print("=" * 100)
    print("3-BYTE UNIVERSAL POSITION-HASH CLUSTERING TEST")
    print("=" * 100)
    print(f"Corpus size: {len(engine.corpus)} tokens")
    print(f"Window size: {engine.window} tokens")
    print(f"Hash space: 0x000000 - 0x{UNIVERSE_SIZE:06X} ({UNIVERSE_SIZE:,} positions)")
    print()
    
    # Show phrase hashes
    print("=" * 100)
    print("PHRASE 3-BYTE HASHES")
    print("=" * 100)
    
    phrase_data = {}
    for phrase in test_phrases:
        result = engine.calculate_interference(phrase)
        phrase_data[phrase] = result
        
        print(f"{phrase:20} → Hash: 0x{result['hash']:06X} | Positions: {result['occurrences']:3} | Amplitude: {result['amplitude']:.3f}")
    
    print()
    
    # Pairwise comparison
    print("=" * 100)
    print("PAIRWISE HASH & POSITION ANALYSIS")
    print("=" * 100)
    
    clusters = defaultdict(list)
    
    for i, phrase1 in enumerate(test_phrases):
        for phrase2 in test_phrases[i+1:]:
            comp = engine.compare_phrases(phrase1, phrase2)
            
            if comp['combined_similarity'] > 0.3:  # Clustering threshold
                hash_dist = comp['hash_distance']
                corpus_dist = comp['min_corpus_distance']
                
                print(f"{phrase1:20} ↔ {phrase2:20}")
                print(f"  Hash: {comp['hash1']} ↔ {comp['hash2']} (dist: {hash_dist:7,})")
                print(f"  Corpus: {corpus_dist:3} tokens | Overlaps: {comp['corpus_overlaps']:3} | Similarity: {comp['combined_similarity']:.3f}")
                print()
    
    # Group by hash proximity
    print("=" * 100)
    print("HASH SPACE CLUSTERING (sorted by hash)")
    print("=" * 100)
    
    sorted_phrases = sorted(test_phrases, key=lambda p: engine.get_hash(p))
    
    for phrase in sorted_phrases:
        data = phrase_data[phrase]
        print(f"0x{data['hash']:06X} | {phrase:20} | {data['occurrences']:3} occurrences")
    
    print()
    print("=" * 100)

if __name__ == "__main__":
    test_3byte_clustering()