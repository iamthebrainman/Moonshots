import re
from typing import List, Tuple, Dict
import pickle
from relational_system import Relations
from collections import defaultdict


def hash_phrase(phrase: str) -> int:
    """Division Chain hash - fast, low collision"""
    h = 2
    for char in phrase:
        h = (h + ord(char)) * 33
    return h % 0xFFFFFF


def collision_step(phrase: str) -> int:
    """XOR Shift for collision resolution"""
    h = len(phrase)
    return (h ^ (h << 3)) & 0xFF


class WordClassifier:
    """Complete word classification: THING, RELATION, or OPERATOR"""
    
    # Determiners/Pointers
    DETERMINERS = {
        'the': 'DEFINITE_REF',
        'a': 'INDEFINITE_REF',
        'an': 'INDEFINITE_REF',
        'this': 'PROXIMAL_REF',
        'that': 'DISTAL_REF',
        'these': 'PROXIMAL_PLURAL_REF',
        'those': 'DISTAL_PLURAL_REF',
    }
    
    # Logical Connectives
    LOGICAL_OPS = {
        'and': 'CONJUNCTION',
        'or': 'DISJUNCTION',
        'but': 'CONTRAST',
        'nor': 'NEGATIVE_CONJUNCTION',
        'yet': 'CONCESSIVE',
        'so': 'CONSEQUENCE',
    }
    
    # Conditionals
    CONDITIONALS = {
        'if': 'CONDITION',
        'then': 'CONSEQUENT',
        'else': 'ALTERNATIVE',
        'unless': 'NEGATIVE_CONDITION',
        'whether': 'CHOICE_CONDITION',
    }
    
    # Temporal Operators
    TEMPORAL_OPS = {
        'when': 'TEMPORAL_QUERY',
        'while': 'TEMPORAL_SIMULTANEOUS',
        'before': 'TEMPORAL_BEFORE',
        'after': 'TEMPORAL_AFTER',
        'until': 'TEMPORAL_UNTIL',
        'since': 'TEMPORAL_SINCE',
        'during': 'TEMPORAL_DURATION',
    }
    
    # Spatial Operators
    SPATIAL_OPS = {
        'in': 'SPATIAL_CONTAINMENT',
        'on': 'SPATIAL_CONTACT',
        'at': 'SPATIAL_LOCATION',
        'to': 'SPATIAL_DIRECTION',
        'from': 'SPATIAL_SOURCE',
        'by': 'SPATIAL_PROXIMITY',
        'near': 'SPATIAL_NEAR',
        'above': 'SPATIAL_ABOVE',
        'below': 'SPATIAL_BELOW',
        'inside': 'SPATIAL_INSIDE',
        'outside': 'SPATIAL_OUTSIDE',
    }
    
    # Causal Operators
    CAUSAL_OPS = {
        'because': 'CAUSAL_REASON',
        'therefore': 'CAUSAL_CONCLUSION',
        'thus': 'CAUSAL_RESULT',
        'hence': 'CAUSAL_INFERENCE',
    }
    
    # Quantifiers
    QUANTIFIERS = {
        'all': 'UNIVERSAL_QUANTIFIER',
        'some': 'EXISTENTIAL_QUANTIFIER',
        'many': 'PLURAL_QUANTIFIER',
        'few': 'SPARSE_QUANTIFIER',
        'none': 'NEGATIVE_QUANTIFIER',
        'every': 'DISTRIBUTIVE_QUANTIFIER',
        'each': 'INDIVIDUAL_QUANTIFIER',
        'any': 'INDEFINITE_QUANTIFIER',
    }
    
    # Possessive Operators
    POSSESSIVES = {
        'my': 'POSSESSIVE_1ST_SING',
        'your': 'POSSESSIVE_2ND',
        'his': 'POSSESSIVE_3RD_MASC',
        'her': 'POSSESSIVE_3RD_FEM',
        'its': 'POSSESSIVE_3RD_NEUT',
        'our': 'POSSESSIVE_1ST_PLUR',
        'their': 'POSSESSIVE_3RD_PLUR',
    }
    
    # All operators combined
    ALL_OPERATORS = {}
    
    @classmethod
    def _init_operators(cls):
        """Combine all operator categories"""
        if cls.ALL_OPERATORS:
            return
        
        cls.ALL_OPERATORS.update(cls.DETERMINERS)
        cls.ALL_OPERATORS.update(cls.LOGICAL_OPS)
        cls.ALL_OPERATORS.update(cls.CONDITIONALS)
        cls.ALL_OPERATORS.update(cls.TEMPORAL_OPS)
        cls.ALL_OPERATORS.update(cls.SPATIAL_OPS)
        cls.ALL_OPERATORS.update(cls.CAUSAL_OPS)
        cls.ALL_OPERATORS.update(cls.QUANTIFIERS)
        cls.ALL_OPERATORS.update(cls.POSSESSIVES)
    
    def __init__(self):
        WordClassifier._init_operators()
        self.relation_types = self._extract_relation_types()
    
    def _extract_relation_types(self) -> set:
        """Extract all relation types from Relations patterns"""
        r = Relations()
        return set(rel_type for _, rel_type in r.MULTIWORD_PATTERNS)
    
    def classify(self, word: str) -> Tuple[str, str]:
        """
        Classify a word into THING, RELATION, or OPERATOR.
        
        Returns: (class, subtype)
        Examples:
            "the" → ("OPERATOR", "DEFINITE_REF")
            "created" → ("RELATION", "CREATED")
            "god" → ("THING", "god")
        """
        word_lower = word.lower()
        
        # Check operators first (most specific)
        if word_lower in self.ALL_OPERATORS:
            return ("OPERATOR", self.ALL_OPERATORS[word_lower])
        
        # Check if it's a relation verb
        # Try to match common verb forms
        if self._is_relation_word(word_lower):
            return ("RELATION", word_lower.upper())
        
        # Default: it's a THING (noun/entity)
        return ("THING", word_lower)
    
    def _is_relation_word(self, word: str) -> bool:
        """Check if word is a relation/verb"""
        # Common verb patterns
        verb_patterns = [
            'is', 'are', 'am', 'was', 'were',
            'has', 'have', 'had',
            'can', 'could', 'will', 'would', 'shall', 'should',
            'must', 'may', 'might',
            'do', 'does', 'did',
            'make', 'makes', 'made',
            'create', 'creates', 'created',
            'give', 'gives', 'gave',
            'take', 'takes', 'took',
            'know', 'knows', 'knew',
            'like', 'likes', 'liked',
            'want', 'wants', 'wanted',
            'need', 'needs', 'needed',
            'love', 'loves', 'loved',
            'hate', 'hates', 'hated',
        ]
        
        return word in verb_patterns


class RelationalVocab:
    """Stores semantic units with complete classification"""
    
    def __init__(self):
        self.table = {}      # addr -> {phrase, class, subtype}
        self.reverse = {}    # phrase -> addr
        
        # Triple storage with classification
        self.triples = []    # List of classified triples
        self.triple_index = {}  # triple_id -> triple_data
        
        # Class indices for fast lookup
        self.by_class = defaultdict(list)  # "THING" -> [addrs]
        self.by_subtype = defaultdict(list)  # "DEFINITE_REF" -> [addrs]
        
        self.classifier = WordClassifier()
    
    def add(self, phrase: str, word_class: str = None, subtype: str = None) -> int:
        """Add phrase with classification"""
        if phrase in self.reverse:
            return self.reverse[phrase]
        
        # Auto-classify if not provided
        if word_class is None:
            word_class, subtype = self.classifier.classify(phrase)
        
        addr = hash_phrase(phrase)
        step = collision_step(phrase)
        
        probes = 0
        while addr in self.table and self.table[addr]['phrase'] != phrase:
            addr = (addr + step) % 0xFFFFFF
            probes += 1
            if probes > 10000:
                raise Exception(f"Too many collisions: {phrase}")
        
        self.table[addr] = {
            'phrase': phrase,
            'class': word_class,
            'subtype': subtype
        }
        self.reverse[phrase] = addr
        
        # Index by class
        self.by_class[word_class].append(addr)
        self.by_subtype[subtype].append(addr)
        
        return addr
    
    def add_triple(self, subj: str, rel: str, obj: str) -> Dict:
        """Add a classified triple"""
        # Classify and store each component
        subj_addr = self.add(subj) if subj else None
        rel_addr = self.add(rel, "RELATION", rel.upper()) if rel else None
        obj_addr = self.add(obj) if obj else None
        
        # Create triple with full metadata
        triple_data = {
            'subj': {'addr': subj_addr, 'phrase': subj},
            'rel': {'addr': rel_addr, 'phrase': rel},
            'obj': {'addr': obj_addr, 'phrase': obj},
            'triple_id': len(self.triples)
        }
        
        self.triples.append(triple_data)
        self.triple_index[triple_data['triple_id']] = triple_data
        
        return triple_data
    
    def get(self, addr: int) -> Dict:
        """Get phrase with classification"""
        return self.table.get(addr)
    
    def get_phrase(self, addr: int) -> str:
        """Get just the phrase string"""
        entry = self.table.get(addr)
        return entry['phrase'] if entry else None
    
    def find_by_class(self, word_class: str) -> List[str]:
        """Get all phrases of a class"""
        addrs = self.by_class.get(word_class, [])
        return [self.get_phrase(addr) for addr in addrs]
    
    def find_by_subtype(self, subtype: str) -> List[str]:
        """Get all phrases of a subtype"""
        addrs = self.by_subtype.get(subtype, [])
        return [self.get_phrase(addr) for addr in addrs]
    
    def analyze_coverage(self) -> Dict:
        """Check classification coverage"""
        total = len(self.table)
        things = len(self.by_class.get('THING', []))
        relations = len(self.by_class.get('RELATION', []))
        operators = len(self.by_class.get('OPERATOR', []))
        
        return {
            'total': total,
            'things': things,
            'relations': relations,
            'operators': operators,
            'thing_pct': (things / total * 100) if total > 0 else 0,
            'relation_pct': (relations / total * 100) if total > 0 else 0,
            'operator_pct': (operators / total * 100) if total > 0 else 0,
        }
    
    def query_by_pattern(self, subj_class=None, rel_class=None, obj_class=None):
        """Query triples by classification pattern"""
        results = []
        
        for triple in self.triples:
            match = True
            
            if subj_class:
                subj_data = self.get(triple['subj']['addr'])
                if not subj_data or subj_data['class'] != subj_class:
                    match = False
            
            if rel_class and match:
                rel_data = self.get(triple['rel']['addr'])
                if not rel_data or rel_data['subtype'] != rel_class:
                    match = False
            
            if obj_class and match:
                obj_data = self.get(triple['obj']['addr'])
                if not obj_data or obj_data['class'] != obj_class:
                    match = False
            
            if match:
                results.append((
                    triple['subj']['phrase'],
                    triple['rel']['phrase'],
                    triple['obj']['phrase']
                ))
        
        return results


def parse_with_classification(text: str, vocab: RelationalVocab) -> int:
    """Extract relations with full classification"""
    r = Relations()
    tokens = text.split()
    positions = list(range(len(tokens)))
    
    r.extract_from_tokens(tokens, positions)
    
    count = 0
    for subj, rel, obj, pos, mods in r.triples:
        vocab.add_triple(subj, rel, obj)
        count += 1
    
    return count


if __name__ == "__main__":
    vocab = RelationalVocab()
    
    # Test classification
    test_sentence = "In the beginning God created the heavens and the earth"
    
    print("=== WORD CLASSIFICATION ===")
    for word in test_sentence.split():
        word_class, subtype = vocab.classifier.classify(word)
        print(f"{word:15} → {word_class:12} : {subtype}")
    
    print("\n=== EXTRACTING FROM BIBLE ===")
    with open('bible.txt', 'r', encoding='utf-8') as f:
        text = f.read()
    
    triple_count = parse_with_classification(text, vocab)
    
    print(f"Extracted: {triple_count:,} triples")
    print(f"Vocab size: {len(vocab.table):,} unique phrases")
    
    # Analyze coverage
    coverage = vocab.analyze_coverage()
    print(f"\n=== CLASSIFICATION COVERAGE ===")
    print(f"THINGS: {coverage['things']:,} ({coverage['thing_pct']:.1f}%)")
    print(f"RELATIONS: {coverage['relations']:,} ({coverage['relation_pct']:.1f}%)")
    print(f"OPERATORS: {coverage['operators']:,} ({coverage['operator_pct']:.1f}%)")
    
    # Show sample triples
    print(f"\n=== SAMPLE CLASSIFIED TRIPLES ===")
    for i in range(min(10, len(vocab.triples))):
        triple = vocab.triples[i]
        print(f"{i}: ({triple['subj']['phrase']}, {triple['rel']['phrase']}, {triple['obj']['phrase']})")
    
    # Test pattern queries
    print(f"\n=== QUERY: All CREATED relations ===")
    created = vocab.query_by_pattern(rel_class='CREATED')
    for subj, rel, obj in created[:5]:
        print(f"  {subj} {rel} {obj}")
        # At the end of the file, replace the query section:

# Test pattern queries
print(f"\n=== QUERY: All MADE relations ===")
made = vocab.query_by_pattern(rel_class='MADE')
for subj, rel, obj in made[:10]:
    print(f"  {subj} {rel} {obj}")

print(f"\n=== ALL RELATION TYPES ===")
all_relations = vocab.find_by_class('RELATION')
relation_types = {}
for rel in all_relations:
    rel_data = vocab.get(vocab.reverse[rel])
    subtype = rel_data['subtype']
    relation_types[subtype] = relation_types.get(subtype, 0) + 1

for rel_type, count in sorted(relation_types.items(), key=lambda x: x[1], reverse=True)[:20]:
    print(f"  {rel_type}: {count}")

print(f"\n=== QUERY: Find who MADE things ===")
made_things = vocab.query_by_pattern(rel_class='MADE')
print(f"Found {len(made_things)} triples with MADE")
for subj, rel, obj in made_things[:10]:
    print(f"  {subj} → {rel} → {obj}")

print(f"\n=== QUERY: All WAS relations ===")
was_things = vocab.query_by_pattern(rel_class='WAS')
print(f"Found {len(was_things)} triples with WAS")
for subj, rel, obj in was_things[:10]:
    print(f"  {subj} → {rel} → {obj}")