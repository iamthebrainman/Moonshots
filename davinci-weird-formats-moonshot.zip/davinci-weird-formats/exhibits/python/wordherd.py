import time
import sys
import os
import random
import math

# ==============================================================================
# GOLDEN RATIO HASH (Your "God Mode" Algorithm)
# ==============================================================================

PHI = 1.6180339887498948482

def is_prime(n):
    if n <= 1: return False
    if n <= 3: return True
    if n % 2 == 0 or n % 3 == 0: return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

def next_prime(n):
    if n % 2 == 0: n += 1
    while not is_prime(n):
        n += 2
    return n

def hash_division_xor(key, table_size):
    h = 5381
    for char in key:
        h = ((h << 5) + h) ^ ord(char)
    return (h & 0xFFFFFFFF) % table_size

def step_golden_ratio(key, table_size):
    h = 0
    for c in key: h = (h * 31) + ord(c)
    val = h * PHI
    fraction = val % 1
    step = int(fraction * table_size)
    if step == 0: step = 1
    if step % 2 == 0: step += 1
    return step

# ==============================================================================
# PHRASE EXTRACTION
# ==============================================================================

def extract_ngrams(text, n):
    """Extract all n-word phrases from text."""
    words = text.lower().split()
    words = ["".join(c for c in w if c.isalpha()) for w in words]
    words = [w for w in words if w]
    
    if n == 1:
        return list(set(words))
    
    phrases = []
    for i in range(len(words) - n + 1):
        phrase = " ".join(words[i:i+n])
        phrases.append(phrase)
    
    return list(set(phrases))

# ==============================================================================
# STRESS TEST
# ==============================================================================

def run_stress_test(phrases, load_factor, sector_name=""):
    count = len(phrases)
    raw_size = int(count / load_factor)
    table_size = next_prime(raw_size)
    actual_load = count / table_size
    
    table = [None] * table_size
    collisions = 0
    total_probes = 0
    max_probes = 0
    probe_histogram = [0] * 10  # Track probes 0-9+
    
    start_time = time.perf_counter()
    
    for phrase in phrases:
        idx = hash_division_xor(phrase, table_size)
        
        if table[idx] is None:
            table[idx] = phrase
            probe_histogram[0] += 1
            continue
        
        collisions += 1
        probes = 0
        step = step_golden_ratio(phrase, table_size)
        curr = idx
        
        while table[curr] is not None:
            probes += 1
            curr = (curr + step) % table_size
            if probes > 5000: return None
            if curr == idx: return None
        
        table[curr] = phrase
        total_probes += probes
        if probes > max_probes: max_probes = probes
        
        # Histogram
        hist_idx = min(probes, 9)
        probe_histogram[hist_idx] += 1
    
    duration = time.perf_counter() - start_time
    
    return {
        "sector": sector_name,
        "phrase_count": count,
        "load_factor": actual_load,
        "table_size": table_size,
        "avg_probes": total_probes / count if count else 0,
        "max_probes": max_probes,
        "collisions": collisions,
        "duration": duration,
        "histogram": probe_histogram
    }

# ==============================================================================
# MAIN BENCHMARK
# ==============================================================================

def main():
    if not os.path.exists("bible.txt"):
        print("[!] bible.txt not found!")
        return
    
    print("[-] Loading bible.txt...")
    with open("bible.txt", 'r', encoding='utf-8') as f:
        text = f.read()
    
    print("\n" + "="*100)
    print("SEMANTIC TIER DENSITY BENCHMARK")
    print("="*100)
    
    # Test each tier separately
    tiers = [
        ("SINGULARS (1-word)", 1),
        ("DOUBLES (2-word)", 2),
        ("TRIPLES (3-word)", 3),
    ]
    
    load_factors = [0.50, 0.75, 0.85, 0.90, 0.95, 0.98]
    
    for tier_name, n in tiers:
        print(f"\n{'='*100}")
        print(f"TIER: {tier_name}")
        print(f"{'='*100}")
        
        phrases = extract_ngrams(text, n)
        print(f"Extracted: {len(phrases):,} unique {n}-grams\n")
        
        print(f"{'Load%':<8} | {'Actual%':<8} | {'Table':<10} | {'Avg Probe':<10} | {'Max Probe':<10} | {'Collisions':<12} | {'Time':<8}")
        print("-" * 100)
        
        for lf in load_factors:
            res = run_stress_test(phrases, lf, tier_name)
            
            if res is None:
                print(f"{lf*100:.0f}%      | CRASHED")
            else:
                max_marker = f"! {res['max_probes']} !" if res['max_probes'] > 100 else str(res['max_probes'])
                print(f"{lf*100:.0f}%      | {res['load_factor']*100:.1f}%     | {res['table_size']:<10} | {res['avg_probes']:<10.4f} | {max_marker:<10} | {res['collisions']:<12} | {res['duration']:.4f}s")
        
        print()
    
    print("="*100)
    print("\nRECOMMENDED SECTOR SIZES:")
    print("-" * 100)
    
    # Calculate recommendations based on actual phrase counts
    singles = len(extract_ngrams(text, 1))
    doubles = len(extract_ngrams(text, 2))
    triples = len(extract_ngrams(text, 3))
    
    # Add 50% headroom for growth, round to nice numbers
    rec_singles = int(singles * 1.5 / 1000) * 1000
    rec_doubles = int(doubles * 1.5 / 1000) * 1000
    rec_triples = int(triples * 1.5 / 1000) * 1000
    
    total_semantic = rec_singles + rec_doubles + rec_triples
    remaining = 16_777_216 - total_semantic
    
    print(f"Singulars:  {rec_singles:>10,} slots  (0x{0:06X} - 0x{rec_singles:06X})")
    print(f"Doubles:    {rec_doubles:>10,} slots  (0x{rec_singles:06X} - 0x{rec_singles+rec_doubles:06X})")
    print(f"Triples:    {rec_triples:>10,} slots  (0x{rec_singles+rec_doubles:06X} - 0x{total_semantic:06X})")
    print(f"            {'-'*10}")
    print(f"SEMANTIC:   {total_semantic:>10,} slots")
    print(f"AVAILABLE:  {remaining:>10,} slots  (0x{total_semantic:06X} - 0xFFFFFF)")
    print(f"            {'-'*10}")
    print(f"TOTAL:      {16_777_216:>10,} slots\n")
    print(f"Machine code space: {remaining/1_000_000:.1f}M slots ({remaining/16_777_216*100:.1f}% of address space)")
    print("="*100)

if __name__ == "__main__":
    main()