import time
import sys
import os
import random
import math

# ==============================================================================
# 1. CORE LOGIC (The "God Mode" Algorithms)
# ==============================================================================

# Exact Golden Ratio (The irrational constant)
PHI = 1.6180339887498948482

def is_prime(n):
    """Simple check to ensure table size is prime."""
    if n <= 1: return False
    if n <= 3: return True
    if n % 2 == 0 or n % 3 == 0: return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

def next_prime(n):
    """Finds the next prime number >= n."""
    if n % 2 == 0: n += 1
    while not is_prime(n):
        n += 2
    return n

def hash_division_xor_chain(key, table_size):
    """
    Primary Hash: Division-XOR Chain.
    Creates high-turbulence bitwise mixing.
    """
    h = 5381 # Common djb2 start seed
    for char in key:
        # The "Chain": (h * 33) ^ char
        # Shifts bits left, adds h, then XORs the character data
        h = ((h << 5) + h) ^ ord(char)
    
    # Force positive and map to table
    return (h & 0xFFFFFFFF) % table_size

def step_golden_ratio(key, table_size):
    """
    Collision Step: The 'God Mode' Golden Ratio.
    Uses floating-point irrationality to generate a unique stride 
    that mathematically cannot resonate with integer table sizes.
    """
    # 1. Get a raw integer signature (Standard polynomial)
    h = 0
    for c in key: h = (h * 31) + ord(c)
    
    # 2. Golden Ratio Multiplication (Float Math)
    # The result is a messy float with infinite non-repeating decimals
    val = h * PHI
    
    # 3. Extract the Fractional Entropy
    # We drop the integer and keep the chaotic tail (e.g. 0.56789...)
    fraction = val % 1
    
    # 4. Map to Table Size
    # Jump 'fraction' of the way around the table
    step = int(fraction * table_size)
    
    # 5. Safety: Step must be non-zero and ODD
    if step == 0: step = 1
    if step % 2 == 0: step += 1
    
    return step

# ==============================================================================
# 2. TEST BENCH
# ==============================================================================

def run_stress_test(words, load_factor):
    count = len(words)
    
    # 1. Calculate Prime Table Size
    raw_size = int(count / load_factor)
    table_size = next_prime(raw_size)
    
    # Recalculate actual load factor based on prime size
    actual_load = count / table_size
    
    table = [None] * table_size
    collisions = 0
    total_probes = 0
    max_probes = 0
    start_time = time.perf_counter()
    
    for word in words:
        # A. Primary Hash
        idx = hash_division_xor_chain(word, table_size)
        
        # B. Fast Path (Empty Slot)
        if table[idx] is None:
            table[idx] = word
            continue
            
        # C. Collision Path (Golden Spiral)
        collisions += 1
        probes = 0
        step = step_golden_ratio(word, table_size)
        
        curr = idx
        while table[curr] is not None:
            probes += 1
            curr = (curr + step) % table_size
            
            # Hard Safety
            if probes > 5000: return None 
            if curr == idx: return None

        table[curr] = word
        total_probes += probes
        if probes > max_probes: max_probes = probes
        
    duration = time.perf_counter() - start_time
    
    return {
        "load_factor": actual_load,
        "table_size": table_size,
        "avg_probes": total_probes / count,
        "max_probes": max_probes,
        "collisions": collisions,
        "duration": duration
    }

# ==============================================================================
# 3. DATA LOADER
# ==============================================================================

def get_bible_data():
    filename = "bible.txt"
    if os.path.exists(filename):
        print(f"[-] Loading real '{filename}'...")
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                # Simple cleanup: lowercase, alpha only
                text = f.read().lower()
                clean_words = []
                for w in text.split():
                    # Strip punctuation
                    w = "".join(c for c in w if c.isalpha())
                    if w: clean_words.append(w)
                
                unique_words = list(set(clean_words))
                print(f"[-] Loaded {len(unique_words):,} unique words.")
                return unique_words
        except Exception as e:
            print(f"[!] Error: {e}")
    
    print(f"[!] '{filename}' not found. Generating synthetic corpus...")
    data = set()
    chars = "abcdefghijklmnopqrstuvwxyz"
    # Generate 150k unique words to match your load
    while len(data) < 150000:
        w = "".join(random.choices(chars, k=random.randint(3, 10)))
        data.add(w)
    return list(data)

# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == "__main__":
    words = get_bible_data()
    word_count = len(words)
    
    load_factors = [0.50, 0.75, 0.85, 0.90, 0.95, 0.98, 0.99]
    
    print("\n" + "="*95)
    print(f"BENCHMARK: Division-XOR + Golden Ratio Float Step + Prime Table")
    print(f"CORPUS:    {word_count:,} unique words")
    print("="*95)
    print(f"{'Target':<8} | {'Actual %':<8} | {'Table Size':<12} | {'Avg Probe':<10} | {'Max Probe':<10} | {'Collisions':<12} | {'Time'}")
    print("-" * 95)
    
    for lf in load_factors:
        res = run_stress_test(words, lf)
        
        if res is None:
            print(f"{lf*100:.1f}%    | CRASHED")
        else:
            max_p = res['max_probes']
            max_s = f"{max_p}"
            if max_p > 100: max_s = f"! {max_p} !"
            
            print(f"{lf*100:.1f}%    | {res['load_factor']*100:.1f}%    | {res['table_size']:<12} | {res['avg_probes']:<10.4f} | {max_s:<10} | {res['collisions']:<12} | {res['duration']:.4f}s")
            
    print("="*95)