import time
from typing import List, Optional

import chromadb

# ==============================================================================
# CHROMADB SIMPLE TEST (Just the vector search, no fancy settings)
# ==============================================================================


def extract_ngrams(text: str, n: int) -> List[str]:
    """Extract all n-word phrases from text"""
    words = text.lower().split()
    words = ["".join(c for c in w if c.isalpha()) for w in words]
    words = [w for w in words if w]

    phrases = []
    for i in range(len(words) - n + 1):
        phrase = " ".join(words[i : i + n])
        phrases.append(phrase)

    return phrases


def test_chromadb():
    """Test ChromaDB with minimal configuration"""
    try:
        import chromadb
    except ImportError:
        print("ChromaDB not installed. Skipping.")
        return

    print("=" * 100)
    print("CHROMADB RAG VECTOR SEARCH BENCHMARK")
    print("=" * 100)

    # Load Genesis
    with open("bible.txt", "r", encoding="utf-8") as f:
        text = f.read()

    print(f"[-] Loaded {len(text):,} characters\n")

    # Initialize with simplest possible config
    print("[-] Initializing ChromaDB client...")
    init_start = time.perf_counter()

    try:
        client = chromadb.Client()  # In-memory, no persistence
        collection = client.create_collection(
            name="genesis_test", metadata={"hnsw:space": "cosine"}
        )
    except Exception as e:
        print(f"[!] Failed to initialize: {e}")
        return

    init_time = time.perf_counter() - init_start
    print(f"[-] Client initialized in {init_time:.4f}s\n")

    # Extract phrases
    print("[-] Extracting phrases...")
    phrases = []
    for n in [2, 3]:
        phrases.extend(extract_ngrams(text, n))

    unique_phrases = list(set(phrases))
    print(f"[-] Extracted {len(unique_phrases):,} unique phrases\n")

    # Build index (this is the slow part)
    print("[-] Building vector index (generating embeddings)...")
    build_start = time.perf_counter()

    batch_size = 100
    total_added = 0

    try:
        for i in range(0, len(unique_phrases), batch_size):
            batch = unique_phrases[i : i + batch_size]
            ids = [f"phrase_{j}" for j in range(i, i + len(batch))]

            collection.add(documents=batch, ids=ids)

            total_added += len(batch)

            if total_added % 1000 == 0:
                print(f"  ... {total_added:,} phrases indexed")

    except Exception as e:
        print(f"[!] Error during indexing: {e}")
        return

    build_time = time.perf_counter() - build_start

    print(f"[-] Indexing complete in {build_time:.4f}s")
    print(f"    Rate: {total_added / build_time:.1f} phrases/second\n")

    # Query tests (semantic similarity - what ChromaDB is designed for)
    print("=" * 100)
    print("SEMANTIC SIMILARITY QUERIES (ChromaDB's Strength)")
    print("=" * 100)

    test_queries = [
        "god created the world",
        "divine speech and command",
        "in the beginning of time",
        "people and humanity",
    ]

    query_times = []

    for query in test_queries:
        print(f"\nQuery: '{query}'")

        start = time.perf_counter()
        try:
            results = collection.query(query_texts=[query], n_results=10)
            query_time = time.perf_counter() - start
            query_times.append(query_time)

            print(f"Time: {query_time * 1000:.3f}ms")

            if results and results["documents"] and results["documents"][0]:
                for i, phrase in enumerate(results["documents"][0][:5], 1):
                    distance = (
                        results["distances"][0][i - 1] if results["distances"] else 0
                    )
                    print(f"  {i}. {phrase} (distance: {distance:.3f})")
            else:
                print("  (no results)")

        except Exception as e:
            print(f"  Error: {e}")

    # Benchmark (repeated queries)
    print("\n" + "=" * 100)
    print("SPEED BENCHMARK (100 queries)")
    print("=" * 100)

    benchmark_query = "god created heaven"
    iterations = 100

    print(f"Running '{benchmark_query}' {iterations} times...")

    bench_start = time.perf_counter()

    try:
        for _ in range(iterations):
            collection.query(query_texts=[benchmark_query], n_results=10)
    except Exception as e:
        print(f"Benchmark failed: {e}")
        return

    bench_time = time.perf_counter() - bench_start
    avg_query_time = (bench_time / iterations) * 1000

    print(f"Average query time: {avg_query_time:.3f}ms")
    print(f"Queries per second: {iterations / bench_time:.1f}")

    # Summary
    print("\n" + "=" * 100)
    print("CHROMADB SUMMARY")
    print("=" * 100)
    print(f"Initialization: {init_time:.4f}s")
    print(f"Indexing time: {build_time:.4f}s ({total_added:,} phrases)")
    print(f"Indexing rate: {total_added / build_time:.1f} phrases/sec")
    print(f"Average query: {avg_query_time:.3f}ms")
    print(f"Query throughput: {iterations / bench_time:.1f} queries/sec")
    print("=" * 100)


def test_your_hash():
    """Quick comparison with your hash table"""
    from collections import defaultdict

    print("\n" + "=" * 100)
    print("YOUR TRIPLE-LAYER HASH (Quick Comparison)")
    print("=" * 100)

    # Load Genesis
    with open("bible.txt", "r", encoding="utf-8") as f:
        text = f.read()

    # Simple hash implementation
    def hash_word(word):
        h = 5381
        for char in word.lower():
            h = ((h << 5) + h) ^ ord(char)
        return h & 0xFFFFFFFFFFFFFFFF

    # Build index
    print("[-] Building hash index...")
    build_start = time.perf_counter()

    layer_0 = defaultdict(set)
    layer_1 = defaultdict(set)
    layer_2 = defaultdict(set)
    phrases = {}

    phrase_id = 0
    for n in [2, 3]:
        for phrase in extract_ngrams(text, n):
            words = phrase.split()

            if len(words) >= 1:
                layer_0[hash_word(words[0])].add(phrase_id)
            if len(words) >= 2:
                layer_1[hash_word(words[1])].add(phrase_id)
            if len(words) >= 3:
                layer_2[hash_word(words[2])].add(phrase_id)

            phrases[phrase_id] = phrase
            phrase_id += 1

    build_time = time.perf_counter() - build_start

    print(f"[-] Indexed {len(phrases):,} phrases in {build_time:.4f}s")
    print(f"    Rate: {len(phrases) / build_time:.1f} phrases/sec\n")

    # Benchmark
    print("[-] Running benchmark (1000 queries)...")

    iterations = 1000
    bench_start = time.perf_counter()

    for _ in range(iterations):
        # Query: "god" in position 0
        h = hash_word("god")
        results = layer_0.get(h, set())

    bench_time = time.perf_counter() - bench_start
    avg_query_time = (bench_time / iterations) * 1000

    print(f"Average query time: {avg_query_time:.6f}ms")
    print(f"Queries per second: {iterations / bench_time:,.0f}")
    print("=" * 100)


if __name__ == "__main__":
    test_chromadb()
    test_your_hash()
