import time
from typing import List, Dict, Set, Optional
from collections import defaultdict

# ==============================================================================
# TRIPLE-LAYER POSITION HASH (Wildcard Search Engine)
# ==============================================================================

PHI = 1.6180339887498948482

def hash_word_64bit(word: str) -> int:
    """Hash single word to 64-bit address"""
    h = 5381
    for char in word.lower():
        h = ((h << 5) + h) ^ ord(char)
    return h & 0xFFFFFFFFFFFFFFFF

class TripleLayerHashTable:
    """
    Three independent 64-bit hash layers for wildcard phrase search.
    Each layer hashes one word position in 2-gram and 3-gram phrases.
    """
    
    def __init__(self):
        # Three layers: word position 0, 1, 2
        self.layer_0 = defaultdict(set)  # hash(word_0) -> {phrase_ids}
        self.layer_1 = defaultdict(set)  # hash(word_1) -> {phrase_ids}
        self.layer_2 = defaultdict(set)  # hash(word_2) -> {phrase_ids}
        
        # Master storage
        self.phrases = {}  # phrase_id -> phrase_text
        self.phrase_to_id = {}  # phrase_text -> phrase_id
        
        # Stats
        self.insert_count = 0
    
    def insert(self, phrase: str) -> int:
        """Insert phrase and index by word positions"""
        phrase = phrase.lower().strip()
        
        # Skip if already exists
        if phrase in self.phrase_to_id:
            return self.phrase_to_id[phrase]
        
        # Generate new ID
        phrase_id = self.insert_count
        self.insert_count += 1
        
        # Store phrase
        self.phrases[phrase_id] = phrase
        self.phrase_to_id[phrase] = phrase_id
        
        # Split into words
        words = phrase.split()
        
        # Hash each word position
        if len(words) >= 1:
            h0 = hash_word_64bit(words[0])
            self.layer_0[h0].add(phrase_id)
        
        if len(words) >= 2:
            h1 = hash_word_64bit(words[1])
            self.layer_1[h1].add(phrase_id)
        
        if len(words) >= 3:
            h2 = hash_word_64bit(words[2])
            self.layer_2[h2].add(phrase_id)
        
        return phrase_id
    
    def query(self, 
              word_0: Optional[str] = None,
              word_1: Optional[str] = None, 
              word_2: Optional[str] = None,
              limit: int = 100) -> List[str]:
        """
        Wildcard search across phrase positions.
        None = wildcard (matches anything)
        
        Examples:
            query("god", None, None)     → "god created...", "god said...", etc.
            query(None, "created", None) → "god created...", "man created...", etc.
            query("in", "the", None)     → "in the beginning", "in the garden", etc.
        """
        candidates = None
        
        # Layer 0 filter
        if word_0 is not None:
            h0 = hash_word_64bit(word_0)
            if h0 in self.layer_0:
                candidates = self.layer_0[h0].copy()
            else:
                return []  # No matches
        
        # Layer 1 filter
        if word_1 is not None:
            h1 = hash_word_64bit(word_1)
            if h1 in self.layer_1:
                layer_1_matches = self.layer_1[h1]
                if candidates is None:
                    candidates = layer_1_matches.copy()
                else:
                    candidates &= layer_1_matches
            else:
                return []
        
        # Layer 2 filter
        if word_2 is not None:
            h2 = hash_word_64bit(word_2)
            if h2 in self.layer_2:
                layer_2_matches = self.layer_2[h2]
                if candidates is None:
                    candidates = layer_2_matches.copy()
                else:
                    candidates &= layer_2_matches
            else:
                return []
        
        # If no filters provided, return all
        if candidates is None:
            candidates = set(self.phrases.keys())
        
        # Convert to phrases (with limit)
        results = []
        for phrase_id in list(candidates)[:limit]:
            results.append(self.phrases[phrase_id])
        
        return results
    
    def stats(self) -> Dict:
        """Get table statistics"""
        return {
            "total_phrases": len(self.phrases),
            "layer_0_buckets": len(self.layer_0),
            "layer_1_buckets": len(self.layer_1),
            "layer_2_buckets": len(self.layer_2),
            "avg_phrases_per_bucket_0": sum(len(v) for v in self.layer_0.values()) / len(self.layer_0) if self.layer_0 else 0,
            "avg_phrases_per_bucket_1": sum(len(v) for v in self.layer_1.values()) / len(self.layer_1) if self.layer_1 else 0,
            "avg_phrases_per_bucket_2": sum(len(v) for v in self.layer_2.values()) / len(self.layer_2) if self.layer_2 else 0,
        }

# ==============================================================================
# PHRASE EXTRACTION FROM TEXT
# ==============================================================================

def extract_ngrams(text: str, n: int) -> List[str]:
    """Extract all n-word phrases from text"""
    words = text.lower().split()
    words = ["".join(c for c in w if c.isalpha()) for w in words]
    words = [w for w in words if w]
    
    if n == 1:
        return list(set(words))
    
    phrases = []
    for i in range(len(words) - n + 1):
        phrase = " ".join(words[i:i+n])
        phrases.append(phrase)
    
    return phrases

# ==============================================================================
# MAIN TEST
# ==============================================================================

def main():
    print("="*100)
    print("TRIPLE-LAYER WILDCARD HASH SEARCH ENGINE")
    print("="*100)
    
    # Load Genesis
    with open("bible.txt", 'r', encoding='utf-8') as f:
        text = f.read()
    
    print(f"[-] Loaded {len(text):,} characters\n")
    
    # Build hash table
    print("[-] Building triple-layer hash table...")
    table = TripleLayerHashTable()
    
    start = time.perf_counter()
    
    # Extract and insert 2-grams and 3-grams
    for n in [2, 3]:
        phrases = extract_ngrams(text, n)
        for phrase in phrases:
            table.insert(phrase)
    
    build_time = time.perf_counter() - start
    
    # Stats
    stats = table.stats()
    print(f"[-] Build complete in {build_time:.4f}s\n")
    print("="*100)
    print("TABLE STATISTICS")
    print("="*100)
    print(f"Total phrases indexed: {stats['total_phrases']:,}")
    print(f"Layer 0 hash buckets: {stats['layer_0_buckets']:,}")
    print(f"Layer 1 hash buckets: {stats['layer_1_buckets']:,}")
    print(f"Layer 2 hash buckets: {stats['layer_2_buckets']:,}")
    print(f"Avg phrases/bucket (L0): {stats['avg_phrases_per_bucket_0']:.2f}")
    print(f"Avg phrases/bucket (L1): {stats['avg_phrases_per_bucket_1']:.2f}")
    print(f"Avg phrases/bucket (L2): {stats['avg_phrases_per_bucket_2']:.2f}")
    print()
    
    # Test queries
    print("="*100)
    print("WILDCARD QUERY TESTS")
    print("="*100)
    
    test_queries = [
        ("god", None, None, "All phrases starting with 'god'"),
        (None, "created", None, "All phrases with 'created' in position 2"),
        ("in", "the", None, "All 'in the [BLANK]' phrases"),
        ("and", "god", None, "All 'and god [BLANK]' phrases"),
        (None, None, "heaven", "All phrases ending with 'heaven'"),
        ("god", "said", None, "All 'god said [BLANK]' phrases"),
        (None, "was", None, "All phrases with 'was' in middle"),
    ]
    
    for word_0, word_1, word_2, description in test_queries:
        print(f"\n{description}:")
        print(f"Query: ({word_0 or 'ANY'}, {word_1 or 'ANY'}, {word_2 or 'ANY'})")
        
        start = time.perf_counter()
        results = table.query(word_0, word_1, word_2, limit=15)
        query_time = time.perf_counter() - start
        
        print(f"Found {len(results)} matches in {query_time*1000:.3f}ms")
        
        if results:
            for i, phrase in enumerate(results[:10], 1):
                print(f"  {i}. {phrase}")
            if len(results) > 10:
                print(f"  ... and {len(results)-10} more")
        else:
            print("  (no matches)")
        print()
    
    # Speed benchmark
    print("="*100)
    print("SPEED BENCHMARK (1000 queries)")
    print("="*100)
    
    queries = [
        ("god", None, None),
        (None, "created", None),
        ("in", "the", None),
    ]
    
    for word_0, word_1, word_2 in queries:
        iterations = 1000
        start = time.perf_counter()
        
        for _ in range(iterations):
            table.query(word_0, word_1, word_2, limit=100)
        
        total_time = time.perf_counter() - start
        avg_time = (total_time / iterations) * 1000
        
        print(f"Query ({word_0 or 'ANY'}, {word_1 or 'ANY'}, {word_2 or 'ANY'}): {avg_time:.3f}ms avg")
    
    print("\n" + "="*100)

if __name__ == "__main__":
    main()