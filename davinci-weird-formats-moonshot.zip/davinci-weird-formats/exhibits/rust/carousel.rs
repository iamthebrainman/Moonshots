//! # 8-Bit Carousel Encoder
//!
//! Each character → 1 byte: `[3-bit cartridge | 5-bit char_id]`
//!
//! Cartridge 0 (000): lowercase a-z + common punctuation (32 slots)
//! Cartridge 1 (001): uppercase A-Z + extended punctuation (32 slots)
//! Cartridge 2 (010): digits 0-9 + math symbols (32 slots)
//! Cartridge 3 (011): whitespace + control chars (32 slots)
//! Cartridges 4-7: reserved for expansion (unicode blocks, emoji, etc.)
//!
//! The raw binary output feeds directly into the hash function —
//! no UTF-8 decoding, no abstraction layers, just bits.

/// Cartridge 0: lowercase + common punctuation
const CART_0: [char; 32] = [
    'a','b','c','d','e','f','g','h','i','j','k','l','m',
    'n','o','p','q','r','s','t','u','v','w','x','y','z',
    '.',',','!','?',';',':',
];

/// Cartridge 1: uppercase + extended punctuation
const CART_1: [char; 32] = [
    'A','B','C','D','E','F','G','H','I','J','K','L','M',
    'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    '"','\'','-','(',')','/',
];

/// Cartridge 2: digits + math/programming symbols
const CART_2: [char; 32] = [
    '0','1','2','3','4','5','6','7','8','9',
    '+','-','*','/','=','<','>','%','&','|',
    '^','~','@','#','$','\\','{','}','[',']',
    '`','_',
];

/// Cartridge 3: whitespace + structural
const CART_3: [char; 32] = [
    ' ','\t','\n','\r',
    // The rest are reserved/unused slots — map to space
    ' ',' ',' ',' ',' ',' ',' ',' ',
    ' ',' ',' ',' ',' ',' ',' ',' ',
    ' ',' ',' ',' ',' ',' ',' ',' ',
    ' ',' ',' ',' ',
];

/// All cartridges in order for lookup
const CARTRIDGES: [&[char; 32]; 4] = [&CART_0, &CART_1, &CART_2, &CART_3];

/// Encode a single character into an 8-bit carousel byte.
/// Returns `(cartridge_id, char_id)` packed as `(cart << 5) | char_id`.
#[inline(always)]
pub fn encode_char(c: char) -> u8 {
    // Fast path: lowercase ASCII (most common case)
    if c >= 'a' && c <= 'z' {
        return (c as u8) - b'a'; // cartridge 0, char_id 0-25
    }
    // Fast path: uppercase ASCII
    if c >= 'A' && c <= 'Z' {
        return (1 << 5) | ((c as u8) - b'A'); // cartridge 1, char_id 0-25
    }
    // Fast path: digits
    if c >= '0' && c <= '9' {
        return (2 << 5) | ((c as u8) - b'0'); // cartridge 2, char_id 0-9
    }
    // Fast path: space
    if c == ' ' {
        return 3 << 5; // cartridge 3, char_id 0
    }

    // Slow path: scan cartridges for punctuation/symbols
    for (cart_idx, cart) in CARTRIDGES.iter().enumerate() {
        if let Some(pos) = cart.iter().position(|&ch| ch == c) {
            return ((cart_idx as u8) << 5) | (pos as u8);
        }
    }

    // Unknown character → cartridge 0, slot 31 (reserved "unknown" marker)
    0b000_11111
}

/// Decode an 8-bit carousel byte back to a character.
#[inline(always)]
pub fn decode_byte(byte: u8) -> char {
    let cart = ((byte >> 5) & 0b111) as usize;
    let char_id = (byte & 0b11111) as usize;
    if cart < 4 {
        CARTRIDGES[cart][char_id]
    } else {
        '?' // Future cartridges
    }
}

/// Encode a full string into carousel bytes.
/// This is the raw binary representation that feeds the hash.
#[inline]
pub fn encode_string(s: &str) -> Vec<u8> {
    s.chars().map(encode_char).collect()
}

/// Encode a string into a fixed-size buffer (no allocation).
/// Returns the number of bytes written.
#[inline]
pub fn encode_string_fixed(s: &str, buf: &mut [u8; 64]) -> usize {
    let mut i = 0;
    for c in s.chars() {
        if i >= 64 { break; }
        buf[i] = encode_char(c);
        i += 1;
    }
    i
}

/// Decode carousel bytes back to a string.
pub fn decode_bytes(bytes: &[u8]) -> String {
    bytes.iter().map(|&b| decode_byte(b)).collect()
}

/// The Carousel8 struct from your existing code — packs up to 8 chars into a u64.
/// Slot 0 = LSB, Slot 7 = MSB.
#[derive(Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct Carousel8 {
    pub packed: u64,
}

impl Carousel8 {
    /// Encode a word (up to 8 chars) into a packed u64.
    #[inline]
    pub fn from_word(word: &str) -> Self {
        let mut packed: u64 = 0;
        for (i, c) in word.chars().enumerate().take(8) {
            packed |= (encode_char(c) as u64) << (i * 8);
        }
        Self { packed }
    }

    #[inline(always)]
    pub fn as_u64(self) -> u64 {
        self.packed
    }

    /// Debug representation
    pub fn pretty(self) -> String {
        let mut parts = Vec::new();
        for slot in 0..8 {
            let byte = ((self.packed >> (slot * 8)) & 0xFF) as u8;
            let cart = (byte >> 5) & 0b111;
            let char_id = byte & 0b11111;
            let ch = decode_byte(byte);
            parts.push(format!("{}[c{}:{}]", ch, cart, char_id));
        }
        parts.join(" ")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_roundtrip() {
        let words = ["hello", "World", "test123", "Hello, World!", "the dog is"];
        for w in &words {
            let encoded = encode_string(w);
            let decoded = decode_bytes(&encoded);
            // Lowercase roundtrips perfectly; case is preserved via cartridges
            assert_eq!(&decoded, w, "Roundtrip failed for '{}'", w);
        }
    }

    #[test]
    fn test_carousel8_packing() {
        let c = Carousel8::from_word("cat");
        let packed = c.as_u64();
        // 'c' = cart 0, id 2 = 0b000_00010 = 0x02
        // 'a' = cart 0, id 0 = 0b000_00000 = 0x00
        // 't' = cart 0, id 19 = 0b000_10011 = 0x13
        assert_eq!(packed & 0xFF, 0x02);
        assert_eq!((packed >> 8) & 0xFF, 0x00);
        assert_eq!((packed >> 16) & 0xFF, 0x13);
    }

    #[test]
    fn test_encode_char_fast_paths() {
        // Lowercase
        assert_eq!(encode_char('a'), 0);
        assert_eq!(encode_char('z'), 25);
        // Uppercase
        assert_eq!(encode_char('A'), 0b001_00000);
        assert_eq!(encode_char('Z'), 0b001_11001);
        // Digits
        assert_eq!(encode_char('0'), 0b010_00000);
        assert_eq!(encode_char('9'), 0b010_01001);
        // Space
        assert_eq!(encode_char(' '), 0b011_00000);
    }
}
