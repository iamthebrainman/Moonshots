//! # .crsl File Loading Integration
//!
//! Integrates memory-mapped .crsl file loading with the Word Engine
//! for instant corpus ingestion without copying or parsing overhead.

use std::path::Path;
use crate::persist::MappedTable;
use crate::word_engine::WordEngine;
use crate::table::SlotKind;
use std::fs::OpenOptions;
use std::io::{Seek, SeekFrom, Write};
use crate::table::Slot;

// --- Streaming CRSL format constants (sedimentary stream) -----------------
const STREAM_MAGIC: [u8; 8] = [b'C', b'R', b'S', b'L', b'S', b'T', b'R', b'M'];
const STREAM_VERSION: u32 = 1;
const STREAM_HEADER_SIZE: usize = 40; // per spec (compact header)

/// Write a sedimentary CRSL *stream* file. This is a compact, append-only
/// format where each record is written as: [u32 slot_index][Slot (40 bytes)].
/// If `write_index` is true, a compact index (slot_index -> file_offset)
/// is appended and the header.index_offset updated.
pub fn save_crsl_stream(path: impl AsRef<Path>, entries: &[(u32, Slot)], write_index: bool) -> Result<u64, Box<dyn std::error::Error>> {
    let path = path.as_ref();
    let mut f = OpenOptions::new().create(true).write(true).truncate(true).open(path)?;

    // --- Header (40 bytes) ---
    // magic (8), version (4), reserved/timestamp (8), index_offset (8), reserved (12) = 40
    f.write_all(&STREAM_MAGIC)?;                       // 0..8
    f.write_all(&STREAM_VERSION.to_le_bytes())?;      // 8..12
    f.write_all(&0u64.to_le_bytes())?;                // 12..20 reserved/timestamp
    f.write_all(&0u64.to_le_bytes())?;                // 20..28 index_offset (filled later)
    f.write_all(&[0u8; 12])?;                         // 28..40 reserved

    // Write stream entries sequentially and remember offsets
    let mut offsets: Vec<(u32, u64)> = Vec::new();
    for (slot_idx, slot) in entries.iter() {
        let offset = f.stream_position()?;
        offsets.push((*slot_idx, offset));

        f.write_all(&slot_idx.to_le_bytes())?;
        // Slot is repr(C) and 40 bytes — write raw bytes
        let slot_bytes: &[u8] = unsafe { std::slice::from_raw_parts(slot as *const Slot as *const u8, std::mem::size_of::<Slot>()) };
        f.write_all(slot_bytes)?;
    }

    // Append index if requested
    let index_offset = if write_index {
        let idx_off = f.stream_position()?;
        let entry_count = offsets.len() as u32;
        f.write_all(&entry_count.to_le_bytes())?;
        for (slot_idx, off) in &offsets {
            f.write_all(&slot_idx.to_le_bytes())?;
            f.write_all(&off.to_le_bytes())?;
        }
        Some(idx_off)
    } else {
        None
    };

    // If we wrote an index, patch the header.index_offset (at byte 20)
    if let Some(idx_off) = index_offset {
        f.seek(SeekFrom::Start(20))?;
        f.write_all(&idx_off.to_le_bytes())?;
    }

    let total = f.stream_position()?;
    Ok(total)
}

/// Iterate a sedimentary CRSL stream file sequentially, yielding
/// (file_offset, slot_index, Slot) for each record in insertion order.
pub fn crsl_iter_stream(path: impl AsRef<Path>) -> Result<Vec<(u64, u32, Slot)>, Box<dyn std::error::Error>> {
    use std::fs::File;
    use std::io::Read;

    let mut file = File::open(path)?;
    let mut header = [0u8; STREAM_HEADER_SIZE];
    file.read_exact(&mut header)?;
    if header[0..8] != STREAM_MAGIC { return Err("Bad stream magic".into()); }

    let mut out = Vec::new();

    // If an index was written, stop iterating when we reach it.
    let index_offset = u64::from_le_bytes([
        header[20], header[21], header[22], header[23],
        header[24], header[25], header[26], header[27]
    ]);

    loop {
        let offset = file.stream_position()?;
        if index_offset != 0 && offset >= index_offset {
            break; // reached appended index area
        }

        let mut idx_buf = [0u8; 4];
        match file.read_exact(&mut idx_buf) {
            Ok(()) => {}
            Err(e) if e.kind() == std::io::ErrorKind::UnexpectedEof => break,
            Err(e) => return Err(Box::new(e)),
        }
        let slot_idx = u32::from_le_bytes(idx_buf);

        let mut slot_bytes = [0u8; std::mem::size_of::<Slot>()];
        file.read_exact(&mut slot_bytes)?;
        let slot: Slot = unsafe { std::ptr::read(slot_bytes.as_ptr() as *const Slot) };

        out.push((offset, slot_idx, slot));
    }
    Ok(out)
}

/// Read the compact index appended to a stream file. Returns None if no index.
pub fn crsl_load_index(path: impl AsRef<Path>) -> Result<Option<std::collections::HashMap<u32, u64>>, Box<dyn std::error::Error>> {
    use std::fs::File;
    use std::io::Read;

    let mut file = File::open(path)?;
    let mut header = [0u8; STREAM_HEADER_SIZE];
    file.read_exact(&mut header)?;
    if header[0..8] != STREAM_MAGIC { return Err("Bad stream magic".into()); }

    let index_offset = u64::from_le_bytes([header[20], header[21], header[22], header[23], header[24], header[25], header[26], header[27]]);
    if index_offset == 0 { return Ok(None); }

    file.seek(SeekFrom::Start(index_offset))?;
    let mut count_buf = [0u8; 4];
    file.read_exact(&mut count_buf)?;
    let entry_count = u32::from_le_bytes(count_buf) as usize;

    let mut map = std::collections::HashMap::new();
    for _ in 0..entry_count {
        let mut idx_buf = [0u8; 4];
        let mut off_buf = [0u8; 8];
        file.read_exact(&mut idx_buf)?;
        file.read_exact(&mut off_buf)?;
        let slot_idx = u32::from_le_bytes(idx_buf);
        let off = u64::from_le_bytes(off_buf);
        map.insert(slot_idx, off);
    }
    Ok(Some(map))
}

/// Load a .crsl file directly into the Word Engine's hash table.
/// Uses memory mapping for zero-copy access and instant loading.
pub fn load_crsl_into_engine(engine: &mut WordEngine, path: impl AsRef<Path>) -> Result<(), Box<dyn std::error::Error>> {
    let path = path.as_ref();
    
    // Open the .crsl file as a memory-mapped table
    let mapped_table = MappedTable::open(path)?;
    
    // Get the underlying hash table from the engine
    let table = &mut engine.table;
    
    // Copy slots from the mapped table to the engine's table
    // This is necessary because the engine needs mutable access
    for i in 0..mapped_table.slot_count() {
        let slot = mapped_table.slot(i);
        if !slot.is_empty() {
            // Reconstruct the key from the slot (only use valid bytes)
            let key_len = slot.key_len as usize;
            let key = &slot.key[..key_len];
            let kind = SlotKind::from_u8(slot.kind).unwrap_or(SlotKind::Empty);
            let value = slot.value;
            let next_pos = slot.next_pos;
            let score = slot.score;
            
            // Insert into engine's table
            table.insert(key, kind, value, next_pos, score);
        }
    }
    
    // Update engine statistics
    engine.total_tokens += mapped_table.count as u32;
    
    // Build token index from the loaded data
    build_token_index_from_table(engine, &mapped_table)?;
    
    // Rebuild relation chains from loaded Relation slots
    // This is critical: .crsl stores the slots, but chain pointers need reconstruction
    println!("  🔗 Rebuilding relation chains...");
    engine.table.rebuild_chains();

    // Restore token timeline from the v2+ token section (if present)
    match crate::persist::load_tokens(path) {
        Ok(Some(tokens)) => {
            let n = tokens.len();
            // Rebuild token_index from the restored timeline. Tokens are
            // case-preserved on disk (Ingest v2) but token_index stays
            // lowercase-keyed, same invariant ingest_with_source keeps --
            // and boundary markers / function words are excluded, same as
            // ingest, so a reloaded engine's index matches a freshly
            // ingested one instead of silently diverging.
            let mut token_index: std::collections::HashMap<String, Vec<u32>> = std::collections::HashMap::new();
            for (pos, tok) in tokens.iter().enumerate() {
                if crate::word_engine::WordEngine::tok_is_boundary(tok) { continue; }
                if engine.tok_is_function_word(tok) { continue; }
                token_index.entry(tok.to_lowercase()).or_default().push(pos as u32);
            }
            engine.tokens = tokens;
            engine.total_tokens = n as u32;
            engine.token_index = token_index;
            println!("  📜 Token timeline restored: {} tokens", n);

            // Restore speaker-provenance spans (v3) or synthesize back-compat
            // coverage for v1/v2 files -- one Corpus span over the whole
            // restored tape, since untracked provenance defaults to
            // background-knowledge (see WordEngine::speaker_at).
            match crate::persist::load_speaker_spans(path) {
                Ok(Some(spans)) => {
                    engine.speaker_spans = spans.into_iter()
                        .map(|(start, end, tag)| (start, end, crate::word_engine::Speaker::from_u8(tag)))
                        .collect();
                    println!("  🗣  Speaker spans restored: {}", engine.speaker_spans.len());
                }
                Ok(None) => {
                    if n > 0 {
                        engine.speaker_spans = vec![(0, n as u32, crate::word_engine::Speaker::Corpus)];
                    }
                    println!("  ⚠ pre-v3 .crsl — no speaker spans; whole tape treated as Corpus");
                }
                Err(e) => {
                    eprintln!("  ⚠ Failed to read speaker section: {}", e);
                    if n > 0 {
                        engine.speaker_spans = vec![(0, n as u32, crate::word_engine::Speaker::Corpus)];
                    }
                }
            }

            // Re-derive relations from the token tape.
            // Relations are ephemeral — the token timeline is canonical.
            // slot_val is recomputed here via the same pack_slot path as ingest.
            engine.rebuild_relations_from_tokens();
            println!("  🔗 Relations rebuilt: {}", engine.relations.len());
            // Build the address-bucket index for radial queries.
            // Use the active query_mode's hash method so radial clustering matches the chosen method.
            engine.addr_index = engine.table.build_addr_index(engine.query_mode.hash_method());
        }
        Ok(None) => {
            // v1 file — no token section; token_index was already built from table
            println!("  ⚠ v1 .crsl (hash table only) — token timeline not present");
        }
        Err(e) => {
            eprintln!("  ⚠ Failed to read token section: {}", e);
        }
    }

    Ok(())
}

/// Build the token index from a loaded table for fast lookups
fn build_token_index_from_table(engine: &mut WordEngine, mapped_table: &MappedTable) -> Result<(), Box<dyn std::error::Error>> {
    for i in 0..mapped_table.slot_count() {
        let slot = mapped_table.slot(i);
        if slot.kind == (SlotKind::Word as u8) && !slot.is_empty() {
            // Decode the key back to a string (only use valid bytes)
            let key_len = slot.key_len as usize;
            let key_str = decode_carousel_key(&slot.key[..key_len]);
            if !key_str.is_empty() {
                let position = slot.value as u32;
                engine.token_index.entry(key_str).or_default().push(position);
            }
        }
    }
    Ok(())
}

/// Decode a carousel-encoded key back to a string
fn decode_carousel_key(key: &[u8]) -> String {
    key.iter()
        .map(|&byte| {
            let cart = (byte >> 5) & 0b111;
            let char_id = byte & 0b11111;
            
            match cart {
                0 => {
                    // Cartridge 0: lowercase a-z + punctuation
                    match char_id {
                        0..=25 => (b'a' + char_id) as char,
                        26 => '.',
                        27 => ',',
                        28 => '!',
                        29 => '?',
                        30 => ';',
                        31 => ':',
                        _ => ' ',
                    }
                }
                1 => {
                    // Cartridge 1: uppercase A-Z + punctuation
                    match char_id {
                        0..=25 => (b'A' + char_id) as char,
                        26 => '"',
                        27 => '\'',
                        28 => '-',
                        29 => '(',
                        30 => ')',
                        31 => '/',
                        _ => ' ',
                    }
                }
                2 => {
                    // Cartridge 2: digits + symbols
                    match char_id {
                        0..=9 => (b'0' + char_id) as char,
                        10 => '+',
                        11 => '-',
                        12 => '*',
                        13 => '/',
                        14 => '=',
                        15 => '<',
                        16 => '>',
                        17 => '%',
                        18 => '&',
                        19 => '|',
                        20 => '^',
                        21 => '~',
                        22 => '@',
                        23 => '#',
                        24 => '$',
                        25 => '\\',
                        26 => '{',
                        27 => '}',
                        28 => '[',
                        29 => ']',
                        30 => '`',
                        31 => '_',
                        _ => ' ',
                    }
                }
                3 => {
                    // Cartridge 3: whitespace + control
                    match char_id {
                        0 => ' ',
                        1 => '\t',
                        2 => '\n',
                        3 => '\r',
                        _ => ' ', // Reserved slots map to space
                    }
                }
                _ => ' ', // Unknown cartridge
            }
        })
        .collect()
}

/// Batch load multiple .crsl files into the engine
pub fn load_crsl_batch(engine: &mut WordEngine, paths: &[impl AsRef<Path>]) -> Result<(), Box<dyn std::error::Error>> {
    for path in paths {
        match load_crsl_into_engine(engine, path) {
            Ok(()) => {
                println!("✓ Loaded {}", path.as_ref().display());
            }
            Err(e) => {
                eprintln!("✗ Failed to load {}: {}", path.as_ref().display(), e);
            }
        }
    }
    Ok(())
}

/// Load all .crsl files from a directory
pub fn load_crsl_directory(engine: &mut WordEngine, dir_path: impl AsRef<Path>) -> Result<usize, Box<dyn std::error::Error>> {
    let dir = std::fs::read_dir(dir_path)?;
    let mut loaded_count = 0;
    
    for entry in dir {
        let entry = entry?;
        let path = entry.path();
        
        if path.extension().and_then(|s| s.to_str()) == Some("crsl") {
            match load_crsl_into_engine(engine, &path) {
                Ok(()) => {
                    loaded_count += 1;
                    println!("✓ Loaded {}", path.display());
                }
                Err(e) => {
                    eprintln!("✗ Failed to load {}: {}", path.display(), e);
                }
            }
        }
    }
    
    Ok(loaded_count)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::NamedTempFile;
    
    #[test]
    fn test_crsl_loading() {
        let mut engine = WordEngine::new(8);
        
        // Create a test .crsl file
        let mut table = crate::table::HashTable24::new_sized(12); // 4K slots
        table.insert_word("hello", 42);
        table.insert_word("world", 99);
        table.insert_bigram("hello", "world", 100);
        
        let temp_file = NamedTempFile::new().unwrap();
        crate::persist::save(&table, temp_file.path()).unwrap();
        
        // Load it into the engine
        let result = load_crsl_into_engine(&mut engine, temp_file.path());
        assert!(result.is_ok());
        
        // Verify the data was loaded
        assert!(engine.table.get_word("hello").is_some());
        assert!(engine.table.get_word("world").is_some());
        assert!(engine.table.get_bigram("hello", "world").is_some());
        
        // Clean up
        let _ = fs::remove_file(temp_file.path());
    }

    #[test]
    fn test_crsl_stream_write_and_iter_and_index() {
        use crate::table::Slot;
        use std::fs;

        let path = std::env::temp_dir().join("crsl_stream_test.crsl");

        // Build three sample Slot entries (minimal fields set)
        let mut s1 = Slot::default(); s1.kind = SlotKind::Word as u8; s1.key_len = 3; s1.key[0..3].copy_from_slice(&crate::carousel::encode_string("you"));
        let mut s2 = Slot::default(); s2.kind = SlotKind::Relation as u8; s2.key_len = 7; s2.key[0..7].copy_from_slice(&crate::carousel::encode_string("you#num"));
        let mut s3 = Slot::default(); s3.kind = SlotKind::Word as u8; s3.key_len = 4; s3.key[0..4].copy_from_slice(&crate::carousel::encode_string("john"));

        let entries = vec![(1234u32, s1), (40000u32, s2), (4321u32, s3)];

        // Save stream with index
        let _ = save_crsl_stream(&path, &entries, true).expect("save stream failed");

        // Iterate stream and verify order and offsets
        let records = crsl_iter_stream(&path).expect("iter failed");
        let ids: Vec<u32> = records.iter().map(|(_, id, _)| *id).collect();
        assert_eq!(ids, vec![1234u32, 40000u32, 4321u32]);

        // Load index and verify mapping points to offsets returned above
        let idx_map = crsl_load_index(&path).expect("load index failed").expect("index missing");
        for (off, id, _slot) in records.iter() {
            let mapped = idx_map.get(id).expect("index entry missing");
            assert_eq!(*mapped, *off);
        }

        let _ = fs::remove_file(&path);
    }
}