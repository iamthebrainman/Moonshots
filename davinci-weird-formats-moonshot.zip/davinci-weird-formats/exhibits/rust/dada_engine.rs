//! # Dada Engine v3 — Learned Recursive Transition Networks
//!
//! Inspired by Andrew Bulhak's original Dada Engine (1995).
//!
//! ## Conversation Model
//!
//! A conversation is a **chain**, not pairs:
//!
//! ```text
//!   T₀ (human) → T₁ (system) → T₂ (human) → T₃ (system) → ...
//! ```
//!
//! Only T₀ is unprompted. Every subsequent turn — by EITHER speaker —
//! is a response to the one before it. T₂ responds to T₁ the same
//! way T₁ responds to T₀.
//!
//! The implicit feedback signal: T[n+1] tells you how well T[n] landed.
//! When the human builds on what the system said, that's positive.
//! When the human rejects or restates, that's negative. No explicit
//! rating needed — the conversation IS the feedback.
//!
//! ## Learned Grammar
//!
//! | Bulhak pb concept     | Learned equivalent                          |
//! |-----------------------|---------------------------------------------|
//! | Rule with alternatives| `LearnedRule` with weighted `Alternative`s  |
//! | Inline choices [a|b]  | `Slot` with observed fillers                |
//! | Parametric rules      | Templates with typed `SlotDef`s             |
//! | Variables (v<<atom)   | `ConversationState` bindings                |
//! | Mappings (a->b)       | `LearnedMapping` from observed transforms   |
//! | Resource rules        | `Dependency` rules (won't fire as start)    |
//! | Indirection (@@rule)  | `DynamicDispatch` via slot value → rule     |

use std::collections::{HashMap, HashSet, VecDeque};
use crate::interference::{InterferenceReasoner, GdaCore};

// ═══════════════════════════════════════════════════════════════════
// Core Types — The atoms of the learned grammar
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, PartialEq)]
pub enum Atom {
    /// Fixed text: `"the"`, `"is"`, `"."`
    Literal(String),
    /// Variable position — indexes into the rule's slot definitions.
    Slot(SlotId),
    /// Reference to another learned rule — the recursion in RTN.
    RuleRef(RuleId),
    /// Optional: sometimes present, sometimes absent. `[""|content]` in pb.
    Optional(Box<Atom>),
    /// Inline choice: `[a | b | c]` in pb.
    Choice(Vec<WeightedAtom>),
}

#[derive(Debug, Clone, PartialEq)]
pub struct WeightedAtom {
    pub atom: Atom,
    pub weight: f32,
    pub times_selected: u32,
    pub times_successful: u32,
}

impl WeightedAtom {
    pub fn new(atom: Atom, weight: f32) -> Self {
        Self { atom, weight, times_selected: 0, times_successful: 0 }
    }

    pub fn effective_weight(&self) -> f32 {
        if self.times_selected == 0 {
            return self.weight;
        }
        let success_ratio = (self.times_successful as f32 + 1.0)
            / (self.times_selected as f32 + 2.0);
        self.weight * success_ratio
    }
}

pub type SlotId = u32;
pub type RuleId = u32;
pub type TurnId = u64;
pub type PatternHash = u64;

// ═══════════════════════════════════════════════════════════════════
// Shared Types — backward-compatible with word_engine
// ═══════════════════════════════════════════════════════════════════

/// Where did this knowledge come from?
///
/// Two qualitatively different learning streams:
/// - `Self_`: Things the engine says about itself / the world (offline training,
///            ingestion files, self-narrative). High-confidence priors.
/// - `User`: Things the user tells the engine about itself during chat
///           ("Your name is X", corrections). Layered on top as overlays.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub enum KnowledgeSource {
    /// First-person self-story and world knowledge from training/ingestion
    #[serde(rename = "self")]
    Self_,
    /// Second-person facts told by the user during chat
    User,
    /// Source not yet determined (legacy/transitional)
    Unknown,
}

impl Default for KnowledgeSource {
    fn default() -> Self { KnowledgeSource::Unknown }
}

/// Grammatical person of the assertion that created this triple.
///
/// Tracks whether the original statement was:
/// - First person: "I am a language engine" (self-narrative)
/// - Second person: "You are helpful" (user addressing the engine)
/// - Third person: "Dogs are mammals" (world facts)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub enum PersonPerspective {
    First,
    Second,
    Third,
}

impl Default for PersonPerspective {
    fn default() -> Self { PersonPerspective::Third }
}

/// How should the definition LM behave?
///
/// Controls prompt complexity to prevent definition explosion:
/// - `Simple`: ELI5 mode — one short sentence, basic vocabulary only.
///             Default for most runs. Prevents jargon token proliferation.
/// - `Normal`: Standard definitions (current behavior).
/// - `Technical`: Rich domain-specific definitions. Only use when you
///               intentionally want detailed vocabulary for a domain mind.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum DefinitionStyle {
    Simple,
    Normal,
    Technical,
}

impl Default for DefinitionStyle {
    fn default() -> Self { DefinitionStyle::Simple }
}

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct RelationalTriple {
    pub subject: String,
    pub relation: String,
    pub object: String,
    pub confidence: f32,
    /// Where this knowledge came from (training vs chat)
    #[serde(default)]
    pub source: KnowledgeSource,
    /// Grammatical person of the original assertion
    #[serde(default)]
    pub person: PersonPerspective,
    /// 10-bit Fibonacci slot value: bits[9:5]=a, bits[4:0]=b.
    /// Encodes semantic geometry: magnitude = F(a)*F(b), band = a+b.
    /// 0 means "not yet computed" (legacy / pre-decoder triples).
    #[serde(default)]
    pub slot_val: u16,
}

impl RelationalTriple {
    pub fn new(subject: String, relation: String, object: String, confidence: f32) -> Self {
        Self { subject, relation, object, confidence, source: KnowledgeSource::Unknown, person: PersonPerspective::Third, slot_val: 0 }
    }

    /// Create a triple with explicit source and person metadata.
    pub fn with_provenance(
        subject: String,
        relation: String,
        object: String,
        confidence: f32,
        source: KnowledgeSource,
        person: PersonPerspective,
    ) -> Self {
        Self { subject, relation, object, confidence, source, person, slot_val: 0 }
    }

    /// Mark this triple as coming from self-narrative (training/ingestion).
    pub fn as_self_knowledge(mut self) -> Self {
        self.source = KnowledgeSource::Self_;
        self
    }

    /// Mark this triple as coming from user assertion (chat).
    pub fn as_user_knowledge(mut self) -> Self {
        self.source = KnowledgeSource::User;
        self
    }

    /// Mark this triple with a specific person perspective.
    pub fn with_person(mut self, person: PersonPerspective) -> Self {
        self.person = person;
        self
    }

    /// Is this an identity fact (e.g. about "my name", "your name")?
    pub fn is_identity(&self) -> bool {
        let subj = self.subject.to_lowercase();
        let rel = self.relation.to_lowercase();
        subj.contains("name") || subj == "i" || subj == "you"
            || rel.contains("name") || rel.contains("called")
    }
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct SynthesisRule {
    pub relation_pattern: String,
    pub usage_count: u32,
    pub success_count: u32,
    pub failure_count: u32,
}

impl SynthesisRule {
    pub fn new(pattern: String) -> Self {
        Self { relation_pattern: pattern, usage_count: 0, success_count: 0, failure_count: 0 }
    }

    pub fn confidence(&self) -> f32 {
        if self.usage_count == 0 { 0.5 }
        else { self.success_count as f32 / self.usage_count as f32 }
    }

    pub fn record_use(&mut self, was_successful: bool) {
        self.usage_count += 1;
        if was_successful { self.success_count += 1; }
        else { self.failure_count += 1; }
    }
}

// ═══════════════════════════════════════════════════════════════════
// Slot Definitions
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, PartialEq)]
pub enum SlotType {
    ContentWord,
    NounPhrase,
    VerbPhrase,
    Enumerated(Vec<String>),
    EntityClass(String),
    Free,
}

#[derive(Debug, Clone)]
pub struct SlotDef {
    pub id: SlotId,
    pub name: String,
    pub slot_type: SlotType,
    pub observed_fillers: HashMap<String, u32>,
    pub last_filler: Option<String>,
}

impl SlotDef {
    pub fn new(id: SlotId, name: String) -> Self {
        Self { id, name, slot_type: SlotType::Free, observed_fillers: HashMap::new(), last_filler: None }
    }

    pub fn observe(&mut self, filler: &str) {
        *self.observed_fillers.entry(filler.to_string()).or_default() += 1;
        self.last_filler = Some(filler.to_string());
        self.refine_type();
    }

    fn refine_type(&mut self) {
        let total: u32 = self.observed_fillers.values().sum();
        let unique = self.observed_fillers.len();
        if total >= 4 && unique <= 8 {
            let fillers: Vec<String> = self.observed_fillers.keys().cloned().collect();
            self.slot_type = SlotType::Enumerated(fillers);
        }
    }

    pub fn pick_filler(&self, rng_seed: u64) -> Option<String> {
        if self.observed_fillers.is_empty() {
            return self.last_filler.clone();
        }
        let total: u32 = self.observed_fillers.values().sum();
        let target = (rng_seed % total as u64) as u32;
        let mut acc = 0u32;
        for (filler, &count) in &self.observed_fillers {
            acc += count;
            if acc > target { return Some(filler.clone()); }
        }
        self.observed_fillers.keys().next().cloned()
    }
}

// ═══════════════════════════════════════════════════════════════════
// Templates
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum TemplateMode {
    /// Mostly literals — mirrors/summarizes.
    Compressive,
    /// Mostly slots — explores/branches.
    Expansive,
    /// Opens with compression, then expands.
    Mixed,
}

#[derive(Debug, Clone)]
pub struct Template {
    pub atoms: Vec<Atom>,
    pub slots: Vec<SlotDef>,
    pub source_hash: PatternHash,
    pub times_used: u32,
    pub times_successful: u32,
}

impl Template {
    pub fn new(atoms: Vec<Atom>, slots: Vec<SlotDef>) -> Self {
        let hash = Self::compute_hash(&atoms);
        Self { atoms, slots, source_hash: hash, times_used: 0, times_successful: 0 }
    }

    fn compute_hash(atoms: &[Atom]) -> PatternHash {
        let mut hash: u64 = 0xcbf29ce484222325;
        for atom in atoms {
            match atom {
                Atom::Literal(s) => {
                    for byte in s.bytes() {
                        hash ^= byte as u64;
                        hash = hash.wrapping_mul(0x100000001b3);
                    }
                }
                Atom::Slot(id) => {
                    hash ^= 0xDEAD_0000 | *id as u64;
                    hash = hash.wrapping_mul(0x100000001b3);
                }
                Atom::RuleRef(id) => {
                    hash ^= 0xBEEF_0000 | *id as u64;
                    hash = hash.wrapping_mul(0x100000001b3);
                }
                _ => {
                    hash ^= 0xCAFE;
                    hash = hash.wrapping_mul(0x100000001b3);
                }
            }
        }
        hash
    }

    pub fn confidence(&self) -> f32 {
        if self.times_used == 0 { 0.5 }
        else { (self.times_successful as f32 + 1.0) / (self.times_used as f32 + 2.0) }
    }

    pub fn classify_mode(&self) -> TemplateMode {
        if self.atoms.is_empty() { return TemplateMode::Compressive; }
        let total = self.atoms.len() as f32;
        let slot_count = self.atoms.iter()
            .filter(|a| matches!(a, Atom::Slot(_) | Atom::Choice(_)))
            .count() as f32;
        let ratio = slot_count / total;
        if ratio < 0.25 { TemplateMode::Compressive }
        else if ratio > 0.5 { TemplateMode::Expansive }
        else { TemplateMode::Mixed }
    }

    pub fn instantiate(&self, bindings: &HashMap<SlotId, String>, rng_seed: u64) -> String {
        let mut parts = Vec::new();
        let mut seed = rng_seed;
        for atom in &self.atoms {
            match atom {
                Atom::Literal(s) => parts.push(s.clone()),
                Atom::Slot(id) => {
                    if let Some(bound) = bindings.get(id) {
                        parts.push(bound.clone());
                    } else if let Some(slot_def) = self.slots.iter().find(|s| s.id == *id) {
                        if let Some(filler) = slot_def.pick_filler(seed) {
                            parts.push(filler);
                        } else {
                            parts.push("?".to_string());
                        }
                    }
                    seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
                }
                Atom::Optional(inner) => {
                    if seed % 2 == 0 {
                        if let Atom::Literal(s) = inner.as_ref() {
                            parts.push(s.clone());
                        }
                    }
                    seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
                }
                Atom::Choice(choices) => {
                    if !choices.is_empty() {
                        let total_weight: f32 = choices.iter().map(|c| c.effective_weight()).sum();
                        let target = (seed as f32 / u64::MAX as f32) * total_weight;
                        let mut acc = 0.0;
                        for choice in choices {
                            acc += choice.effective_weight();
                            if acc >= target {
                                if let Atom::Literal(s) = &choice.atom { parts.push(s.clone()); }
                                break;
                            }
                        }
                    }
                    seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
                }
                Atom::RuleRef(_) => { parts.push("[rule]".to_string()); }
            }
        }
        parts.join(" ")
    }
}

// ═══════════════════════════════════════════════════════════════════
// Learned Rules — The heart of the RTN
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone)]
pub struct LearnedRule {
    pub id: RuleId,
    pub name: String,
    pub alternatives: Vec<Template>,
    pub is_resource: bool,
    pub eval_count: u32,
    pub last_chosen: Option<usize>,
}

impl LearnedRule {
    pub fn new(id: RuleId, name: String) -> Self {
        Self { id, name, alternatives: Vec::new(), is_resource: false, eval_count: 0, last_chosen: None }
    }

    pub fn add_alternative(&mut self, template: Template) {
        let hash = template.source_hash;
        if let Some(existing) = self.alternatives.iter_mut().find(|t| t.source_hash == hash) {
            for new_slot in &template.slots {
                if let Some(existing_slot) = existing.slots.iter_mut().find(|s| s.id == new_slot.id) {
                    for (filler, &count) in &new_slot.observed_fillers {
                        *existing_slot.observed_fillers.entry(filler.clone()).or_default() += count;
                    }
                    existing_slot.refine_type();
                }
            }
            existing.times_used += 1;
        } else {
            self.alternatives.push(template);
        }
    }

    /// Select alternative — weighted, never same twice in a row (Dada Engine rule).
    pub fn select_alternative(&mut self, rng_seed: u64) -> Option<&Template> {
        if self.alternatives.is_empty() { return None; }
        if self.alternatives.len() == 1 {
            self.last_chosen = Some(0);
            self.eval_count += 1;
            return Some(&self.alternatives[0]);
        }
        let mut candidates: Vec<(usize, f32)> = self.alternatives.iter().enumerate()
            .filter(|(i, _)| self.last_chosen.map_or(true, |last| *i != last))
            .map(|(i, t)| (i, t.confidence()))
            .collect();
        if candidates.is_empty() {
            candidates = self.alternatives.iter().enumerate()
                .map(|(i, t)| (i, t.confidence())).collect();
        }
        let total: f32 = candidates.iter().map(|(_, w)| w).sum();
        let target = (rng_seed as f32 / u64::MAX as f32) * total;
        let mut acc = 0.0;
        for (idx, weight) in &candidates {
            acc += weight;
            if acc >= target {
                self.last_chosen = Some(*idx);
                self.eval_count += 1;
                return Some(&self.alternatives[*idx]);
            }
        }
        let idx = candidates.last().map(|(i, _)| *i).unwrap_or(0);
        self.last_chosen = Some(idx);
        self.eval_count += 1;
        Some(&self.alternatives[idx])
    }
}

// ═══════════════════════════════════════════════════════════════════
// Turn — A single utterance in the conversation chain
// ═══════════════════════════════════════════════════════════════════

/// Who spoke this turn.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Speaker {
    Human,
    System,
}

impl Speaker {
    pub fn other(self) -> Self {
        match self { Speaker::Human => Speaker::System, Speaker::System => Speaker::Human }
    }
}

/// A single turn in the conversation chain.
///
/// ```text
///   T₀ (human) → T₁ (system) → T₂ (human) → T₃ (system) → ...
/// ```
///
/// Only T₀ is unprompted. Every other turn is a RESPONSE to the
/// one before it, regardless of who the speaker is.
#[derive(Debug, Clone)]
pub struct Turn {
    pub id: TurnId,
    pub speaker: Speaker,
    pub tokens: Vec<String>,
    pub template: Option<Template>,
    pub rule_id: Option<RuleId>,
    pub relations_extracted: Vec<RelationalTriple>,
    pub timestamp: u64,
}

/// Legacy alias — for backward compatibility with WordEngine.
/// Constructed from two consecutive Turns in the chain.
#[derive(Debug, Clone)]
pub struct TurnPair {
    pub id: TurnId,
    pub input_tokens: Vec<String>,
    pub response_tokens: Vec<String>,
    pub input_template: Option<Template>,
    pub response_template: Option<Template>,
    pub relations_extracted: Vec<RelationalTriple>,
    pub was_successful: Option<bool>,
    pub timestamp: u64,
}

impl TurnPair {
    /// Build from two consecutive turns (the prior and the response to it).
    pub fn from_consecutive(prior: &Turn, response: &Turn) -> Self {
        Self {
            id: response.id,
            input_tokens: prior.tokens.clone(),
            response_tokens: response.tokens.clone(),
            input_template: prior.template.clone(),
            response_template: response.template.clone(),
            relations_extracted: response.relations_extracted.clone(),
            was_successful: None,
            timestamp: response.timestamp,
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// Learned Mappings
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone)]
pub struct LearnedMapping {
    pub name: String,
    pub pairs: Vec<(String, String)>,
    pub bidirectional: bool,
}

impl LearnedMapping {
    pub fn new(name: String) -> Self {
        Self { name, pairs: Vec::new(), bidirectional: false }
    }

    pub fn add_pair(&mut self, from: String, to: String) {
        if !self.pairs.iter().any(|(f, t)| f == &from && t == &to) {
            self.pairs.push((from, to));
        }
    }

    pub fn apply(&self, input: &str) -> Option<String> {
        for (from, to) in &self.pairs {
            if input == from { return Some(to.clone()); }
            if self.bidirectional && input == to { return Some(from.clone()); }
        }
        None
    }
}

// ═══════════════════════════════════════════════════════════════════
// Continuation Signal — The conversation IS the feedback
// ═══════════════════════════════════════════════════════════════════

/// Implicit feedback derived from how T[n+1] relates to T[n].
///
/// Works for any three consecutive turns in the chain:
///   T[n-1] → T[n] → T[n+1]
///
/// T[n+1] is the "continuation" — it tells us how T[n] landed,
/// regardless of which speaker produced which turn.
#[derive(Debug, Clone)]
pub struct ContinuationSignal {
    /// Did the continuation build on T[n]? (term overlap)
    pub engagement: f32,
    /// Did the continuation reject T[n]? (negation markers, restating)
    pub rejection: f32,
    /// Did the topic shift abruptly? (low overlap with both prior turns)
    pub topic_drift: f32,
    /// Length ratio: T[n+1].len / T[n].len
    pub length_ratio: f32,
    /// Net score: positive = good, negative = bad
    pub net_score: f32,
}

impl ContinuationSignal {
    /// Compute from three consecutive turns in the chain.
    /// `prior` = T[n-1], `current` = T[n], `continuation` = T[n+1]
    pub fn from_chain(
        prior: &[String],
        current: &[String],
        continuation: &[String],
    ) -> Self {
        if continuation.is_empty() || current.is_empty() {
            return Self { engagement: 0.0, rejection: 0.0, topic_drift: 1.0, length_ratio: 0.0, net_score: 0.0 };
        }

        let current_terms: HashSet<&String> = current.iter().collect();
        let cont_terms: HashSet<&String> = continuation.iter().collect();

        // Engagement: does continuation use terms from current?
        let shared = current_terms.intersection(&cont_terms).count() as f32;
        let engagement = if current_terms.is_empty() { 0.0 }
            else { shared / current_terms.len() as f32 };

        // Rejection: negation markers in continuation
        let rejection_markers = ["no", "not", "wrong", "that's", "thats",
            "didn't", "dont", "don't", "isn't", "isnt",
            "what", "huh", "again", "i said", "i meant"];
        let cont_text: String = continuation.iter()
            .map(|s| s.to_lowercase()).collect::<Vec<_>>().join(" ");
        let rejection_count = rejection_markers.iter()
            .filter(|&&m| cont_text.contains(m)).count() as f32;
        let rejection = (rejection_count / 3.0).min(1.0);

        // Topic drift: how much does continuation diverge from both prior turns?
        let prior_terms: HashSet<&String> = prior.iter().collect();
        let all_prior: HashSet<&String> = prior_terms.union(&current_terms).cloned().collect();
        let drift_overlap = all_prior.intersection(&cont_terms).count() as f32;
        let topic_drift = if all_prior.is_empty() { 1.0 }
            else { 1.0 - (drift_overlap / all_prior.len() as f32) };

        let length_ratio = continuation.len() as f32 / current.len() as f32;

        let net_score = ((engagement * 2.0) - (rejection * 3.0) - (topic_drift * 0.5)
            + (length_ratio.min(2.0) * 0.3)).clamp(-1.0, 1.0);

        Self { engagement, rejection, topic_drift, length_ratio, net_score }
    }
}

// ═══════════════════════════════════════════════════════════════════
// Dialogue Graph — The Recursive Transition Network
// ═══════════════════════════════════════════════════════════════════

/// Edge: an observed transition from one turn's pattern to the next.
/// Speaker-agnostic — works for human→system AND system→human.
#[derive(Debug, Clone)]
pub struct DialogueEdge {
    /// The pattern that preceded this transition
    pub from_rule: RuleId,
    /// The pattern that followed
    pub to_rule: RuleId,
    /// How many times this transition was observed
    pub frequency: u32,
    /// Implicit success rate from continuation signals
    pub success_rate: f32,
    /// Context tags required for this transition
    pub required_context: Vec<String>,
}

#[derive(Debug, Clone)]
pub struct DialogueGraph {
    pub edges: Vec<DialogueEdge>,
    pub from_index: HashMap<RuleId, Vec<usize>>,
    pub to_index: HashMap<RuleId, Vec<usize>>,
}

impl DialogueGraph {
    pub fn new() -> Self {
        Self { edges: Vec::new(), from_index: HashMap::new(), to_index: HashMap::new() }
    }

    /// Record an observed transition: one turn's pattern → next turn's pattern.
    pub fn record_transition(&mut self, from: RuleId, to: RuleId, context: Vec<String>) {
        if let Some(idx) = self.edges.iter().position(|e| e.from_rule == from && e.to_rule == to) {
            self.edges[idx].frequency += 1;
        } else {
            let idx = self.edges.len();
            self.edges.push(DialogueEdge {
                from_rule: from, to_rule: to, frequency: 1,
                success_rate: 0.5, required_context: context,
            });
            self.from_index.entry(from).or_default().push(idx);
            self.to_index.entry(to).or_default().push(idx);
        }
    }

    /// Find the best next pattern given what was just said.
    pub fn best_continuation(
        &self,
        from: RuleId,
        context: &HashSet<String>,
    ) -> Option<(RuleId, f32)> {
        let edge_indices = self.from_index.get(&from)?;
        let mut best: Option<(RuleId, f32)> = None;
        for &idx in edge_indices {
            let edge = &self.edges[idx];
            if !edge.required_context.iter().all(|req| context.contains(req)) {
                continue;
            }
            let score = edge.frequency as f32 * edge.success_rate;
            if best.map_or(true, |(_, best_score)| score > best_score) {
                best = Some((edge.to_rule, score));
            }
        }
        best
    }

    /// Same as above but blends in accumulated continuation scores.
    pub fn best_continuation_with_implicit(
        &self,
        from: RuleId,
        context: &HashSet<String>,
        continuation_scores: &HashMap<(RuleId, RuleId), Vec<f32>>,
    ) -> Option<(RuleId, f32)> {
        let edge_indices = self.from_index.get(&from)?;
        let mut best: Option<(RuleId, f32)> = None;
        for &idx in edge_indices {
            let edge = &self.edges[idx];
            if !edge.required_context.iter().all(|req| context.contains(req)) {
                continue;
            }
            let mut score = edge.frequency as f32 * edge.success_rate;
            // Blend implicit scores
            if let Some(scores) = continuation_scores.get(&(from, edge.to_rule)) {
                if !scores.is_empty() {
                    let avg = scores.iter().sum::<f32>() / scores.len() as f32;
                    score *= 1.0 + avg * 0.5; // Map [-1,1] to [0.5, 1.5]
                }
            }
            if best.map_or(true, |(_, best_score)| score > best_score) {
                best = Some((edge.to_rule, score));
            }
        }
        best
    }

    /// What typically follows a given pattern?
    pub fn continuations_after(&self, from: RuleId) -> Vec<(RuleId, f32)> {
        self.from_index.get(&from).map(|indices| {
            indices.iter().map(|&idx| {
                let e = &self.edges[idx];
                (e.to_rule, e.frequency as f32 * e.success_rate)
            }).collect()
        }).unwrap_or_default()
    }
}

// ═══════════════════════════════════════════════════════════════════
// Wave Controller — Compress/Expand rhythm
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone)]
pub struct WaveController {
    /// -1.0 = compress, +1.0 = expand. Updated from structural signals.
    pub explore_bias: f32,
    /// Slow oscillator (0 to 2π). Macro breathing pattern.
    pub wave_phase: f32,
    /// Radians per turn. ~0.3 = full cycle every ~20 turns.
    pub wave_frequency: f32,
    /// How strongly the wave influences selection.
    pub wave_amplitude: f32,
    /// Running average of novelty.
    pub novelty_ema: f32,
    /// Running average of density.
    pub density_ema: f32,
    /// EMA smoothing factor.
    pub ema_alpha: f32,
}

impl Default for WaveController {
    fn default() -> Self {
        Self {
            explore_bias: 0.0, wave_phase: 0.0, wave_frequency: 0.3,
            wave_amplitude: 0.4, novelty_ema: 0.5, density_ema: 0.5, ema_alpha: 0.3,
        }
    }
}

impl WaveController {
    /// Update from a single new turn. Pure structural signals.
    pub fn update(&mut self, turn: &Turn, recent_vocab: &HashSet<&String>, fatigue_count: usize) {
        self.wave_phase += self.wave_frequency;
        if self.wave_phase > std::f32::consts::TAU {
            self.wave_phase -= std::f32::consts::TAU;
        }

        // Novelty: fraction of tokens not in recent vocabulary
        let new_count = turn.tokens.iter().filter(|t| !recent_vocab.contains(t)).count();
        let novelty = if turn.tokens.is_empty() { 0.0 }
            else { new_count as f32 / turn.tokens.len() as f32 };
        self.novelty_ema = self.ema_alpha * novelty + (1.0 - self.ema_alpha) * self.novelty_ema;

        // Density: unique / total
        let unique: HashSet<&String> = turn.tokens.iter().collect();
        let density = if turn.tokens.is_empty() { 0.0 }
            else { unique.len() as f32 / turn.tokens.len() as f32 };
        self.density_ema = self.ema_alpha * density + (1.0 - self.ema_alpha) * self.density_ema;

        let novelty_signal = (self.novelty_ema - 0.5) * 2.0;
        let density_signal = (self.density_ema - 0.5) * -1.0;
        let wave_signal = self.wave_amplitude * self.wave_phase.sin();
        let fatigue_pressure = if fatigue_count > 10 { 0.3 } else { 0.0 };

        self.explore_bias = (
            novelty_signal * 0.4 + density_signal * 0.2 + wave_signal + fatigue_pressure
        ).clamp(-1.0, 1.0);
    }

    /// (compress_weight, expand_weight) summing to ~1.0
    pub fn mode_mix(&self) -> (f32, f32) {
        let expand = (self.explore_bias + 1.0) / 2.0;
        (1.0 - expand, expand)
    }

    /// Lead with compression? True in the mixed zone.
    pub fn lead_with_compression(&self) -> bool {
        self.explore_bias > -0.3 && self.explore_bias < 0.6
    }
}

// ═══════════════════════════════════════════════════════════════════
// Conversation State — The chain and runtime variables
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone)]
pub struct ConversationState {
    /// The conversation chain — alternating speakers.
    /// This IS the conversation. Not pairs. A chain.
    pub chain: VecDeque<Turn>,
    /// Maximum chain depth to keep in memory.
    pub max_chain: usize,
    /// Bound variables (like pb's `$var`)
    pub bindings: HashMap<String, String>,
    /// Active context tags
    pub context: HashSet<String>,
    /// Current turn number (total across conversation)
    pub turn_number: u64,
    /// Fatigue: pattern_hash → fatigue level
    pub fatigue: HashMap<PatternHash, f32>,
    /// Wave controller
    pub wave: WaveController,
    /// Accumulated continuation scores for edge quality
    pub continuation_scores: HashMap<(RuleId, RuleId), Vec<f32>>,
}

impl ConversationState {
    pub fn new(max_chain: usize) -> Self {
        Self {
            chain: VecDeque::new(),
            max_chain,
            bindings: HashMap::new(),
            context: HashSet::new(),
            turn_number: 0,
            fatigue: HashMap::new(),
            wave: WaveController::default(),
            continuation_scores: HashMap::new(),
        }
    }

    /// Push a new turn onto the chain.
    pub fn push_turn(&mut self, turn: Turn) {
        self.turn_number += 1;
        self.chain.push_back(turn);
        while self.chain.len() > self.max_chain {
            self.chain.pop_front();
        }
    }

    /// The most recent turn (what was just said).
    pub fn last_turn(&self) -> Option<&Turn> {
        self.chain.back()
    }

    /// The second-to-last turn (what was said before that).
    pub fn prev_turn(&self) -> Option<&Turn> {
        let len = self.chain.len();
        if len >= 2 { Some(&self.chain[len - 2]) } else { None }
    }

    /// The third-to-last (for computing continuation signal on the one before).
    pub fn prev_prev_turn(&self) -> Option<&Turn> {
        let len = self.chain.len();
        if len >= 3 { Some(&self.chain[len - 3]) } else { None }
    }

    /// Get the recent vocabulary from the chain.
    pub fn recent_vocab(&self) -> HashSet<&String> {
        self.chain.iter().flat_map(|t| t.tokens.iter()).collect()
    }

    /// Compute implicit continuation signal for the most recent transition.
    /// Looks at the last three turns: T[n-2] → T[n-1] → T[n].
    /// T[n] is the continuation that tells us how T[n-1] landed.
    pub fn compute_continuation(&self) -> Option<ContinuationSignal> {
        let t_n = self.last_turn()?;
        let t_n1 = self.prev_turn()?;
        let t_n2 = self.prev_prev_turn()?;

        Some(ContinuationSignal::from_chain(
            &t_n2.tokens,
            &t_n1.tokens,
            &t_n.tokens,
        ))
    }

    /// Record a continuation score on the edge T[n-1] → T[n].
    pub fn record_continuation_score(&mut self, from_rule: RuleId, to_rule: RuleId, score: f32) {
        self.continuation_scores
            .entry((from_rule, to_rule))
            .or_default()
            .push(score);
    }

    // ── Variables (pb compat) ──

    pub fn bind(&mut self, name: &str, value: &str) {
        self.bindings.insert(name.to_string(), value.to_string());
    }

    pub fn bind_once(&mut self, name: &str, value: &str) -> &str {
        self.bindings.entry(name.to_string()).or_insert_with(|| value.to_string())
    }

    pub fn get(&self, name: &str) -> Option<&str> {
        self.bindings.get(name).map(|s| s.as_str())
    }

    // ── Fatigue ──

    pub fn decay_fatigue(&mut self, decay_rate: f32) {
        self.fatigue.values_mut().for_each(|f| {
            *f *= 1.0 - decay_rate;
            if *f < 0.01 { *f = 0.0; }
        });
        self.fatigue.retain(|_, f| *f > 0.0);
    }

    pub fn is_fatigued(&self, hash: PatternHash, threshold: f32) -> bool {
        self.fatigue.get(&hash).map_or(false, |&f| f >= threshold)
    }

    pub fn use_pattern(&mut self, hash: PatternHash, increment: f32) {
        *self.fatigue.entry(hash).or_default() += increment;
    }

    /// Build a legacy TurnPair from the last two turns in the chain.
    /// For backward compatibility with WordEngine/persistence code.
    pub fn last_pair(&self) -> Option<TurnPair> {
        let len = self.chain.len();
        if len >= 2 {
            Some(TurnPair::from_consecutive(&self.chain[len - 2], &self.chain[len - 1]))
        } else {
            None
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// Template Extraction
// ═══════════════════════════════════════════════════════════════════

fn extract_template_from_tokens(
    tokens: &[String],
    function_words: &HashSet<String>,
) -> Template {
    let mut atoms = Vec::new();
    let mut slots = Vec::new();
    let mut slot_counter: SlotId = 0;
    for token in tokens {
        let lower = token.to_lowercase();
        if function_words.contains(&lower) {
            atoms.push(Atom::Literal(lower));
        } else {
            let slot_id = slot_counter;
            slot_counter += 1;
            let mut slot_def = SlotDef::new(slot_id, format!("slot_{}", slot_id));
            slot_def.observe(&lower);
            slots.push(slot_def);
            atoms.push(Atom::Slot(slot_id));
        }
    }
    Template::new(atoms, slots)
}

fn align_and_generalize(
    tokens_a: &[String],
    tokens_b: &[String],
    _function_words: &HashSet<String>,
) -> Option<Template> {
    if tokens_a.len() != tokens_b.len() || tokens_a.is_empty() { return None; }
    let mut atoms = Vec::new();
    let mut slots = Vec::new();
    let mut slot_counter: SlotId = 0;
    for (a, b) in tokens_a.iter().zip(tokens_b.iter()) {
        let a_lower = a.to_lowercase();
        let b_lower = b.to_lowercase();
        if a_lower == b_lower {
            atoms.push(Atom::Literal(a_lower));
        } else {
            let slot_id = slot_counter;
            slot_counter += 1;
            let mut slot_def = SlotDef::new(slot_id, format!("var_{}", slot_id));
            slot_def.observe(&a_lower);
            slot_def.observe(&b_lower);
            slots.push(slot_def);
            atoms.push(Atom::Slot(slot_id));
        }
    }
    Some(Template::new(atoms, slots))
}

// ═══════════════════════════════════════════════════════════════════
// DadaEngine — The main engine
// ═══════════════════════════════════════════════════════════════════

pub struct DadaEngine {
    // ── Public interface (backward-compatible) ──
    pub novelty_boost: f32,
    pub fatigue_penalty: f32,
    pub last_used_objects: Vec<String>,

    // ── Learned grammar (the RTN) ──
    pub learned_rules: HashMap<String, SynthesisRule>,
    rules: Vec<LearnedRule>,
    rule_name_index: HashMap<String, RuleId>,
    next_rule_id: RuleId,

    // ── Dialogue graph ──
    dialogue_graph: DialogueGraph,

    // ── Conversation state (the chain) ──
    pub state: ConversationState,

    // ── Pattern learning ──
    relation_frequencies: HashMap<String, u32>,
    subject_patterns: HashMap<String, Vec<String>>,
    object_patterns: HashMap<String, Vec<String>>,
    mappings: HashMap<String, LearnedMapping>,

    // ── Fatigue (backward-compatible) ──
    pub fatigue_map: HashMap<String, f32>,

    // ── Interference ──
    interference_reasoner: Option<InterferenceReasoner>,

    // ── Internal ──
    current_timestamp: u64,
    rng_state: u64,
    function_words: HashSet<String>,
}

impl Default for DadaEngine {
    fn default() -> Self {
        let mut engine = Self {
            novelty_boost: 2.0,
            fatigue_penalty: 1.5,
            last_used_objects: Vec::new(),
            learned_rules: HashMap::new(),
            rules: Vec::new(),
            rule_name_index: HashMap::new(),
            next_rule_id: 0,
            dialogue_graph: DialogueGraph::new(),
            state: ConversationState::new(100),
            relation_frequencies: HashMap::new(),
            subject_patterns: HashMap::new(),
            object_patterns: HashMap::new(),
            mappings: HashMap::new(),
            fatigue_map: HashMap::new(),
            interference_reasoner: Some(InterferenceReasoner::new(GdaCore::new())),
            current_timestamp: 0,
            rng_state: 0xDEAD_BEEF_CAFE_BABE,
            function_words: HashSet::new(),
        };
        engine.init_function_words();
        engine
    }
}

impl DadaEngine {
    pub fn new(novelty_boost: f32, fatigue_penalty: f32) -> Self {
        Self { novelty_boost, fatigue_penalty, ..Default::default() }
    }

    fn init_function_words(&mut self) {
        for w in [
            "a", "an", "the", "this", "that", "these", "those",
            "some", "any", "every", "each", "all", "no",
            "i", "me", "my", "you", "your", "we", "us", "our",
            "they", "them", "their", "he", "him", "his", "she", "her", "it", "its",
            "is", "are", "am", "was", "were", "be", "been", "being",
            "has", "have", "had", "do", "does", "did",
            "will", "would", "shall", "should", "can", "could", "may", "might", "must",
            "of", "in", "on", "to", "for", "with", "at", "by",
            "from", "about", "into", "through", "during", "before",
            "after", "above", "below", "between", "under", "over",
            "and", "or", "but", "nor", "yet", "so",
            "who", "what", "where", "when", "why", "how", "which",
            "not", "no", "never",
            "very", "really", "also", "just", "still", "already",
            ".", ",", "!", "?", ";", ":",
        ] {
            self.function_words.insert(w.to_string());
        }
    }

    /// Post-training finalization: extract relations from observed turns
    /// and create diverse templates for synthesis
    pub fn finalize_learning(&mut self) {
        // Extract all unique relations from the turns we observed
        let mut relation_templates: HashMap<String, Vec<Vec<String>>> = HashMap::new();
        
        for turn in &self.state.chain {
            // Extract SVO patterns from each turn
            for i in 0..turn.tokens.len().saturating_sub(2) {
                let s = &turn.tokens[i];
                let v = &turn.tokens[i + 1];
                let o = &turn.tokens[i + 2];
                
                // Only content words
                if !self.function_words.contains(s) 
                    && !self.function_words.contains(v)
                    && !self.function_words.contains(o) {
                    
                    let rel_key = v.to_lowercase();
                    relation_templates.entry(rel_key)
                        .or_insert_with(Vec::new)
                        .push(vec![s.clone(), v.clone(), o.clone()]);
                }
            }
        }
        
        // Create templates for each discovered relation
        for (rel_name, patterns) in relation_templates {
            let rel_rule_name = format!("rel:{}", rel_name);
            let _rel_rule_id = self.get_or_create_rule(&rel_rule_name);
            
            // Sample diverse patterns and create templates
            for pattern in patterns.iter().take(5) {
                let template = extract_template_from_tokens(pattern, &self.function_words);
                self.add_template_to_rule(&rel_rule_name, template);
            }
        }
    }

    // ═══════════════════════════════════════════════════════
    // Rule Management
    // ═══════════════════════════════════════════════════════

    fn get_or_create_rule(&mut self, name: &str) -> RuleId {
        if let Some(&id) = self.rule_name_index.get(name) { return id; }
        let id = self.next_rule_id;
        self.next_rule_id += 1;
        self.rules.push(LearnedRule::new(id, name.to_string()));
        self.rule_name_index.insert(name.to_string(), id);
        id
    }

    fn add_template_to_rule(&mut self, rule_name: &str, template: Template) {
        let id = self.get_or_create_rule(rule_name);
        if let Some(rule) = self.rules.get_mut(id as usize) {
            rule.add_alternative(template);
        }
    }

    // ═══════════════════════════════════════════════════════
    // The Core Learning Method — One turn at a time
    // ═══════════════════════════════════════════════════════

    /// Learn from a single turn in the conversation chain.
    ///
    /// This is the primary learning entry point. Call it for every turn
    /// as it arrives, alternating speakers:
    ///
    /// ```text
    ///   engine.observe_turn(Speaker::Human, &tokens_0);  // T₀ opens
    ///   engine.observe_turn(Speaker::System, &tokens_1);  // T₁ responds to T₀
    ///   engine.observe_turn(Speaker::Human, &tokens_2);  // T₂ responds to T₁
    ///   engine.observe_turn(Speaker::System, &tokens_3);  // T₃ responds to T₂
    /// ```
    ///
    /// Every call after T₀:
    /// 1. Computes the implicit continuation signal on the PREVIOUS transition
    /// 2. Extracts a template from this turn
    /// 3. Records the transition T[n-1] → T[n] in the dialogue graph
    /// 4. Tries to generalize with recent history
    /// 5. Updates the wave controller
    pub fn observe_turn(&mut self, speaker: Speaker, tokens: &[String]) {
        self.current_timestamp += 1;

        // Build the Turn - FAST, no extraction
        let template = extract_template_from_tokens(tokens, &self.function_words);
        let rule_name = format!("turn:{:016x}", template.source_hash);
        let rule_id = self.get_or_create_rule(&rule_name);
        self.add_template_to_rule(&rule_name, template.clone());

        let turn = Turn {
            id: self.current_timestamp,
            speaker,
            tokens: tokens.to_vec(),
            template: Some(template),
            rule_id: Some(rule_id),
            relations_extracted: Vec::new(),
            timestamp: self.current_timestamp,
        };

        // ── Before pushing: compute implicit feedback on the previous transition ──
        // We need at least 2 prior turns to score T[n-2] → T[n-1] using T[n]
        if self.state.chain.len() >= 2 {
            // prev_prev = the turn before last, prev = the last turn in the chain
            if let (Some(prev_prev), Some(prev)) = (self.state.prev_turn(), self.state.last_turn()) {
                let signal = ContinuationSignal::from_chain(
                    &prev_prev.tokens,
                    &prev.tokens,
                    &turn.tokens,
                );

                // Score the edge T[n-2] → T[n-1] using T[n] as implicit feedback
                if let (Some(from_id), Some(to_id)) = (prev_prev.rule_id, prev.rule_id) {
                    self.state.record_continuation_score(from_id, to_id, signal.net_score);

                    // Also update the graph edge directly
                    for edge in &mut self.dialogue_graph.edges {
                        if edge.from_rule == from_id && edge.to_rule == to_id {
                            let alpha = 0.2;
                            let implicit = (signal.net_score + 1.0) / 2.0;
                            edge.success_rate = alpha * implicit + (1.0 - alpha) * edge.success_rate;
                        }
                    }
                }
            }
        }

        // ── Record transition T[n-1] → T[n] ──
        if let Some(prev) = self.state.last_turn() {
            if let Some(prev_rule_id) = prev.rule_id {
                let context: Vec<String> = self.state.context.iter().cloned().collect();
                self.dialogue_graph.record_transition(prev_rule_id, rule_id, context);
            }
        }

        // ── Try to generalize with recent history ──
        let recent_items: Vec<_> = self.state.chain.iter().rev().take(10).map(|t| t.clone()).collect();
        for recent in recent_items {
            if let Some(generalized) = align_and_generalize(
                &recent.tokens, tokens, &self.function_words,
            ) {
                let gen_name = format!("gen:{:016x}", generalized.source_hash);
                self.add_template_to_rule(&gen_name, generalized);
            }
        }

        // ── Update wave controller ──
        // Collect recent vocab into an owned set first so we don't hold a borrow on
        // `self.state` while calling `wave.update` (which mutably borrows state).
        let recent_vocab_owned: std::collections::HashSet<String> = self.state.recent_vocab()
            .into_iter().map(|s| (*s).clone()).collect();
        let fatigue_count = self.state.fatigue.len();
        let vocab_set: std::collections::HashSet<&String> = recent_vocab_owned.iter().collect();
        self.state.wave.update(&turn, &vocab_set, fatigue_count);

        // ── Push turn onto the chain ──
        self.state.push_turn(turn);
    }

    /// Legacy adapter: learn from a (user, system) pair.
    /// Calls observe_turn twice — once for each speaker.
    pub fn learn_from_turn_pair(
        &mut self,
        input_tokens: &[String],
        response_tokens: &[String],
        _was_successful: Option<bool>,
    ) {
        self.observe_turn(Speaker::Human, input_tokens);
        self.observe_turn(Speaker::System, response_tokens);
    }

    // ═══════════════════════════════════════════════════════
    // Learning from Relations
    // ═══════════════════════════════════════════════════════

    pub fn learn_from_triple(&mut self, triple: &RelationalTriple) {
        self.current_timestamp += 1;
        let rel_lower = triple.relation.to_lowercase().trim().to_string();
        *self.relation_frequencies.entry(rel_lower.clone()).or_default() += 1;
        self.learned_rules.entry(rel_lower.clone())
            .or_insert_with(|| SynthesisRule::new(rel_lower.clone()));
        self.subject_patterns.entry(triple.subject.clone()).or_default().push(rel_lower.clone());
        self.object_patterns.entry(rel_lower.clone()).or_default().push(triple.object.clone());

        // Template: [SUBJECT] relation [OBJECT]
        let mut subj_slot = SlotDef::new(0, "subject".to_string());
        subj_slot.observe(&triple.subject);
        subj_slot.slot_type = SlotType::NounPhrase;
        let mut obj_slot = SlotDef::new(1, "object".to_string());
        obj_slot.observe(&triple.object);
        obj_slot.slot_type = SlotType::NounPhrase;

        let template = Template::new(
            vec![Atom::Slot(0), Atom::Literal(rel_lower.clone()), Atom::Slot(1)],
            vec![subj_slot, obj_slot],
        );
        self.add_template_to_rule(&format!("rel:{}", rel_lower), template);

        if let Some(ref mut reasoner) = self.interference_reasoner {
            reasoner.add_triple_with_field(&triple.subject, &triple.relation, &triple.object, triple.confidence);
        }
    }

    pub fn learn_mapping(&mut self, name: &str, from: &str, to: &str) {
        self.mappings.entry(name.to_string())
            .or_insert_with(|| LearnedMapping::new(name.to_string()))
            .add_pair(from.to_string(), to.to_string());
    }

    // ═══════════════════════════════════════════════════════
    // Feedback (legacy — implicit is preferred)
    // ═══════════════════════════════════════════════════════

    /// **LEGACY**: Explicit feedback still works but the engine now
    /// learns implicitly from how the next turn relates to the current one.
    pub fn record_feedback(&mut self, _generated_text: &str, was_successful: bool) {
        if let Some((_, rule)) = self.learned_rules.iter_mut().last() {
            rule.record_use(was_successful);
        }
    }

    pub fn learn_pattern(&mut self, template: String, _context_tags: HashSet<String>) {
        self.learned_rules.entry(template.clone())
            .or_insert_with(|| SynthesisRule::new(template));
    }

    // ═══════════════════════════════════════════════════════
    // Synthesis — Generating responses
    // ═══════════════════════════════════════════════════════

    /// Generate from relational chains. Wave-aware, mode-mixing.
    /// Synthesize natural language from relational triples using subject aggregation.
    /// 
    /// Algorithm (ported from Python DadaEngine):
    ///   1. Aggregate: group all predicates by subject
    ///   2. Collapse: remove redundant substring predicates
    ///   3. Join: oxford comma within subject, space between subjects
    ///   4. Clean: capitalize, punctuate
    pub fn synthesize(
        &mut self,
        chains: &[RelationalTriple],
        _query_text: Option<&str>,
        fatigue_map: Option<&HashMap<String, f32>>,
    ) -> String {
        use std::collections::HashMap;
        
        self.current_timestamp += 1;
        self.state.decay_fatigue(0.15);

        if chains.is_empty() {
            return "I need more information to help you.".to_string();
        }

        // ── Phase 1: Validate triples into clean (subj, rel, obj) tuples ─────
        let mut clean_triples: Vec<(String, String, String)> = Vec::new();
        let mut seen_facts = std::collections::HashSet::new();

        for triple in chains.iter().take(12) {
            if triple.confidence < 0.2 { continue; }
            
            // Check interference contradiction
            if let Some(ref reasoner) = self.interference_reasoner {
                if reasoner.check_contradiction(&triple.subject, &triple.relation, &triple.object).contradiction {
                    continue;
                }
            }
            
            // Skip if object is fatigued
            if let Some(fm) = fatigue_map {
                let fatigue = fm.get(&triple.object.to_lowercase()).copied().unwrap_or(0.0);
                if fatigue >= 0.8 { continue; }
            }
            
            let subj = self.clean_predicate_text(&triple.subject).to_lowercase();
            let rel = triple.relation.to_uppercase();
            let obj = self.clean_predicate_text(&triple.object);
            
            if subj.is_empty() || obj.is_empty() { continue; }

            // Skip degenerate objects: if EVERY word is a function word
            {
                const FILLER: &[&str] = &[
                    "a", "an", "the", "it", "its", "is", "are", "be", "to",
                    "me", "my", "i", "we", "he", "she", "they", "or", "and",
                    "but", "so", "if", "of", "in", "on", "at", "by", "as",
                    "no", "do", "can", "was", "were", "has", "had", "for",
                ];
                let all_filler = obj.split_whitespace().all(|w| {
                    FILLER.contains(&w.to_lowercase().as_str())
                });
                if all_filler { continue; }
            }
            
            // Deduplicate
            let fact_key = format!("{}:{}:{}", subj, rel, obj);
            if !seen_facts.insert(fact_key) { continue; }
            
            clean_triples.push((subj, rel, obj));
        }

        if clean_triples.is_empty() {
            return "I'm still learning how to express that.".to_string();
        }

        // ── Phase 2: Build chain graph (object→subject linking) ───────────────
        //
        // Gated logic: relation types determine whether a triple's object
        // can chain into the next triple's subject.
        //
        //   CHAIN-TYPE (gate OPEN → object becomes next subject):
        //     CAN, CAUSES, ENABLES, LEADS, REQUIRES, CREATES, USES,
        //     DOES, WILL, BECOMES, ACTION, PRODUCES
        //
        //   TERMINAL-TYPE (gate CLOSED → sentence ends here):
        //     IS, HAS, AT, IN, ON, NEAR, SIMILAR, KNOWS, BELIEVES
        //
        // A chain: S₁ --R₁--> O₁ = S₂ --R₂--> O₂ = S₃ --R₃--> O₃
        // where O₁≈S₂ means the object of one triple matches the subject of another.

        // Index: subject → list of triple indices that have this subject
        let mut subj_index: HashMap<String, Vec<usize>> = HashMap::new();
        for (i, (subj, _, _)) in clean_triples.iter().enumerate() {
            subj_index.entry(subj.clone()).or_default().push(i);
        }

        // Walk chains: start from each triple, follow object→subject links
        let mut used: Vec<bool> = vec![false; clean_triples.len()];
        let mut chain_sentences: Vec<String> = Vec::new();

        // Try to build chains starting from each unused triple, prioritising
        // chain-type relations (they're the ones that OPEN the gate)
        let mut start_order: Vec<usize> = (0..clean_triples.len()).collect();
        // Sort: chain-type starters first, then by original pool order
        start_order.sort_by_key(|&i| {
            let is_chain = Self::is_chain_relation(&clean_triples[i].1);
            if is_chain { 0 } else { 1 }
        });

        for &start_idx in &start_order {
            if used[start_idx] { continue; }

            // Walk the chain from this triple
            let mut chain: Vec<usize> = vec![start_idx];
            used[start_idx] = true;
            let mut current_obj = clean_triples[start_idx].2.to_lowercase();

            // Follow object→subject links while the current relation is chain-type
            for _hop in 0..6 {
                let current_rel = &clean_triples[*chain.last().unwrap()].1;
                if !Self::is_chain_relation(current_rel) {
                    break; // terminal relation — gate is CLOSED
                }

                // Find a continuation: exact literal match only
                let mut best_next: Option<usize> = None;

                // LITERAL MATCH ONLY: the object of this triple must
                // exactly equal the subject of the next. No fuzzy/word-overlap
                // bridging — that risks hallucinating connections.
                if let Some(candidates) = subj_index.get(&current_obj) {
                    for &ci in candidates {
                        if !used[ci] {
                            best_next = Some(ci);
                            break;
                        }
                    }
                }

                match best_next {
                    Some(ni) => {
                        chain.push(ni);
                        used[ni] = true;
                        current_obj = clean_triples[ni].2.to_lowercase();
                    }
                    None => break, // no continuation found
                }
            }

            // Synthesize this chain into a sentence
            if chain.len() >= 2 {
                // Multi-hop chain: use relation-gated connectives
                let sentence = self.synthesize_chain(&clean_triples, &chain);
                if !sentence.is_empty() {
                    chain_sentences.push(sentence);
                }
            }
            // Single-triple chains handled in Phase 3
        }

        // ── Phase 3: Aggregate remaining unchained triples by subject ─────────
        let mut knowledge_graph: HashMap<String, HashMap<String, Vec<String>>> = HashMap::new();
        for (i, (subj, rel, obj)) in clean_triples.iter().enumerate() {
            if used[i] { continue; } // already part of a chain sentence
            knowledge_graph.entry(subj.clone())
                .or_default()
                .entry(rel.clone())
                .or_default()
                .push(obj.clone());
        }

        let mut flat_sentences: Vec<String> = Vec::new();
        for (subject, predicates) in knowledge_graph.iter() {
            let mut is_complements = Vec::new();
            let mut are_complements = Vec::new();
            let mut other_phrases = Vec::new();
            
            for (relation, objects) in predicates {
                for obj in objects {
                    let pred = self.build_predicate_phrase(relation, obj);
                    let pred_lower = pred.to_lowercase();
                    if pred_lower.starts_with("is ") {
                        is_complements.push(pred[3..].to_string());
                    } else if pred_lower.starts_with("are ") {
                        are_complements.push(pred[4..].to_string());
                    } else {
                        other_phrases.push(pred);
                    }
                }
            }
            
            is_complements = self.collapse_predicates(is_complements);
            are_complements = self.collapse_predicates(are_complements);
            other_phrases = self.collapse_predicates(other_phrases);
            
            let mut sentence_parts = Vec::new();
            if !is_complements.is_empty() {
                sentence_parts.push(format!("is {}", self.oxford_join(&is_complements)));
            }
            if !are_complements.is_empty() {
                sentence_parts.push(format!("are {}", self.oxford_join(&are_complements)));
            }
            for phrase in other_phrases {
                sentence_parts.push(phrase);
            }
            
            if sentence_parts.is_empty() { continue; }
            
            let full_predicate = sentence_parts.join(" and ");
            let subj_cap = self.capitalize_first(subject);
            flat_sentences.push(format!("{} {}.", subj_cap, full_predicate));
        }

        // ── Phase 4: Combine — chains first (they're higher structure) ────────
        let mut all_sentences = Vec::new();
        all_sentences.extend(chain_sentences);
        all_sentences.extend(flat_sentences);

        if all_sentences.is_empty() {
            "I'm still learning how to express that.".to_string()
        } else {
            all_sentences.join(" ")
        }
    }

    /// Returns true if the relation type is "chain-type" — its object
    /// logically flows into the next triple's subject.  These are the
    /// OPEN gates in gated logic reasoning.
    fn is_chain_relation(rel: &str) -> bool {
        let r = rel.to_uppercase().replace('_', " ");
        // Split on + for composite relations like CAN+FIND
        let base = r.split('+').next().unwrap_or(&r).trim();
        matches!(base,
            "CAN" | "COULD" | "WILL" | "WOULD" | "SHALL" | "SHOULD" |
            "MUST" | "MAY" | "MIGHT" |
            "CAUSES" | "CAUSE" | "CAUSED BY" |
            "ENABLES" | "ENABLE" |
            "LEADS" | "LEADS TO" | "LEAD" |
            "REQUIRES" | "REQUIRE" |
            "CREATES" | "CREATE" |
            "USES" | "USE" |
            "DOES" | "DO" | "DID" |
            "BECOMES" | "BECOME" | "BECAME" |
            "ACTION" | "PERFORMED" |
            "PRODUCES" | "PRODUCE" |
            "GENERATES" | "GENERATE" |
            "PREVENTS" | "PREVENT" |
            "NEEDS" | "NEED" |
            "MAKES" | "MAKE" |
            "WANTS" | "WANT" |
            "BUILDS" | "BUILD" |
            "RESULTS IN" | "EFFECT OF" | "REASON FOR"
        )
    }

    /// Synthesize a multi-hop chain into a connected sentence using
    /// relation-gated connectives.
    ///
    /// Chain: [(S₁,R₁,O₁), (S₂,R₂,O₂), ...] where O₁≈S₂
    /// Output: "S₁ R₁ O₁, [connective] R₂ O₂, [connective] R₃ O₃."
    fn synthesize_chain(&self, triples: &[(String, String, String)], chain: &[usize]) -> String {
        if chain.is_empty() { return String::new(); }

        let mut parts: Vec<String> = Vec::new();

        for (hop_idx, &triple_idx) in chain.iter().enumerate() {
            let (ref subj, ref rel, ref obj) = triples[triple_idx];

            if hop_idx == 0 {
                // First hop: full "Subject relation object"
                let subj_cap = self.capitalize_first(subj);
                let pred = self.build_predicate_phrase(rel, obj);
                parts.push(format!("{} {}", subj_cap, pred));
            } else {
                // Subsequent hops: use a connective based on the PREVIOUS
                // relation's type (that's the gate that opened this hop)
                let prev_rel = &triples[chain[hop_idx - 1]].1;
                let connective = Self::gate_connective(prev_rel);
                let pred = self.build_predicate_phrase(rel, obj);
                parts.push(format!("{} {}", connective, pred));
            }
        }

        if parts.is_empty() { return String::new(); }
        format!("{}.", parts.join(", "))
    }

    /// Choose a connective word/phrase based on the relation type that
    /// opened the gate. This is the linguistic realization of the gate.
    fn gate_connective(rel: &str) -> &'static str {
        let r = rel.to_uppercase().replace('_', " ");
        let base = r.split('+').next().unwrap_or(&r).trim();
        match base {
            "CAUSES" | "CAUSE" | "CAUSED BY" => "which causes",
            "ENABLES" | "ENABLE" => "enabling",
            "LEADS" | "LEADS TO" | "LEAD" | "RESULTS IN" => "leading to",
            "REQUIRES" | "REQUIRE" | "NEEDS" | "NEED" => "which requires",
            "CREATES" | "CREATE" | "BUILDS" | "BUILD" | "MAKES" | "MAKE" => "creating",
            "USES" | "USE" => "using",
            "PRODUCES" | "PRODUCE" | "GENERATES" | "GENERATE" => "producing",
            "PREVENTS" | "PREVENT" => "which prevents",
            "BECOMES" | "BECOME" | "BECAME" => "becoming",
            "DOES" | "DO" | "DID" | "ACTION" | "PERFORMED" => "and then",
            "WANTS" | "WANT" => "wanting",
            "EFFECT OF" | "REASON FOR" => "resulting in",
            // Modals: the object already contains the action, so "which" suffices
            "CAN" | "COULD" | "WILL" | "WOULD" | "SHALL" | "SHOULD" |
            "MUST" | "MAY" | "MIGHT" => "which",
            _ => "and",
        }
    }

    /// Clean text: strip leading prepositions, trim whitespace
    fn clean_predicate_text(&self, text: &str) -> String {
        let trimmed = text.trim();
        if trimmed.is_empty() { return String::new(); }
        
        // Strip leading prepositions common in extracted objects
        const PREPS: &[&str] = &["in ", "into ", "from ", "to ", "on ", "at ", "by ", "through "];
        let lower = trimmed.to_lowercase();
        for prep in PREPS {
            if lower.starts_with(prep) {
                return trimmed[prep.len()..].trim().to_string();
            }
        }
        
        trimmed.to_string()
    }

    /// Build predicate phrase from relation + object: "IS dog" → "is a dog"
    fn build_predicate_phrase(&self, relation: &str, object: &str) -> String {
        let rel_lower = relation.to_lowercase().replace('_', " ");
        
        // Add article if needed for copula relations
        if rel_lower == "is" || rel_lower == "are" {
            // Check if object already starts with article
            let obj_lower = object.to_lowercase();
            if obj_lower.starts_with("a ") || obj_lower.starts_with("an ") || obj_lower.starts_with("the ") {
                format!("{} {}", rel_lower, object)
            } else {
                // Heuristic: add "a" unless object is plural or proper noun
                let needs_article = !obj_lower.ends_with('s') && 
                                   object.chars().next().map_or(false, |c| c.is_lowercase());
                if needs_article {
                    format!("{} a {}", rel_lower, object)
                } else {
                    format!("{} {}", rel_lower, object)
                }
            }
        } else {
            format!("{} {}", rel_lower, object)
        }
    }

    /// Collapse redundant predicates: remove substrings
    /// ["a greeting", "a greeting used to start"] → ["a greeting used to start"]
    fn collapse_predicates(&self, mut phrases: Vec<String>) -> Vec<String> {
        if phrases.len() <= 1 { return phrases; }
        
        // Sort by length descending (keep longest/most detailed)
        phrases.sort_by_key(|p| std::cmp::Reverse(p.len()));
        
        let mut kept: Vec<String> = Vec::new();
        for phrase in phrases {
            let p_lower = phrase.to_lowercase();
            let mut is_substring = false;
            
            for kept_phrase in &kept {
                let k_lower = kept_phrase.to_lowercase();
                if k_lower.contains(&p_lower) {
                    is_substring = true;
                    break;
                }
            }
            
            if !is_substring {
                kept.push(phrase);
            }
        }
        
        kept
    }

    /// Oxford comma join: ["a", "b", "c"] → "a, b, and c"
    fn oxford_join(&self, items: &[String]) -> String {
        match items.len() {
            0 => String::new(),
            1 => items[0].clone(),
            2 => format!("{} and {}", items[0], items[1]),
            _ => {
                let last = items.len() - 1;
                let mut parts: Vec<String> = items[..last].iter().cloned().collect();
                parts.push(format!("and {}", items[last]));
                parts.join(", ")
            }
        }
    }

    /// Synthesize using the dialogue graph — what should follow
    /// the most recent turn in the chain?
    pub fn synthesize_from_graph(
        &mut self,
        input_tokens: &[String],
        bindings: &HashMap<SlotId, String>,
    ) -> Option<String> {
        let input_template = extract_template_from_tokens(input_tokens, &self.function_words);
        let input_name = format!("turn:{:016x}", input_template.source_hash);
        let input_rule_id = *self.rule_name_index.get(&input_name)?;

        let (response_rule_id, _) = self.dialogue_graph.best_continuation_with_implicit(
            input_rule_id,
            &self.state.context,
            &self.state.continuation_scores,
        )?;

        let seed = self.advance_rng();
        let (compress_w, expand_w) = self.state.wave.mode_mix();

        let rule = self.rules.get_mut(response_rule_id as usize)?;
        let template = if rule.alternatives.len() > 1 {
            let mut best_idx = 0;
            let mut best_score = f32::NEG_INFINITY;
            for (i, tmpl) in rule.alternatives.iter().enumerate() {
                if rule.last_chosen == Some(i) && rule.alternatives.len() > 1 { continue; }
                let mode_score = match tmpl.classify_mode() {
                    TemplateMode::Compressive => compress_w,
                    TemplateMode::Expansive => expand_w,
                    TemplateMode::Mixed => 0.5,
                };
                let combined = mode_score * 0.6 + tmpl.confidence() * 0.4;
                if combined > best_score { best_score = combined; best_idx = i; }
            }
            rule.last_chosen = Some(best_idx);
            rule.eval_count += 1;
            &rule.alternatives[best_idx]
        } else {
            rule.select_alternative(seed)?
        };

        if self.state.is_fatigued(template.source_hash, 0.8) { return None; }
        let response = template.instantiate(bindings, seed);
        self.state.use_pattern(template.source_hash, 1.0);
        Some(self.format_sentence(&response))
    }

    /// Synthesize using the dialogue graph with synthesis method context
    pub fn synthesize_from_graph_with_method(
        &mut self,
        input_tokens: &[String],
        bindings: &HashMap<SlotId, String>,
        synthesis_method: crate::SynthesisMethod,
    ) -> Option<String> {
        let input_template = extract_template_from_tokens(input_tokens, &self.function_words);
        let input_name = format!("turn:{:016x}", input_template.source_hash);
        let input_rule_id = *self.rule_name_index.get(&input_name)?;

        let (response_rule_id, _) = self.dialogue_graph.best_continuation_with_implicit(
            input_rule_id,
            &self.state.context,
            &self.state.continuation_scores,
        )?;

        let seed = self.advance_rng();
        let (compress_w, expand_w) = self.state.wave.mode_mix();

        let rule = self.rules.get_mut(response_rule_id as usize)?;
        let template = if rule.alternatives.len() > 1 {
            let mut best_idx = 0;
            let mut best_score = f32::NEG_INFINITY;
            for (i, tmpl) in rule.alternatives.iter().enumerate() {
                if rule.last_chosen == Some(i) && rule.alternatives.len() > 1 { continue; }
                
                // Adjust mode scoring based on synthesis method
                let mode_score = match synthesis_method {
                    crate::SynthesisMethod::Definition => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.2,
                        TemplateMode::Expansive => expand_w * 0.8,
                        TemplateMode::Mixed => 0.6,
                    },
                    crate::SynthesisMethod::Process => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 0.9,
                        TemplateMode::Expansive => expand_w * 1.1,
                        TemplateMode::Mixed => 0.7,
                    },
                    crate::SynthesisMethod::Capability => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.0,
                        TemplateMode::Expansive => expand_w * 1.0,
                        TemplateMode::Mixed => 0.8,
                    },
                    crate::SynthesisMethod::Location => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.1,
                        TemplateMode::Expansive => expand_w * 0.9,
                        TemplateMode::Mixed => 0.6,
                    },
                    crate::SynthesisMethod::Identity => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.3,
                        TemplateMode::Expansive => expand_w * 0.7,
                        TemplateMode::Mixed => 0.5,
                    },
                    crate::SynthesisMethod::Temporal => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 0.8,
                        TemplateMode::Expansive => expand_w * 1.2,
                        TemplateMode::Mixed => 0.7,
                    },
                    crate::SynthesisMethod::Causal => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 0.9,
                        TemplateMode::Expansive => expand_w * 1.1,
                        TemplateMode::Mixed => 0.6,
                    },
                    crate::SynthesisMethod::Method => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 0.8,
                        TemplateMode::Expansive => expand_w * 1.2,
                        TemplateMode::Mixed => 0.7,
                    },
                    crate::SynthesisMethod::Quantitative => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.1,
                        TemplateMode::Expansive => expand_w * 0.9,
                        TemplateMode::Mixed => 0.6,
                    },
                    crate::SynthesisMethod::Instructional => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 0.7,
                        TemplateMode::Expansive => expand_w * 1.3,
                        TemplateMode::Mixed => 0.8,
                    },
                    crate::SynthesisMethod::Personal => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.0,
                        TemplateMode::Expansive => expand_w * 1.0,
                        TemplateMode::Mixed => 0.9,
                    },
                    crate::SynthesisMethod::Comparative => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 0.9,
                        TemplateMode::Expansive => expand_w * 1.1,
                        TemplateMode::Mixed => 0.6,
                    },
                    crate::SynthesisMethod::Sequential => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 0.8,
                        TemplateMode::Expansive => expand_w * 1.2,
                        TemplateMode::Mixed => 0.7,
                    },
                    crate::SynthesisMethod::Refusal => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.2,
                        TemplateMode::Expansive => expand_w * 0.8,
                        TemplateMode::Mixed => 0.5,
                    },
                    crate::SynthesisMethod::Inability => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.1,
                        TemplateMode::Expansive => expand_w * 0.9,
                        TemplateMode::Mixed => 0.6,
                    },
                    crate::SynthesisMethod::Disapproval => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.0,
                        TemplateMode::Expansive => expand_w * 1.0,
                        TemplateMode::Mixed => 0.7,
                    },
                    crate::SynthesisMethod::Negation => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.1,
                        TemplateMode::Expansive => expand_w * 0.9,
                        TemplateMode::Mixed => 0.6,
                    },
                    crate::SynthesisMethod::Correction => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w * 1.0,
                        TemplateMode::Expansive => expand_w * 1.0,
                        TemplateMode::Mixed => 0.8,
                    },
                    crate::SynthesisMethod::General => match tmpl.classify_mode() {
                        TemplateMode::Compressive => compress_w,
                        TemplateMode::Expansive => expand_w,
                        TemplateMode::Mixed => 0.5,
                    },
                };
                
                let combined = mode_score * 0.7 + tmpl.confidence() * 0.3;
                if combined > best_score { best_score = combined; best_idx = i; }
            }
            rule.last_chosen = Some(best_idx);
            rule.eval_count += 1;
            &rule.alternatives[best_idx]
        } else {
            rule.select_alternative(seed)?
        };

        if self.state.is_fatigued(template.source_hash, 0.8) { return None; }
        let response = template.instantiate(bindings, seed);
        self.state.use_pattern(template.source_hash, 1.0);
        Some(self.format_sentence(&response))
    }

    pub fn triple_to_sentence(&self, triple: &RelationalTriple) -> String {
        format!("{} {} {}.", self.capitalize_first(&triple.subject), triple.relation.trim(), &triple.object)
    }

    fn capitalize_first(&self, text: &str) -> String {
        let mut chars: Vec<char> = text.chars().collect();
        if !chars.is_empty() { chars[0] = chars[0].to_uppercase().next().unwrap_or(chars[0]); }
        chars.into_iter().collect()
    }

    fn format_sentence(&self, text: &str) -> String {
        let trimmed = text.trim();
        if trimmed.is_empty() { return String::new(); }
        let c = self.capitalize_first(trimmed);
        if c.ends_with('.') || c.ends_with('!') || c.ends_with('?') { c } else { format!("{}.", c) }
    }

    fn advance_rng(&mut self) -> u64 {
        let mut x = self.rng_state;
        x ^= x << 13; x ^= x >> 7; x ^= x << 17;
        self.rng_state = x; x
    }

    // ═══════════════════════════════════════════════════════
    // Offline Corpus Ingestion
    // ═══════════════════════════════════════════════════════

    /// Ingest conversation logs offline. Each log is a chain of
    /// alternating turns: [(Speaker, tokens), (Speaker, tokens), ...].
    ///
    /// NOT pairs. A chain. The engine calls observe_turn for each.
    pub fn ingest_corpus(
        &mut self,
        logs: &[Vec<(Speaker, Vec<String>)>],
    ) {
        for conversation in logs {
            for (speaker, tokens) in conversation {
                self.observe_turn(*speaker, tokens);
            }
            // Clear chain between conversations to prevent cross-bleed
            self.state.chain.clear();
        }
    }

    /// Legacy adapter: ingest logs as (user, system) pairs.
    /// Internally converts to the chain model.
    pub fn ingest_corpus_logs(
        &mut self,
        logs: &[Vec<(Vec<String>, Vec<String>)>],
    ) {
        for conversation in logs {
            for (user_tokens, system_tokens) in conversation {
                self.observe_turn(Speaker::Human, user_tokens);
                self.observe_turn(Speaker::System, system_tokens);
            }
            self.state.chain.clear();
        }
    }

    // ═══════════════════════════════════════════════════════
    // Diagnostics
    // ═══════════════════════════════════════════════════════

    pub fn stats(&self) -> DadaStats {
        DadaStats {
            total_rules: self.rules.len(),
            total_alternatives: self.rules.iter().map(|r| r.alternatives.len()).sum(),
            total_edges: self.dialogue_graph.edges.len(),
            chain_depth: self.state.chain.len(),
            total_relation_types: self.relation_frequencies.len(),
            avg_alternatives_per_rule: if self.rules.is_empty() { 0.0 }
                else { self.rules.iter().map(|r| r.alternatives.len() as f64).sum::<f64>() / self.rules.len() as f64 },
            turn_number: self.state.turn_number,
            wave_explore_bias: self.state.wave.explore_bias,
            wave_phase: self.state.wave.wave_phase,
            continuation_edges_scored: self.state.continuation_scores.len(),
        }
    }

    /// Get the current conversation chain length for routing decisions
    pub fn conversation_length(&self) -> usize {
        self.state.chain.len()
    }
}

#[derive(Debug, Clone)]
pub struct DadaStats {
    pub total_rules: usize,
    pub total_alternatives: usize,
    pub total_edges: usize,
    pub chain_depth: usize,
    pub total_relation_types: usize,
    pub avg_alternatives_per_rule: f64,
    pub turn_number: u64,
    pub wave_explore_bias: f32,
    pub wave_phase: f32,
    pub continuation_edges_scored: usize,
}

// ═══════════════════════════════════════════════════════════════════
// Tests
// ═══════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_chain_model_basic() {
        let mut dada = DadaEngine::default();

        // Conversation is a chain, not pairs
        dada.observe_turn(Speaker::Human, &["hello".into()]);
        assert_eq!(dada.state.chain.len(), 1);
        assert_eq!(dada.state.chain[0].speaker, Speaker::Human);

        dada.observe_turn(Speaker::System, &["hi".into(), "there".into()]);
        assert_eq!(dada.state.chain.len(), 2);
        assert_eq!(dada.state.chain[1].speaker, Speaker::System);

        dada.observe_turn(Speaker::Human, &["how".into(), "are".into(), "you".into()]);
        assert_eq!(dada.state.chain.len(), 3);

        // Each turn after the first creates a graph edge
        assert!(dada.dialogue_graph.edges.len() >= 2);
    }

    #[test]
    fn test_implicit_feedback_from_chain() {
        let mut dada = DadaEngine::default();

        // T₀: human opens
        dada.observe_turn(Speaker::Human, &["what".into(), "is".into(), "rust".into()]);
        // T₁: system responds
        dada.observe_turn(Speaker::System, &["rust".into(), "is".into(), "a".into(), "language".into()]);
        // T₂: human builds on it (picks up "language") — implicit positive
        dada.observe_turn(Speaker::Human, &["tell".into(), "me".into(), "more".into(), "about".into(), "language".into()]);

        // T₂ should have generated a continuation signal scoring T₀→T₁
        assert!(!dada.state.continuation_scores.is_empty(),
            "Should have implicit continuation scores");
    }

    #[test]
    fn test_implicit_feedback_rejection() {
        let mut dada = DadaEngine::default();

        dada.observe_turn(Speaker::Human, &["what".into(), "is".into(), "rust".into()]);
        dada.observe_turn(Speaker::System, &["rust".into(), "is".into(), "a".into(), "color".into()]);
        // Human rejects
        dada.observe_turn(Speaker::Human, &["no".into(), "not".into(), "what".into(), "i".into(), "meant".into()]);

        // The continuation score on the T₀→T₁ edge should be negative
        let scores: Vec<f32> = dada.state.continuation_scores.values()
            .flatten().copied().collect();
        assert!(!scores.is_empty());
        // At least one score should be negative (rejection signal)
        assert!(scores.iter().any(|&s| s < 0.0),
            "Rejection should produce negative score, got: {:?}", scores);
    }

    #[test]
    fn test_alternating_speakers() {
        let mut dada = DadaEngine::default();

        // Natural conversation alternation
        dada.observe_turn(Speaker::Human, &["cats".into(), "are".into(), "great".into()]);
        dada.observe_turn(Speaker::System, &["yes".into(), "cats".into(), "are".into(), "wonderful".into()]);
        dada.observe_turn(Speaker::Human, &["especially".into(), "orange".into(), "cats".into()]);
        dada.observe_turn(Speaker::System, &["orange".into(), "cats".into(), "have".into(), "personality".into()]);
        dada.observe_turn(Speaker::Human, &["my".into(), "cat".into(), "is".into(), "orange".into()]);

        assert_eq!(dada.state.chain.len(), 5);

        // Speakers alternate
        for (i, turn) in dada.state.chain.iter().enumerate() {
            let expected = if i % 2 == 0 { Speaker::Human } else { Speaker::System };
            assert_eq!(turn.speaker, expected, "Turn {} should be {:?}", i, expected);
        }

        // Multiple continuation signals computed (for turns 3, 4, 5)
        assert!(dada.state.continuation_scores.len() >= 1);
    }

    #[test]
    fn test_wave_updates_per_turn() {
        let mut dada = DadaEngine::default();

        let initial_phase = dada.state.wave.wave_phase;

        dada.observe_turn(Speaker::Human, &["quantum".into(), "entanglement".into()]);
        assert!(dada.state.wave.wave_phase > initial_phase, "Wave should advance each turn");

        dada.observe_turn(Speaker::System, &["interesting".into(), "topic".into()]);
        assert!(dada.state.wave.wave_phase > initial_phase + 0.2, "Wave should keep advancing");
    }

    #[test]
    fn test_continuation_signal_math() {
        // Engagement: continuation picks up terms from current
        let signal = ContinuationSignal::from_chain(
            &["hello".into()],
            &["rust".into(), "is".into(), "fast".into()],
            &["tell".into(), "me".into(), "about".into(), "rust".into(), "fast".into()],
        );
        assert!(signal.engagement > 0.0);
        assert!(signal.net_score > 0.0);

        // Rejection
        let signal = ContinuationSignal::from_chain(
            &["hello".into()],
            &["rust".into(), "is".into(), "a".into(), "color".into()],
            &["no".into(), "wrong".into(), "not".into(), "that".into()],
        );
        assert!(signal.rejection > 0.0);
        assert!(signal.net_score < 0.0);
    }

    #[test]
    fn test_dialogue_graph() {
        let mut graph = DialogueGraph::new();
        graph.record_transition(0, 1, vec![]);
        graph.record_transition(0, 1, vec![]);
        graph.record_transition(0, 2, vec![]);

        assert_eq!(graph.edges.len(), 2);
        assert_eq!(graph.edges[0].frequency, 2);
        assert_eq!(graph.edges[1].frequency, 1);

        let best = graph.best_continuation(0, &HashSet::new());
        assert_eq!(best.unwrap().0, 1); // Higher frequency wins
    }

    #[test]
    fn test_template_mode() {
        let compress = Template::new(
            vec![Atom::Literal("a".into()), Atom::Literal("b".into()), Atom::Literal("c".into()), Atom::Literal("d".into())],
            vec![],
        );
        assert_eq!(compress.classify_mode(), TemplateMode::Compressive);

        let expand = Template::new(
            vec![Atom::Slot(0), Atom::Slot(1), Atom::Literal("is".into()), Atom::Slot(2)],
            vec![],
        );
        assert_eq!(expand.classify_mode(), TemplateMode::Expansive);
    }

    #[test]
    fn test_corpus_ingestion_chain_model() {
        let mut dada = DadaEngine::default();

        let logs = vec![
            vec![
                (Speaker::Human, vec!["hello".into()]),
                (Speaker::System, vec!["hi".into(), "there".into()]),
                (Speaker::Human, vec!["how".into(), "are".into(), "you".into()]),
                (Speaker::System, vec!["doing".into(), "well".into()]),
            ],
            vec![
                (Speaker::Human, vec!["hello".into()]),
                (Speaker::System, vec!["hey".into()]),
            ],
        ];

        dada.ingest_corpus(&logs);

        let stats = dada.stats();
        assert!(stats.total_rules > 0);
        assert!(stats.total_edges > 0);
    }

    #[test]
    fn test_legacy_pair_adapter() {
        let mut dada = DadaEngine::default();

        // Old-style pair learning still works
        dada.learn_from_turn_pair(
            &["what".into(), "is".into(), "rust".into()],
            &["rust".into(), "is".into(), "fast".into()],
            None,
        );

        // Should have created 2 turns in the chain
        assert_eq!(dada.state.chain.len(), 2);
        assert_eq!(dada.state.chain[0].speaker, Speaker::Human);
        assert_eq!(dada.state.chain[1].speaker, Speaker::System);
    }

    #[test]
    fn test_learn_from_triple() {
        let mut dada = DadaEngine::default();
        dada.learn_from_triple(&RelationalTriple::new("cat".into(), "is".into(), "animal".into(), 1.0));
        dada.learn_from_triple(&RelationalTriple::new("dog".into(), "is".into(), "animal".into(), 1.0));

        let rule_id = dada.rule_name_index["rel:is"];
        let rule = &dada.rules[rule_id as usize];
        assert!(!rule.alternatives.is_empty());
        let slot = &rule.alternatives[0].slots[0];
        assert!(slot.observed_fillers.contains_key("cat"));
        assert!(slot.observed_fillers.contains_key("dog"));
    }

    #[test]
    fn test_synthesis() {
        let mut dada = DadaEngine::default();
        let triples = vec![
            RelationalTriple::new("alice".into(), "is".into(), "kind".into(), 1.0),
            RelationalTriple::new("bob".into(), "likes".into(), "alice".into(), 1.0),
        ];
        let result = dada.synthesize(&triples, None, None);
        assert!(!result.is_empty());
        assert_ne!(result, "I need more information to help you.");
    }

    #[test]
    fn test_conversation_state_chain() {
        let mut state = ConversationState::new(5);

        state.push_turn(Turn {
            id: 1, speaker: Speaker::Human, tokens: vec!["hi".into()],
            template: None, rule_id: None, relations_extracted: vec![], timestamp: 1,
        });
        state.push_turn(Turn {
            id: 2, speaker: Speaker::System, tokens: vec!["hello".into()],
            template: None, rule_id: None, relations_extracted: vec![], timestamp: 2,
        });

        assert_eq!(state.last_turn().unwrap().speaker, Speaker::System);
        assert_eq!(state.prev_turn().unwrap().speaker, Speaker::Human);
        assert!(state.prev_prev_turn().is_none()); // Only 2 turns

        state.push_turn(Turn {
            id: 3, speaker: Speaker::Human, tokens: vec!["how".into()],
            template: None, rule_id: None, relations_extracted: vec![], timestamp: 3,
        });

        assert!(state.prev_prev_turn().is_some()); // Now 3 turns
    }
}
