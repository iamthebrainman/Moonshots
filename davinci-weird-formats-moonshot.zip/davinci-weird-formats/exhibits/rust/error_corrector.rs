//! # Relational Error Corrector
//!
//! Learns relation correction rules by diffing a student graph against a
//! teacher graph, then applies those rules to future triples.
//!
//! Workflow:
//!   1. `analyze_teacher_correction(student_text, teacher_text)` — parse both
//!      into triple sets, compute a graph diff, infer substitution rules,
//!      and persist them.
//!   2. `apply_corrections(triples)` — rewrite any triple whose relation
//!      matches a learned pattern.
//!   3. `should_suppress(triple)` — returns true for relation types that
//!      the teacher has explicitly removed (no replacement).
//!
//! Matching strategy (mirroring the Python):
//!   - Exact: same subject AND object
//!   - Fuzzy: head-word match (last meaningful non-stopword token)
//!   - Phrase extraction: middle text between head-words → normalised label
//!
//! All from Python `RelationalErrorCorrector`.

use std::collections::HashSet;

/// A single learned substitution rule.
#[derive(Debug, Clone)]
pub struct CorrectionRule {
    /// Relation label to match against (wildcard on subject/object).
    pub bad_relation: String,
    /// Replacement relation label.
    pub good_relation: String,
    /// Optional (subject_head, object_head) context for specificity.
    pub context: Option<(String, String)>,
    /// 0.0–1.0
    pub confidence: f32,
}

/// Summary of one graph-diff operation.
#[derive(Debug, Clone)]
pub struct GraphDiff {
    /// Triples only in student graph (wrong/extra).
    pub errors: HashSet<(String, String, String)>,
    /// Triples only in teacher graph (missing/correct).
    pub corrections: HashSet<(String, String, String)>,
    /// Triples in both (confirmed correct).
    pub confirmations: HashSet<(String, String, String)>,
    /// Directly paired (bad → good) fixes.
    pub fixes: Vec<Fix>,
    /// Triples deleted by teacher with no replacement.
    pub deletions: Vec<(String, String, String)>,
}

#[derive(Debug, Clone)]
pub struct Fix {
    pub kind: FixKind,
    pub bad: (String, String, String),
    pub good: (String, String, String),
    pub rule_description: String,
}

#[derive(Debug, Clone, PartialEq)]
pub enum FixKind {
    RelationSubstitution,
    PhraseInferred,
}

// --- Stop-words for head-word extraction ---
const SKIP_WORDS: &[&str] = &[
    "a", "an", "the", "is", "are", "was", "were", "of", "in", "on",
    "to", "for", "as", "by", "at", "part", "kind", "made", "used", "use", "can",
];

fn head_word(phrase: &str) -> String {
    if phrase.is_empty() {
        return String::new();
    }
    let parts: Vec<&str> = phrase
        .split(|c: char| !c.is_alphanumeric())
        .filter(|p| !p.is_empty())
        .collect();
    // Prefer last meaningful content word
    for p in parts.iter().rev() {
        let low = p.to_lowercase();
        if !SKIP_WORDS.contains(&low.as_str()) && low.len() >= 2 {
            return low;
        }
    }
    parts.last().map(|s| s.to_lowercase()).unwrap_or_default()
}

/// Map a middle phrase to a normalised relation label.
fn phrase_to_label(phrase: &str) -> String {
    let p = phrase.to_lowercase();
    if p.contains("kind") { return "IS_KIND_OF".to_string(); }
    if p.contains("part") || p.trim() == "of" { return "PART_OF".to_string(); }
    if p.contains("made of") || p.contains("made") { return "MADE_OF".to_string(); }
    if p.contains("used to") || p.contains("used for") { return "USED_FOR".to_string(); }
    if p.trim() == "is" { return "IS".to_string(); }
    p.replace(' ', "_").to_uppercase()
}

/// Extract the text between `a` and `b` in `text`, up to a reasonable span.
fn extract_middle(text: &str, a: &str, b: &str) -> Option<String> {
    let t = text.to_lowercase();
    let start = t.find(a)?;
    let after_a = start + a.len();
    let end = t[after_a..].find(b)?;
    let middle = t[after_a..after_a + end].trim().to_string();
    // Limit to ≤ 5 words to avoid capturing whole sentences
    let words: Vec<&str> = middle.split_whitespace().collect();
    if words.len() <= 5 && !middle.is_empty() {
        Some(middle)
    } else {
        None
    }
}

pub struct RelationalErrorCorrector {
    pub correction_rules: Vec<CorrectionRule>,
    pub suppressed_relations: HashSet<String>,
}

impl Default for RelationalErrorCorrector {
    fn default() -> Self {
        Self::new()
    }
}

impl RelationalErrorCorrector {
    pub fn new() -> Self {
        Self {
            correction_rules: Vec::new(),
            suppressed_relations: HashSet::new(),
        }
    }

    // ---- Graph diff ----

    /// Compute differences between student and teacher triple sets.
    pub fn graph_diff(
        &self,
        student: &HashSet<(String, String, String)>,
        teacher: &HashSet<(String, String, String)>,
    ) -> GraphDiff {
        let errors: HashSet<_> = student.difference(teacher).cloned().collect();
        let corrections: HashSet<_> = teacher.difference(student).cloned().collect();
        let confirmations: HashSet<_> = student.intersection(teacher).cloned().collect();

        let mut fixes = Vec::new();

        // Exact subject+object pairs with different relations
        for bad @ (s_bad, r_bad, o_bad) in &errors {
            for good @ (s_good, r_good, o_good) in &corrections {
                if s_bad == s_good && o_bad == o_good && r_bad != r_good {
                    fixes.push(Fix {
                        kind: FixKind::RelationSubstitution,
                        bad: bad.clone(),
                        good: good.clone(),
                        rule_description: format!("REPLACE {} WITH {} FOR ({}, {})", r_bad, r_good, s_bad, o_bad),
                    });
                }
            }
        }

        // Deletions: errors with no matching correction on same (s, o)
        let deletions: Vec<_> = errors
            .iter()
            .filter(|(s, _, o)| {
                !corrections.iter().any(|(cs, _, co)| cs == s && co == o)
            })
            .cloned()
            .collect();

        GraphDiff {
            errors,
            corrections,
            confirmations,
            fixes,
            deletions,
        }
    }

    // ---- Learning ----

    /// Parse student + teacher texts, diff, learn rules, return diff.
    /// Accepts pre-parsed triple sets (the caller handles parsing via RelationEngine).
    pub fn analyze_correction(
        &mut self,
        student_triples: HashSet<(String, String, String)>,
        teacher_triples: HashSet<(String, String, String)>,
        student_text: &str,
        teacher_text: &str,
    ) -> GraphDiff {
        let mut diff = self.graph_diff(&student_triples, &teacher_triples);

        // --- Fuzzy pairing via head-words ---
        let mut extra_fixes: Vec<Fix> = Vec::new();
        for err @ (s_bad, r_bad, o_bad) in &diff.errors {
            let hs_bad = head_word(s_bad);
            let ho_bad = head_word(o_bad);
            if hs_bad.is_empty() || ho_bad.is_empty() { continue; }

            for corr @ (s_good, r_good, o_good) in &diff.corrections {
                let hs_good = head_word(s_good);
                let ho_good = head_word(o_good);
                if r_bad != r_good && hs_bad == hs_good && ho_bad == ho_good {
                    extra_fixes.push(Fix {
                        kind: FixKind::RelationSubstitution,
                        bad: err.clone(),
                        good: corr.clone(),
                        rule_description: format!("REPLACE {} WITH {} FOR ({}, {})", r_bad, r_good, hs_bad, ho_bad),
                    });
                }
            }
        }

        // Learn from extra fuzzy fixes
        for fix in &extra_fixes {
            self.learn_rule(fix);
        }
        diff.fixes.extend(extra_fixes);

        // --- Phrase extraction fallback (still no fixes) ---
        if diff.fixes.is_empty() {
            for err @ (s_bad, r_bad, o_bad) in &diff.errors {
                let hs = head_word(s_bad);
                let ho = head_word(o_bad);
                if hs.is_empty() || ho.is_empty() { continue; }

                let s_phrase = extract_middle(student_text, &hs, &ho);
                let t_phrase = extract_middle(teacher_text, &hs, &ho);

                if let (Some(sp), Some(tp)) = (s_phrase, t_phrase) {
                    if sp != tp {
                        let good_rel = phrase_to_label(&tp);
                        let fix = Fix {
                            kind: FixKind::PhraseInferred,
                            bad: err.clone(),
                            good: (s_bad.clone(), good_rel.clone(), o_bad.clone()),
                            rule_description: format!("REPLACE {} WITH {} FOR ({}, {})", r_bad, good_rel, hs, ho),
                        };
                        self.learn_rule(&fix);
                        diff.fixes.push(fix);
                    }
                }
            }
        }

        // Learn from direct fixes too
        for fix in &diff.fixes {
            self.learn_rule(fix);
        }

        // Suppress explicitly deleted relations
        for (_, rel, _) in &diff.deletions {
            self.suppressed_relations.insert(rel.clone());
        }

        diff
    }

    /// Persist a fix as a reusable rule (deduplicates).
    pub fn learn_rule(&mut self, fix: &Fix) {
        let (_, bad_rel, _) = &fix.bad;
        let (s_bad, _, o_bad) = &fix.bad;
        let (_, good_rel, _) = &fix.good;

        let context = {
            let hs = head_word(s_bad);
            let ho = head_word(o_bad);
            if hs.is_empty() && ho.is_empty() {
                None
            } else {
                Some((hs, ho))
            }
        };

        let rule = CorrectionRule {
            bad_relation:  bad_rel.clone(),
            good_relation: good_rel.clone(),
            context:       context.clone(),
            confidence:    1.0,
        };

        // Deduplicate
        let already = self.correction_rules.iter().any(|r| {
            r.bad_relation  == rule.bad_relation
                && r.good_relation == rule.good_relation
                && r.context      == rule.context
        });
        if !already {
            self.correction_rules.push(rule);
        }
    }

    // ---- Application ----

    /// Apply learned rules to a list of triples. Returns new list.
    pub fn apply_corrections(
        &self,
        triples: &[(String, String, String)],
    ) -> Vec<(String, String, String)> {
        triples
            .iter()
            .map(|(s, r, o)| {
                let hs = head_word(s);
                let ho = head_word(o);
                for rule in &self.correction_rules {
                    if rule.bad_relation != *r {
                        continue;
                    }
                    let ctx_ok = match &rule.context {
                        None => true,
                        Some((ctx_s, ctx_o)) => {
                            (ctx_s.is_empty() || *ctx_s == hs)
                                && (ctx_o.is_empty() || *ctx_o == ho)
                        }
                    };
                    if ctx_ok {
                        return (s.clone(), rule.good_relation.clone(), o.clone());
                    }
                }
                (s.clone(), r.clone(), o.clone())
            })
            .collect()
    }

    /// True if the relation in this triple has been suppressed.
    pub fn should_suppress(&self, triple: &(String, String, String)) -> bool {
        self.suppressed_relations.contains(&triple.1)
    }

    // ---- Serialisation helpers ----

    pub fn export_rules(&self) -> Vec<(String, String, Option<(String, String)>, f32)> {
        self.correction_rules
            .iter()
            .map(|r| (r.bad_relation.clone(), r.good_relation.clone(), r.context.clone(), r.confidence))
            .collect()
    }

    pub fn import_rules(&mut self, rules: Vec<(String, String, Option<(String, String)>, f32)>) {
        for (bad, good, ctx, conf) in rules {
            self.correction_rules.push(CorrectionRule {
                bad_relation: bad,
                good_relation: good,
                context: ctx,
                confidence: conf,
            });
        }
    }
}

// ---- helper: build triple set from slice ----
pub fn to_triple_set(triples: &[(String, String, String)]) -> HashSet<(String, String, String)> {
    triples.iter().cloned().collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ts(data: &[(&str, &str, &str)]) -> HashSet<(String, String, String)> {
        data.iter()
            .map(|(s, r, o)| (s.to_string(), r.to_string(), o.to_string()))
            .collect()
    }

    #[test]
    fn test_graph_diff_basic() {
        let corrector = RelationalErrorCorrector::new();
        let student = ts(&[("dog", "IS", "animal"), ("cat", "LIKES", "fish")]);
        let teacher = ts(&[("dog", "IS_A", "animal"), ("cat", "LIKES", "fish")]);
        let diff = corrector.graph_diff(&student, &teacher);
        assert!(diff.errors.contains(&("dog".to_string(), "IS".to_string(), "animal".to_string())));
        assert!(diff.corrections.contains(&("dog".to_string(), "IS_A".to_string(), "animal".to_string())));
        assert_eq!(diff.fixes.len(), 1);
        assert_eq!(diff.fixes[0].good.1, "IS_A");
    }

    #[test]
    fn test_learn_and_apply() {
        let mut corrector = RelationalErrorCorrector::new();
        let fix = Fix {
            kind: FixKind::RelationSubstitution,
            bad:  ("dog".to_string(), "IS".to_string(),   "animal".to_string()),
            good: ("dog".to_string(), "IS_A".to_string(), "animal".to_string()),
            rule_description: String::new(),
        };
        corrector.learn_rule(&fix);

        let triples = vec![
            ("dog".to_string(), "IS".to_string(), "animal".to_string()),
            ("cat".to_string(), "LIKES".to_string(), "fish".to_string()),
        ];
        let corrected = corrector.apply_corrections(&triples);
        assert_eq!(corrected[0].1, "IS_A");
        assert_eq!(corrected[1].1, "LIKES"); // untouched
    }

    #[test]
    fn test_suppress() {
        let mut corrector = RelationalErrorCorrector::new();
        corrector.suppressed_relations.insert("DEPRECATED".to_string());
        assert!(corrector.should_suppress(&("x".to_string(), "DEPRECATED".to_string(), "y".to_string())));
        assert!(!corrector.should_suppress(&("x".to_string(), "IS".to_string(), "y".to_string())));
    }

    #[test]
    fn test_dedup_rules() {
        let mut corrector = RelationalErrorCorrector::new();
        let fix = Fix {
            kind: FixKind::RelationSubstitution,
            bad:  ("dog".to_string(), "IS".to_string(),   "animal".to_string()),
            good: ("dog".to_string(), "IS_A".to_string(), "animal".to_string()),
            rule_description: String::new(),
        };
        corrector.learn_rule(&fix);
        corrector.learn_rule(&fix);
        assert_eq!(corrector.correction_rules.len(), 1);
    }

    #[test]
    fn test_head_word() {
        assert_eq!(head_word("the quick brown fox"), "fox");
        assert_eq!(head_word("is a kind of animal"), "animal");
        assert_eq!(head_word("engine"), "engine");
    }
}
