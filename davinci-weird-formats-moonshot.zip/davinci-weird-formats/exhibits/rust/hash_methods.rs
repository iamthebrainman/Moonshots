/// Hash method selection and query mode for radial / "one bin over" lookups.
///
/// ## Architecture note
/// This module lives at Layer 1 (no deps above itself).
/// It is imported by:
///   - `table.rs`  → `HashTable24::lookup_radial()`
///   - `word_engine.rs` → `WordEngine.query_mode` field + Stage 2.5
///   - `pathway_table.rs` → `PathwayTable::settle_radial()`
///   - `bin/word.rs` → `Mind.query_mode` + `mode` shell command
///
/// The `QueryMode::Exact` default preserves all existing behaviour — nothing
/// changes until the user explicitly toggles the mode.

use std::f32::consts::PI;

// ============================================================================
// HASH METHOD SELECTOR
// ============================================================================

/// Ten hash functions mirroring the bench7.rs benchmark methods.
///
/// Each variant selects a different hash function when `lookup_radial` probes
/// neighbouring bins.  Method 0 (`Original`) is `hash_carousel` — the existing
/// primary hash and the safe default.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum HashMethod {
    /// XOR-multiply-shift chain with prime seed (current `hash_carousel`).
    #[default]
    Original    = 0,
    /// Golden ratio multiply: `h * φ_64` folded to 24 bits.
    PhiRatio    = 1,
    /// Geometric mean of consecutive byte pairs.
    GeometricMean = 2,
    /// Fibonacci-indexed modular accumulation.
    FibIndex    = 3,
    /// Knuth multiplicative hash on φ approximation.
    PhiKnuth    = 4,
    /// Resonance hash: `π × φ` constant multiply.
    PiPhiResonance = 5,
    /// Silver ratio multiply: `1 + √2` approximation.
    SilverRatio = 6,
    /// Tribonacci constant multiply — best continuation precision at radius 1.
    /// This is the "one bin over" sweet spot from bench7.rs.
    Tribonacci  = 7,
    /// Golden spiral: byte-angle accumulation modulo TABLE_SIZE.
    GoldenSpiral = 8,
    /// Tau (2π) circle hash.
    TauCircle   = 9,
}

impl HashMethod {
    /// Parse a method name or index string from the CLI.
    /// Accepts: "0"–"9", "original", "phi", "tribonacci", "cascade", etc.
    pub fn from_str(s: &str) -> Option<Self> {
        match s.trim().to_lowercase().as_str() {
            "0" | "original" | "exact"   => Some(Self::Original),
            "1" | "phi" | "phiratio"     => Some(Self::PhiRatio),
            "2" | "geo" | "geometric"    => Some(Self::GeometricMean),
            "3" | "fib" | "fibindex"     => Some(Self::FibIndex),
            "4" | "knuth" | "phiknuth"   => Some(Self::PhiKnuth),
            "5" | "pi" | "piphiresonance"=> Some(Self::PiPhiResonance),
            "6" | "silver" | "silverratio"=> Some(Self::SilverRatio),
            "7" | "trib" | "tribonacci"  => Some(Self::Tribonacci),
            "8" | "spiral" | "goldenspiral"=> Some(Self::GoldenSpiral),
            "9" | "tau" | "taucircle"    => Some(Self::TauCircle),
            _ => None,
        }
    }

    /// Parse a method from a numeric index (0-9).
    pub fn from_u8(n: u8) -> Option<Self> {
        match n {
            0 => Some(Self::Original),
            1 => Some(Self::PhiRatio),
            2 => Some(Self::GeometricMean),
            3 => Some(Self::FibIndex),
            4 => Some(Self::PhiKnuth),
            5 => Some(Self::PiPhiResonance),
            6 => Some(Self::SilverRatio),
            7 => Some(Self::Tribonacci),
            8 => Some(Self::GoldenSpiral),
            9 => Some(Self::TauCircle),
            _ => None,
        }
    }

    /// Human-readable label.
    pub fn label(self) -> &'static str {
        match self {
            Self::Original     => "Original (hash_carousel)",
            Self::PhiRatio     => "PhiRatio",
            Self::GeometricMean=> "GeometricMean",
            Self::FibIndex     => "FibIndex",
            Self::PhiKnuth     => "PhiKnuth",
            Self::PiPhiResonance=>"PiPhiResonance",
            Self::SilverRatio  => "SilverRatio",
            Self::Tribonacci   => "Tribonacci (★ radius-1 sweet spot)",
            Self::GoldenSpiral => "GoldenSpiral",
            Self::TauCircle    => "TauCircle",
        }
    }
}

// ============================================================================
// QUERY MODE
// ============================================================================

/// Three-tier query mode that controls how the WORD engine probes the hash table.
///
/// | Mode    | Hash fn     | Radius | Effect                                      |
/// |---------|-------------|--------|---------------------------------------------|
/// | Exact   | Original(0) | 0      | Current behaviour — no change               |
/// | Cascade | Tribonacci(7)| 1     | "One bin over" expansion — best precision   |
/// | Diffuse | Tribonacci(7)| ≥2    | Cosine-weighted radial field + interference |
///
/// The presets are chosen based on the bench7.rs finding that Method 7
/// Flat, fully-tunable query config.  Every field can be changed individually
/// with `set <flag> <value>` in the shell, or bulk-preset with `mode <name>`.
///
/// All fields are `pub` so the shell can mutate them directly.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct QueryMode {
    /// Enable radial (collision-chain) expansion.  `false` = exact, zero overhead.
    pub radial: bool,
    /// Hash method used to compute the probe-chain start address.
    pub method: HashMethod,
    /// Number of extra Word slots to collect from the collision chain
    /// (centre slot + up to `chain_depth` more).  Default 3.
    pub chain_depth: u8,
    /// Max golden-ratio probe steps to walk before giving up.  Default 128.
    pub probe_cap: u16,
    /// Cosine window denominator for weighting chain distance.  Default 8.
    pub window: u16,
    /// Weight assigned to relations found via radial expansion (0.0–1.0).
    pub relation_weight: f32,
}

impl Default for QueryMode {
    fn default() -> Self {
        Self {
            radial: false,
            method: HashMethod::Original,
            chain_depth: 3,
            probe_cap: 128,
            window: 8,
            relation_weight: 0.65,
        }
    }
}

impl QueryMode {
    // ── Preset constructors ───────────────────────────────────────────────

    /// `mode exact` — radial off, standard pipeline.
    pub fn exact() -> Self { Self::default() }

    /// `mode cascade` — collision-chain walk, Tribonacci hash, depth 5.
    pub fn cascade() -> Self {
        Self { radial: true, method: HashMethod::Tribonacci,
               chain_depth: 5, probe_cap: 128, window: 8, relation_weight: 0.65 }
    }

    /// `mode diffuse` — wider chain walk, larger cosine window.
    pub fn diffuse() -> Self {
        Self { radial: true, method: HashMethod::Tribonacci,
               chain_depth: 10, probe_cap: 256, window: 20, relation_weight: 0.55 }
    }

    // ── Parse `mode <preset>` ─────────────────────────────────────────────
    pub fn parse(args: &[&str]) -> Option<Self> {
        match args.first().copied().unwrap_or("exact").to_lowercase().as_str() {
            "exact" | "off" | "0" => Some(Self::exact()),
            "cascade" | "on"  | "1" => Some(Self::cascade()),
            "diffuse"         | "2" => Some(Self::diffuse()),
            _ => None,
        }
    }

    /// Apply a single `set <flag> <value>` mutation.  Returns an error string on bad input.
    ///
    /// Flags:
    ///   radial      <true|false|on|off>
    ///   method      <0-8 | original | tribonacci | ...>
    ///   chain_depth <u8>
    ///   probe_cap   <u16>
    ///   window      <u16>
    ///   weight      <f32>   (relation_weight)
    pub fn set_flag(&mut self, flag: &str, value: &str) -> Result<(), String> {
        match flag.to_lowercase().as_str() {
            "radial" => {
                self.radial = matches!(value.to_lowercase().as_str(), "true" | "on" | "1" | "yes");
                Ok(())
            }
            "method" => {
                self.method = HashMethod::from_str(value)
                    .ok_or_else(|| format!("unknown method '{}' — use 0-8 or name", value))?;
                Ok(())
            }
            "chain_depth" | "depth" => {
                self.chain_depth = value.parse::<u8>()
                    .map_err(|_| format!("chain_depth must be 1-255, got '{}'", value))?;
                Ok(())
            }
            "probe_cap" | "cap" => {
                self.probe_cap = value.parse::<u16>()
                    .map_err(|_| format!("probe_cap must be 1-65535, got '{}'", value))?;
                Ok(())
            }
            "window" => {
                self.window = value.parse::<u16>()
                    .map_err(|_| format!("window must be 1-65535, got '{}'", value))?;
                Ok(())
            }
            "weight" | "relation_weight" => {
                self.relation_weight = value.parse::<f32>()
                    .map_err(|_| format!("weight must be 0.0-1.0, got '{}'", value))?;
                Ok(())
            }
            _ => Err(format!("unknown flag '{}'", flag)),
        }
    }

    /// Short description for status display.
    pub fn describe(self) -> String {
        if !self.radial {
            return "exact (standard)".to_string();
        }
        format!("radial on | method={} | chain_depth={} | probe_cap={} | window={} | weight={:.2}",
            self.method.label(), self.chain_depth, self.probe_cap, self.window, self.relation_weight)
    }

    /// Extract the hash method (default: Original).
    pub fn hash_method(self) -> HashMethod {
        self.method
    }

    /// True when radial expansion is active.
    pub fn is_radial(self) -> bool { self.radial }

    /// Chain depth (replaces old `radius`).
    pub fn radius(self) -> u8 { self.chain_depth }

    // ── Legacy match arms for word_engine.rs ─────────────────────────────
    // The old code did `matches!(self.query_mode, QueryMode::Cascade { .. })`.
    // Replace those with `self.query_mode.radial`.
    //
    // Kept here so callers compile without changes:
    #[allow(dead_code)]
    pub fn is_cascade(self) -> bool { self.radial && self.chain_depth <= 6 }
    #[allow(dead_code)]
    pub fn is_diffuse(self) -> bool { self.radial && self.chain_depth > 6 }
}

// ============================================================================
// COSINE WEIGHT (shared formula)
// ============================================================================

/// Cosine amplitude for a bin that is `delta` steps from the probe centre.
///
/// Uses the same formula as `WordEngine::interference_amplitude()`:
///   `cos(π × |delta| / window).max(0)`
///
/// Returns:
/// - `1.0` when `delta == 0`
/// - smooth decay to `0.0` at `|delta| == window`
/// - `0.0` beyond window
///
/// `window` must be > 0; if `delta` ≥ `window` the result is always 0.
#[inline]
pub fn cosine_weight(delta: i32, window: u16) -> f32 {
    if window == 0 { return if delta == 0 { 1.0 } else { 0.0 }; }
    let abs_delta = delta.unsigned_abs() as f32;
    let w = window as f32;
    if abs_delta >= w { return 0.0; }
    (PI * abs_delta / w).cos().max(0.0)
}

// ============================================================================
// HASH DISPATCHERS (matching bench7.rs methods 0–9)
// ============================================================================

/// TABLE_MASK equivalent — caller must AND with their own table mask.
/// We expose the raw 64-bit mixed value so callers can apply their own
/// `& (table_size - 1)` without being coupled to any specific table size.
///
/// `mask` is the table mask (e.g. 0xFFFFF for 1M slots). Methods that need
/// table size for range folding compute `sz = (mask + 1) as f64`.
///
/// Returns a 64-bit value; callers apply `& mask` to fit their table.
pub fn hash_raw(bytes: &[u8], method: HashMethod, mask: u64) -> u64 {
    match method {
        HashMethod::Original => hash_original(bytes, mask),
        HashMethod::PhiRatio => hash_phi_ratio(bytes, mask),
        HashMethod::GeometricMean => hash_geometric_mean(bytes, mask),
        HashMethod::FibIndex => hash_fib_index(bytes, mask),
        HashMethod::PhiKnuth => hash_phi_knuth(bytes, mask),
        HashMethod::PiPhiResonance => hash_pi_phi(bytes, mask),
        HashMethod::SilverRatio => hash_silver_ratio(bytes, mask),
        HashMethod::Tribonacci => hash_tribonacci(bytes, mask),
        HashMethod::GoldenSpiral => hash_golden_spiral(bytes, mask),
        HashMethod::TauCircle => hash_tau_circle(bytes, mask),
    }
}

// ---------- method implementations (ported from bench7.rs) -----------------
//
// These are the EXACT algorithms from bench7.rs.  They use f64 arithmetic
// and `carousel_seed()` to produce the same address distributions that the
// bench's semantic explorer uses.  The prior implementations were integer
// avalanche hashes that shared names but had completely different clustering
// properties — which is why radial lookup always returned empty neighbours.

// Constants matching bench7.rs
const PHI: f64        = 1.6180339887498948482;
const PHI_32: u64     = 2654435769;
const SQRT5: f64      = 2.2360679774997896964;
const TRIBONACCI_C: f64 = 1.8392867552141612;
const SILVER_C: f64   = 2.4142135623730950488;
const TAU_C: f64      = 6.2831853071795864769;

/// Fibonacci table matching bench7.rs
const FIB: [u64; 64] = {
    let mut f = [0u64; 64];
    f[0] = 2; f[1] = 3;
    let mut i = 2;
    while i < 64 { f[i] = f[i-1].saturating_add(f[i-2]); i += 1; }
    f
};

/// Carousel seed: maps an encoded byte to a seed value (2–258).
/// Identical to bench7.rs `carousel_seed`.
#[inline(always)]
fn carousel_seed(byte: u8) -> u64 {
    let char_id = (byte & 0x1F) as u64;
    let cart    = ((byte >> 5) & 0x07) as u64;
    2 + char_id + (cart * 32)
}

#[inline(always)]
fn hash_original(bytes: &[u8], mask: u64) -> u64 {
    // bench7 Method::Original — alternating mul/div with carousel_seed
    let mut acc: u64 = 1;
    for (i, &b) in bytes.iter().enumerate() {
        let seed = carousel_seed(b).max(1);
        if i % 2 == 0 { acc = acc.wrapping_mul(seed); }
        else           { acc = acc.wrapping_div(seed).max(1); }
    }
    acc & mask
}

#[inline(always)]
fn hash_phi_ratio(bytes: &[u8], mask: u64) -> u64 {
    let sz = (mask + 1) as f64;
    let mut acc: f64 = 0.0;
    for &b in bytes { acc = (acc + b as f64) / PHI; }
    ((acc - acc.floor()).abs() * sz) as u64 & mask
}

#[inline(always)]
fn hash_geometric_mean(bytes: &[u8], mask: u64) -> u64 {
    let sz = (mask + 1) as f64;
    let mut acc: f64 = 1.0;
    for (n, &b) in bytes.iter().enumerate() {
        acc = (acc * (b as f64 + 1.0) * PHI.powi(n as i32 + 1))
            .powf(1.0 / (n as f64 + 1.0));
    }
    ((acc - acc.floor()).abs() * sz) as u64 & mask
}

#[inline(always)]
fn hash_fib_index(bytes: &[u8], mask: u64) -> u64 {
    let bits = (mask + 1).trailing_zeros();
    let mut acc: u64 = 0;
    for (i, &b) in bytes.iter().enumerate() {
        let fib_val = FIB[(b as usize) % 64];
        acc = acc.wrapping_add(fib_val);
        acc = acc.rotate_left((i as u32 % 31) + 1);
    }
    (acc.wrapping_mul(PHI_32) >> (64 - bits)) & mask
}

#[inline(always)]
fn hash_phi_knuth(bytes: &[u8], mask: u64) -> u64 {
    let bits = (mask + 1).trailing_zeros();
    let mut h: u64 = 0xcbf29ce484222325;
    for &b in bytes {
        h = h.wrapping_mul(PHI_32);
        h ^= b as u64;
        let f = h.wrapping_mul(0x9e3779b97f4a7c15);
        h = (h ^ f).wrapping_add(b as u64 * PHI_32);
    }
    (h >> (64 - bits)) & mask
}

#[inline(always)]
fn hash_pi_phi(bytes: &[u8], mask: u64) -> u64 {
    let sz = (mask + 1) as f64;
    let pop = std::f64::consts::PI / PHI;
    let mut acc: f64 = 0.0;
    for (i, &b) in bytes.iter().enumerate() {
        let s = b as f64 + 1.0;
        if i % 2 == 0 { acc = (acc + s) * pop; }
        else           { acc = (acc + s) / PHI; }
        if acc > 1_000_000.0 { acc /= pop; }
    }
    ((acc - acc.floor()).abs() * sz) as u64 & mask
}

#[inline(always)]
fn hash_silver_ratio(bytes: &[u8], mask: u64) -> u64 {
    let sz = (mask + 1) as f64;
    let mut acc: f64 = 0.0;
    for &b in bytes { acc = (acc + b as f64) / SILVER_C; }
    ((acc - acc.floor()).abs() * sz) as u64 & mask
}

#[inline(always)]
fn hash_tribonacci(bytes: &[u8], mask: u64) -> u64 {
    let sz = (mask + 1) as f64;
    let mut acc: f64 = 1.0;
    for &b in bytes {
        acc = acc / TRIBONACCI_C + b as f64;
        if acc > sz { acc /= TRIBONACCI_C; }
    }
    acc as u64 & mask
}

#[inline(always)]
fn hash_golden_spiral(bytes: &[u8], mask: u64) -> u64 {
    let sz = (mask + 1) as f64;
    let ga = TAU_C * (1.0 - 1.0 / (PHI * PHI));
    let mut angle: f64 = 0.0;
    let mut r: f64 = 1.0;
    for &b in bytes {
        angle += ga * (b as f64 + 1.0);
        r *= 1.0 + (b as f64 / 255.0) * 0.1;
    }
    let x = r * angle.cos();
    let y = r * angle.sin();
    (((x + y).abs() * sz) as u64) & mask
}

#[inline(always)]
fn hash_tau_circle(bytes: &[u8], mask: u64) -> u64 {
    let sz = (mask + 1) as f64;
    let mut acc: f64 = 0.0;
    for &b in bytes {
        acc += TAU_C * (b as f64 + 1.0);
        acc = acc.sin() * sz;
    }
    (acc.abs() as u64) & mask
}

// ============================================================================
// UNIT TESTS
// ============================================================================
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cosine_weight_boundary() {
        assert!((cosine_weight(0, 10) - 1.0).abs() < 1e-6);
        assert!((cosine_weight(10, 10)).abs() < 1e-6);
        assert_eq!(cosine_weight(11, 10), 0.0);
    }

    #[test]
    fn cosine_weight_midpoint() {
        // At delta == window/2 expect cos(π/2) ≈ 0
        let w = 4u16;
        assert!(cosine_weight(2, w).abs() < 1e-5);
    }

    #[test]
    fn query_mode_parse() {
        let exact = QueryMode::parse(&["exact"]).unwrap();
        assert!(!exact.radial);
        let cascade = QueryMode::parse(&["cascade"]).unwrap();
        assert!(cascade.radial);
        assert_eq!(cascade.chain_depth, 5);
        let diffuse = QueryMode::parse(&["diffuse"]).unwrap();
        assert!(diffuse.radial);
        assert_eq!(diffuse.chain_depth, 10);
    }

    #[test]
    fn query_mode_set_flag() {
        let mut m = QueryMode::cascade();
        m.set_flag("depth", "12").unwrap();
        assert_eq!(m.chain_depth, 12);
        m.set_flag("probe_cap", "64").unwrap();
        assert_eq!(m.probe_cap, 64);
        m.set_flag("window", "30").unwrap();
        assert_eq!(m.window, 30);
        m.set_flag("radial", "off").unwrap();
        assert!(!m.radial);
    }

    #[test]
    fn hash_methods_deterministic() {
        let key = b"hello";
        let mask: u64 = 0xFFFFF; // 1M slots
        for m in [HashMethod::Original, HashMethod::Tribonacci, HashMethod::SilverRatio] {
            let h1 = hash_raw(key, m, mask);
            let h2 = hash_raw(key, m, mask);
            assert_eq!(h1, h2, "hash_raw not deterministic for {:?}", m);
        }
    }

    #[test]
    fn hash_method_from_str() {
        assert_eq!(HashMethod::from_str("7"), Some(HashMethod::Tribonacci));
        assert_eq!(HashMethod::from_str("tribonacci"), Some(HashMethod::Tribonacci));
        assert_eq!(HashMethod::from_str("cascade"), None); // "cascade" is a mode, not a method
    }
}
