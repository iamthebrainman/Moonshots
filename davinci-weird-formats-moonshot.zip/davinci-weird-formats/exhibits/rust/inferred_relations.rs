//! # Inferred Relations
//!
//! Derives lightweight relations from token co-occurrence positions.
//! No grammar rules - purely positional: tokens near each other in the
//! corpus are inferred to be related, with the relation type determined
//! by distance.
//!
//! Distance 1  → NEXT_TO
//! Distance 2  → NEAR
//! Distance ≤5 → RELATED
//! Distance >5 → DISTANT
//!
//! This is the Rust port of Python's `InferredRelations`, which backed
//! the UnForkCollection query system and provided fast proximity scoring.
//!
//! The GDA position index (already in interference.rs) provides O(1) token
//! lookup; here we hold our own lightweight HashMap<String, Vec<u32>>
//! that mirrors WordEngine::token_index so this module can be used standalone.

use std::collections::HashMap;
use crate::synsets::Synsets;

/// A single inferred relation triple.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct InferredTriple {
    pub subject: String,
    pub predicate: String, // NEXT_TO | NEAR | RELATED | DISTANT
    pub object: String,
}

impl InferredTriple {
    pub fn new(subject: impl Into<String>, predicate: &str, object: impl Into<String>) -> Self {
        Self {
            subject: subject.into(),
            predicate: predicate.to_string(),
            object: object.into(),
        }
    }
}

fn distance_predicate(distance: usize) -> &'static str {
    match distance {
        1 => "NEXT_TO",
        2 => "NEAR",
        3..=5 => "RELATED",
        _ => "DISTANT",
    }
}

/// Inferred relation engine. Holds a token position index and corpus.
/// Call `add_token` as you ingest, then `infer` to query.
pub struct InferredRelations {
    /// token → sorted list of corpus positions
    pub token_positions: HashMap<String, Vec<u32>>,
    /// flat corpus token array for neighbor lookups
    pub corpus_tokens: Vec<String>,
    /// optional synset expansion on queries
    pub synsets: Option<Synsets>,
}

impl InferredRelations {
    pub fn new() -> Self {
        Self {
            token_positions: HashMap::new(),
            corpus_tokens: Vec::new(),
            synsets: None,
        }
    }

    /// Build from existing parallel data (mirrors WordEngine fields).
    pub fn from_index(
        token_positions: HashMap<String, Vec<u32>>,
        corpus_tokens: Vec<String>,
    ) -> Self {
        Self {
            token_positions,
            corpus_tokens,
            synsets: None,
        }
    }

    /// Attach a Synsets store for query expansion.
    pub fn with_synsets(mut self, synsets: Synsets) -> Self {
        self.synsets = Some(synsets);
        self
    }

    /// Add a single token at a corpus position (call during ingestion).
    pub fn add_token(&mut self, token: &str, position: u32) {
        let key = token.to_lowercase();
        self.token_positions
            .entry(key)
            .or_insert_with(Vec::new)
            .push(position);
    }

    /// Append a token to the corpus array (call in lockstep with add_token).
    pub fn push_corpus_token(&mut self, token: &str) {
        self.corpus_tokens.push(token.to_lowercase());
    }

    /// Get all corpus positions for a token.
    pub fn get_positions(&self, token: &str) -> &[u32] {
        let key = token.to_lowercase();
        self.token_positions
            .get(key.as_str())
            .map(|v| v.as_slice())
            .unwrap_or(&[])
    }

    /// Infer relations for a set of query tokens within a proximity window.
    ///
    /// `window_size`: how many tokens to look ahead from each position.
    /// `invert`: if true, look BEHIND instead of ahead (object→subject).
    pub fn infer(
        &self,
        query_tokens: &[&str],
        window_size: usize,
        invert: bool,
    ) -> Vec<InferredTriple> {
        // Optionally expand tokens via synsets
        let expanded: Vec<String> = if let Some(syns) = &self.synsets {
            syns.expand_words(query_tokens.iter().copied())
                .into_iter()
                .collect()
        } else {
            query_tokens.iter().map(|s| s.to_lowercase()).collect()
        };

        let mut results = Vec::new();
        let corpus_len = self.corpus_tokens.len();

        for token in &expanded {
            let positions = match self.token_positions.get(token.as_str()) {
                Some(p) => p,
                None => continue,
            };

            for &pos in positions {
                let pos = pos as usize;

                let neighbor_range: Box<dyn Iterator<Item = usize>> = if invert {
                    Box::new((pos.saturating_sub(window_size)..pos).rev())
                } else {
                    Box::new((pos + 1)..(pos + window_size + 1).min(corpus_len))
                };

                for npos in neighbor_range {
                    let neighbor = &self.corpus_tokens[npos];
                    let distance = (npos as isize - pos as isize).unsigned_abs();
                    let predicate = distance_predicate(distance);

                    let triple = if invert {
                        InferredTriple::new(neighbor.clone(), predicate, token.clone())
                    } else {
                        InferredTriple::new(token.clone(), predicate, neighbor.clone())
                    };
                    results.push(triple);
                }
            }
        }

        // Deduplicate while preserving order
        let mut seen = std::collections::HashSet::new();
        results.retain(|t| seen.insert((t.subject.clone(), t.predicate.clone(), t.object.clone())));

        results
    }

    /// Convenience: get all relations where `subject` is the subject.
    pub fn by_subject(&self, subject: &str) -> Vec<InferredTriple> {
        self.infer(&[subject], 5, false)
    }

    /// Convenience: get all relations where `object` is the object.
    pub fn by_object(&self, object: &str) -> Vec<InferredTriple> {
        self.infer(&[object], 5, true)
    }

    /// Score a set of documents against a query.
    /// `doc_positions`: doc_id → (start, end) index in corpus_tokens.
    /// Returns map of doc_id → score (higher = more relevant).
    pub fn score_documents(
        &self,
        query_tokens: &[&str],
        doc_positions: &HashMap<String, (usize, usize)>,
        window_size: usize,
    ) -> HashMap<String, f32> {
        let inferred = self.infer(query_tokens, window_size, false);
        let mut scores: HashMap<String, f32> = HashMap::new();

        for triple in &inferred {
            // Find which doc contains the object token's position
            let obj_positions = self.get_positions(&triple.object);
            for &opos in obj_positions {
                let opos = opos as usize;
                for (doc_id, &(start, end)) in doc_positions {
                    if opos >= start && opos < end {
                        // Weight by relation proximity
                        let weight: f32 = match triple.predicate.as_str() {
                            "NEXT_TO" => 3.0,
                            "NEAR"    => 2.0,
                            "RELATED" => 1.0,
                            _         => 0.5,
                        };
                        *scores.entry(doc_id.clone()).or_insert(0.0) += weight;
                    }
                }
            }
        }
        scores
    }
}

impl Default for InferredRelations {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn build_test_ir() -> InferredRelations {
        let mut ir = InferredRelations::new();
        let tokens = ["the", "dog", "is", "an", "animal", "and", "the", "dog", "can", "bark"];
        for (i, t) in tokens.iter().enumerate() {
            ir.add_token(t, i as u32);
            ir.push_corpus_token(t);
        }
        ir
    }

    #[test]
    fn test_next_to() {
        let ir = build_test_ir();
        let results = ir.infer(&["dog"], 1, false);
        let predicates: Vec<&str> = results.iter().map(|t| t.predicate.as_str()).collect();
        assert!(predicates.contains(&"NEXT_TO"));
    }

    #[test]
    fn test_by_subject() {
        let ir = build_test_ir();
        let rels = ir.by_subject("dog");
        assert!(!rels.is_empty());
        assert!(rels.iter().all(|t| t.subject == "dog"));
    }

    #[test]
    fn test_by_object() {
        let ir = build_test_ir();
        let rels = ir.by_object("bark");
        assert!(!rels.is_empty());
        assert!(rels.iter().all(|t| t.object == "bark"));
    }

    #[test]
    fn test_invert() {
        let ir = build_test_ir();
        let fwd = ir.infer(&["animal"], 3, false);
        let bwd = ir.infer(&["animal"], 3, true);
        // Forward from "animal" should find tokens after it
        assert!(fwd.iter().any(|t| t.subject == "animal"));
        // Backward from "animal" should find tokens before it
        assert!(bwd.iter().any(|t| t.object == "animal"));
    }

    #[test]
    fn test_synset_expansion() {
        let mut syns = Synsets::new();
        syns.add_group(&["dog", "canine", "hound"]);
        let ir = build_test_ir().with_synsets(syns);
        // "canine" is not literally in the corpus but should expand to "dog"
        let results = ir.infer(&["canine"], 2, false);
        assert!(!results.is_empty(), "Synset expansion should yield results for 'canine'");
    }
}
