//! # Corpus Ingestion
//!
//! Tokenizes text and populates the hash table with:
//! - Single words (SlotKind::Word) with corpus position
//! - Bigrams (SlotKind::Bigram) for "what comes next" lookups
//! - Trigrams (SlotKind::Trigram) for phrase matching
//!
//! Each word stores its first occurrence position and frequency.
//! Bigrams store the position of the second word.

use crate::carousel;
use crate::table::{HashTable24, SlotKind};

/// Ingest a full corpus into the hash table.
/// Returns the number of tokens processed.
pub fn ingest_corpus(table: &mut HashTable24, text: &str) -> usize {
    let tokens: Vec<&str> = text.split_whitespace().collect();
    let n = tokens.len();
    if n == 0 {
        return 0;
    }

    // Pass 1: Insert all unique words with their first position
    for (pos, &word) in tokens.iter().enumerate() {
        // Strip trailing period if followed by space (sentence boundary)
        // Preserve domain.name and word.something patterns
        let cleaned = if word.ends_with('.') && word.matches('.').count() == 1 {
            &word[..word.len() - 1]
        } else {
            word
        };
        
        let encoded = carousel::encode_string(cleaned);

        // Check if word already exists
        if let Some(slot) = table.get_mut(&encoded) {
            // Increment frequency (stored in score, capped at u16::MAX)
            slot.score = slot.score.saturating_add(1);
        } else {
            // New word — insert with position
            table.insert(&encoded, SlotKind::Word, pos as u64, 0, 1);
        }
    }

    // Pass 2: Insert bigrams (consecutive word pairs)
    for i in 0..n.saturating_sub(1) {
        let w1 = tokens[i];
        let w2 = tokens[i + 1];

        let mut key = carousel::encode_string(w1);
        key.push(0xFF); // separator
        key.extend(carousel::encode_string(w2));

        if table.get(&key).is_none() {
            // Store position of w2 as value, position of w1's next as next_pos
            let next = if i + 2 < n { (i + 2) as u32 } else { 0 };
            table.insert(&key, SlotKind::Bigram, (i + 1) as u64, next, 1);
        } else if let Some(slot) = table.get_mut(&key) {
            slot.score = slot.score.saturating_add(1);
        }
    }

    // Pass 3: Insert trigrams
    for i in 0..n.saturating_sub(2) {
        let w1 = tokens[i];
        let w2 = tokens[i + 1];
        let w3 = tokens[i + 2];

        let mut key = carousel::encode_string(w1);
        key.push(0xFF);
        key.extend(carousel::encode_string(w2));
        key.push(0xFF);
        key.extend(carousel::encode_string(w3));

        if table.get(&key).is_none() {
            let next = if i + 3 < n { (i + 3) as u32 } else { 0 };
            table.insert(&key, SlotKind::Trigram, (i + 2) as u64, next, 1);
        } else if let Some(slot) = table.get_mut(&key) {
            slot.score = slot.score.saturating_add(1);
        }
    }

    n
}

/// Store the raw token stream for position-based generation.
/// Returns a flat Vec of carousel-encoded tokens for O(1) positional access.
pub fn build_position_array(text: &str) -> Vec<Vec<u8>> {
    text.split_whitespace()
        .map(|w| carousel::encode_string(w))
        .collect()
}

/// Query: "what word comes after X?" — pure hash lookup, O(1).
pub fn next_word_after<'a>(
    table: &'a HashTable24,
    word: &str,
    corpus_tokens: &[&'a str],
) -> Option<&'a str> {
    // This is a simplified version — real usage would store chains
    let encoded = carousel::encode_string(word);
    if let Some(slot) = table.get(&encoded) {
        let pos = slot.value as usize;
        if pos + 1 < corpus_tokens.len() {
            return Some(corpus_tokens[pos + 1]);
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ingest_basic() {
        let mut table = HashTable24::new_sized(20);
        let text = "the quick brown fox jumps over the lazy dog";
        let count = ingest_corpus(&mut table, text);
        assert_eq!(count, 9);

        // Word lookup
        assert!(table.get_word("the").is_some());
        assert!(table.get_word("fox").is_some());
        assert!(table.get_word("missing").is_none());

        // "the" appears twice
        let the_slot = table.get_word("the").unwrap();
        assert_eq!(the_slot.score, 2);
    }

    #[test]
    fn test_bigram_lookup() {
        let mut table = HashTable24::new_sized(20);
        let text = "in the beginning God created the heavens and the earth";
        ingest_corpus(&mut table, text);

        assert!(table.get_bigram("the", "beginning").is_some());
        assert!(table.get_bigram("God", "created").is_some());
        assert!(table.get_bigram("cat", "dog").is_none());
    }
}
