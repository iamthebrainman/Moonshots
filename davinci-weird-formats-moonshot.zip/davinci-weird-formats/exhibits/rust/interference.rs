// Interference Reasoning - Rust implementation of GDA-style physics
// Port of Python interference.py and infer.py

use std::collections::HashMap;
use std::time::Instant;
use crate::carousel;

/// 24-bit phrase ID for GDA addressing
pub type PhraseId = u32;

/// GDA Core - 24-bit phrase hash table
#[derive(Debug)]
pub struct GdaCore {
    /// Phrase to ID mapping
    phrase_to_id: HashMap<String, PhraseId>,
    /// ID to phrase reverse mapping
    id_to_phrase: HashMap<PhraseId, String>,
    /// Triple storage: (subject_id, relation_id, object_id, weight)
    pub triples: Vec<GdaTriple>,
    /// Next available ID
    next_id: PhraseId,
    /// Indices for fast lookup
    pub subject_index: HashMap<PhraseId, Vec<usize>>,
    pub relation_index: HashMap<PhraseId, Vec<usize>>,
    pub object_index: HashMap<PhraseId, Vec<usize>>,
}

#[derive(Debug, Clone)]
pub struct GdaTriple {
    pub subject_id: PhraseId,
    pub relation_id: PhraseId,
    pub object_id: PhraseId,
    pub weight: f32,
    pub position: u32,
}

impl GdaCore {
    pub fn new() -> Self {
        Self {
            phrase_to_id: HashMap::new(),
            id_to_phrase: HashMap::new(),
            triples: Vec::new(),
            next_id: 1, // Start at 1, reserve 0 for special cases
            subject_index: HashMap::new(),
            relation_index: HashMap::new(),
            object_index: HashMap::new(),
        }
    }
    
    /// Encode phrase to 24-bit ID (deterministic)
    pub fn encode(&mut self, phrase: &str) -> PhraseId {
        if let Some(&id) = self.phrase_to_id.get(phrase) {
            return id;
        }
        
        // Create new ID
        let id = self.next_id;
        self.next_id += 1;
        
        self.phrase_to_id.insert(phrase.to_string(), id);
        self.id_to_phrase.insert(id, phrase.to_string());
        
        id
    }
    
    /// Try to get existing ID without creating new one
    pub fn try_encode(&self, phrase: &str) -> Option<PhraseId> {
        self.phrase_to_id.get(phrase).copied()
    }
    
    /// Decode ID back to phrase
    pub fn decode(&self, id: PhraseId) -> Option<&String> {
        self.id_to_phrase.get(&id)
    }
    
    /// Add a triple to the knowledge base
    pub fn add_triple(&mut self, subject_id: PhraseId, relation_id: PhraseId, object_id: PhraseId, position: u32, weight: f32) {
        let triple = GdaTriple {
            subject_id,
            relation_id,
            object_id,
            weight,
            position,
        };
        
        let index = self.triples.len();
        self.triples.push(triple);
        
        // Update indices
        self.subject_index.entry(subject_id).or_default().push(index);
        self.relation_index.entry(relation_id).or_default().push(index);
        self.object_index.entry(object_id).or_default().push(index);
    }
    
    /// Find triples matching pattern
    pub fn triples_matching(&self, subject_id: Option<PhraseId>, relation_id: Option<PhraseId>, object_id: Option<PhraseId>) -> Vec<&GdaTriple> {
        let mut candidates = Vec::new();
        
        // Use most selective index
        if let Some(sid) = subject_id {
            if let Some(indices) = self.subject_index.get(&sid) {
                candidates.extend(indices.iter().map(|&i| &self.triples[i]));
            }
        } else if let Some(rid) = relation_id {
            if let Some(indices) = self.relation_index.get(&rid) {
                candidates.extend(indices.iter().map(|&i| &self.triples[i]));
            }
        } else if let Some(oid) = object_id {
            if let Some(indices) = self.object_index.get(&oid) {
                candidates.extend(indices.iter().map(|&i| &self.triples[i]));
            }
        } else {
            // No constraints - return all
            candidates.extend(self.triples.iter());
        }
        
        // Filter by remaining constraints
        candidates.into_iter()
            .filter(|triple| {
                subject_id.map_or(true, |sid| triple.subject_id == sid) &&
                relation_id.map_or(true, |rid| triple.relation_id == rid) &&
                object_id.map_or(true, |oid| triple.object_id == oid)
            })
            .collect()
    }
    
    /// Get all triples by subject
    pub fn triples_by_subject(&self, subject_id: PhraseId) -> Vec<&GdaTriple> {
        self.triples_matching(Some(subject_id), None, None)
    }
    
    /// Get all triples by relation
    pub fn triples_by_relation(&self, relation_id: PhraseId) -> Vec<&GdaTriple> {
        self.triples_matching(None, Some(relation_id), None)
    }
    
    /// Get all triples by object
    pub fn triples_by_object(&self, object_id: PhraseId) -> Vec<&GdaTriple> {
        self.triples_matching(None, None, Some(object_id))
    }
}

/// Interference field entry
#[derive(Debug, Clone)]
pub struct FieldEntry {
    pub amplitude: f32,
    pub contributors: Vec<PhraseId>,
}

/// Interference reasoning engine
#[derive(Debug)]
pub struct InterferenceReasoner {
    pub gda: GdaCore,
    /// Computed interference field: phrase_id -> field_entry
    pub field: HashMap<PhraseId, FieldEntry>,
    /// Window size for interference calculation
    pub window_size: usize,
}

/// Query result from interference reasoning
#[derive(Debug, Clone)]
pub struct InterferenceResult {
    pub exists: bool,
    pub amplitude: f32,
    pub source: String, // "direct", "interference", "not_found"
    pub time_us: f64,
}

impl InterferenceReasoner {
    pub fn new(gda: GdaCore) -> Self {
        Self {
            gda,
            field: HashMap::new(),
            window_size: 5,
        }
    }
    
    /// Add triple and update interference field
    pub fn add_triple_with_field(&mut self, subject: &str, relation: &str, object: &str, weight: f32) -> PhraseId {
        let subject_id = self.gda.encode(subject);
        let relation_id = self.gda.encode(relation);
        let object_id = self.gda.encode(object);
        
        // Add to GDA storage
        self.gda.add_triple(subject_id, relation_id, object_id, 0, weight);
        
        // Update interference field
        self.update_field_for_triple(subject_id, relation_id, object_id, weight);
        
        subject_id
    }
    
    /// Update interference field for a new triple
    fn update_field_for_triple(&mut self, subject_id: PhraseId, relation_id: PhraseId, object_id: PhraseId, weight: f32) {
        // Subject influences object (and vice versa)
        self.add_field_influence(subject_id, object_id, weight * 0.8);
        self.add_field_influence(object_id, subject_id, weight * 0.8);
        
        // Relation influences both subject and object
        self.add_field_influence(relation_id, subject_id, weight * 0.6);
        self.add_field_influence(relation_id, object_id, weight * 0.6);
    }
    
    /// Add influence from source to target in field
    fn add_field_influence(&mut self, source_id: PhraseId, target_id: PhraseId, amplitude: f32) {
        let entry = self.field.entry(target_id).or_insert_with(|| FieldEntry {
            amplitude: 0.0,
            contributors: Vec::new(),
        });
        
        entry.amplitude += amplitude;
        if !entry.contributors.contains(&source_id) {
            entry.contributors.push(source_id);
        }
    }
    
    /// Recompute entire interference field
    pub fn recompute_field(&mut self) {
        self.field.clear();
        
        // Process all stored triples
        for triple in &self.gda.triples.clone() {
            self.update_field_for_triple(triple.subject_id, triple.relation_id, triple.object_id, triple.weight);
        }
        
        // Apply transitive inference
        self.propagate_transitive_inference();
    }
    
    /// Propagate transitive inference through the field
    fn propagate_transitive_inference(&mut self) {
        // Find chains: A->B, B->C implies A->C with reduced confidence
        let triples = self.gda.triples.clone();
        
        for triple1 in &triples {
            for triple2 in &triples {
                // Check for transitive pattern: triple1.object == triple2.subject
                if triple1.object_id == triple2.subject_id && 
                   triple1.subject_id != triple2.object_id { // Avoid self-loops
                    
                    // Create transitive inference: triple1.subject -> triple2.object
                    let confidence = triple1.weight * triple2.weight * 0.7; // Decay factor
                    
                    if confidence > 0.3 { // Minimum threshold
                        self.add_field_influence(triple1.subject_id, triple2.object_id, confidence);
                    }
                }
            }
        }
    }
    
    /// Query for a derived fact using interference
    pub fn query_derived(&self, subject: &str, relation: &str, object: &str, threshold: f32) -> InterferenceResult {
        let start = Instant::now();
        
        let subject_id = match self.gda.try_encode(subject) {
            Some(id) => id,
            None => return InterferenceResult {
                exists: false,
                amplitude: 0.0,
                source: "not_found".to_string(),
                time_us: start.elapsed().as_secs_f64() * 1e6,
            }
        };
        
        let relation_id = match self.gda.try_encode(relation) {
            Some(id) => id,
            None => return InterferenceResult {
                exists: false,
                amplitude: 0.0,
                source: "not_found".to_string(),
                time_us: start.elapsed().as_secs_f64() * 1e6,
            }
        };
        
        let object_id = match self.gda.try_encode(object) {
            Some(id) => id,
            None => return InterferenceResult {
                exists: false,
                amplitude: 0.0,
                source: "not_found".to_string(),
                time_us: start.elapsed().as_secs_f64() * 1e6,
            }
        };
        
        // Check direct storage first
        let direct_matches = self.gda.triples_matching(Some(subject_id), Some(relation_id), Some(object_id));
        if !direct_matches.is_empty() {
            return InterferenceResult {
                exists: true,
                amplitude: direct_matches[0].weight,
                source: "direct".to_string(),
                time_us: start.elapsed().as_secs_f64() * 1e6,
            };
        }
        
        // Check interference field
        let amplitude = self.compute_interference_amplitude(subject_id, relation_id, object_id);
        
        InterferenceResult {
            exists: amplitude >= threshold,
            amplitude,
            source: if amplitude >= threshold { "interference" } else { "weak_interference" }.to_string(),
            time_us: start.elapsed().as_secs_f64() * 1e6,
        }
    }
    
    /// Compute interference amplitude for a potential fact
    fn compute_interference_amplitude(&self, subject_id: PhraseId, relation_id: PhraseId, object_id: PhraseId) -> f32 {
        let mut total_amplitude = 0.0;
        
        // Subject-object interference
        if let Some(field_entry) = self.field.get(&object_id) {
            if field_entry.contributors.contains(&subject_id) {
                total_amplitude += field_entry.amplitude * 0.5;
            }
        }
        
        // Relation-subject interference
        if let Some(field_entry) = self.field.get(&subject_id) {
            if field_entry.contributors.contains(&relation_id) {
                total_amplitude += field_entry.amplitude * 0.3;
            }
        }
        
        // Relation-object interference
        if let Some(field_entry) = self.field.get(&object_id) {
            if field_entry.contributors.contains(&relation_id) {
                total_amplitude += field_entry.amplitude * 0.3;
            }
        }
        
        // Normalize to [0,1]
        total_amplitude.min(1.0)
    }
    
    /// Check if fact contradicts existing knowledge
    pub fn check_contradiction(&self, subject: &str, relation: &str, object: &str) -> ContradictsResult {
        let start = Instant::now();
        
        // Get IDs
        let subject_id = match self.gda.try_encode(subject) {
            Some(id) => id,
            None => return ContradictsResult {
                contradiction: false,
                reason: "unknown_subject".to_string(),
                amplitude: 0.0,
                time_us: start.elapsed().as_secs_f64() * 1e6,
            }
        };
        
        let relation_id = match self.gda.try_encode(relation) {
            Some(id) => id,
            None => return ContradictsResult {
                contradiction: false,
                reason: "unknown_relation".to_string(),
                amplitude: 0.0,
                time_us: start.elapsed().as_secs_f64() * 1e6,
            }
        };
        
        // Look for contradictory relations
        // For now, simple contradiction: same subject+relation with different object
        let existing_facts = self.gda.triples_matching(Some(subject_id), Some(relation_id), None);
        
        for fact in existing_facts {
            if let (Some(existing_obj), Some(new_obj)) = (self.gda.decode(fact.object_id), self.gda.try_encode(object)) {
                if fact.object_id != new_obj && fact.weight > 0.7 {
                    return ContradictsResult {
                        contradiction: true,
                        reason: format!("conflicts with existing fact: {} {} {}", subject, relation, existing_obj),
                        amplitude: fact.weight,
                        time_us: start.elapsed().as_secs_f64() * 1e6,
                    };
                }
            }
        }
        
        ContradictsResult {
            contradiction: false,
            reason: "no_conflict".to_string(),
            amplitude: 0.0,
            time_us: start.elapsed().as_secs_f64() * 1e6,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ContradictsResult {
    pub contradiction: bool,
    pub reason: String,
    pub amplitude: f32,
    pub time_us: f64,
}

/// Hash function for phrases (simpler version)
pub fn gda_hash(phrase: &str) -> u32 {
    let encoded = carousel::encode_string(phrase);
    crate::table::hash_carousel(&encoded)
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_gda_core_basic() {
        let mut gda = GdaCore::new();
        
        let spot_id = gda.encode("spot");
        let dog_id = gda.encode("dog");
        let is_id = gda.encode("IS");
        
        gda.add_triple(spot_id, is_id, dog_id, 0, 1.0);
        
        let matches = gda.triples_matching(Some(spot_id), Some(is_id), Some(dog_id));
        assert_eq!(matches.len(), 1);
        assert_eq!(matches[0].weight, 1.0);
    }
    
    #[test]
    fn test_interference_reasoning() {
        let mut reasoner = InterferenceReasoner::new(GdaCore::new());
        
        // Add facts
        reasoner.add_triple_with_field("spot", "IS", "dog", 1.0);
        reasoner.add_triple_with_field("dog", "CAN", "bark", 1.0);
        
        // Recompute field
        reasoner.recompute_field();
        
        // Test direct query
        let result = reasoner.query_derived("spot", "IS", "dog", 0.3);
        assert!(result.exists);
        assert_eq!(result.source, "direct");
        
        // Test inference query
        let result = reasoner.query_derived("spot", "CAN", "bark", 0.3);
        assert!(result.exists);
        assert_eq!(result.source, "interference");
    }
}