//! Space-aware lexer that distinguishes word tokens from boundary punctuation.
//!
//! This lexer treats whitespace as hard separators, preserves infix operators
//! (., @, -) inside tokens, and emits explicit boundary markers for clause/list logic.

#[derive(Debug, Clone, PartialEq)]
pub enum TokKind {
    Word,      // content tokens, may include joiner punctuation like '.' '@' '-'
    Boundary,  // clause/list markers like __PERIOD__, __COMMA__, __EMDASH__
}

#[derive(Debug, Clone)]
pub struct Token {
    pub kind: TokKind,
    pub text: String,                 // surface form ("api.example.com", "__COMMA__")
    pub internal_ops: Vec<(char, usize)>, // e.g. ('.', 3), ('@', 4) - positions within text
}

pub struct Lexer {
    // Configuration for what punctuation acts as joiners vs separators
    joiner_chars: std::collections::HashSet<char>,
    separator_chars: std::collections::HashSet<char>,
}

impl Default for Lexer {
    fn default() -> Self {
        Self::new()
    }
}

impl Lexer {
    pub fn new() -> Self {
        let mut joiner_chars = std::collections::HashSet::new();
        joiner_chars.insert('.');
        joiner_chars.insert('@');
        joiner_chars.insert('-');

        let mut separator_chars = std::collections::HashSet::new();
        separator_chars.insert('.');
        separator_chars.insert('!');
        separator_chars.insert('?');
        separator_chars.insert(';');
        separator_chars.insert(',');
        separator_chars.insert('—'); // em-dash
        separator_chars.insert(':');

        Lexer {
            joiner_chars,
            separator_chars,
        }
    }

    /// Lex the input text into tokens.
    /// Returns a vector of tokens where:
    /// - Word tokens contain content with preserved infix punctuation
    /// - Boundary tokens are markers for clause/list boundaries
    pub fn lex(&mut self, text: &str) -> Vec<Token> {
        let mut tokens = Vec::new();
        let chars: Vec<char> = text.chars().collect();
        let mut i = 0;
        let mut current_word = String::new();
        let mut internal_ops = Vec::new();

        while i < chars.len() {
            let c = chars[i];

            // Whitespace: hard separator—flush current word and skip
            if c.is_whitespace() {
                if !current_word.is_empty() {
                    tokens.push(Token {
                        kind: TokKind::Word,
                        text: current_word.clone(),
                        internal_ops: internal_ops.clone(),
                    });
                    current_word.clear();
                    internal_ops.clear();
                }
                i += 1;
                continue;
            }

            // Check context for separator vs joiner
            if self.separator_chars.contains(&c) {
                let has_prev = !current_word.is_empty() || (i > 0 && !chars[i-1].is_whitespace());
                let has_next = i + 1 < chars.len() && !chars[i+1].is_whitespace();

                if has_prev && has_next && self.joiner_chars.contains(&c) {
                    // Joiner: include in word
                    let pos = current_word.len();
                    current_word.push(c);
                    internal_ops.push((c, pos));
                } else {
                    // Separator: flush word, emit boundary
                    if !current_word.is_empty() {
                        tokens.push(Token {
                            kind: TokKind::Word,
                            text: current_word.clone(),
                            internal_ops: internal_ops.clone(),
                        });
                        current_word.clear();
                        internal_ops.clear();
                    }

                    let boundary_name = match c {
                        '.' => "__PERIOD__",
                        '!' => "__BANG__",
                        '?' => "__QMARK__",
                        ';' => "__SEMICOLON__",
                        ',' => "__COMMA__",
                        '—' => "__EMDASH__",
                        ':' => "__COLON__",
                        _ => "__BOUNDARY__",
                    };

                    tokens.push(Token {
                        kind: TokKind::Boundary,
                        text: boundary_name.to_string(),
                        internal_ops: Vec::new(),
                    });
                }
            } else {
                // Regular alphanumeric: add to current word
                current_word.push(c);
            }

            i += 1;
        }

        // Flush any remaining word
        if !current_word.is_empty() {
            tokens.push(Token {
                kind: TokKind::Word,
                text: current_word,
                internal_ops,
            });
        }

        tokens
    }

    /// Extract just the word tokens as strings (for backward compatibility)
    pub fn extract_words(&self, tokens: &[Token]) -> Vec<String> {
        tokens.iter()
            .filter(|t| matches!(t.kind, TokKind::Word))
            .map(|t| t.text.clone())
            .collect()
    }

    /// Extract boundary markers as strings
    pub fn extract_boundaries(&self, tokens: &[Token]) -> Vec<String> {
        tokens.iter()
            .filter(|t| matches!(t.kind, TokKind::Boundary))
            .map(|t| t.text.clone())
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_domain_preservation() {
        let mut lexer = Lexer::new();
        let tokens = lexer.lex("Visit api.example.com for details");
        let words = lexer.extract_words(&tokens);

        assert_eq!(words, vec!["Visit", "api.example.com", "for", "details"]);
    }

    #[test]
    fn test_email_preservation() {
        let mut lexer = Lexer::new();
        let tokens = lexer.lex("Contact user@example.com now");
        let words = lexer.extract_words(&tokens);

        assert_eq!(words, vec!["Contact", "user@example.com", "now"]);
    }

    #[test]
    fn test_emdash_boundary() {
        let mut lexer = Lexer::new();
        let tokens = lexer.lex("God—the eternal—source");
        let words = lexer.extract_words(&tokens);
        let boundaries = lexer.extract_boundaries(&tokens);

        assert_eq!(words, vec!["God", "the", "eternal", "source"]);
        assert_eq!(boundaries, vec!["__EMDASH__", "__EMDASH__"]);
    }

    #[test]
    fn test_comma_boundary() {
        let mut lexer = Lexer::new();
        let tokens = lexer.lex("faith, hope, love");
        let words = lexer.extract_words(&tokens);
        let boundaries = lexer.extract_boundaries(&tokens);

        assert_eq!(words, vec!["faith", "hope", "love"]);
        assert_eq!(boundaries, vec!["__COMMA__", "__COMMA__"]);
    }

    #[test]
    fn test_hyphen_joiner() {
        let mut lexer = Lexer::new();
        let tokens = lexer.lex("self-contained system");
        let words = lexer.extract_words(&tokens);

        assert_eq!(words, vec!["self-contained", "system"]);
    }
}