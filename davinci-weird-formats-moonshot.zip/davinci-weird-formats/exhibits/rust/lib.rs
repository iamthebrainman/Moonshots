pub mod carousel;
pub mod table;
pub mod hash_methods;
pub mod superposition_decoder;
pub mod ingest;
pub mod relations;
pub mod persist;
pub mod crsl_loader;
pub mod word_engine_persistence;
pub mod adaptive_dada;
pub mod word_engine;
pub mod interference;
pub mod relation_engine;
pub mod dada_engine;
pub mod compositional_relations;
pub mod synsets;
pub mod inferred_relations;
pub mod transitive_reasoner;
pub mod universal_resolver;
pub mod perspective;
pub mod error_corrector;
pub mod semantic_matcher;
pub mod pathway_table;
pub mod conversation_learner;
pub mod pathway_synth;
pub mod lexer;
pub mod typo_detector;
pub mod relation_classifier;
pub mod morph;

#[cfg(target_arch = "wasm32")]
pub mod wasm;

#[cfg(test)]
pub mod test_word_engine;
#[cfg(test)]
pub mod test_harness;
#[cfg(test)]
mod tests;

// Re-export key types for easy access
pub use word_engine::{WordEngine, QueryResult, Metrics, SynthesisMethod};
pub use interference::{GdaCore, InterferenceReasoner, InterferenceResult};
pub use relation_engine::{RelationEngine, ExtractedRelation};
pub use dada_engine::{DadaEngine, RelationalTriple, KnowledgeSource, PersonPerspective, DefinitionStyle};
pub use compositional_relations::{RelationExtractor, RelationalStatement, CompositeRelation, BaseRelation, Modifier, Phrase};
pub use table::HashTable24;
pub use synsets::Synsets;
pub use inferred_relations::{InferredRelations, InferredTriple};
pub use transitive_reasoner::{TransitiveReasoner, Chain, ChainHop, PropertyAnswer, triples_to_outgoing};
pub use universal_resolver::{UniversalResolver, ContextTriple, Resolved};
pub use perspective::{PerspectiveTranslator, Perspective, finalize_student_perspective, finalize_teacher_perspective};
pub use error_corrector::{RelationalErrorCorrector, GraphDiff, Fix, FixKind, CorrectionRule, to_triple_set};
pub use semantic_matcher::{SemanticMatcher, Fingerprint, build_by_object};
pub use typo_detector::{TypoDetector, TypoCandidate};
pub use relation_classifier::{RelationVariant, VariantClassification, Marker, classify_relation_variant, classify, find_is_position, is_domain_to_variant};
pub use pathway_table::PathwayTable;
pub use conversation_learner::{ConversationLearner, LearningChatEngine, FeedbackSignal, Speaker};
pub use pathway_synth::{UnifiedSynthesizer, SynthesisResult};
pub use morph::{VerbState, verb_lemma_state, verb_state, same_lemma};
pub use superposition_decoder::{SuperpositionDecoder, DecodeContext, DecodeResult, ManifoldState, FIB, pack_slot, unpack_slot};
pub use table::{IsDomain, AssertionModality, ConjugationWeights, conjugation_weights, CONJUGATION_TABLE};
pub use relations::{QueryPipeline, select_pipeline, collapse_is_domain};
pub use hash_methods::{HashMethod, QueryMode, cosine_weight};
