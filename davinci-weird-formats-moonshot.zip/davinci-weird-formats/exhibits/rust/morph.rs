//! # Verb Morphology — surface form → (lemma, state)
//!
//! Word-state detection for the token tape. "makes", "made", "making",
//! "make" are one verb in four temporal states. Knowing the state of the
//! pivot verb in a matched span is what lets the engine keep SEPARATE
//! ledgers of past truth and present truth instead of letting "X made Y"
//! and "X makes Y" collide as unrelated tokens:
//!
//!   - MATCHING: a probe built with "make" should be able to match a tape
//!     span that says "made" (same lemma), instead of missing entirely.
//!   - STATE: the matched surface form's tense is recorded, so ranking can
//!     prefer matches whose tense agrees with the question's tense
//!     ("what DID i make" wants Past-state evidence; "what DO i make"
//!     wants Present-state evidence).
//!   - EVIDENCE: corroboration counting groups attestations per
//!     (lemma, tense) — three past-tense statements corroborate a past
//!     truth without outvoting a single present-tense correction.
//!
//! Irregular verbs are hardcoded (English irregulars don't follow rules —
//! there is no way around a table). Open-class regular verbs fall back to
//! suffix analysis (-s/-es → Present, -ed → Past, -ing → Progressive).
//! The table covers the operator/verb set the engine actually treats as
//! pivots (see word_engine's `operators` set) plus the most common English
//! irregulars, so tape pivots resolve through the table and rarer regulars
//! resolve through the suffix rules.

/// Temporal/aspectual state of a verb surface form.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum VerbState {
    /// Base or present form: "make", "makes", "is", "are", "am", "have"
    Present,
    /// Simple past: "made", "was", "were", "had", "did"
    Past,
    /// Past participle where it differs from simple past: "been", "gone",
    /// "taken", "known". (For verbs where they coincide — "made" — the
    /// table just uses Past.)
    Participle,
    /// Progressive/-ing form: "making", "being", "having"
    Progressive,
}

/// Resolve a verb surface form to `(lemma, state)`.
///
/// Returns `None` for words that aren't recognizable verb forms — callers
/// should treat `None` as "not a verb / no state information", NOT as an
/// error. Lookup is case-insensitive; the returned lemma is lowercase.
pub fn verb_lemma_state(word: &str) -> Option<(&'static str, VerbState)> {
    use VerbState::*;
    let w = word.to_lowercase();

    // ── Irregulars: the hardcoded table ─────────────────────────────────
    // Ordered roughly by frequency on a typical tape. Every form the
    // engine's operator set contains appears here so pivot verbs always
    // resolve through the table, never the suffix fallback.
    let hit: Option<(&'static str, VerbState)> = match w.as_str() {
        // be — the big one
        "am" | "is" | "are" | "be" => Some(("be", Present)),
        "was" | "were" => Some(("be", Past)),
        "been" => Some(("be", Participle)),
        "being" => Some(("be", Progressive)),

        // have
        "have" | "has" => Some(("have", Present)),
        "had" => Some(("have", Past)),
        "having" => Some(("have", Progressive)),

        // do
        "do" | "does" => Some(("do", Present)),
        "did" => Some(("do", Past)),
        "done" => Some(("do", Participle)),
        "doing" => Some(("do", Progressive)),

        // make
        "make" | "makes" => Some(("make", Present)),
        "made" => Some(("make", Past)),
        "making" => Some(("make", Progressive)),

        // go
        "go" | "goes" => Some(("go", Present)),
        "went" => Some(("go", Past)),
        "gone" => Some(("go", Participle)),
        "going" => Some(("go", Progressive)),

        // take
        "take" | "takes" => Some(("take", Present)),
        "took" => Some(("take", Past)),
        "taken" => Some(("take", Participle)),
        "taking" => Some(("take", Progressive)),

        // get
        "get" | "gets" => Some(("get", Present)),
        "got" => Some(("get", Past)),
        "gotten" => Some(("get", Participle)),
        "getting" => Some(("get", Progressive)),

        // give
        "give" | "gives" => Some(("give", Present)),
        "gave" => Some(("give", Past)),
        "given" => Some(("give", Participle)),
        "giving" => Some(("give", Progressive)),

        // see
        "see" | "sees" => Some(("see", Present)),
        "saw" => Some(("see", Past)),
        "seen" => Some(("see", Participle)),
        "seeing" => Some(("see", Progressive)),

        // know
        "know" | "knows" => Some(("know", Present)),
        "knew" => Some(("know", Past)),
        "known" => Some(("know", Participle)),
        "knowing" => Some(("know", Progressive)),

        // think
        "think" | "thinks" => Some(("think", Present)),
        "thought" => Some(("think", Past)),
        "thinking" => Some(("think", Progressive)),

        // say
        "say" | "says" => Some(("say", Present)),
        "said" => Some(("say", Past)),
        "saying" => Some(("say", Progressive)),

        // tell
        "tell" | "tells" => Some(("tell", Present)),
        "told" => Some(("tell", Past)),
        "telling" => Some(("tell", Progressive)),

        // come
        "come" | "comes" => Some(("come", Present)),
        "came" => Some(("come", Past)),
        "coming" => Some(("come", Progressive)),

        // run
        "run" | "runs" => Some(("run", Present)),
        "ran" => Some(("run", Past)),
        "running" => Some(("run", Progressive)),

        // eat
        "eat" | "eats" => Some(("eat", Present)),
        "ate" => Some(("eat", Past)),
        "eaten" => Some(("eat", Participle)),
        "eating" => Some(("eat", Progressive)),

        // write
        "write" | "writes" => Some(("write", Present)),
        "wrote" => Some(("write", Past)),
        "written" => Some(("write", Participle)),
        "writing" => Some(("write", Progressive)),

        // build
        "build" | "builds" => Some(("build", Present)),
        "built" => Some(("build", Past)),
        "building" => Some(("build", Progressive)),

        // hear
        "hear" | "hears" => Some(("hear", Present)),
        "heard" => Some(("hear", Past)),
        "hearing" => Some(("hear", Progressive)),

        // feel
        "feel" | "feels" => Some(("feel", Present)),
        "felt" => Some(("feel", Past)),
        "feeling" => Some(("feel", Progressive)),

        // find
        "find" | "finds" => Some(("find", Present)),
        "found" => Some(("find", Past)),
        "finding" => Some(("find", Progressive)),

        // keep
        "keep" | "keeps" => Some(("keep", Present)),
        "kept" => Some(("keep", Past)),
        "keeping" => Some(("keep", Progressive)),

        // leave
        "leave" | "leaves" => Some(("leave", Present)),
        "left" => Some(("leave", Past)),
        "leaving" => Some(("leave", Progressive)),

        // mean
        "mean" | "means" => Some(("mean", Present)),
        "meant" => Some(("mean", Past)),
        "meaning" => Some(("mean", Progressive)),

        // put (invariant past)
        "put" | "puts" => Some(("put", Present)),
        "putting" => Some(("put", Progressive)),

        // read (spelling-invariant past; state genuinely ambiguous, treat as Present)
        "read" | "reads" => Some(("read", Present)),
        "reading" => Some(("read", Progressive)),

        // can/will/would/could — modals carry tense signal too
        "can" => Some(("can", Present)),
        "could" => Some(("can", Past)),
        "will" => Some(("will", Present)),
        "would" => Some(("will", Past)),
        "shall" => Some(("shall", Present)),
        "should" => Some(("shall", Past)),
        "may" => Some(("may", Present)),
        "might" => Some(("may", Past)),

        _ => None,
    };
    if hit.is_some() {
        return hit;
    }

    // ── Regular suffix fallback ─────────────────────────────────────────
    // Only fires for words long enough that stripping a suffix leaves a
    // plausible stem (>= 3 chars), to avoid mangling short nouns.
    // NOTE: this is heuristic — "red" is not the past tense of "r". The
    // stem-length guard plus the caller's context (these are only consulted
    // for tokens in pivot position next to a subject) keeps the false-
    // positive rate acceptable; anything misclassified still matches
    // exact-form first, so the worst case is a spurious lemma equivalence,
    // not a lost match.
    if let Some(stem) = w.strip_suffix("ing") {
        if stem.len() >= 3 {
            return Some((leak_lemma(stem), VerbState::Progressive));
        }
    }
    if let Some(stem) = w.strip_suffix("ied") {
        if stem.len() >= 2 {
            return Some((leak_lemma(&format!("{}y", stem)), VerbState::Past));
        }
    }
    if let Some(stem) = w.strip_suffix("ed") {
        if stem.len() >= 3 {
            return Some((leak_lemma(stem), VerbState::Past));
        }
    }
    if let Some(stem) = w.strip_suffix("ies") {
        if stem.len() >= 2 {
            return Some((leak_lemma(&format!("{}y", stem)), VerbState::Present));
        }
    }
    if let Some(stem) = w.strip_suffix("es") {
        if stem.len() >= 3 {
            return Some((leak_lemma(stem), VerbState::Present));
        }
    }
    if let Some(stem) = w.strip_suffix("s") {
        if stem.len() >= 3 && !w.ends_with("ss") {
            return Some((leak_lemma(stem), VerbState::Present));
        }
    }

    None
}

/// True if two surface forms are states of the same verb lemma.
/// "makes"/"made" → true. "makes"/"has" → false. Exact equality (case-
/// insensitive) is always true regardless of whether the word is a known
/// verb, so this is safe to use as a general token-equivalence test.
pub fn same_lemma(a: &str, b: &str) -> bool {
    if a.eq_ignore_ascii_case(b) {
        return true;
    }
    match (verb_lemma_state(a), verb_lemma_state(b)) {
        (Some((la, _)), Some((lb, _))) => la == lb,
        _ => false,
    }
}

/// The state of a surface form, if it's a recognizable verb.
pub fn verb_state(word: &str) -> Option<VerbState> {
    verb_lemma_state(word).map(|(_, s)| s)
}

/// Intern dynamically-derived lemmas from the suffix fallback so the
/// return type can stay `&'static str` (matching the irregular table).
/// Bounded in practice by vocabulary size; each distinct stem leaks once.
fn leak_lemma(stem: &str) -> &'static str {
    use std::collections::HashMap;
    use std::sync::Mutex;
    use std::sync::OnceLock;
    static INTERN: OnceLock<Mutex<HashMap<String, &'static str>>> = OnceLock::new();
    let m = INTERN.get_or_init(|| Mutex::new(HashMap::new()));
    let mut guard = m.lock().unwrap();
    if let Some(&s) = guard.get(stem) {
        return s;
    }
    let leaked: &'static str = Box::leak(stem.to_string().into_boxed_str());
    guard.insert(stem.to_string(), leaked);
    leaked
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn irregulars_resolve() {
        assert_eq!(verb_lemma_state("made"), Some(("make", VerbState::Past)));
        assert_eq!(verb_lemma_state("makes"), Some(("make", VerbState::Present)));
        assert_eq!(verb_lemma_state("Making"), Some(("make", VerbState::Progressive)));
        assert_eq!(verb_lemma_state("was"), Some(("be", VerbState::Past)));
        assert_eq!(verb_lemma_state("is"), Some(("be", VerbState::Present)));
        assert_eq!(verb_lemma_state("did"), Some(("do", VerbState::Past)));
    }

    #[test]
    fn regulars_resolve_via_suffix() {
        assert_eq!(verb_state("created"), Some(VerbState::Past));
        assert_eq!(verb_state("creates"), Some(VerbState::Present));
        assert_eq!(verb_state("creating"), Some(VerbState::Progressive));
        assert_eq!(verb_state("carried"), Some(VerbState::Past));
    }

    #[test]
    fn lemma_equivalence() {
        assert!(same_lemma("makes", "made"));
        assert!(same_lemma("is", "was"));
        assert!(same_lemma("liked", "likes"));
        assert!(!same_lemma("makes", "has"));
        assert!(same_lemma("Pizza", "pizza")); // exact match always true
        assert!(!same_lemma("pizza", "pasta"));
    }

    #[test]
    fn non_verbs_return_none() {
        assert_eq!(verb_lemma_state("pizza"), None);
        assert_eq!(verb_lemma_state("the"), None);
        // short words don't get mangled by suffix rules
        assert_eq!(verb_lemma_state("red"), None);
        assert_eq!(verb_lemma_state("as"), None);
    }
}
