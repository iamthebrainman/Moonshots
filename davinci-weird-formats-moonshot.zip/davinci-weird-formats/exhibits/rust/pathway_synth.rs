use std::collections::HashMap;
use crate::pathway_table::PathwayTable;
use crate::transitive_reasoner::TransitiveReasoner;
use crate::semantic_matcher::SemanticMatcher;
use crate::inferred_relations::InferredRelations;
use crate::adaptive_dada::AdaptiveDadaEngine;

pub struct SynthesisResult {
    pub text: String,
    pub pathway: Vec<u32>,
    pub confidence: f32,
    pub method: &'static str,
}

pub fn synthesize_transitive(query: &str, pathway_table: &PathwayTable, _transitive: &TransitiveReasoner) -> SynthesisResult {
    let words: Vec<&str> = query.split_whitespace().collect();
    let mut pathway = Vec::new();
    let mut chains = Vec::new();

    for word in &words {
        if let Some(idx) = pathway_table.table.get_word_index(word) {
            pathway.push(idx);
            let rels = pathway_table.table.relations_where_subject(word);
            for (rel_type, obj_idx, conf) in rels {
                if matches!(rel_type, crate::table::RelationType::IS | crate::table::RelationType::IS_A) {
                    pathway.push(obj_idx);
                    if let Some(obj_word) = pathway_table.table.word_at(obj_idx) {
                        let weight = pathway_table.table.slots[obj_idx as usize].score as f32 / 255.0;
                        chains.push((word.to_string(), obj_word, weight * (conf as f32 / 255.0)));
                    }
                }
            }
        }
    }

    let text = if chains.is_empty() { format!("I don't have IS/IS_A relations for '{}'", words.join(" ")) }
    else {
        chains.sort_by(|a,b| b.2.partial_cmp(&a.2).unwrap());
        let parts: Vec<String> = chains.iter().take(3).map(|(s,o,_)| format!("{} is {}", s, o)).collect();
        parts.join(". ")
    };

    let confidence = chains.get(0).map(|c| c.2).unwrap_or(0.0);
    SynthesisResult { text, pathway, confidence, method: "transitive" }
}

pub fn synthesize_property(query: &str, pathway_table: &PathwayTable) -> SynthesisResult {
    let words: Vec<&str> = query.split_whitespace().collect();
    let mut pathway = Vec::new();
    let mut properties = Vec::new();

    for word in &words {
        if let Some(idx) = pathway_table.table.get_word_index(word) {
            pathway.push(idx);
            let rels = pathway_table.table.relations_where_subject(word);
            for (rel_type, obj_idx, conf) in rels {
                if matches!(rel_type, crate::table::RelationType::HAS | crate::table::RelationType::HAS_A | crate::table::RelationType::OWNS) {
                    pathway.push(obj_idx);
                    if let Some(prop) = pathway_table.table.word_at(obj_idx) {
                        let weight = pathway_table.table.slots[obj_idx as usize].score as f32 / 255.0;
                        properties.push((word.to_string(), prop, weight * (conf as f32 / 255.0)));
                    }
                }
            }
        }
    }

    let text = if properties.is_empty() { format!("No properties found for '{}'", words.join(" ")) }
    else {
        properties.sort_by(|a,b| b.2.partial_cmp(&a.2).unwrap());
        let mut by_subject: HashMap<String, Vec<String>> = HashMap::new();
        for (subj, prop, _) in &properties { by_subject.entry(subj.clone()).or_default().push(prop.clone()); }
        let parts: Vec<String> = by_subject.iter().map(|(s,ps)| format!("{} has {}", s, ps.join(", "))).collect();
        parts.join(". ")
    };

    let confidence = properties.get(0).map(|p| p.2).unwrap_or(0.0);
    SynthesisResult { text, pathway, confidence, method: "property" }
}

pub fn synthesize_capability(query: &str, pathway_table: &PathwayTable) -> SynthesisResult {
    let words: Vec<&str> = query.split_whitespace().collect();
    let mut pathway = Vec::new();
    let mut capabilities = Vec::new();

    for word in &words {
        if let Some(idx) = pathway_table.table.get_word_index(word) {
            pathway.push(idx);
            let rels = pathway_table.table.relations_where_subject(word);
            for (rel_type, obj_idx, conf) in rels {
                if matches!(rel_type, crate::table::RelationType::CAN | crate::table::RelationType::DOES | crate::table::RelationType::ABLE_TO | crate::table::RelationType::CAPABLE_OF) {
                    pathway.push(obj_idx);
                    if let Some(action) = pathway_table.table.word_at(obj_idx) {
                        let weight = pathway_table.table.slots[obj_idx as usize].score as f32 / 255.0;
                        capabilities.push((word.to_string(), format!("{:?}", rel_type).to_lowercase(), action, weight * (conf as f32 / 255.0)));
                    }
                }
            }
        }
    }

    let text = if capabilities.is_empty() { format!("No capabilities found for '{}'", words.join(" ")) }
    else {
        capabilities.sort_by(|a,b| b.3.partial_cmp(&a.3).unwrap());
        let parts: Vec<String> = capabilities.iter().take(5).map(|(s,r,a,_)| format!("{} {} {}", s, r, a)).collect();
        parts.join(". ")
    };

    let confidence = capabilities.get(0).map(|c| c.3).unwrap_or(0.0);
    SynthesisResult { text, pathway, confidence, method: "capability" }
}

pub fn synthesize_delta_space(query: &str, pathway_table: &PathwayTable) -> SynthesisResult {
    let words: Vec<&str> = query.split_whitespace().collect();
    let mut pathway = Vec::new();
    let mut delta_clusters = Vec::new();

    for word in &words {
        if let Some(idx) = pathway_table.table.get_word_index(word) {
            pathway.push(idx);
            let neighbors = pathway_table.delta_neighbors(idx, 1000);
            for neighbor_idx in neighbors.iter().take(5) {
                if let Some(neighbor_word) = pathway_table.table.word_at(*neighbor_idx) {
                    let weight = pathway_table.table.slots[*neighbor_idx as usize].score as f32 / 255.0;
                    let my_delta = pathway_table.delta(idx).unwrap_or(0);
                    let their_delta = pathway_table.delta(*neighbor_idx).unwrap_or(0);
                    let delta_similarity = 1.0 / (1.0 + (my_delta - their_delta).abs() as f32 / 1000.0);
                    delta_clusters.push((word.to_string(), neighbor_word, delta_similarity * weight));
                    pathway.push(*neighbor_idx);
                }
            }
        }
    }

    let text = if delta_clusters.is_empty() { format!("No interference patterns for '{}'", words.join(" ")) }
    else {
        delta_clusters.sort_by(|a,b| b.2.partial_cmp(&a.2).unwrap());
        let parts: Vec<String> = delta_clusters.iter().take(5).map(|(s,n,score)| format!("{} relates to {} (δ={:.2})", s, n, score)).collect();
        parts.join(". ")
    };

    let confidence = delta_clusters.get(0).map(|d| d.2).unwrap_or(0.0);
    SynthesisResult { text, pathway, confidence, method: "delta_space" }
}

pub fn synthesize_sequential(query: &str, pathway_table: &PathwayTable, inferred: &InferredRelations) -> SynthesisResult {
    let words: Vec<&str> = query.split_whitespace().collect();
    let mut pathway = Vec::new();
    let relations = inferred.infer(&words, 5, false);

    for word in &words { if let Some(idx) = pathway_table.table.get_word_index(word) { pathway.push(idx); } }
    for rel in &relations { if let Some(idx) = pathway_table.table.get_word_index(&rel.object) { pathway.push(idx); } }

    let text = if relations.is_empty() { format!("No sequential context for '{}'", words.join(" ")) }
    else {
        let mut by_type: HashMap<&str, Vec<String>> = HashMap::new();
        for rel in relations.iter().take(10) { by_type.entry(rel.predicate.as_str()).or_default().push(rel.object.clone()); }
        let parts: Vec<String> = by_type.iter().map(|(pred, objs)| format!("{}: {}", pred.to_lowercase(), objs.join(", "))).collect();
        parts.join(". ")
    };

    let confidence = if relations.is_empty() { 0.0 } else { 0.7 };
    SynthesisResult { text, pathway, confidence, method: "sequential" }
}

pub fn synthesize_adaptive(query: &str, pathway_table: &PathwayTable, adaptive: &mut AdaptiveDadaEngine, word_engine: &mut crate::word_engine::WordEngine, relations: &[crate::dada_engine::RelationalTriple]) -> SynthesisResult {
    let result = adaptive.synthesize_adaptive(word_engine, query, relations);
    let mut pathway = Vec::new();
    for concept in adaptive.active_concepts.iter() {
        if let Some(idx) = pathway_table.table.get_word_index(concept) { pathway.push(idx); }
    }
    SynthesisResult { text: result.generated, pathway, confidence: 0.5, method: "adaptive" }
}

pub struct UnifiedSynthesizer<'a> {
    pub pathway_table: &'a mut PathwayTable<'a>,
    pub transitive: &'a TransitiveReasoner<'a>,
    pub semantic: &'a SemanticMatcher<'a>,
    pub inferred: &'a InferredRelations,
    pub adaptive: &'a mut AdaptiveDadaEngine,
    pub word_engine: &'a mut crate::word_engine::WordEngine,
}

impl<'a> UnifiedSynthesizer<'a> {
    pub fn synthesize(&mut self, query: &str, relations: &[(String, String, String)]) -> SynthesisResult {
        let query_words: Vec<String> = query.split_whitespace().map(|s| s.to_lowercase()).collect();
        let method = self.route(&query_words, relations);
        match method {
            RouteMethod::Transitive => synthesize_transitive(query, &*self.pathway_table, self.transitive),
            RouteMethod::Property => synthesize_property(query, &*self.pathway_table),
            RouteMethod::Capability => synthesize_capability(query, &*self.pathway_table),
            RouteMethod::DeltaSpace => synthesize_delta_space(query, &*self.pathway_table),
            RouteMethod::Sequential => synthesize_sequential(query, &*self.pathway_table, self.inferred),
            RouteMethod::Adaptive => {
                let rel_triples: Vec<crate::dada_engine::RelationalTriple> = relations.iter().map(|(s,r,o)| crate::dada_engine::RelationalTriple::new(s.clone(), r.clone(), o.clone(), 0.8)).collect();
                synthesize_adaptive(query, &*self.pathway_table, self.adaptive, self.word_engine, &rel_triples)
            }
        }
    }

    fn route(&self, query_words: &[String], relations: &[(String, String, String)]) -> RouteMethod {
        let rel_types: Vec<&str> = relations.iter().map(|(_, r, _)| r.as_str()).collect();
        let has_delta_clustering = query_words.iter().any(|w| {
            if let Some(idx) = self.pathway_table.table.get_word_index(w) { self.pathway_table.delta_neighbors(idx, 1000).len() > 3 } else { false }
        });
        if rel_types.iter().any(|r| matches!(*r, "IS" | "IS_A" | "IS_NOT")) { RouteMethod::Transitive }
        else if rel_types.iter().any(|r| matches!(*r, "HAS" | "HAS_A" | "OWNS")) { RouteMethod::Property }
        else if rel_types.iter().any(|r| matches!(*r, "CAN" | "DOES" | "PERFORMS")) { RouteMethod::Capability }
        else if has_delta_clustering { RouteMethod::DeltaSpace }
        else if rel_types.iter().any(|r| matches!(*r, "NEXT_TO" | "NEAR" | "RELATED")) { RouteMethod::Sequential }
        else { RouteMethod::Adaptive }
    }

    pub fn learn_from_feedback(&mut self, result: &SynthesisResult, success: bool) {
        if success {
            for &idx in &result.pathway {
                if idx as usize >= self.pathway_table.table.slots.len() { continue; }
                let slot = &mut self.pathway_table.table.slots[idx as usize];
                let w = slot.score as f32 / 255.0;
                slot.score = ((w + 0.1 * (1.0 - w)) * 255.0) as u16;
            }
        } else {
            for &idx in &result.pathway {
                if idx as usize >= self.pathway_table.table.slots.len() { continue; }
                let slot = &mut self.pathway_table.table.slots[idx as usize];
                let w = slot.score as f32 / 255.0;
                slot.score = ((w + 0.1 * (0.3 - w)) * 255.0) as u16;
            }
        }
    }

}

// Local enum for pathway-based synthesizer routing (keeps this file independent
// from the `word_engine::SynthesisMethod` enum which covers conversational
// surface forms).
enum RouteMethod {
    Transitive,
    Property,
    Capability,
    DeltaSpace,
    Sequential,
    Adaptive,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::pathway_table::PathwayTable;
    use crate::transitive_reasoner::TransitiveReasoner;

    #[test]
    fn synthesize_transitive_no_data() {
        let mut table = crate::table::HashTable24::new_sized(12);
        let pt = PathwayTable::from_table_ref(&mut table);
        let binding: std::collections::HashMap<String, Vec<(String, String)>> = std::collections::HashMap::new();
        let tr = TransitiveReasoner::new(&binding);
        let out = synthesize_transitive("what is a unicorn", &pt, &tr);
        assert!(out.text.contains("I don't have IS/IS_A"));
    }
}
