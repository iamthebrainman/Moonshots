use crate::table::HashTable24;
use crate::table::RelationType;
use std::collections::HashMap;
use std::path::Path;
use std::fs;
use std::io::Write;

// ═══════════════════════════════════════════════════════════════════
// Predictive Coding Layer — Prediction error tracking per slot
// ═══════════════════════════════════════════════════════════════════

/// Per-slot prediction tracking for the predictive coding layer.
///
/// Each slot has:
/// - `predicted_score`: top-down prediction of what score this slot should have
/// - `error`: difference between actual score and predicted score
/// - `energy_contribution`: this slot's contribution to total prediction energy
///
/// The prediction error drives both weight updates (Hebbian learning)
/// and inference (settling to energy minimum).
#[derive(Debug, Clone, Default)]
pub struct PredictionState {
    /// Top-down predicted score for this slot
    pub predicted_score: f32,
    /// Prediction error: actual - predicted
    pub error: f32,
    /// Accumulated energy contribution (squared error)
    pub energy: f32,
    /// How many times this slot has been part of a settling cycle
    pub settle_count: u32,
}

impl PredictionState {
    /// Update prediction error from the current actual score.
    pub fn compute_error(&mut self, actual_score: u16) {
        self.error = actual_score as f32 - self.predicted_score;
        self.energy = self.error * self.error;
    }

    /// Apply a Hebbian weight update: dW = -error * pre_activation * learning_rate
    ///
    /// Returns the suggested score adjustment (can be positive or negative).
    pub fn hebbian_update(&self, pre_activation: f32, learning_rate: f32) -> f32 {
        -self.error * pre_activation * learning_rate
    }
}

/// Lightweight pathway table wrapper that borrows an existing HashTable24.
///
/// Now includes a prediction layer for predictive coding:
/// - Each slot can have an associated `PredictionState`
/// - Settling loops minimize total prediction energy
/// - Hebbian updates adjust scores based on local prediction errors
pub struct PathwayTable<'a> {
    pub table: &'a mut HashTable24,
    /// Prediction states keyed by slot index.
    /// Lazily populated — only slots involved in active queries get states.
    pub predictions: HashMap<u32, PredictionState>,
    /// Total prediction energy across all active slots.
    pub total_energy: f64,
    /// Learning rate for Hebbian weight updates (0.0 to 1.0).
    pub learning_rate: f32,
}

impl<'a> PathwayTable<'a> {
    /// Create a borrowing wrapper around an existing table.
    pub fn from_table_ref(table: &'a mut HashTable24) -> Self {
        Self {
            table,
            predictions: HashMap::new(),
            total_energy: 0.0,
            learning_rate: 0.01,
        }
    }

    /// Forwarding helpers used by synthesizers / learners.
    pub fn get_word_index(&self, word: &str) -> Option<u32> {
        self.table.get_word_index(word)
    }

    pub fn word_at(&self, idx: u32) -> Option<String> {
        self.table.word_at(idx)
    }

    pub fn relations_where_subject(&self, word: &str) -> Vec<(RelationType, u32, u8)> {
        self.table.relations_where_subject(word)
    }

    /// Naive delta-neighbors implementation: scan a small window of slots
    /// around `idx` and return indices of non-empty word slots.
    pub fn delta_neighbors(&self, idx: u32, _radius: usize) -> Vec<u32> {
        let mut out = Vec::new();
        let start = idx.saturating_sub(50) as usize;
        let end = (idx as usize + 50).min(self.table.slots.len().saturating_sub(1));
        for i in start..=end {
            if !self.table.slots[i].is_empty() && self.table.slots[i].key_len > 0 {
                out.push(i as u32);
            }
            if out.len() >= 50 { break; }
        }
        out
    }

    /// Return a small integer 'delta' for a slot index; we expose slot.score
    /// as a cheap proxy for whatever internal delta metric the synthesis
    /// pipeline expects.
    pub fn delta(&self, idx: u32) -> Option<i32> {
        self.table.slots.get(idx as usize).map(|s| s.score as i32)
    }

    // ═══════════════════════════════════════════════════════════════
    // Predictive Coding Operations
    // ═══════════════════════════════════════════════════════════════

    /// Set the top-down prediction for a slot.
    ///
    /// Call this during the top-down pass of the settling loop:
    /// higher layers predict what scores lower layers should have.
    pub fn predict(&mut self, slot_idx: u32, predicted_score: f32) {
        let state = self.predictions.entry(slot_idx).or_default();
        state.predicted_score = predicted_score;
    }

    /// Compute prediction errors for all tracked slots.
    ///
    /// Call this after setting predictions and before reading errors.
    /// Updates `total_energy` as the sum of squared errors across all slots.
    pub fn compute_errors(&mut self) {
        self.total_energy = 0.0;
        let slot_indices: Vec<u32> = self.predictions.keys().copied().collect();
        for idx in slot_indices {
            let actual_score = self.table.slots.get(idx as usize)
                .map(|s| s.score)
                .unwrap_or(0);
            if let Some(state) = self.predictions.get_mut(&idx) {
                state.compute_error(actual_score);
                self.total_energy += state.energy as f64;
            }
        }
    }

    /// Run one settling iteration: predict → compute errors → update scores.
    ///
    /// `top_down_predictions` maps slot indices to predicted scores from
    /// the layer above. `pre_activations` maps slot indices to the
    /// pre-synaptic activation that should drive Hebbian learning.
    ///
    /// Returns the total energy after this iteration (lower = more settled).
    pub fn settle_step(
        &mut self,
        top_down_predictions: &[(u32, f32)],
        pre_activations: &[(u32, f32)],
    ) -> f64 {
        // 1. Set predictions from layer above
        for &(idx, pred) in top_down_predictions {
            self.predict(idx, pred);
        }

        // 2. Compute errors (bottom-up: actual vs predicted)
        self.compute_errors();

        // 3. Hebbian weight updates: adjust scores toward predictions
        let lr = self.learning_rate;
        for &(idx, pre_act) in pre_activations {
            if let Some(state) = self.predictions.get(&idx) {
                let adjustment = state.hebbian_update(pre_act, lr);
                if let Some(slot) = self.table.slots.get_mut(idx as usize) {
                    let new_score = (slot.score as f32 + adjustment).clamp(0.0, u16::MAX as f32);
                    slot.score = new_score as u16;
                }
            }
        }

        // 4. Increment settle counts
        for state in self.predictions.values_mut() {
            state.settle_count += 1;
        }

        self.total_energy
    }

    /// Run a full settling loop until energy stabilizes or max iterations reached.
    ///
    /// Returns `(final_energy, iterations_used)`.
    pub fn settle(
        &mut self,
        top_down_predictions: &[(u32, f32)],
        pre_activations: &[(u32, f32)],
        max_iterations: usize,
        energy_threshold: f64,
    ) -> (f64, usize) {
        let mut prev_energy = f64::MAX;
        for i in 0..max_iterations {
            let energy = self.settle_step(top_down_predictions, pre_activations);
            let delta = (prev_energy - energy).abs();
            if delta < energy_threshold {
                return (energy, i + 1);
            }
            prev_energy = energy;
        }
        (self.total_energy, max_iterations)
    }

    /// Get the prediction error for a specific slot (if tracked).
    pub fn prediction_error(&self, slot_idx: u32) -> Option<f32> {
        self.predictions.get(&slot_idx).map(|s| s.error)
    }

    /// Clear all prediction states (between queries / settling cycles).
    pub fn clear_predictions(&mut self) {
        self.predictions.clear();
        self.total_energy = 0.0;
    }

    /// Persist non-zero pathway scores to a JSON file keyed by word.
    /// Only saves entries where `slot.score != 0`.
    pub fn save_weights(&self, path: impl AsRef<Path>) -> std::io::Result<()> {
        let mut map: Vec<(String, u16)> = Vec::new();
        for (i, slot) in self.table.slots.iter().enumerate() {
            if slot.key_len > 0 && slot.score > 0 {
                if let Some(word) = self.table.word_at(i as u32) {
                    map.push((word, slot.score));
                }
            }
        }
        let json = serde_json::to_string_pretty(&map)?;
        let mut f = fs::File::create(path)?;
        f.write_all(json.as_bytes())?;
        Ok(())
    }

    /// Load pathway weights previously saved with `save_weights`.
    /// For each recorded word, find its current slot index and set score.
    pub fn load_weights(&mut self, path: impl AsRef<Path>) -> std::io::Result<()> {
        let p = path.as_ref();
        if !p.exists() { return Ok(()); }
        let raw = fs::read_to_string(p)?;
        let map: Vec<(String, u16)> = serde_json::from_str(&raw)?;
        for (word, score) in map {
            if let Some(idx) = self.table.get_word_index(&word) {
                if let Some(s) = self.table.slots.get_mut(idx as usize) {
                    s.score = score;
                }
            }
        }
        Ok(())
    }

    /// Radial settle: build `top_down_predictions` from the radial hash field
    /// around `word` and feed them into `settle_step`.
    ///
    /// This is the `PathwayTable`-level entry point for the "one bin over"
    /// mode.  It mirrors `settle_step` exactly except that the prediction set
    /// is derived from `lookup_radial` instead of being supplied by the caller.
    ///
    /// Returns the same prediction error scalar as `settle_step`.
    ///
    /// # Arguments
    /// * `word`        — pivot word to look up radially
    /// * `method`      — hash method for the radial centre (Tribonacci for cascade)
    /// * `chain_depth` — how many Word slots to collect from the collision chain
    /// * `probe_cap`   — max probe steps before giving up
    /// * `window`      — cosine decay window
    ///
    /// The function converts each `(slot_idx, cosine_weight)` hit from
    /// `lookup_radial` into a `(slot_idx, cosine_weight)` prediction pair and
    /// passes them directly to `settle_step`.  The `pre_activations` are
    /// synthesised from the `score` field already stored in each slot
    /// (normalised to `[0, 1]`).
    pub fn settle_radial(
        &mut self,
        word: &str,
        method: crate::hash_methods::HashMethod,
        chain_depth: u8,
        probe_cap: u16,
        window: u16,
        addr_index: &std::collections::HashMap<u32, Vec<u32>>,
    ) -> f64 {
        let hits = self.table.lookup_radial(word, method, chain_depth, probe_cap, window, addr_index);
        if hits.is_empty() {
            return 0.0;
        }

        // Build prediction pairs: (slot_idx, cosine_weight)
        let top_down: Vec<(u32, f32)> = hits.clone();

        // Build pre-activation pairs from slot scores (normalised to [0,1])
        let pre_activations: Vec<(u32, f32)> = hits
            .iter()
            .map(|&(idx, _w)| {
                let score = self.table.slots.get(idx as usize)
                    .map(|s| s.score as f32 / 65535.0)
                    .unwrap_or(0.0);
                (idx, score)
            })
            .collect();

        self.settle_step(&top_down, &pre_activations)
    }
}

// NOTE: `SynthesisMethod` is defined in `word_engine::SynthesisMethod`.
// The pathway modules should use that single canonical enum to avoid
// duplicate type definitions in the crate.

#[cfg(test)]
mod tests {
    use super::*;
    use crate::table::HashTable24;

    #[test]
    fn pathway_table_smoke() {
        let mut table = HashTable24::new_sized(12);
        let mut pt = PathwayTable::from_table_ref(&mut table);
        assert!(pt.get_word_index("missing").is_none());
        assert_eq!(pt.delta_neighbors(0, 100).len(), 0);
    }

    #[test]
    fn save_and_load_weights_roundtrip() {
        let mut table = HashTable24::new_sized(12);
        // insert a word so we have a slot (use carousel encoding)
        let encoded = crate::carousel::encode_string("dog");
        let idx = table.insert(&encoded, crate::table::SlotKind::Word, 0, 0, 5);
        assert!(table.word_at(idx).is_some());
        let mut pt = PathwayTable::from_table_ref(&mut table);
        let tmp = std::env::temp_dir().join("pathway_weights_test.json");
        let _ = std::fs::remove_file(&tmp);
        pt.save_weights(&tmp).unwrap();
        // (no debug output)
        // clear score and reload
        pt.table.slots[idx as usize].score = 0;
        pt.load_weights(&tmp).unwrap();
        // sanity: score restored
        assert!(pt.table.slots[idx as usize].score > 0);
        let _ = std::fs::remove_file(&tmp);
    }
}
