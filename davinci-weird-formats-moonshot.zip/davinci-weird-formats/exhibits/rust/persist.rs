//! # Binary Persistence for HashTable24
//!
//! No databases. No serialization frameworks. No abstraction layers.
//! The Slot array IS the file format.
//!
//! ## File Layout (v3)
//!
//! ```text
//! Offset  Size    Field
//! ------  ----    -----
//! 0x00    8       Magic: b"CRSL\x00\x24\x00\x01" (Carousel, 24-bit, v1)
//! 0x08    4       Version (u32 LE) — 1=hash only, 2=+token timeline, 3=+speaker spans
//! 0x0C    4       Slot count (u32 LE) — must be power of 2
//! 0x10    8       Entry count (u64 LE) — number of occupied slots
//! 0x18    4       Max probe depth (u32 LE)
//! 0x1C    4       Checksum (u32 LE) — XOR-fold of all slot bytes
//! 0x20    8       Token section offset (u64 LE) — 0 if not present (v1)
//! 0x28    8       Speaker section offset (u64 LE) — 0 if not present (v1/v2)
//! 0x30    16      Reserved (zero-padded)
//! 0x40    N×40    Raw Slot array — direct memory image
//! 0x??    ...     Token section (if version>=2): [token_count:u32][len:u16,bytes...]*
//! 0x??    ...     Speaker section (if version>=3): [span_count:u32][start:u32,end:u32,speaker:u8]*
//! ```
//!
//! Total header: 64 bytes (0x40). Aligned to cache line.
//! Slot size: 40 bytes each. Minimum file (hash only) = 64 + (slot_count × 40).
//!
//! ## Loading
//!
//! Memory-mapped when available. The OS pages in slots on demand —
//! only the slots you actually probe get loaded from disk.
//! Cold start for a 4M-slot table: the header + your first lookup.
//! The rest stays on disk until you touch it. Zero deserialization.
//!
//! ## Integrity
//!
//! A 32-bit XOR checksum over the raw slot bytes catches corruption.
//! Not cryptographic — just a sanity check that the file isn't truncated
//! or garbled. If you need more, layer your own.

use crate::table::{HashTable24, Slot};
use std::fs::File;
use std::io::{self, Read, Write, BufWriter, BufReader};
use std::path::Path;

/// Magic bytes: "CRSL" + 0x00 + 0x24 (24-bit) + 0x00 + 0x01 (format v1)
const MAGIC: [u8; 8] = [b'C', b'R', b'S', b'L', 0x00, 0x24, 0x00, 0x01];

/// File format versions:
/// 1 = hash table only
/// 2 = hash table + appended token timeline section
/// 3 = hash table + token timeline + speaker-span section (provenance overlay)
const VERSION_HASH_ONLY: u32 = 1;
const VERSION_WITH_TOKENS: u32 = 2;
const VERSION_WITH_SPEAKERS: u32 = 3;

/// Header size in bytes (64 = cache-line aligned)
const HEADER_SIZE: usize = 64;

/// Size of a single Slot in bytes
const SLOT_SIZE: usize = std::mem::size_of::<Slot>(); // 40

// ============================================================================
// CHECKSUM: XOR-fold across the raw slot array
// ============================================================================

/// Compute a 32-bit XOR checksum over raw bytes.
/// Fast, not cryptographic — just catches corruption and truncation.
#[inline]
fn xor_checksum(data: &[u8]) -> u32 {
    let mut h: u32 = 0;
    // Process 4 bytes at a time
    let chunks = data.chunks_exact(4);
    let remainder = chunks.remainder();
    for chunk in chunks {
        let word = u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
        h ^= word;
    }
    // Handle remaining bytes
    for (i, &b) in remainder.iter().enumerate() {
        h ^= (b as u32) << (i * 8);
    }
    h
}

// ============================================================================
// SAVE: Table → Binary File
// ============================================================================

/// Save a HashTable24 to a binary file.
///
/// The file is the table. No encoding, no transformation, no overhead.
/// Slots are written as raw bytes in their in-memory layout.
///
/// Returns the number of bytes written.
pub fn save(table: &HashTable24, path: impl AsRef<Path>) -> io::Result<u64> {
    let path = path.as_ref();
    let slot_count = table.slots.len() as u32;
    let entry_count = table.count as u64;
    let max_probe = table.max_probe_depth as u32;

    // Reinterpret slot array as raw bytes — zero-copy view
    let slot_bytes: &[u8] = unsafe {
        std::slice::from_raw_parts(
            table.slots.as_ptr() as *const u8,
            table.slots.len() * SLOT_SIZE,
        )
    };

    let checksum = xor_checksum(slot_bytes);

    let file = File::create(path)?;
    let mut writer = BufWriter::with_capacity(1 << 20, file); // 1MB buffer

    // --- Header (64 bytes) ---
    writer.write_all(&MAGIC)?;                                  // 0x00: 8 bytes
    writer.write_all(&VERSION_HASH_ONLY.to_le_bytes())?;       // 0x08: 4 bytes
    writer.write_all(&slot_count.to_le_bytes())?;               // 0x0C: 4 bytes
    writer.write_all(&entry_count.to_le_bytes())?;              // 0x10: 8 bytes
    writer.write_all(&max_probe.to_le_bytes())?;                // 0x18: 4 bytes
    writer.write_all(&checksum.to_le_bytes())?;                 // 0x1C: 4 bytes
    writer.write_all(&0u64.to_le_bytes())?;                     // 0x20: token_section_offset=0
    writer.write_all(&[0u8; 24])?;                              // 0x28: 24 bytes reserved

    // --- Slot array (raw binary) ---
    writer.write_all(slot_bytes)?;

    writer.flush()?;

    let total = HEADER_SIZE as u64 + slot_bytes.len() as u64;
    Ok(total)
}

/// Save a HashTable24 **plus** the full token timeline into a single .crsl file.
///
/// Format: standard header (version=2, token_section_offset filled in) +
///         raw slot array + token section.
///
/// Token section layout:
///   [token_count: u32 LE]
///   for each token: [len: u16 LE][utf-8 bytes]
///
/// This is the canonical save path for the word engine. The token timeline
/// is the other half of the knowledge base; it must live in the same file.
pub fn save_with_tokens(
    table: &HashTable24,
    tokens: &[String],
    path: impl AsRef<Path>,
) -> io::Result<u64> {
    let path = path.as_ref();
    let slot_count = table.slots.len() as u32;
    let entry_count = table.count as u64;
    let max_probe = table.max_probe_depth as u32;

    let slot_bytes: &[u8] = unsafe {
        std::slice::from_raw_parts(
            table.slots.as_ptr() as *const u8,
            table.slots.len() * SLOT_SIZE,
        )
    };
    let checksum = xor_checksum(slot_bytes);

    // token_section_offset = HEADER_SIZE + len(slot_bytes)
    let token_section_offset: u64 = (HEADER_SIZE + slot_bytes.len()) as u64;

    let file = File::create(path)?;
    let mut writer = BufWriter::with_capacity(1 << 20, file);

    // --- Header (64 bytes) ---
    writer.write_all(&MAGIC)?;                                  // 0x00: 8
    writer.write_all(&VERSION_WITH_TOKENS.to_le_bytes())?;     // 0x08: 4
    writer.write_all(&slot_count.to_le_bytes())?;               // 0x0C: 4
    writer.write_all(&entry_count.to_le_bytes())?;              // 0x10: 8
    writer.write_all(&max_probe.to_le_bytes())?;                // 0x18: 4
    writer.write_all(&checksum.to_le_bytes())?;                 // 0x1C: 4
    writer.write_all(&token_section_offset.to_le_bytes())?;    // 0x20: 8 — pointer to tokens
    writer.write_all(&[0u8; 24])?;                              // 0x28: 24 reserved

    // --- Slot array ---
    writer.write_all(slot_bytes)?;

    // --- Token section ---
    let token_count = tokens.len() as u32;
    writer.write_all(&token_count.to_le_bytes())?;
    for tok in tokens {
        let bytes = tok.as_bytes();
        let len = bytes.len().min(u16::MAX as usize) as u16;
        writer.write_all(&len.to_le_bytes())?;
        writer.write_all(&bytes[..len as usize])?;
    }

    writer.flush()?;

    let total = writer.get_ref().metadata().map(|m| m.len()).unwrap_or(0);
    Ok(total)
}

/// Save a HashTable24 **plus** token timeline **plus** speaker-provenance
/// spans into a single .crsl file (version 3).
///
/// `speaker_spans` is `(start, end, speaker_tag)` — half-open token-position
/// ranges with an opaque `u8` speaker tag. This module doesn't know what a
/// "speaker" is (that's `word_engine::Speaker`'s job); it just round-trips
/// whatever byte the caller hands it, same way the rest of this format
/// treats tokens as opaque length-prefixed strings.
///
/// Speaker section layout (appended after the token section):
///   [span_count: u32 LE]
///   for each span: [start: u32 LE][end: u32 LE][speaker: u8]
pub fn save_with_tokens_and_speakers(
    table: &HashTable24,
    tokens: &[String],
    speaker_spans: &[(u32, u32, u8)],
    path: impl AsRef<Path>,
) -> io::Result<u64> {
    let path = path.as_ref();
    let slot_count = table.slots.len() as u32;
    let entry_count = table.count as u64;
    let max_probe = table.max_probe_depth as u32;

    let slot_bytes: &[u8] = unsafe {
        std::slice::from_raw_parts(
            table.slots.as_ptr() as *const u8,
            table.slots.len() * SLOT_SIZE,
        )
    };
    let checksum = xor_checksum(slot_bytes);

    // token_section_offset = HEADER_SIZE + len(slot_bytes)
    let token_section_offset: u64 = (HEADER_SIZE + slot_bytes.len()) as u64;

    // Token section size = 4 (count) + sum(2 + byte_len) per token
    let token_section_size: u64 = 4 + tokens.iter()
        .map(|t| 2 + t.as_bytes().len().min(u16::MAX as usize) as u64)
        .sum::<u64>();
    let speaker_section_offset: u64 = token_section_offset + token_section_size;

    let file = File::create(path)?;
    let mut writer = BufWriter::with_capacity(1 << 20, file);

    // --- Header (64 bytes) ---
    writer.write_all(&MAGIC)?;                                    // 0x00: 8
    writer.write_all(&VERSION_WITH_SPEAKERS.to_le_bytes())?;     // 0x08: 4
    writer.write_all(&slot_count.to_le_bytes())?;                 // 0x0C: 4
    writer.write_all(&entry_count.to_le_bytes())?;                // 0x10: 8
    writer.write_all(&max_probe.to_le_bytes())?;                  // 0x18: 4
    writer.write_all(&checksum.to_le_bytes())?;                   // 0x1C: 4
    writer.write_all(&token_section_offset.to_le_bytes())?;      // 0x20: 8 — pointer to tokens
    writer.write_all(&speaker_section_offset.to_le_bytes())?;    // 0x28: 8 — pointer to speaker spans
    writer.write_all(&[0u8; 16])?;                                // 0x30: 16 reserved

    // --- Slot array ---
    writer.write_all(slot_bytes)?;

    // --- Token section ---
    let token_count = tokens.len() as u32;
    writer.write_all(&token_count.to_le_bytes())?;
    for tok in tokens {
        let bytes = tok.as_bytes();
        let len = bytes.len().min(u16::MAX as usize) as u16;
        writer.write_all(&len.to_le_bytes())?;
        writer.write_all(&bytes[..len as usize])?;
    }

    // --- Speaker section ---
    let span_count = speaker_spans.len() as u32;
    writer.write_all(&span_count.to_le_bytes())?;
    for &(start, end, speaker) in speaker_spans {
        writer.write_all(&start.to_le_bytes())?;
        writer.write_all(&end.to_le_bytes())?;
        writer.write_all(&[speaker])?;
    }

    writer.flush()?;

    let total = writer.get_ref().metadata().map(|m| m.len()).unwrap_or(0);
    Ok(total)
}

/// Load the token timeline from a .crsl file that was saved with `save_with_tokens()`.
/// Returns `Ok(None)` for v1 files (hash-only). Returns `Ok(Some(tokens))` for v2.
pub fn load_tokens(path: impl AsRef<Path>) -> io::Result<Option<Vec<String>>> {
    use std::io::Seek;
    let path = path.as_ref();
    let mut file = File::open(path)?;
    let mut header = [0u8; HEADER_SIZE];
    file.read_exact(&mut header)?;

    if header[0..8] != MAGIC {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "Bad magic"));
    }

    let version = u32::from_le_bytes([header[8], header[9], header[10], header[11]]);
    if version < VERSION_WITH_TOKENS {
        return Ok(None); // v1 file — no token section
    }

    let token_section_offset = u64::from_le_bytes([
        header[0x20], header[0x21], header[0x22], header[0x23],
        header[0x24], header[0x25], header[0x26], header[0x27],
    ]);
    if token_section_offset == 0 {
        return Ok(None);
    }

    file.seek(std::io::SeekFrom::Start(token_section_offset))?;

    let mut count_buf = [0u8; 4];
    file.read_exact(&mut count_buf)?;
    let token_count = u32::from_le_bytes(count_buf) as usize;

    let mut tokens = Vec::with_capacity(token_count);
    let mut len_buf = [0u8; 2];
    for _ in 0..token_count {
        file.read_exact(&mut len_buf)?;
        let len = u16::from_le_bytes(len_buf) as usize;
        let mut bytes = vec![0u8; len];
        file.read_exact(&mut bytes)?;
        tokens.push(String::from_utf8(bytes).unwrap_or_default());
    }

    Ok(Some(tokens))
}

/// Load the speaker-span table from a .crsl file that was saved with
/// `save_with_tokens_and_speakers()`. Returns `Ok(None)` for v1/v2 files
/// (no speaker section — the caller should synthesize one default span
/// covering the whole restored tape). Returns `Ok(Some(spans))` for v3,
/// where each span is `(start, end, speaker_tag)` and `speaker_tag` is
/// whatever opaque `u8` the writer encoded (see `word_engine::Speaker`).
pub fn load_speaker_spans(path: impl AsRef<Path>) -> io::Result<Option<Vec<(u32, u32, u8)>>> {
    use std::io::Seek;
    let path = path.as_ref();
    let mut file = File::open(path)?;
    let mut header = [0u8; HEADER_SIZE];
    file.read_exact(&mut header)?;

    if header[0..8] != MAGIC {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "Bad magic"));
    }

    let version = u32::from_le_bytes([header[8], header[9], header[10], header[11]]);
    if version < VERSION_WITH_SPEAKERS {
        return Ok(None); // v1/v2 file — no speaker section
    }

    let speaker_section_offset = u64::from_le_bytes([
        header[0x28], header[0x29], header[0x2A], header[0x2B],
        header[0x2C], header[0x2D], header[0x2E], header[0x2F],
    ]);
    if speaker_section_offset == 0 {
        return Ok(None);
    }

    file.seek(std::io::SeekFrom::Start(speaker_section_offset))?;

    let mut count_buf = [0u8; 4];
    file.read_exact(&mut count_buf)?;
    let span_count = u32::from_le_bytes(count_buf) as usize;

    let mut spans = Vec::with_capacity(span_count);
    let mut span_buf = [0u8; 9]; // start:4 + end:4 + speaker:1
    for _ in 0..span_count {
        file.read_exact(&mut span_buf)?;
        let start = u32::from_le_bytes([span_buf[0], span_buf[1], span_buf[2], span_buf[3]]);
        let end = u32::from_le_bytes([span_buf[4], span_buf[5], span_buf[6], span_buf[7]]);
        let speaker = span_buf[8];
        spans.push((start, end, speaker));
    }

    Ok(Some(spans))
}

// ============================================================================
// LOAD: Binary File → Table
// ============================================================================

/// Load a HashTable24 from a binary file.
///
/// Reads the header, validates magic/version/checksum, then loads
/// the raw slot array directly into memory. No parsing, no decoding.
///
/// For tables that fit in RAM, this is a single sequential read.
/// The table is ready for nanosecond lookups immediately after.
pub fn load(path: impl AsRef<Path>) -> io::Result<HashTable24> {
    let path = path.as_ref();
    let file = File::open(path)?;
    let file_len = file.metadata()?.len();
    let mut reader = BufReader::with_capacity(1 << 20, file); // 1MB buffer

    // --- Read header ---
    let mut header = [0u8; HEADER_SIZE];
    reader.read_exact(&mut header)?;

    // Validate magic
    if header[0..8] != MAGIC {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "Not a Carousel hash file (bad magic bytes)",
        ));
    }

    // Parse header fields
    let version = u32::from_le_bytes([header[8], header[9], header[10], header[11]]);
    if version != VERSION_HASH_ONLY && version != VERSION_WITH_TOKENS && version != VERSION_WITH_SPEAKERS {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("Unsupported version: {} (supported: 1, 2, 3)", version),
        ));
    }

    let slot_count = u32::from_le_bytes([header[12], header[13], header[14], header[15]]) as usize;
    let entry_count = u64::from_le_bytes([
        header[16], header[17], header[18], header[19],
        header[20], header[21], header[22], header[23],
    ]) as usize;
    let max_probe = u32::from_le_bytes([header[24], header[25], header[26], header[27]]) as usize;
    let stored_checksum = u32::from_le_bytes([header[28], header[29], header[30], header[31]]);

    // Validate file size: v2/v3 files have extra sections after the slots
    let expected_slots_end = HEADER_SIZE as u64 + (slot_count as u64 * SLOT_SIZE as u64);
    if version == VERSION_HASH_ONLY && file_len != expected_slots_end {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "File size mismatch: expected {} bytes ({} slots × {} + {} header), got {}",
                expected_slots_end, slot_count, SLOT_SIZE, HEADER_SIZE, file_len
            ),
        ));
    }
    if version >= VERSION_WITH_TOKENS && file_len < expected_slots_end {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("File too short for slot array: need {} bytes, got {}", expected_slots_end, file_len),
        ));
    }

    // Verify slot_count is power of 2 (required for masking)
    if slot_count == 0 || (slot_count & (slot_count - 1)) != 0 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("Slot count {} is not a power of 2", slot_count),
        ));
    }

    // --- Read raw slot array ---
    let mut slot_bytes = vec![0u8; slot_count * SLOT_SIZE];
    reader.read_exact(&mut slot_bytes)?;

    // Validate checksum
    let computed_checksum = xor_checksum(&slot_bytes);
    if computed_checksum != stored_checksum {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "Checksum mismatch: stored=0x{:08X}, computed=0x{:08X} (file corrupted?)",
                stored_checksum, computed_checksum
            ),
        ));
    }

    // --- Reinterpret bytes as Slot array ---
    // Safety: Slot is repr(C), all-byte fields, no pointers, no Drop.
    // The byte layout on disk is identical to the in-memory layout.
    let mut slots = vec![Slot::default(); slot_count];
    unsafe {
        std::ptr::copy_nonoverlapping(
            slot_bytes.as_ptr(),
            slots.as_mut_ptr() as *mut u8,
            slot_bytes.len(),
        );
    }

    Ok(HashTable24 {
        slots,
        count: entry_count,
        max_probe_depth: max_probe,
    })
}

// ============================================================================
// MEMORY-MAPPED LOAD (zero-copy, OS-paged)
// ============================================================================

/// Memory-mapped table handle.
/// The OS pages slots in from disk on demand — only touched slots get loaded.
/// This means a 160MB table file can be "loaded" in microseconds.
/// The actual I/O happens lazily when you probe a slot.
///
/// The table borrows from the mmap, so the MappedTable must outlive any references.
pub struct MappedTable {
    /// Raw memory-mapped bytes (header + slots)
    _mmap: memmap2::Mmap,
    /// Pointer to the start of the slot array
    slot_ptr: *const Slot,
    /// Number of slots
    slot_count: usize,
    /// Number of occupied entries
    pub count: usize,
    /// Max probe depth
    pub max_probe_depth: usize,
}

// Safety: Slot is repr(C), no interior mutability, read-only mmap
unsafe impl Send for MappedTable {}
unsafe impl Sync for MappedTable {}

impl MappedTable {
    /// Open a Carousel hash file as a memory-mapped read-only table.
    /// Returns instantly — the OS will page in data as you access it.
    pub fn open(path: impl AsRef<Path>) -> io::Result<Self> {
        let file = File::open(path.as_ref())?;
        let file_len = file.metadata()?.len();
        
        // Safety: we only read, and the file won't be modified while mapped
        let mmap = unsafe { memmap2::MmapOptions::new().map(&file)? };

        if mmap.len() < HEADER_SIZE {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "File too small for header"));
        }

        // Validate magic
        if mmap[0..8] != MAGIC {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "Bad magic bytes"));
        }

        let version = u32::from_le_bytes([mmap[8], mmap[9], mmap[10], mmap[11]]);
        if version != VERSION_HASH_ONLY && version != VERSION_WITH_TOKENS && version != VERSION_WITH_SPEAKERS {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "Unsupported version"));
        }

        let slot_count = u32::from_le_bytes([mmap[12], mmap[13], mmap[14], mmap[15]]) as usize;
        let entry_count = u64::from_le_bytes([
            mmap[16], mmap[17], mmap[18], mmap[19],
            mmap[20], mmap[21], mmap[22], mmap[23],
        ]) as usize;
        let max_probe = u32::from_le_bytes([mmap[24], mmap[25], mmap[26], mmap[27]]) as usize;

        // v2 files have a token section after the slots; just require file >= slots end
        let expected_slots_end = HEADER_SIZE + slot_count * SLOT_SIZE;
        if file_len < expected_slots_end as u64 {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "File too short for slot array"));
        }

        // Pointer to the slot array (after the 64-byte header)
        let slot_ptr = unsafe { mmap.as_ptr().add(HEADER_SIZE) as *const Slot };

        Ok(MappedTable {
            _mmap: mmap,
            slot_ptr,
            slot_count,
            count: entry_count,
            max_probe_depth: max_probe,
        })
    }

    /// Get the number of slots in this table.
    #[inline]
    pub fn slot_count(&self) -> usize {
        self.slot_count
    }

    /// Get a slot by index. Zero-copy — reads directly from the mmap.
    #[inline(always)]
    pub fn slot(&self, index: usize) -> &Slot {
        debug_assert!(index < self.slot_count);
        unsafe { &*self.slot_ptr.add(index) }
    }

    #[inline(always)]
    fn mask(&self) -> u32 {
        (self.slot_count as u32) - 1
    }

    #[inline(always)]
    fn golden_step(&self) -> u32 {
        let size = self.slot_count as u64;
        let step = (size * 10_368_890 / (1u64 << 24)) as u32;
        step | 1
    }

    /// Lookup a carousel-encoded key. Same golden ratio probing as HashTable24.
    /// O(1) average, reads directly from memory-mapped file.
    #[inline(always)]
    pub fn get(&self, key: &[u8]) -> Option<&Slot> {
        let mask = self.mask();
        let step = self.golden_step();
        let mut idx = crate::table::hash_carousel(key) & mask;
        let mut probes = 0usize;

        loop {
            let slot = self.slot(idx as usize);
            if slot.is_empty() {
                return None;
            }
            if slot.key_matches(key) {
                return Some(slot);
            }
            idx = (idx.wrapping_add(step)) & mask;
            probes += 1;
            if probes >= 128 {
                return None;
            }
        }
    }

    /// Convenience: lookup a word by string.
    #[inline]
    pub fn get_word(&self, word: &str) -> Option<&Slot> {
        let mut buf = [0u8; 64];
        let len = crate::carousel::encode_string_fixed(word, &mut buf);
        self.get(&buf[..len])
    }

    /// Convenience: lookup a bigram.
    pub fn get_bigram(&self, w1: &str, w2: &str) -> Option<&Slot> {
        let mut key = crate::carousel::encode_string(w1);
        key.push(0xFF);
        key.extend(crate::carousel::encode_string(w2));
        self.get(&key)
    }

    /// Convenience: lookup a trigram.
    pub fn get_trigram(&self, w1: &str, w2: &str, w3: &str) -> Option<&Slot> {
        let mut key = crate::carousel::encode_string(w1);
        key.push(0xFF);
        key.extend(crate::carousel::encode_string(w2));
        key.push(0xFF);
        key.extend(crate::carousel::encode_string(w3));
        self.get(&key)
    }

    /// Load factor.
    pub fn load_factor(&self) -> f64 {
        self.count as f64 / self.slot_count as f64
    }
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    #[test]
    fn test_save_load_roundtrip() {
        let mut table = HashTable24::new_sized(16); // 64K slots
        table.insert_word("hello", 42);
        table.insert_word("world", 99);
        table.insert_word("carousel", 777);
        table.insert_bigram("in", "the", 100);
        table.insert_trigram("son", "of", "god", 200);

        let path = std::env::temp_dir().join("carousel_test.crsl");
        
        // Save
        let bytes_written = save(&table, &path).expect("save failed");
        assert!(bytes_written > HEADER_SIZE as u64);

        // Load
        let loaded = load(&path).expect("load failed");
        assert_eq!(loaded.count, table.count);
        assert_eq!(loaded.max_probe_depth, table.max_probe_depth);
        assert_eq!(loaded.slots.len(), table.slots.len());

        // Verify lookups work identically
        assert_eq!(loaded.get_word("hello").unwrap().value, 42);
        assert_eq!(loaded.get_word("world").unwrap().value, 99);
        assert_eq!(loaded.get_word("carousel").unwrap().value, 777);
        assert_eq!(loaded.get_bigram("in", "the").unwrap().value, 100);
        assert_eq!(loaded.get_trigram("son", "of", "god").unwrap().value, 200);
        assert!(loaded.get_word("missing").is_none());

        // Cleanup
        let _ = fs::remove_file(&path);
    }

    #[test]
    fn test_mmap_roundtrip() {
        let mut table = HashTable24::new_sized(16);
        table.insert_word("faith", 1);
        table.insert_word("hope", 2);
        table.insert_word("love", 3);
        table.insert_bigram("holy", "spirit", 50);

        let path = std::env::temp_dir().join("carousel_mmap_test.crsl");
        save(&table, &path).expect("save failed");

        // Open as memory-mapped
        let mapped = MappedTable::open(&path).expect("mmap open failed");
        assert_eq!(mapped.count, table.count);
        assert_eq!(mapped.get_word("faith").unwrap().value, 1);
        assert_eq!(mapped.get_word("hope").unwrap().value, 2);
        assert_eq!(mapped.get_word("love").unwrap().value, 3);
        assert_eq!(mapped.get_bigram("holy", "spirit").unwrap().value, 50);
        assert!(mapped.get_word("missing").is_none());

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn test_checksum_detects_corruption() {
        let mut table = HashTable24::new_sized(12); // 4K slots
        table.insert_word("test", 1);

        let path = std::env::temp_dir().join("carousel_corrupt_test.crsl");
        save(&table, &path).expect("save failed");

        // Corrupt a byte in the slot region
        let mut data = fs::read(&path).unwrap();
        let corrupt_offset = HEADER_SIZE + 10; // somewhere in the first slot
        data[corrupt_offset] ^= 0xFF;
        fs::write(&path, &data).unwrap();

        // Load should fail with checksum error
        match load(&path) {
            Err(e) => {
                let err_msg = e.to_string();
                assert!(err_msg.contains("Checksum"), "Expected checksum error, got: {}", err_msg);
            }
            Ok(_) => panic!("Expected checksum error but load succeeded"),
        }

        let _ = fs::remove_file(&path);
    }

    #[test]
    fn test_bad_magic_rejected() {
        let path = std::env::temp_dir().join("carousel_badmagic.crsl");
        // Write 64+ bytes of garbage — enough for the header read to succeed
        // but with wrong magic bytes
        let garbage = vec![0xDE; 128];
        fs::write(&path, &garbage).unwrap();

        match load(&path) {
            Err(e) => {
                let msg = e.to_string();
                assert!(msg.contains("magic") || msg.contains("Carousel"),
                    "Expected magic-related error, got: {}", msg);
            }
            Ok(_) => panic!("Expected magic error but load succeeded"),
        }

        let _ = fs::remove_file(&path);
    }
}
