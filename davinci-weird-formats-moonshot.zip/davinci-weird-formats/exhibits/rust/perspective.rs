//! # Perspective Translator
//!
//! Translates sentences between first / second / third person perspectives,
//! preserving punctuation and capitalisation.
//!
//! Also provides `finalize_student_perspective` — a final regex-style fixup
//! pass that guarantees first-person correctness in generated responses.
//!
//! Ported directly from the Python `PerspectiveTranslator` and
//! `perspective_finalizer.py`.

use std::collections::HashMap;

/// The three perspective slots.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Perspective {
    First,
    Second,
    Third,
}

impl Perspective {
    pub fn as_str(self) -> &'static str {
        match self {
            Perspective::First  => "FIRST",
            Perspective::Second => "SECOND",
            Perspective::Third  => "THIRD",
        }
    }
}

/// Prepositions used for subject-vs-object "you" disambiguation.
const PREPOSITIONS: &[&str] = &[
    "from", "to", "with", "for", "at", "by", "about", "between", "of", "in", "on", "into",
];

pub struct PerspectiveTranslator {
    first_to_second: HashMap<&'static str, &'static str>,
    second_to_first: HashMap<&'static str, &'static str>,
    third_to_second: HashMap<&'static str, &'static str>,
}

impl Default for PerspectiveTranslator {
    fn default() -> Self {
        Self::new()
    }
}

impl PerspectiveTranslator {
    pub fn new() -> Self {
        let mut first_to_second = HashMap::new();
        first_to_second.insert("i",      "you");
        first_to_second.insert("me",     "you");
        first_to_second.insert("my",     "your");
        first_to_second.insert("mine",   "yours");
        first_to_second.insert("myself", "yourself");
        first_to_second.insert("we",     "you");
        first_to_second.insert("us",     "you");
        first_to_second.insert("our",    "your");
        first_to_second.insert("am",     "are");
        first_to_second.insert("was",    "were");
        first_to_second.insert("have",   "have");
        first_to_second.insert("has",    "have");

        let mut second_to_first = HashMap::new();
        second_to_first.insert("your",     "my");
        second_to_first.insert("yours",    "mine");
        second_to_first.insert("yourself", "myself");
        second_to_first.insert("are",      "am");
        second_to_first.insert("were",     "was");
        second_to_first.insert("have",     "have");
        // Note: "you" (subject/object) handled specially in translate_sentence

        let mut third_to_second = HashMap::new();
        third_to_second.insert("he",     "you");
        third_to_second.insert("she",    "you");
        third_to_second.insert("it",     "you");
        third_to_second.insert("they",   "you");
        third_to_second.insert("him",    "you");
        third_to_second.insert("her",    "you");
        third_to_second.insert("them",   "you");
        third_to_second.insert("his",    "your");
        third_to_second.insert("hers",   "your");
        third_to_second.insert("their",  "your");
        third_to_second.insert("theirs", "yours");
        third_to_second.insert("is",     "are");
        third_to_second.insert("was",    "were");
        third_to_second.insert("has",    "have");

        Self {
            first_to_second,
            second_to_first,
            third_to_second,
        }
    }

    /// Detect the perspective of a sentence.
    pub fn detect(&self, sentence: &str) -> Perspective {
        let lower = sentence.to_lowercase();
        let words: Vec<&str> = lower.split_whitespace().collect();

        let first_person  = ["i", "me", "my", "mine", "myself", "we", "us", "our", "ours"];
        let second_person = ["you", "your", "yours", "yourself"];

        for w in &words {
            let stripped = w.trim_matches(|c: char| !c.is_alphabetic());
            if first_person.contains(&stripped)  { return Perspective::First; }
            if second_person.contains(&stripped) { return Perspective::Second; }
        }
        Perspective::Third
    }

    /// Translate `sentence` from `from_p` to `to_p`.
    pub fn translate(&self, sentence: &str, from_p: Perspective, to_p: Perspective) -> String {
        if from_p == to_p {
            return sentence.to_string();
        }

        let words: Vec<&str> = sentence.split_whitespace().collect();
        let mut out = Vec::with_capacity(words.len());

        for (i, &word) in words.iter().enumerate() {
            // Split trailing punctuation
            let (core, suffix) = split_punctuation(word);
            let core_lower = core.to_lowercase();
            let was_capitalised = core.starts_with(|c: char| c.is_uppercase());

            let translated_lower: String = match (from_p, to_p) {
                (Perspective::First, Perspective::Second) => {
                    self.first_to_second
                        .get(core_lower.as_str())
                        .copied()
                        .unwrap_or(core_lower.as_str())
                        .to_string()
                }
                (Perspective::Second, Perspective::First) => {
                    if core_lower == "you" {
                        // Heuristic: "you" after a preposition → "me", else → "I"
                        let is_object = i > 0 && {
                            let prev = words[i - 1].to_lowercase();
                            let prev_core = prev.trim_matches(|c: char| !c.is_alphabetic()).to_string();
                            PREPOSITIONS.contains(&prev_core.as_str())
                        };
                        if is_object { "me" } else { "I" }.to_string()
                    } else {
                        self.second_to_first
                            .get(core_lower.as_str())
                            .copied()
                            .unwrap_or(core_lower.as_str())
                            .to_string()
                    }
                }
                (Perspective::Third, Perspective::Second) => {
                    self.third_to_second
                        .get(core_lower.as_str())
                        .copied()
                        .unwrap_or(core_lower.as_str())
                        .to_string()
                }
                _ => core_lower.clone(),
            };

            // Restore capitalisation
            let final_word = restore_case(&translated_lower, was_capitalised, i == 0);
            out.push(format!("{}{}", final_word, suffix));
        }
        out.join(" ")
    }
}

// --- Finalizer functions ---

/// Guarantee first-person correctness in a generated student response.
/// Final fixup pass — runs regex-style substitutions over the text.
pub fn finalize_student_perspective(text: &str) -> String {
    if text.is_empty() {
        return text.to_string();
    }
    let mut t = text.to_string();

    // 1. "You are/have/were/can/will/like/want/need" → "I am/have/was/can/will/like/want/need"
    t = replace_pattern(&t, "you are",  "I am",   true);
    t = replace_pattern(&t, "you have", "I have", true);
    t = replace_pattern(&t, "you were", "I was",  true);
    t = replace_pattern(&t, "you can",  "I can",  true);
    t = replace_pattern(&t, "you will", "I will", true);
    t = replace_pattern(&t, "you like", "I like", true);
    t = replace_pattern(&t, "you want", "I want", true);
    t = replace_pattern(&t, "you need", "I need", true);

    // 2. "Your X" → "My X"
    t = replace_word_prefix(&t, "your", "my");
    t = replace_exact_word(&t, "yours", "mine");

    // 3. Object "you" after prepositions → "me"
    for prep in PREPOSITIONS {
        let pattern = format!("{} you", prep);
        let replacement = format!("{} me", prep);
        t = t.replace(&pattern, &replacement);
        // Capitalised
        let cap_pattern = format!("{} You", capitalise(prep));
        let cap_replace  = format!("{} me", capitalise(prep));
        t = t.replace(&cap_pattern, &cap_replace);
    }

    // 4. "Me am/are/have/can/will/like/want/need" → "I verb"
    for verb in ["am", "are", "have", "has", "can", "will", "like", "want", "need"] {
        t = replace_pattern(&t, &format!("me {}", verb), &format!("I {}", verb), true);
    }

    // 5. Fix verb agreement after prior corrections
    t = replace_pattern(&t, "I are",  "I am",  false);
    t = replace_pattern(&t, "I has",  "I have", false);
    t = replace_pattern(&t, "I were", "I was",  false);

    // 6. Capitalise "I"
    t = capitalise_standalone_i(&t);

    // 7. Sentence-initial capitalisation
    if let Some(first) = t.chars().next() {
        if first.is_lowercase() {
            let mut chars = t.chars();
            t = chars.next().unwrap().to_uppercase().to_string() + chars.as_str();
        }
    }
    t
}

/// Defensive cleanup for teacher messages (mostly a no-op; kept for symmetry).
pub fn finalize_teacher_perspective(text: &str) -> String {
    text.to_string()
}

// --- Internal helpers ---

fn split_punctuation(word: &str) -> (&str, &str) {
    let mut end = word.len();
    while end > 0 && !word[..end].ends_with(|c: char| c.is_alphabetic() || c.is_ascii_digit()) {
        end -= 1;
    }
    (&word[..end], &word[end..])
}

fn restore_case(word: &str, was_cap: bool, is_first: bool) -> String {
    let lower = word.to_lowercase();
    // "I" is always uppercase
    if lower == "i" {
        return "I".to_string();
    }
    if was_cap || is_first {
        capitalise(&lower)
    } else {
        lower
    }
}

fn capitalise(s: &str) -> String {
    let mut c = s.chars();
    match c.next() {
        None => String::new(),
        Some(f) => f.to_uppercase().to_string() + c.as_str(),
    }
}

/// Word-boundary-aware case-insensitive replace (first word of pair).
fn replace_pattern(text: &str, from: &str, to: &str, case_insensitive: bool) -> String {
    if case_insensitive {
        let lower = text.to_lowercase();
        let from_lower = from.to_lowercase();
        let mut result = text.to_string();
        let mut offset: isize = 0;
        let mut search_start = 0usize;
        loop {
            match lower[search_start..].find(&from_lower) {
                None => break,
                Some(rel_idx) => {
                    let idx = search_start + rel_idx;
                    // Check word boundary before
                    let before_ok = idx == 0 || !lower[..idx].ends_with(|c: char| c.is_alphanumeric());
                    let after_idx = idx + from_lower.len();
                    let after_ok = after_idx >= lower.len() || !lower[after_idx..].starts_with(|c: char| c.is_alphanumeric());
                    if before_ok && after_ok {
                        let abs_start = (idx as isize + offset) as usize;
                        let abs_end = abs_start + from.len();
                        result.replace_range(abs_start..abs_end, to);
                        offset += to.len() as isize - from.len() as isize;
                        search_start = idx + from_lower.len();
                    } else {
                        search_start = idx + 1;
                    }
                }
            }
        }
        result
    } else {
        text.replace(from, to)
    }
}

fn replace_exact_word(text: &str, from: &str, to: &str) -> String {
    replace_pattern(text, from, to, true)
}

fn replace_word_prefix(text: &str, prefix: &str, replacement: &str) -> String {
    // "Your " → "My ", "your " → "my "
    let mut result = text.to_string();
    result = result.replace(&format!("{} ", capitalise(prefix)), &format!("{} ", capitalise(replacement)));
    result = result.replace(&format!("{} ", prefix), &format!("{} ", replacement));
    result
}

fn capitalise_standalone_i(text: &str) -> String {
    // Replace " i " and " i'" etc. with " I " / " I'" — simple word-boundary approach
    let mut result = String::with_capacity(text.len());
    let words: Vec<&str> = text.split_whitespace().collect();
    for (idx, w) in words.iter().enumerate() {
        if idx > 0 { result.push(' '); }
        let (core, suf) = split_punctuation(w);
        if core == "i" {
            result.push_str("I");
            result.push_str(suf);
        } else {
            result.push_str(w);
        }
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_detect_first() {
        let t = PerspectiveTranslator::new();
        assert_eq!(t.detect("I am alive"), Perspective::First);
        assert_eq!(t.detect("my name is John"), Perspective::First);
    }

    #[test]
    fn test_detect_second() {
        let t = PerspectiveTranslator::new();
        assert_eq!(t.detect("You are running"), Perspective::Second);
    }

    #[test]
    fn test_detect_third() {
        let t = PerspectiveTranslator::new();
        assert_eq!(t.detect("The dog ran fast"), Perspective::Third);
    }

    #[test]
    fn test_first_to_second() {
        let t = PerspectiveTranslator::new();
        let result = t.translate("I am alive", Perspective::First, Perspective::Second);
        assert_eq!(result, "You are alive");
    }

    #[test]
    fn test_second_to_first_subject() {
        let t = PerspectiveTranslator::new();
        let result = t.translate("You are Number 5", Perspective::Second, Perspective::First);
        assert!(result.starts_with("I "), "Should start with 'I ', got: {}", result);
    }

    #[test]
    fn test_second_to_first_object() {
        let t = PerspectiveTranslator::new();
        // "with you" → "with me"
        let result = t.translate("I am talking with you", Perspective::Second, Perspective::First);
        assert!(result.contains("with me"), "Got: {}", result);
    }

    #[test]
    fn test_finalize_you_are() {
        let out = finalize_student_perspective("You are Number 5");
        assert!(out.starts_with("I am"), "Got: {}", out);
    }

    #[test]
    fn test_finalize_your() {
        let out = finalize_student_perspective("Your name is Johnny");
        assert!(out.starts_with("My name"), "Got: {}", out);
    }

    #[test]
    fn test_finalize_lowercase_i() {
        let out = finalize_student_perspective("i love you");
        assert!(out.contains(" I ") || out.starts_with("I "), "Got: {}", out);
    }

    #[test]
    fn test_finalize_verb_agreement() {
        let out = finalize_student_perspective("I are happy");
        assert_eq!(out, "I am happy");
    }
}
