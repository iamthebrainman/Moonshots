//! # Relation Classifier — The Illuminator
//!
//! This module answers: *how* is the relation being asserted?
//!
//! It sits above `relations.rs` (which answers *what* relation exists)
//! and above `table::RelationType` (which answers *what kind* it is).
//!
//! The classifier reads the full token context around an IS-family token
//! and produces a `VariantClassification` — a compact struct carrying:
//!   - which IS-variant domain was selected (`RelationVariant`)
//!   - which markers triggered the classification (`Vec<Marker>`)
//!   - where IS sits in the token stream (`is_position`)
//!   - the character-span of the IS token (`surface_span`)
//!   - a Fibonacci-sampled backward walk of prior context (`anaphoric_chain`)
//!
//! ## IS as Superposition Operator
//!
//! IS does not have a type. IS is a hinge. What follows IS collapses
//! the superposition into a domain:
//!
//! ```
//! IS + [nothing special] → Definition
//! IS + LIKE              → Comparison
//! IS + NOT               → Negation
//! IS + SOMETIMES         → Frequency
//! IS + WHEN              → Timing
//! IS + FOR               → Function
//! IS + WHY               → Causal
//! IS + THAT              → Clarification
//! IS + HOW               → Procedure
//! ```
//!
//! ## IS-Family Conjugations
//!
//! SHOULD, OUGHT, COULD, MIGHT, MUST, WILL, WAS are not "IS + modifier".
//! They ARE IS — conjugated. Each carries its own certainty/obligation weight
//! (see `table::ConjugationWeights`). The classifier detects conjugations at
//! the IS-position token itself, not in what follows.
//!
//! ## Marker Encoding
//!
//! Rather than encoding every combo as its own enum variant, compound patterns
//! are expressed as a base variant + markers:
//!
//! ```
//! "Why is it that sometimes love is painful?"
//! → variant: ClarifyWhy
//! → markers: [Marker::Why, Marker::That, Marker::Sometimes]
//! ```
//!
//! This keeps the enum lean and lets routing/synthesis inspect
//! `variant` and `markers` independently.

use crate::universal_resolver::ContextTriple;
use crate::table::ConjugationWeights;

// ============================================================================
// MARKER — canonical set of IS-modifying tokens
// ============================================================================

/// Canonical set of tokens that modify how IS fires.
/// These are not arbitrary strings — they are a closed set.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Marker {
    Why,        // causal interrogative or domain specifier
    That,       // clarification / subordinate clause introducer
    Sometimes,  // frequency qualifier (< 1.0)
    Often,      // frequency qualifier (> 0.5)
    Always,     // frequency qualifier (1.0)
    Never,      // frequency qualifier (0.0) — also negation
    Like,       // comparison domain
    How,        // procedure domain
    When,       // timing / conditional domain
    For,        // function domain
    Not,        // negation
    It,         // expletive subject ("Why is it that…")
    Ever,       // unbounded temporal scope
    Such,       // intensity marker
}

impl Marker {
    /// Parse a lowercase token into a Marker, if it matches.
    pub fn from_token(token: &str) -> Option<Self> {
        match token {
            "why"       => Some(Marker::Why),
            "that"      => Some(Marker::That),
            "sometimes" => Some(Marker::Sometimes),
            "often"     => Some(Marker::Often),
            "always"    => Some(Marker::Always),
            "never"     => Some(Marker::Never),
            "like"      => Some(Marker::Like),
            "how"       => Some(Marker::How),
            "when" | "whenever" => Some(Marker::When),
            "for"       => Some(Marker::For),
            "not" | "n't" | "never" => Some(Marker::Not),
            "it"        => Some(Marker::It),
            "ever"      => Some(Marker::Ever),
            "such"      => Some(Marker::Such),
            _           => None,
        }
    }

    /// Confidence weight this marker contributes to its domain.
    pub fn weight(&self) -> f32 {
        match self {
            Marker::Sometimes => 0.5,
            Marker::Often     => 0.7,
            Marker::Always    => 1.0,
            Marker::Never     => 0.0,
            Marker::Not       => 0.0,  // negation, not frequency
            _                 => 1.0,
        }
    }
}

// ============================================================================
// RELATION VARIANT — lean enum, no combo-explosion
// ============================================================================

/// Which IS-domain was selected by context.
///
/// Keep this enum lean. Compound patterns are `variant + markers`,
/// not new variants. `ClarifyWhyFrequency` does not exist here —
/// it is `ClarifyWhy` + `[Marker::That, Marker::Sometimes]`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RelationVariant {
    /// "X is Y" — plain noun phrase, flat assertion
    IsDefinition,

    /// "X is like Y" — comparison domain
    IsComparison,

    /// "X is how Y happens" — procedure domain
    IsProcedure,

    /// "X is when Y condition" — timing / conditional domain
    IsTiming,

    /// "X is why Z causes W" — causal definition
    IsCausal,

    /// "X is for Y purpose" — function domain
    IsFunction,

    /// "X is that [clause]" — clarification / subordinate
    IsClarification,

    /// "X is sometimes Y" — frequency domain (Marker::Sometimes present)
    IsFrequency,

    /// "Is X Y?" — interrogative, verification pipeline
    /// IS at position 0, subject follows
    DirectWhy,

    /// "Why is X Y?" — causal interrogative
    /// WHY at position 0, IS at position 1
    ClarifyWhy,

    /// Uncollapsed — IS found but no domain marker matched
    /// Callers should treat this as IsDefinition with low domain confidence
    Unresolved,
}

// ============================================================================
// VARIANT CLASSIFICATION — the output struct
// ============================================================================

/// Full output of the classifier — everything the router and synthesizer need.
#[derive(Debug, Clone)]
pub struct VariantClassification {
    /// Which IS-domain variant was selected.
    pub variant: RelationVariant,

    /// Index of the IS-family token within the token slice.
    pub is_position: usize,

    /// Canonical markers that triggered or modified the classification.
    /// Small vec — rarely more than 3 entries.
    pub markers: Vec<Marker>,

    /// Character-span `(start, end)` of the IS token in the original text.
    /// Use this to slice source text; avoids copying strings.
    pub surface_span: (u32, u32),

    /// Fibonacci-sampled prior context — the backward walk that reconstructs
    /// motivational state. None when no prior context is available.
    pub anaphoric_chain: Option<Vec<ContextTriple>>,

    /// Conjugation weights for the IS-family member at `is_position`.
    /// IS → { certainty: 1.0, obligation: 0.0 }
    /// SHOULD → { certainty: 0.8, obligation: 0.7 }
    /// etc. See `table::CONJUGATION_TABLE`.
    pub conjugation: ConjugationWeights,
}

// ============================================================================
// CLASSIFIER — the Illuminator
// ============================================================================

/// Classify the IS-variant at `is_token_index` in the token stream.
///
/// # Arguments
/// - `tokens`         — full token slice for the sentence (lowercase)
/// - `spans`          — character spans for each token: `spans[i] = (start, end)`
/// - `is_token_index` — index of the IS-family token to classify
/// - `context`        — recent prior triples for anaphoric chain reconstruction
///
/// # Returns
/// A `VariantClassification` with variant, markers, position, span, and
/// Fibonacci-sampled anaphoric chain.
pub fn classify_relation_variant(
    tokens: &[String],
    spans: &[(u32, u32)],
    is_token_index: usize,
    context: &[ContextTriple],
) -> VariantClassification {
    let surface_span = spans
        .get(is_token_index)
        .copied()
        .unwrap_or((0, 0));

    let is_token = tokens
        .get(is_token_index)
        .map(|s| s.to_lowercase())
        .unwrap_or_default();

    let conjugation = crate::table::conjugation_weights(&is_token);

    // ── Step 1: Pipeline selection by word order ─────────────────────────────
    // Word order IS the pipeline selector. Check the first token(s) first.
    let first = tokens.first().map(|s| s.to_lowercase());
    let second = tokens.get(1).map(|s| s.to_lowercase());

    // "Why is X Y?" → ClarifyWhy
    if first.as_deref() == Some("why") {
        let mut markers = vec![Marker::Why];

        // "Why is it that X Y?" — expletive subject + that
        if tokens.get(2).map(|s| s.to_lowercase()).as_deref() == Some("it")
            && tokens.get(3).map(|s| s.to_lowercase()).as_deref() == Some("that")
        {
            markers.push(Marker::It);
            markers.push(Marker::That);

            // "Why is it that sometimes X Y?" — add frequency marker
            if tokens.iter().any(|t| t.to_lowercase() == "sometimes") {
                markers.push(Marker::Sometimes);
            }
        }

        // Collect any remaining domain markers from post-IS tokens
        collect_post_is_markers(tokens, is_token_index, &mut markers);

        return VariantClassification {
            variant: RelationVariant::ClarifyWhy,
            is_position: is_token_index,
            markers,
            surface_span,
            anaphoric_chain: fibonacci_walk(context),
            conjugation,
        };
    }

    // "Is X Y?" — IS at position 0, interrogative verification
    if is_token_index == 0 {
        let mut markers = vec![];
        collect_post_is_markers(tokens, is_token_index, &mut markers);
        return VariantClassification {
            variant: RelationVariant::DirectWhy,
            is_position: is_token_index,
            markers,
            surface_span,
            anaphoric_chain: fibonacci_walk(context),
            conjugation,
        };
    }

    // ── Step 2: Domain collapse from IS-conjugation ──────────────────────────
    // SHOULD/OUGHT → normative; COULD/MIGHT → modal (stored as IsDefinition
    // with conjugation weights carrying the signal — no new variant needed).
    // The conjugation field already carries certainty/obligation.

    // ── Step 3: Domain collapse from post-IS tokens ──────────────────────────
    let after: Vec<String> = tokens
        .get(is_token_index + 1..)
        .unwrap_or(&[])
        .iter()
        .map(|s| s.to_lowercase())
        .collect();

    let first_after = after.first().map(|s| s.as_str()).unwrap_or("");
    let second_after = after.get(1).map(|s| s.as_str()).unwrap_or("");

    let mut markers: Vec<Marker> = Vec::new();
    collect_post_is_markers(tokens, is_token_index, &mut markers);

    let variant = match first_after {
        // Negation
        "not" | "n't" => {
            // Already added via collect_post_is_markers
            RelationVariant::IsDefinition // negation stored on RelationType::IS_NOT
        }

        // Comparison: "is like Y"
        "like" | "similar" => RelationVariant::IsComparison,

        // Frequency: "is sometimes/often/always/rarely Y"
        "sometimes" | "often" | "always" | "rarely" | "occasionally"
            => RelationVariant::IsFrequency,

        // Timing / conditional: "is when Y"
        "when" | "whenever" => RelationVariant::IsTiming,

        // Function: "is for Y"
        "for" => RelationVariant::IsFunction,

        // Causal definition: "is why Y"
        "why" => RelationVariant::IsCausal,

        // Procedure: "is how Y"
        "how" => RelationVariant::IsProcedure,

        // Clarification: "is that [clause]"
        "that" => RelationVariant::IsClarification,

        // Attribution: "is described as Y" / "is characterized by Y"
        "described" if second_after == "as"   => RelationVariant::IsDefinition, // domain=Attribution via RelationType
        "characterized" if second_after == "by" => RelationVariant::IsDefinition,

        // Intensity: "is such a Y"
        "such" => RelationVariant::IsDefinition,

        _ => {
            // Frequency may appear after article: "is a sometimes-painful thing"
            if after.iter().any(|t| t == "sometimes" || t == "often") {
                RelationVariant::IsFrequency
            } else {
                // Default: plain IS - definition (e.g., "love is an emotion")
                RelationVariant::IsDefinition
            }
        }
    };

    VariantClassification {
        variant,
        is_position: is_token_index,
        markers,
        surface_span,
        anaphoric_chain: fibonacci_walk(context),
        conjugation,
    }
}

// ============================================================================
// HELPERS
// ============================================================================

/// Collect Marker values from tokens after the IS position.
/// Mutates `markers` in place. Does not duplicate existing entries.
fn collect_post_is_markers(tokens: &[String], is_pos: usize, markers: &mut Vec<Marker>) {
    let after = tokens.get(is_pos + 1..).unwrap_or(&[]);
    // Only scan first 5 tokens after IS — markers are immediate context
    for token in after.iter().take(5) {
        if let Some(m) = Marker::from_token(token.to_lowercase().as_str()) {
            if !markers.contains(&m) {
                markers.push(m);
            }
        }
    }
}

/// Fibonacci-sampled backward walk through prior context.
///
/// Positions sampled: n-1, n-2, n-3, n-5, n-8, n-13, n-21
/// This is the reconstructor for motivational state — not stored, derived.
/// Returns None if context is empty.
fn fibonacci_walk(context: &[ContextTriple]) -> Option<Vec<ContextTriple>> {
    if context.is_empty() {
        return None;
    }

    const FIB: &[usize] = &[1, 2, 3, 5, 8, 13, 21];
    let len = context.len();

    let sampled: Vec<ContextTriple> = FIB
        .iter()
        .filter_map(|&step| {
            if step <= len {
                context.get(len - step).cloned()
            } else {
                None
            }
        })
        .collect();

    if sampled.is_empty() { None } else { Some(sampled) }
}

// ============================================================================
// FIND IS POSITION — utility for callers that don't already know it
// ============================================================================

/// Scan a token slice and return the index of the first IS-family token.
///
/// IS-family: is, are, am, was, were, will, should, ought, could, might, must, can
///
/// Returns `None` if no IS-family token is found.
pub fn find_is_position(tokens: &[String]) -> Option<usize> {
    const IS_FAMILY: &[&str] = &[
        "is", "are", "am", "was", "were",
        "will", "should", "ought", "could", "might", "must", "can",
    ];
    tokens.iter().position(|t| IS_FAMILY.contains(&t.to_lowercase().as_str()))
}

/// Classify a token slice automatically — finds IS position internally.
/// Convenience wrapper over `classify_relation_variant`.
///
/// Returns `None` if no IS-family token exists in `tokens`.
pub fn classify(
    tokens: &[String],
    spans: &[(u32, u32)],
    context: &[ContextTriple],
) -> Option<VariantClassification> {
    let is_pos = find_is_position(tokens)?;
    Some(classify_relation_variant(tokens, spans, is_pos, context))
}

/// Map storage-side IsDomain to routing RelationVariant.
/// Used by INTEGRATION_PATCHES PATCH 4 to delegate to collapse_is_domain.
pub fn is_domain_to_variant(domain: crate::table::IsDomain) -> RelationVariant {
    use crate::table::IsDomain;
    match domain {
        IsDomain::Comparison => RelationVariant::IsComparison,
        IsDomain::Frequency => RelationVariant::IsFrequency,
        IsDomain::Conditional => RelationVariant::IsTiming,
        IsDomain::Functional => RelationVariant::IsFunction,
        IsDomain::Causal => RelationVariant::IsCausal,
        IsDomain::Attribution => RelationVariant::IsDefinition,
        IsDomain::Normative => RelationVariant::IsDefinition,
        IsDomain::Modal => RelationVariant::IsDefinition,
        IsDomain::Consequence => RelationVariant::IsDefinition,
        IsDomain::Negation => RelationVariant::IsDefinition,
        IsDomain::Definition
        | IsDomain::Identity
        | IsDomain::Equivalence => RelationVariant::IsDefinition,
    }
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    fn tok(s: &str) -> Vec<String> {
        s.split_whitespace().map(String::from).collect()
    }

    fn spans_for(tokens: &[String]) -> Vec<(u32, u32)> {
        let mut offset = 0u32;
        tokens.iter().map(|t| {
            let start = offset;
            let end = offset + t.len() as u32;
            offset = end + 1;
            (start, end)
        }).collect()
    }

    // ── IsDefinition ────────────────────────────────────────────────────────

    #[test]
    fn test_is_definition() {
        let tokens = tok("love is an emotion");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::IsDefinition);
        assert_eq!(c.is_position, 1);
    }

    // ── IsComparison ─────────────────────────────────────────────────────────

    #[test]
    fn test_is_comparison() {
        let tokens = tok("love is like a tingly feeling");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::IsComparison);
        assert!(c.markers.contains(&Marker::Like));
    }

    // ── IsFrequency ──────────────────────────────────────────────────────────

    #[test]
    fn test_is_frequency() {
        let tokens = tok("love is sometimes described as magical");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::IsFrequency);
        assert!(c.markers.contains(&Marker::Sometimes));
    }

    // ── IsTiming ─────────────────────────────────────────────────────────────

    #[test]
    fn test_is_timing() {
        let tokens = tok("one sided love is when someone doesn't reciprocate");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::IsTiming);
        assert!(c.markers.contains(&Marker::When));
    }

    // ── IsFunction ───────────────────────────────────────────────────────────

    #[test]
    fn test_is_function() {
        let tokens = tok("eating is for staying healthy");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::IsFunction);
        assert!(c.markers.contains(&Marker::For));
    }

    // ── IsCausal ─────────────────────────────────────────────────────────────

    #[test]
    fn test_is_causal() {
        let tokens = tok("this is why love hurts");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::IsCausal);
        assert!(c.markers.contains(&Marker::Why));
    }

    // ── IsProcedure ──────────────────────────────────────────────────────────

    #[test]
    fn test_is_procedure() {
        let tokens = tok("photosynthesis is how plants convert sunlight");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::IsProcedure);
        assert!(c.markers.contains(&Marker::How));
    }

    // ── IsClarification ──────────────────────────────────────────────────────

    #[test]
    fn test_is_clarification() {
        let tokens = tok("the problem is that nobody told her");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::IsClarification);
        assert!(c.markers.contains(&Marker::That));
    }

    // ── DirectWhy (interrogative IS at position 0) ───────────────────────────

    #[test]
    fn test_direct_interrogative() {
        let tokens = tok("is love an emotion");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::DirectWhy);
        assert_eq!(c.is_position, 0);
    }

    // ── ClarifyWhy ───────────────────────────────────────────────────────────

    #[test]
    fn test_clarify_why() {
        let tokens = tok("why is love painful");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::ClarifyWhy);
        assert!(c.markers.contains(&Marker::Why));
    }

    #[test]
    fn test_clarify_why_compound() {
        // "Why is it that X Y?" → ClarifyWhy + [Why, It, That]
        let tokens = tok("why is it that love hurts");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::ClarifyWhy);
        assert!(c.markers.contains(&Marker::Why));
        assert!(c.markers.contains(&Marker::It));
        assert!(c.markers.contains(&Marker::That));
    }

    #[test]
    fn test_clarify_why_frequency_compound() {
        // "Why is it that sometimes love is painful?"
        // → ClarifyWhy + [Why, It, That, Sometimes]
        // This is what was called ClarifyWhyFrequency — encoded as markers, not a new variant
        let tokens = tok("why is it that sometimes love is painful");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert_eq!(c.variant, RelationVariant::ClarifyWhy);
        assert!(c.markers.contains(&Marker::Sometimes),
            "ClarifyWhy compound frequency: expected Sometimes marker, got: {:?}", c.markers);
    }

    // ── Conjugation weights ──────────────────────────────────────────────────

    #[test]
    fn test_conjugation_should() {
        let tokens = tok("love should be reciprocated");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        // SHOULD is IS — certainty 0.8, obligation 0.7
        assert!((c.conjugation.certainty - 0.8).abs() < 0.01,
            "should → certainty 0.8, got {}", c.conjugation.certainty);
        assert!((c.conjugation.obligation - 0.7).abs() < 0.01,
            "should → obligation 0.7, got {}", c.conjugation.obligation);
    }

    #[test]
    fn test_conjugation_might() {
        let tokens = tok("lasagna might give me a tummy ache");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert!((c.conjugation.certainty - 0.3).abs() < 0.01,
            "might → certainty 0.3, got {}", c.conjugation.certainty);
    }

    #[test]
    fn test_conjugation_must() {
        let tokens = tok("i must eat either way");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert!((c.conjugation.certainty - 1.0).abs() < 0.01);
        assert!((c.conjugation.obligation - 1.0).abs() < 0.01);
    }

    // ── Fibonacci walk ───────────────────────────────────────────────────────

    #[test]
    fn test_fibonacci_walk_empty() {
        let tokens = tok("love is emotion");
        let spans = spans_for(&tokens);
        let c = classify(&tokens, &spans, &[]).unwrap();
        assert!(c.anaphoric_chain.is_none());
    }

    #[test]
    fn test_find_is_position() {
        let tokens = tok("love is an emotion");
        assert_eq!(find_is_position(&tokens), Some(1));

        let tokens = tok("why is it that love hurts");
        assert_eq!(find_is_position(&tokens), Some(1));

        let tokens = tok("is love an emotion");
        assert_eq!(find_is_position(&tokens), Some(0));

        let tokens = tok("no copula here");
        assert_eq!(find_is_position(&tokens), None);
    }

    // ── LikePreference is NOT in this module ─────────────────────────────────
    // "I like love" has no IS — it's a PREFERENCE relation, not an IS variant.
    // Verify it produces None from classify() since there's no IS-family token.
    #[test]
    fn test_like_preference_not_is_variant() {
        let tokens = tok("i like love");
        let spans = spans_for(&tokens);
        // No IS-family token → classify() returns None
        assert!(classify(&tokens, &spans, &[]).is_none(),
            "LIKE preference should not classify as an IS variant");
    }
}
