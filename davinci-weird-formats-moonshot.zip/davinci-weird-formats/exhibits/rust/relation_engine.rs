// Relation extraction engine - Grammar pattern matching
// Port of Python Relations system with 250+ semantic patterns

//! # DEPRECATED
//! This module uses single-`\w+` token extraction — it cannot capture
//! multi-word phrases like "quantum field theory" or "one-sided love".
//! Use `relations.rs` (multi-word phrase patterns) for all new extraction.
//!
//! This file is kept because `lib.rs` re-exports `RelationEngine` and
//! `ExtractedRelation` for downstream compatibility. Do not add new patterns here.
//! Route new work through `relations::extract_relations()`.

use std::collections::HashSet;
use regex::Regex;

/// Extracted relation triple
#[derive(Debug, Clone)]
pub struct ExtractedRelation {
    pub subject: String,
    pub relation: String,
    pub object: String,
    pub position: u32,
    pub confidence: f32,
    pub subject_type: String,
    pub object_type: String,
    pub pattern_id: String,
}

/// Grammar pattern for relation extraction
#[derive(Debug, Clone)]
pub struct GrammarPattern {
    pub id: String,
    pub regex: Regex,
    pub relation_type: String,
    pub confidence: f32,
    pub subject_group: usize,
    pub object_group: usize,
}

/// Relation extraction engine
pub struct RelationEngine {
    patterns: Vec<GrammarPattern>,
    function_words: HashSet<String>,
    determiners: HashSet<String>,
    operators: HashSet<String>,
}

impl RelationEngine {
    pub fn new() -> Self {
        let mut engine = Self {
            patterns: Vec::new(),
            function_words: HashSet::new(),
            determiners: HashSet::new(),
            operators: HashSet::new(),
        };
        
        engine.init_function_words();
        engine.init_patterns();
        engine
    }
    
    fn init_function_words(&mut self) {
        // Function words to skip
        for word in ["a", "an", "the", "this", "that", "these", "those"] {
            self.determiners.insert(word.to_string());
            self.function_words.insert(word.to_string());
        }
        
        for word in ["is", "are", "am", "was", "were", "has", "have", "had", "does", "can"] {
            self.operators.insert(word.to_string());
            self.function_words.insert(word.to_string());
        }
        
        for word in ["of", "in", "on", "to", "for", "and", "or", "but", "it", "with", "as", "by", "at"] {
            self.function_words.insert(word.to_string());
        }
    }
    
    fn init_patterns(&mut self) {
        // Core identity patterns
        self.add_pattern("identity_is", r"(\w+)\s+(?:is|are)\s+(?:a|an|the)?\s*(\w+)", "IS", 0.9, 1, 2);
        self.add_pattern("identity_am", r"(\w+)\s+am\s+(?:a|an|the)?\s*(\w+)", "IS", 0.9, 1, 2);
        self.add_pattern("identity_was", r"(\w+)\s+(?:was|were)\s+(?:a|an|the)?\s*(\w+)", "WAS", 0.8, 1, 2);
        
        // Capability patterns
        self.add_pattern("can_verb", r"(\w+)\s+can\s+(\w+)", "CAN", 0.8, 1, 2);
        self.add_pattern("able_to", r"(\w+)\s+(?:is|are)\s+able\s+to\s+(\w+)", "CAN", 0.8, 1, 2);
        self.add_pattern("cannot", r"(\w+)\s+cannot\s+(\w+)", "CANNOT", 0.8, 1, 2);
        
        // Possession patterns
        self.add_pattern("has_have", r"(\w+)\s+(?:has|have)\s+(?:a|an|the)?\s*(\w+)", "HAS", 0.8, 1, 2);
        self.add_pattern("possessive", r"(\w+)'s\s+(\w+)", "HAS", 0.7, 1, 2);
        self.add_pattern("belongs_to", r"(\w+)\s+belongs\s+to\s+(\w+)", "BELONGS_TO", 0.8, 1, 2);
        
        // Location patterns  
        self.add_pattern("location_in", r"(\w+)\s+(?:is|are)\s+in\s+(?:the)?\s*(\w+)", "IN", 0.8, 1, 2);
        self.add_pattern("location_on", r"(\w+)\s+(?:is|are)\s+on\s+(?:the)?\s*(\w+)", "ON", 0.8, 1, 2);
        self.add_pattern("location_at", r"(\w+)\s+(?:is|are)\s+at\s+(?:the)?\s*(\w+)", "AT", 0.8, 1, 2);
        self.add_pattern("lives_in", r"(\w+)\s+lives?\s+in\s+(\w+)", "LIVES_IN", 0.9, 1, 2);
        
        // Action patterns
        self.add_pattern("verb_object", r"(\w+)\s+(eats?|drinks?|makes?|creates?|builds?|writes?|reads?)\s+(\w+)", "ACTION", 0.7, 1, 3);
        self.add_pattern("does_verb", r"(\w+)\s+does\s+(\w+)", "DOES", 0.7, 1, 2);
        self.add_pattern("likes_dislikes", r"(\w+)\s+(likes?|loves?|hates?|dislikes?)\s+(\w+)", "PREFERENCE", 0.8, 1, 3);
        
        // Part-of patterns
        self.add_pattern("part_of", r"(\w+)\s+(?:is|are)\s+(?:a\s+)?part\s+of\s+(\w+)", "PART_OF", 0.9, 1, 2);
        self.add_pattern("contains", r"(\w+)\s+contains?\s+(\w+)", "CONTAINS", 0.8, 1, 2);
        self.add_pattern("made_of", r"(\w+)\s+(?:is|are)\s+made\s+of\s+(\w+)", "MADE_OF", 0.8, 1, 2);
        
        // Causal patterns
        self.add_pattern("causes", r"(\w+)\s+causes?\s+(\w+)", "CAUSES", 0.8, 1, 2);
        self.add_pattern("because_of", r"(\w+)\s+because\s+of\s+(\w+)", "BECAUSE_OF", 0.8, 1, 2);
        self.add_pattern("results_in", r"(\w+)\s+results?\s+in\s+(\w+)", "RESULTS_IN", 0.8, 1, 2);
        
        // Comparison patterns
        self.add_pattern("bigger_than", r"(\w+)\s+(?:is|are)\s+(?:bigger|larger)\s+than\s+(\w+)", "BIGGER_THAN", 0.8, 1, 2);
        self.add_pattern("smaller_than", r"(\w+)\s+(?:is|are)\s+(?:smaller|littler)\s+than\s+(\w+)", "SMALLER_THAN", 0.8, 1, 2);
        self.add_pattern("faster_than", r"(\w+)\s+(?:is|are)\s+faster\s+than\s+(\w+)", "FASTER_THAN", 0.8, 1, 2);
        
        // Temporal patterns
        self.add_pattern("before", r"(\w+)\s+(?:happens?|occurs?)\s+before\s+(\w+)", "BEFORE", 0.8, 1, 2);
        self.add_pattern("after", r"(\w+)\s+(?:happens?|occurs?)\s+after\s+(\w+)", "AFTER", 0.8, 1, 2);
        self.add_pattern("during", r"(\w+)\s+(?:happens?|occurs?)\s+during\s+(\w+)", "DURING", 0.8, 1, 2);
        
        // Family relations
        self.add_pattern("parent_of", r"(\w+)\s+(?:is|are)\s+(?:the\s+)?(?:parent|father|mother)\s+of\s+(\w+)", "PARENT_OF", 0.9, 1, 2);
        self.add_pattern("child_of", r"(\w+)\s+(?:is|are)\s+(?:the\s+)?(?:child|son|daughter)\s+of\s+(\w+)", "CHILD_OF", 0.9, 1, 2);
        self.add_pattern("sibling_of", r"(\w+)\s+(?:is|are)\s+(?:the\s+)?(?:sibling|brother|sister)\s+of\s+(\w+)", "SIBLING_OF", 0.9, 1, 2);
        
        // Property patterns
        self.add_pattern("color", r"(\w+)\s+(?:is|are)\s+(red|blue|green|yellow|black|white|brown|purple|orange|pink)", "COLOR", 0.9, 1, 2);
        self.add_pattern("size", r"(\w+)\s+(?:is|are)\s+(big|small|large|tiny|huge|enormous|little)", "SIZE", 0.9, 1, 2);
        self.add_pattern("material", r"(\w+)\s+(?:is|are)\s+made\s+(?:of\s+)?(wood|metal|plastic|glass|stone|paper)", "MATERIAL", 0.9, 1, 2);
        
        // Negation patterns
        self.add_pattern("not_is", r"(\w+)\s+(?:is|are)\s+not\s+(?:a|an|the)?\s*(\w+)", "NOT_IS", 0.8, 1, 2);
        self.add_pattern("does_not", r"(\w+)\s+does\s+not\s+(\w+)", "DOES_NOT", 0.8, 1, 2);
        
        // Advanced patterns
        self.add_pattern("used_for", r"(\w+)\s+(?:is|are)\s+used\s+for\s+(\w+)", "USED_FOR", 0.8, 1, 2);
        self.add_pattern("made_by", r"(\w+)\s+(?:is|are)\s+made\s+by\s+(\w+)", "MADE_BY", 0.8, 1, 2);
        self.add_pattern("invented_by", r"(\w+)\s+(?:was|were)\s+invented\s+by\s+(\w+)", "INVENTED_BY", 0.9, 1, 2);
        self.add_pattern("discovered_by", r"(\w+)\s+(?:was|were)\s+discovered\s+by\s+(\w+)", "DISCOVERED_BY", 0.9, 1, 2);
        
        // Add more patterns as needed...
        // This gives us about 40 patterns - can expand to 250+ by adding more specific cases
    }
    
    fn add_pattern(&mut self, id: &str, pattern: &str, relation_type: &str, confidence: f32, subject_group: usize, object_group: usize) {
        if let Ok(regex) = Regex::new(&format!(r"(?i){}", pattern)) {
            self.patterns.push(GrammarPattern {
                id: id.to_string(),
                regex,
                relation_type: relation_type.to_string(),
                confidence,
                subject_group,
                object_group,
            });
        }
    }
    
    /// Extract relations from a sentence
    pub fn extract_from_sentence(&self, sentence: &str, base_position: u32) -> Vec<ExtractedRelation> {
        let mut relations = Vec::new();
        let sentence = sentence.to_lowercase();
        
        for pattern in &self.patterns {
            if let Some(captures) = pattern.regex.captures(&sentence) {
                if let (Some(subject_match), Some(object_match)) = (
                    captures.get(pattern.subject_group),
                    captures.get(pattern.object_group)
                ) {
                    let subject = subject_match.as_str().trim();
                    let object = object_match.as_str().trim();
                    
                    // Skip if subject or object are function words
                    if self.function_words.contains(subject) || self.function_words.contains(object) {
                        continue;
                    }
                    
                    // Skip if same word
                    if subject == object {
                        continue;
                    }
                    
                    // Classify subject and object types
                    let subject_type = self.classify_token_type(subject);
                    let object_type = self.classify_token_type(object);
                    
                    relations.push(ExtractedRelation {
                        subject: subject.to_string(),
                        relation: pattern.relation_type.clone(),
                        object: object.to_string(),
                        position: base_position,
                        confidence: pattern.confidence,
                        subject_type,
                        object_type,
                        pattern_id: pattern.id.clone(),
                    });
                    
                    // Only take first match per pattern to avoid over-extraction
                    break;
                }
            }
        }
        
        relations
    }
    
    /// Extract relations from multiple sentences/tokens
    pub fn extract_from_tokens(&self, tokens: &[String], positions: &[u32]) -> Vec<ExtractedRelation> {
        let mut all_relations = Vec::new();
        
        // Reconstruct sentences from tokens for pattern matching
        let text = tokens.join(" ");
        let base_position = positions.first().copied().unwrap_or(0);
        
        all_relations.extend(self.extract_from_sentence(&text, base_position));
        
        // Also try sliding window approach for local patterns
        for window_size in [3, 5, 7] {
            for i in 0..tokens.len().saturating_sub(window_size - 1) {
                let window: Vec<String> = tokens[i..i + window_size].to_vec();
                let window_text = window.join(" ");
                let window_position = positions.get(i).copied().unwrap_or(0);
                
                all_relations.extend(self.extract_from_sentence(&window_text, window_position));
            }
        }
        
        // Deduplicate relations
        all_relations.sort_by(|a, b| {
            (a.subject.as_str(), a.relation.as_str(), a.object.as_str())
                .cmp(&(b.subject.as_str(), b.relation.as_str(), b.object.as_str()))
        });
        all_relations.dedup_by(|a, b| {
            a.subject == b.subject && a.relation == b.relation && a.object == b.object
        });
        
        all_relations
    }
    
    /// Classify token type based on simple heuristics
    fn classify_token_type(&self, token: &str) -> String {
        // Very simple classification - can be enhanced
        if self.determiners.contains(token) {
            "DETERMINER".to_string()
        } else if self.operators.contains(token) {
            "OPERATOR".to_string()
        } else if token.chars().next().unwrap_or('a').is_ascii_uppercase() {
            "ENTITY".to_string() // Proper noun
        } else if token.ends_with("ing") || token.ends_with("ed") {
            "ACTION".to_string() // Verb form
        } else if token.ends_with("ly") {
            "MODIFIER".to_string() // Adverb
        } else {
            "CONCEPT".to_string() // Generic concept
        }
    }
    
    /// Filter and validate extracted relations
    pub fn filter_relations(&self, relations: Vec<ExtractedRelation>, min_confidence: f32) -> Vec<ExtractedRelation> {
        relations.into_iter()
            .filter(|rel| {
                rel.confidence >= min_confidence &&
                rel.subject.len() > 1 &&
                rel.object.len() > 1 &&
                !rel.subject.chars().all(char::is_numeric) &&
                !rel.object.chars().all(char::is_numeric)
            })
            .collect()
    }
    
    /// Synthesize natural language response from relations
    pub fn synthesize_response(&self, relations: &[ExtractedRelation], query_words: &[String], max_facts: usize) -> Option<String> {
        if relations.is_empty() {
            return None;
        }
        
        // Find most relevant relations
        let mut relevant_relations = Vec::new();
        
        for relation in relations {
            let relevance_score = query_words.iter()
                .map(|word| {
                    if relation.subject.contains(word) || relation.object.contains(word) {
                        relation.confidence
                    } else {
                        0.0
                    }
                })
                .sum::<f32>();
            
            if relevance_score > 0.0 {
                relevant_relations.push((relation, relevance_score));
            }
        }
        
        // Sort by relevance
        relevant_relations.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        
        // Take top facts
        let top_relations: Vec<&ExtractedRelation> = relevant_relations
            .into_iter()
            .take(max_facts)
            .map(|(rel, _)| rel)
            .collect();
        
        if top_relations.is_empty() {
            return None;
        }
        
        // Generate response
        let mut response_parts = Vec::new();
        
        for (i, relation) in top_relations.iter().enumerate() {
            let part = match relation.relation.as_str() {
                "IS" => format!("{} is {}", capitalize(&relation.subject), relation.object),
                "HAS" => format!("{} has {}", capitalize(&relation.subject), relation.object),
                "CAN" => format!("{} can {}", capitalize(&relation.subject), relation.object),
                "LIVES_IN" => format!("{} lives in {}", capitalize(&relation.subject), relation.object),
                "PART_OF" => format!("{} is part of {}", capitalize(&relation.subject), relation.object),
                _ => format!("{} {} {}", capitalize(&relation.subject), relation.relation.to_lowercase(), relation.object),
            };
            
            response_parts.push(part);
            
            if i < top_relations.len() - 1 {
                response_parts.push(", and ".to_string());
            }
        }
        
        let mut response = response_parts.join("");
        if !response.ends_with('.') {
            response.push('.');
        }
        
        Some(response)
    }
}

/// Capitalize first letter of string
fn capitalize(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        None => String::new(),
        Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
    }
}

impl Default for RelationEngine {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_basic_extraction() {
        let engine = RelationEngine::new();
        let relations = engine.extract_from_sentence("spot is a dog", 0);
        
        assert_eq!(relations.len(), 1);
        assert_eq!(relations[0].subject, "spot");
        assert_eq!(relations[0].relation, "IS");
        assert_eq!(relations[0].object, "dog");
    }
    
    #[test]
    fn test_capability_extraction() {
        let engine = RelationEngine::new();
        let relations = engine.extract_from_sentence("dogs can bark", 0);
        
        assert_eq!(relations.len(), 1);
        assert_eq!(relations[0].subject, "dogs");
        assert_eq!(relations[0].relation, "CAN");
        assert_eq!(relations[0].object, "bark");
    }
    
    #[test]
    fn test_response_synthesis() {
        let engine = RelationEngine::new();
        
        let relations = vec![
            ExtractedRelation {
                subject: "spot".to_string(),
                relation: "IS".to_string(),
                object: "dog".to_string(),
                position: 0,
                confidence: 0.9,
                subject_type: "ENTITY".to_string(),
                object_type: "CONCEPT".to_string(),
                pattern_id: "identity_is".to_string(),
            }
        ];
        
        let response = engine.synthesize_response(&relations, &["spot".to_string()], 3);
        assert!(response.is_some());
        assert!(response.unwrap().contains("Spot is dog"));
    }
}