//! Relation extraction patterns for semantic triple generation.
//!
//! This module extracts subject-relation-object triples from text using
//! MULTI-WORD phrase capture. Every word matters — no filtering, no exclusion.
//! Punctuation serves as clause boundaries (the grammar).
//!
//! Patterns capture the full noun phrase before/after the relational verb,
//! not just a single `\w+` token.

use crate::table::{RelationType, TransformParams};
use crate::dada_engine::{KnowledgeSource, PersonPerspective};
use regex::Regex;
use lazy_static::lazy_static;

lazy_static! {
    // ========================================================================
    // MULTI-WORD PHRASE PATTERNS
    // ========================================================================
    // Subject/Object = one or more words: `(\w+(?:\s+\w+){0,5})`
    // This captures "the big dog", "quantum field theory", "my old house"
    // up to 6 words per phrase. The {0,5} bounded repetition prevents
    // catastrophic backtracking. Since extraction runs on clause-split text,
    // phrases are naturally bounded by punctuation.
    // ========================================================================

    // Identity: "X is/are [a/an] Y"
    static ref PAT_IS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:am|is|are|was|were)\s+(?:an?\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Negated identity: "X is not [a/an] Y"
    static ref PAT_IS_NOT: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:am|is|are|was|were)\s+not\s+(?:an?\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Capability: "X can/could/may Y"
    static ref PAT_CAN: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:can|could|may|might)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Negated capability: "X cannot/can't/won't Y"
    static ref PAT_CAN_NOT: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:cannot|can't|couldn't|won't|will\s+not)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Possession: "X has/have [a] Y"
    static ref PAT_HAS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:has|have|had)\s+(?:a\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Negated possession: "X has no Y"
    static ref PAT_HAS_NOT: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:has|have|had)\s+no\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Location: "X is in [the] Y"
    static ref PAT_IS_IN: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are|was|were)\s+in\s+(?:the\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Location: "X is at [the] Y"
    static ref PAT_IS_AT: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are|was|were)\s+at\s+(?:the\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Location: "X is on [the] Y"
    static ref PAT_IS_ON: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are|was|were)\s+on\s+(?:the\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Action: "X does/did Y"
    static ref PAT_DOES: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:does|do|did)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Property: "X is [adjective-phrase]" (ending in -ing, -ish, -able, -ful, -ous, -ive, -ed)
    static ref PAT_HAS_PROPERTY: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are|was|were)\s+(\w+(?:\s+\w+){0,4}(?:ing|ish|able|ful|ous|ive|ible|ed|ent|ant))").unwrap();

    // Similarity: "X is like [a] Y"
    static ref PAT_LIKE: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are)\s+like\s+(?:an?\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Equality: "X equals Y"
    static ref PAT_EQUALS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:equals|is\s+equal\s+to)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Causal: "X because Y" / "X due to Y"
    static ref PAT_BECAUSE: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:because\s+of?|due\s+to|caused\s+by)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Part-whole: "X is part of [the] Y"
    static ref PAT_PART_OF: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are)\s+(?:a\s+)?part\s+of\s+(?:the\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Composition: "X is made of/from Y"
    static ref PAT_MADE_OF: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are)\s+made\s+(?:of|from)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Temporal: "X before Y"
    static ref PAT_BEFORE: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:before|prior\s+to|earlier\s+than)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Temporal: "X after Y"
    static ref PAT_AFTER: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:after|later\s+than|following)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Knowledge: "X knows [about] Y"
    static ref PAT_KNOWS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:knows?|knew)\s+(?:about\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Belief: "X believes/thinks Y"
    static ref PAT_BELIEVES: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:believes?|thinks?|thought)\s+(?:in\s+|that\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Purpose: "X is for Y" / "X is used for Y"
    static ref PAT_PURPOSE: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are)\s+(?:used\s+)?for\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Contains: "X contains Y" / "X includes Y"
    static ref PAT_CONTAINS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:contains?|includes?|holds?)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Derivation: "X comes from Y"
    static ref PAT_DERIVED: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:comes?\s+from|is\s+derived\s+from|originates?\s+from)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Causes: "X causes Y" / "X leads to Y"
    static ref PAT_CAUSES: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:causes?|leads?\s+to|results?\s+in|produces?)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Needs: "X needs Y" / "X requires Y"
    static ref PAT_NEEDS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:needs?|requires?|depends?\s+on)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Creates: "X creates Y" / "X builds Y"
    static ref PAT_CREATES: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:creates?|builds?|generates?|makes?|produces?)\s+(?:an?\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // Uses: "X uses Y" / "X utilizes Y"
    static ref PAT_USES: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:uses?|utilizes?|employs?)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Wants: "X wants Y"
    static ref PAT_WANTS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:wants?|desires?|wishes?\s+for)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // IS-domain collapsed patterns (must run before generic IS)
    // IS + SOMETIMES → frequency domain
    static ref PAT_IS_SOMETIMES: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are|was|were)\s+sometimes\s+(?:an?\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // IS + SHOULD/OUGHT/MUST → normative domain
    static ref PAT_IS_NORMATIVE: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:should|ought\s+to|must)\s+(?:be\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // IS + WHEN → conditional definition
    static ref PAT_IS_WHEN: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are)\s+when\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // IS DESCRIBED AS / IS CHARACTERIZED BY → attribution domain
    static ref PAT_IS_DESCRIBED: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+(?:is|are|was|were)\s+(?:described|characterized)\s+(?:as|by)\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // Qualified subject: "True X is Y" / "Real X is Y"
    static ref PAT_IS_QUALIFIED: Regex =
        Regex::new(r"(?i)((?:true|real|genuine|authentic)\s+\w+(?:\s+\w+){0,4})\s+(?:is|are)\s+(?:an?\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // OR-synonym binding: "X or Y" where both are subjects before a predicate
    // Fires before the predicate to bind X and Y as interchangeable.
    static ref PAT_OR_SYNONYM: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,3})\s+or\s+(\w+(?:\s+\w+){0,3})\s+(?:is|are|can|could|may|might|will|should)\s+").unwrap();

    // BUT constraint injection: [intention] but [constraint]
    static ref PAT_BUT: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+but\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // DESPITE constraint override
    static ref PAT_DESPITE: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+despite\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // FEELS
    static ref PAT_FEELS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+feels?\s+(?:like\s+)?(\w+(?:\s+\w+){0,5})").unwrap();

    // FEARS
    static ref PAT_FEARS: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+fears?\s+(\w+(?:\s+\w+){0,5})").unwrap();

    // HOPES
    static ref PAT_HOPES: Regex =
        Regex::new(r"(?i)(\w+(?:\s+\w+){0,5})\s+hopes?\s+(?:for\s+|that\s+)?(\w+(?:\s+\w+){0,5})").unwrap();
}

/// A semantic triple: (subject, relation, object, position_in_text)
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Triple {
    pub subject: String,
    pub relation: RelationType,
    pub object: String,
    pub position: usize,
    pub confidence: u8,  // 0-255
    /// Where this knowledge came from (training vs chat)
    pub source: KnowledgeSource,
    /// Grammatical person of the original assertion
    pub person: PersonPerspective,
    /// Which domain IS collapsed into (ARCH-3)
    pub domain: crate::table::IsDomain,
    /// How the assertion is made (ARCH-3)
    pub modality: crate::table::AssertionModality,
}

impl Triple {
    pub fn new(subject: &str, relation: RelationType, object: &str, position: usize) -> Self {
        Self {
            subject: subject.trim().to_lowercase(),
            relation,
            object: object.trim().to_lowercase(),
            position,
            confidence: 200, // high confidence for explicit patterns
            source: KnowledgeSource::Unknown,
            person: PersonPerspective::Third,
            domain: crate::table::IsDomain::Identity,
            modality: crate::table::AssertionModality::Asserted,
        }
    }

    pub fn with_confidence(mut self, conf: u8) -> Self {
        self.confidence = conf;
        self
    }

    /// Tag this triple with knowledge source and person perspective.
    pub fn with_provenance(mut self, source: KnowledgeSource, person: PersonPerspective) -> Self {
        self.source = source;
        self.person = person;
        self
    }

    pub fn with_domain(mut self, domain: crate::table::IsDomain) -> Self {
        self.domain = domain;
        self
    }

    pub fn with_modality(mut self, modality: crate::table::AssertionModality) -> Self {
        self.modality = modality;
        self
    }

    /// Mark as temporal (time-dependent)
    pub fn mark_temporal(self) -> Self {
        self
    }

    /// Convert to TransformParams for storage in a Slot
    pub fn as_transform(&self) -> TransformParams {
        TransformParams::new(self.relation)
            .with_confidence(self.confidence)
    }

    /// Encode the Triple into a compact binary representation.
    pub fn to_binary(&self) -> Vec<u8> {
        let mut bytes = Vec::new();

        let subject_encoded = crate::carousel::encode_string(&self.subject);
        bytes.push(subject_encoded.len() as u8);
        bytes.extend_from_slice(&subject_encoded);

        bytes.extend_from_slice(&(self.relation as u16).to_le_bytes());

        let object_encoded = crate::carousel::encode_string(&self.object);
        bytes.push(object_encoded.len() as u8);
        bytes.extend_from_slice(&object_encoded);

        bytes.extend_from_slice(&(self.position as u32).to_le_bytes());

        bytes.push(self.confidence);

        bytes
    }
}

/// Helper: extract subject/object captures and build Triples.
fn try_extract(
    regex: &Regex,
    text: &str,
    relation: RelationType,
    confidence: u8,
) -> Vec<Triple> {
    let mut results = Vec::new();
    for cap in regex.captures_iter(text) {
        if let (Some(subj), Some(obj)) = (cap.get(1), cap.get(2)) {
            let s = subj.as_str().trim();
            let o = obj.as_str().trim();
            // Both subject and object must have real content (at least 2 chars)
            if s.len() >= 2 && o.len() >= 2 {
                let pos = cap.get(0).unwrap().start();
                results.push(Triple::new(s, relation, o, pos).with_confidence(confidence));
            }
        }
    }
    results
}

/// Extract all semantic triples from the given text.
/// Text should already be split on sentence/clause boundaries by the caller.
pub fn extract_relations(text: &str) -> Vec<Triple> {
    let mut triples = Vec::new();

    // Negated patterns FIRST (more specific beats general)
    triples.extend(try_extract(&PAT_IS_NOT,   text, RelationType::IS_NOT,   200));
    triples.extend(try_extract(&PAT_CAN_NOT,  text, RelationType::CAN_NOT,  200));
    triples.extend(try_extract(&PAT_HAS_NOT,  text, RelationType::HAS_NOT,  200));

    // Location patterns (before generic IS, since "is in" would match IS too)
    triples.extend(try_extract(&PAT_IS_IN,    text, RelationType::IS_IN,    200));
    triples.extend(try_extract(&PAT_IS_AT,    text, RelationType::IS_AT,    200));
    triples.extend(try_extract(&PAT_IS_ON,    text, RelationType::IS_ON,    200));

    // Property patterns (before generic IS, since "is running" would match IS)
    triples.extend(try_extract(&PAT_HAS_PROPERTY, text, RelationType::HAS_PROPERTY, 180));

    // Similarity (before generic IS)
    triples.extend(try_extract(&PAT_LIKE,     text, RelationType::LIKE,     150));

    // Part/composition (before generic IS)
    triples.extend(try_extract(&PAT_PART_OF,  text, RelationType::PART_OF,  200));
    triples.extend(try_extract(&PAT_MADE_OF,  text, RelationType::MADE_OF,  200));

    // Purpose (before generic IS)
    triples.extend(try_extract(&PAT_PURPOSE,  text, RelationType::PURPOSE_OF, 180));

    // Derivation
    triples.extend(try_extract(&PAT_DERIVED,  text, RelationType::DERIVED_FROM, 180));

    // IS-domain collapsed patterns (must run before generic IS)
    {
        let mut domain_triples = try_extract(&PAT_IS_SOMETIMES,  text, RelationType::IS_SOMETIMES,  190);
        for t in &mut domain_triples {
            t.domain = crate::table::IsDomain::Frequency;
        }
        triples.extend(domain_triples);
    }
    {
        let mut domain_triples = try_extract(&PAT_IS_NORMATIVE,  text, RelationType::IS_NORMATIVE,  190);
        for t in &mut domain_triples {
            t.domain = crate::table::IsDomain::Normative;
        }
        triples.extend(domain_triples);
    }
    {
        let mut domain_triples = try_extract(&PAT_IS_WHEN,       text, RelationType::IS_CONDITIONAL, 190);
        for t in &mut domain_triples {
            t.domain = crate::table::IsDomain::Conditional;
        }
        triples.extend(domain_triples);
    }
    {
        let mut domain_triples = try_extract(&PAT_IS_DESCRIBED,  text, RelationType::IS_ATTRIBUTED, 180);
        for t in &mut domain_triples {
            t.domain = crate::table::IsDomain::Attribution;
        }
        triples.extend(domain_triples);
    }
    {
        let mut domain_triples = try_extract(&PAT_IS_QUALIFIED,  text, RelationType::IS_QUALIFIED,  180);
        for t in &mut domain_triples {
            t.domain = crate::table::IsDomain::Definition;
        }
        triples.extend(domain_triples);
    }

    // OR-synonym binding (two-pass: bind synonyms first, then fire predicate on unified concept)
    triples.extend(try_extract(&PAT_OR_SYNONYM, text, RelationType::OR_SYNONYM, 180));

    // Constraint operators
    triples.extend(try_extract(&PAT_BUT,    text, RelationType::BUT,    160));
    triples.extend(try_extract(&PAT_DESPITE,text, RelationType::DESPITE,160));

    // Emotional operators
    triples.extend(try_extract(&PAT_FEELS,  text, RelationType::FEELS,  150));
    triples.extend(try_extract(&PAT_FEARS,  text, RelationType::FEARS,  150));
    triples.extend(try_extract(&PAT_HOPES,  text, RelationType::HOPES,  150));

    // Identity: generic "X is Y" (last among IS variants)
    triples.extend(try_extract(&PAT_IS,       text, RelationType::IS,       200));

    // Capability
    triples.extend(try_extract(&PAT_CAN,      text, RelationType::CAN,      200));

    // Possession
    triples.extend(try_extract(&PAT_HAS,      text, RelationType::HAS,      200));

    // Action
    triples.extend(try_extract(&PAT_DOES,     text, RelationType::DOES,     180));

    // Equality
    triples.extend(try_extract(&PAT_EQUALS,   text, RelationType::EQUALS,   200));

    // Causal
    triples.extend(try_extract(&PAT_BECAUSE,  text, RelationType::CAUSED_BY, 180));
    triples.extend(try_extract(&PAT_CAUSES,   text, RelationType::CAUSES,   180));

    // Temporal
    triples.extend(try_extract(&PAT_BEFORE,   text, RelationType::BEFORE,   200));
    triples.extend(try_extract(&PAT_AFTER,    text, RelationType::AFTER,    200));

    // Knowledge / Belief
    triples.extend(try_extract(&PAT_KNOWS,    text, RelationType::KNOWS,    200));
    triples.extend(try_extract(&PAT_BELIEVES, text, RelationType::BELIEVES, 180));

    // Contains / Includes
    triples.extend(try_extract(&PAT_CONTAINS, text, RelationType::CONTAINS, 200));

    // Needs / Requires
    triples.extend(try_extract(&PAT_NEEDS,    text, RelationType::REASON_FOR, 180));

    // Creates / Builds
    triples.extend(try_extract(&PAT_CREATES,  text, RelationType::CAUSES,  180));

    // Uses / Utilizes
    triples.extend(try_extract(&PAT_USES,     text, RelationType::INSTRUMENT_FOR, 180));

    // Wants / Desires
    triples.extend(try_extract(&PAT_WANTS,    text, RelationType::GOAL_OF,  150));

    // Dedup by (subject, relation, object), keep first occurrence
    triples.sort_by_key(|t| (t.subject.clone(), t.position));
    triples.dedup_by_key(|t| (t.subject.clone(), t.relation as u16, t.object.clone()));

    triples
}

/// Collapse IS based on the token(s) that follow it.
/// IS is a superposition operator; context selects the domain.
///
/// `tokens` — full token slice for the sentence
/// `is_pos` — index of the IS-family token within that slice
pub fn collapse_is_domain(tokens: &[String], is_pos: usize) -> crate::table::IsDomain {
    use crate::table::IsDomain;

    let first_lower = tokens.get(is_pos + 1).map(|s| s.to_lowercase());
    let second_lower = tokens.get(is_pos + 2).map(|s| s.to_lowercase());

    match first_lower.as_deref() {
        Some("not") | Some("never")                         => IsDomain::Negation,
        Some("like") | Some("similar")                      => IsDomain::Comparison,
        Some("sometimes") | Some("often") | Some("rarely")
        | Some("occasionally") | Some("always")             => IsDomain::Frequency,
        Some("when") | Some("whenever")                     => IsDomain::Conditional,
        Some("for")                                         => IsDomain::Functional,
        Some("why")                                         => IsDomain::Causal,
        Some("described") if second_lower.as_deref() == Some("as")
                                                            => IsDomain::Attribution,
        Some("characterized") if second_lower.as_deref() == Some("by")
                                                            => IsDomain::Attribution,
        Some("such")                                        => IsDomain::Consequence,
        _                                                   => {
            // IS-family conjugations with normative/modal weight
            // These ARE IS — check the is_pos token itself, not what follows
            let cop = tokens.get(is_pos).map(|s| s.to_lowercase());
            match cop.as_deref() {
                Some("should") | Some("ought")  => IsDomain::Normative,
                Some("could")  | Some("might")  => IsDomain::Modal,
                Some("will")                    => IsDomain::Consequence,
                _                               => IsDomain::Definition,
            }
        }
    }
}

/// Detect the query pipeline based on word order.
/// Word order IS the pipeline selector — not decoration.
pub fn select_pipeline(tokens: &[String]) -> QueryPipeline {
    let first  = tokens.first().map(|t| t.to_lowercase());
    let second = tokens.get(1).map(|t| t.to_lowercase());

    match (first.as_deref(), second.as_deref()) {
        // More specific patterns first
        (Some("is"), Some("why"))     => QueryPipeline::CausalDefinition,
        (Some("is"), _)               => QueryPipeline::Verification,
        (Some("why"), Some("is"))     => QueryPipeline::CausalQuery,
        (Some("why"), _)              => QueryPipeline::CausalQuery,
        (_, Some("is")) | (_, _)
            if tokens.iter().any(|t| t.to_lowercase() == "is")
                                      => QueryPipeline::Assertion,
        _                             => QueryPipeline::General,
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QueryPipeline {
    Assertion,          // "X is Y"         — store / relate / propagate
    Verification,       // "Is X Y?"        — query / match / confirm
    CausalQuery,        // "Why is X Y?"    — traverse cause chains
    CausalDefinition,   // "Is why X Y..."  — expand WHY node
    General,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_multiword_identity() {
        let text = "the big dog is a friendly animal";
        let triples = extract_relations(text);
        assert!(triples.iter().any(|t|
            t.relation == RelationType::IS
            && t.subject.contains("big dog")
            && t.object.contains("friendly animal")
        ), "Expected multi-word subject/object, got: {:?}", triples);
    }

    #[test]
    fn test_multiword_capability() {
        let text = "the quantum computer can solve complex problems";
        let triples = extract_relations(text);
        assert!(triples.iter().any(|t|
            t.relation == RelationType::CAN
            && t.subject.contains("quantum computer")
            && t.object.contains("solve")
        ), "Expected multi-word capability, got: {:?}", triples);
    }

    #[test]
    fn test_multiword_possession() {
        let text = "the old house has a beautiful garden";
        let triples = extract_relations(text);
        assert!(triples.iter().any(|t|
            t.relation == RelationType::HAS
            && t.subject.contains("old house")
            && t.object.contains("beautiful garden")
        ), "Expected multi-word possession, got: {:?}", triples);
    }

    #[test]
    fn test_location_pattern() {
        let text = "the ancient temple is in the dense jungle";
        let triples = extract_relations(text);
        assert!(triples.iter().any(|t|
            t.relation == RelationType::IS_IN
            && t.subject.contains("ancient temple")
            && t.object.contains("dense jungle")
        ), "Expected multi-word location, got: {:?}", triples);
    }

    #[test]
    fn test_minimum_length_filter() {
        // Single character subjects/objects get filtered (< 2 chars)
        let text = "I is x";
        let triples = extract_relations(text);
        assert!(triples.is_empty() || triples.iter().all(|t| t.subject.len() >= 2 && t.object.len() >= 2),
            "Single-char subjects/objects should be filtered: {:?}", triples);
    }

    #[test]
    fn test_case_insensitive() {
        let text = "Python Is A Programming Language";
        let triples = extract_relations(text);
        assert!(triples.iter().any(|t|
            t.relation == RelationType::IS
            && t.subject.contains("python")
            && t.object.contains("programming language")
        ), "Case-insensitive match failed: {:?}", triples);
    }

    #[test]
    fn test_to_binary_format() {
        let t = Triple::new("dog", RelationType::IS, "animal", 7);
        let bin = t.to_binary();

        let mut offset = 0;
        let subj_len = bin[offset] as usize;
        offset += 1;
        let subj_bytes = &bin[offset..offset + subj_len];
        offset += subj_len;
        let expected_subj = crate::carousel::encode_string("dog");
        assert_eq!(subj_bytes, expected_subj.as_slice());

        let relation = u16::from_le_bytes([bin[offset], bin[offset + 1]]);
        offset += 2;
        assert_eq!(relation, RelationType::IS as u16);

        let obj_len = bin[offset] as usize;
        offset += 1;
        let obj_bytes = &bin[offset..offset + obj_len];
        offset += obj_len;
        let expected_obj = crate::carousel::encode_string("animal");
        assert_eq!(obj_bytes, expected_obj.as_slice());

        let pos = u32::from_le_bytes([bin[offset], bin[offset + 1], bin[offset + 2], bin[offset + 3]]);
        offset += 4;
        assert_eq!(pos as usize, 7usize);

        let conf = bin[offset];
        assert_eq!(conf, 200u8);
    }
}
