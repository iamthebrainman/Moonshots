//! # Semantic Matcher
//!
//! Computes semantic similarity using **Graph Topology Overlap** — no ML,
//! no embeddings. Two words are similar when they share neighbourhood in
//! the relation graph (same IS_A parents, same HAS children, etc.).
//!
//! Algorithm:
//!   1. Build a "context fingerprint" for each concept: the set of
//!      `>REL:object` (outgoing) and `subject:REL>` (incoming) strings.
//!   2. Jaccard(fp1, fp2) = |fp1 ∩ fp2| / |fp1 ∪ fp2|
//!   3. Boost to 0.8 minimum when an explicit IS/IS_A/SIMILAR_TO/SAME_AS
//!      edge links the two concepts directly.
//!
//! Port of Python `SemanticMatcher`.
//!
//! The matcher borrows the engine's `subject_index` and `object_index` maps
//! and the flat `relation_triples` slice — no data is copied.

use std::collections::{HashMap, HashSet};

/// One entry in the relation graph. Stored as (relation_type, other_node).
pub type RelEdge = (String, String);

/// A context fingerprint is a set of role-labelled neighbour strings.
/// `>REL:target` for outgoing edges, `source:REL>` for incoming.
pub type Fingerprint = HashSet<String>;

/// The matcher. Borrows read-only views of the graph.
pub struct SemanticMatcher<'a> {
    /// subject → [(relation, object)]
    by_subject: &'a HashMap<String, Vec<RelEdge>>,
    /// object  → [(subject, relation)]
    by_object:  &'a HashMap<String, Vec<(String, String)>>,
}

impl<'a> SemanticMatcher<'a> {
    pub fn new(
        by_subject: &'a HashMap<String, Vec<RelEdge>>,
        by_object:  &'a HashMap<String, Vec<(String, String)>>,
    ) -> Self {
        Self { by_subject, by_object }
    }

    /// Build the 1-hop relational fingerprint for a concept.
    pub fn fingerprint(&self, concept: &str) -> Fingerprint {
        let c = concept.trim().to_lowercase();
        let mut fp = HashSet::new();

        // Outgoing: Concept → REL → Object
        if let Some(edges) = self.by_subject.get(&c) {
            for (rel, obj) in edges {
                fp.insert(format!(">{}:{}", rel, obj));
            }
        }

        // Incoming: Subject → REL → Concept
        if let Some(edges) = self.by_object.get(&c) {
            for (subj, rel) in edges {
                fp.insert(format!("{}:{}>", subj, rel));
            }
        }

        fp
    }

    /// Jaccard similarity of two concepts' graph neighbourhoods.
    /// Returns 0.0–1.0 (1.0 = identical, 0.0 = no overlap).
    pub fn similarity(&self, c1: &str, c2: &str) -> f32 {
        let a = c1.trim().to_lowercase();
        let b = c2.trim().to_lowercase();

        if a == b {
            return 1.0;
        }

        let fp1 = self.fingerprint(&a);
        let fp2 = self.fingerprint(&b);

        if fp1.is_empty() || fp2.is_empty() {
            return 0.0;
        }

        let intersection = fp1.intersection(&fp2).count() as f32;
        let union        = fp1.union(&fp2).count() as f32;
        let jaccard = if union == 0.0 { 0.0 } else { intersection / union };

        // Boost for direct identity edge c1 → c2 or c2 → c1
        let identity_rels = ["IS", "IS_A", "SIMILAR_TO", "SAME_AS"];
        let direct = self.by_subject.get(&a).map_or(false, |edges| {
            edges.iter().any(|(r, o)| o == &b && identity_rels.contains(&r.as_str()))
        }) || self.by_subject.get(&b).map_or(false, |edges| {
            edges.iter().any(|(r, o)| o == &a && identity_rels.contains(&r.as_str()))
        });

        if direct { jaccard.max(0.8) } else { jaccard }
    }

    /// Find the best-matching concept from `targets` for `concept`.
    /// Returns `(best_match, score)`. Returns `(None, 0.0)` if targets is empty.
    pub fn best_match<'b>(&self, concept: &str, targets: &'b [String]) -> (Option<&'b str>, f32) {
        // Fast path: exact match
        let lower = concept.trim().to_lowercase();
        if let Some(t) = targets.iter().find(|t| t.to_lowercase() == lower) {
            return (Some(t.as_str()), 1.0);
        }

        let mut best_score = 0.0f32;
        let mut best_match: Option<&str> = None;

        for target in targets {
            let score = self.similarity(concept, target);
            if score > best_score {
                best_score = score;
                best_match = Some(target.as_str());
            }
        }
        (best_match, best_score)
    }

    /// Rank all targets by similarity to `concept` (highest first).
    pub fn rank<'b>(&self, concept: &str, targets: &'b [String]) -> Vec<(&'b str, f32)> {
        let mut ranked: Vec<(&str, f32)> = targets
            .iter()
            .map(|t| (t.as_str(), self.similarity(concept, t)))
            .collect();
        ranked.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        ranked
    }
}

/// Build `by_object` index from a flat triple slice.
/// Caller typically has `by_subject` already; this builds the inverse.
pub fn build_by_object(
    by_subject: &HashMap<String, Vec<RelEdge>>,
) -> HashMap<String, Vec<(String, String)>> {
    let mut by_object: HashMap<String, Vec<(String, String)>> = HashMap::new();
    for (subj, edges) in by_subject {
        for (rel, obj) in edges {
            by_object
                .entry(obj.clone())
                .or_insert_with(Vec::new)
                .push((subj.clone(), rel.clone()));
        }
    }
    by_object
}

#[cfg(test)]
mod tests {
    use super::*;

    fn build_test_graph() -> (
        HashMap<String, Vec<RelEdge>>,
        HashMap<String, Vec<(String, String)>>,
    ) {
        let mut by_subj: HashMap<String, Vec<RelEdge>> = HashMap::new();

        // dog and cat both IS_A animal → they should have high overlap
        by_subj.entry("dog".into()).or_default().push(("IS_A".into(), "animal".into()));
        by_subj.entry("dog".into()).or_default().push(("HAS".into(),  "fur".into()));
        by_subj.entry("dog".into()).or_default().push(("CAN".into(),  "bark".into()));

        by_subj.entry("cat".into()).or_default().push(("IS_A".into(), "animal".into()));
        by_subj.entry("cat".into()).or_default().push(("HAS".into(),  "fur".into()));
        by_subj.entry("cat".into()).or_default().push(("CAN".into(),  "meow".into()));

        by_subj.entry("car".into()).or_default().push(("HAS".into(),  "wheels".into()));
        by_subj.entry("car".into()).or_default().push(("IS_A".into(), "vehicle".into()));

        // synonym edge
        by_subj.entry("hound".into()).or_default().push(("IS".into(), "dog".into()));

        let by_obj = build_by_object(&by_subj);
        (by_subj, by_obj)
    }

    #[test]
    fn test_identical_returns_1() {
        let (bs, bo) = build_test_graph();
        let m = SemanticMatcher::new(&bs, &bo);
        assert!((m.similarity("dog", "dog") - 1.0).abs() < 1e-6);
    }

    #[test]
    fn test_similar_animals() {
        let (bs, bo) = build_test_graph();
        let m = SemanticMatcher::new(&bs, &bo);
        let s = m.similarity("dog", "cat");
        // Shared: IS_A:animal, HAS:fur → 2 shared / 4 total = 0.5 Jaccard
        assert!(s > 0.0, "dog and cat should share neighbourhood");
        assert!(s <= 1.0);
    }

    #[test]
    fn test_unrelated_returns_low() {
        let (bs, bo) = build_test_graph();
        let m = SemanticMatcher::new(&bs, &bo);
        let s = m.similarity("dog", "car");
        assert!(s < 0.3, "dog and car should have low similarity, got {}", s);
    }

    #[test]
    fn test_direct_identity_boost() {
        let (bs, bo) = build_test_graph();
        let m = SemanticMatcher::new(&bs, &bo);
        // hound IS dog — direct edge should boost similarity to ≥ 0.8
        let s = m.similarity("hound", "dog");
        assert!(s >= 0.8, "Direct IS edge should boost to ≥0.8, got {}", s);
    }

    #[test]
    fn test_unknown_returns_zero() {
        let (bs, bo) = build_test_graph();
        let m = SemanticMatcher::new(&bs, &bo);
        let s = m.similarity("xyzzy", "plugh");
        assert_eq!(s, 0.0);
    }

    #[test]
    fn test_best_match() {
        let (bs, bo) = build_test_graph();
        let m = SemanticMatcher::new(&bs, &bo);
        let targets = vec!["cat".to_string(), "car".to_string(), "hound".to_string()];
        let (best, score) = m.best_match("dog", &targets);
        assert!(best.is_some());
        // "hound" has direct IS edge → should win or "cat" has high overlap
        assert!(score > 0.0);
    }

    #[test]
    fn test_exact_match_returns_1() {
        let (bs, bo) = build_test_graph();
        let m = SemanticMatcher::new(&bs, &bo);
        let targets = vec!["cat".to_string(), "dog".to_string()];
        let (best, score) = m.best_match("dog", &targets);
        assert_eq!(best, Some("dog"));
        assert!((score - 1.0).abs() < 1e-6);
    }
}
