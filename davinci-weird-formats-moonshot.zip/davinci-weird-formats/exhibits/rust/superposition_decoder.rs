//! # SuperpositionDecoder — Multi-Lens Fibonacci Slot Decoder
//!
//! ## Concept
//!
//! Each 10-bit slot value in the carousel hash table encodes two 5-bit indices
//! `(a, b)` into a Fibonacci sequence that starts at `[2, 3, ...]` (not 0,1)
//! to prevent identity collapse (`F(0)*F(0) = 0`).
//!
//! The same 10 bits mean **different things** depending on the query context
//! (the "lens"). This is zero-cost dispatch: the match is statically resolved
//! with no runtime branching overhead.
//!
//! ## Geometric Properties
//!
//! - `F(a) * F(b)` spans roughly 0 → 1.8 trillion, following a power-law
//!   distribution that mirrors Zipf's law in natural language.
//! - Common words cluster at low magnitudes; rare terms live at high, sparse
//!   coordinates — exactly how language frequency distributions behave.
//! - Multi-resolution slots (word, bigram, trigram) at different Fibonacci
//!   scales create interference patterns that encode semantic proximity.
//!
//! ## Integration with carousel hash
//!
//! The `HashTable24` stores 10-bit semantic geometry in the padding bytes of
//! each `Slot`. Use `SuperpositionDecoder::decode(slot.ten_bit_val, context)`
//! to read that geometry through the appropriate lens.
//!
//! ## Lens summary
//!
//! | Context        | Returns          | Use case                              |
//! |----------------|------------------|---------------------------------------|
//! | Magnitude      | u64              | Semantic weight / coordinate          |
//! | Directionality | f64              | Ratio slope (F_a / F_b)               |
//! | Band           | u16              | Coarse frequency band (a + b)         |
//! | Asymmetry      | i16              | Left/right skew  (a − b)              |
//! | GapFill        | u64              | Interpolated address for sparse slots |
//! | FullManifold   | ManifoldState    | All dimensions at once                |
//! | Flat           | u16              | Raw 10-bit passthrough (no decode)    |

/// Fibonacci table length — 32 entries, starting at F(0)=2, F(1)=3.
const FIB_LEN: usize = 32;

/// Pre-computed Fibonacci sequence starting at [2, 3, ...].
///
/// Starts at 2 (not 0 or 1) to prevent identity collapse:
/// `F(0) * F(0) = 2 * 2 = 4` rather than zero.
const fn build_fib() -> [u64; FIB_LEN] {
    let mut fib = [0u64; FIB_LEN];
    fib[0] = 2;
    fib[1] = 3;
    let mut i = 2;
    while i < FIB_LEN {
        fib[i] = fib[i - 1] + fib[i - 2];
        i += 1;
    }
    fib
}

/// Compile-time Fibonacci table.
pub const FIB: [u64; FIB_LEN] = build_fib();

// ============================================================================
// CONTEXT LENS
// ============================================================================

/// The "lens" through which a 10-bit slot value is interpreted.
///
/// Every 10-bit read **must** declare its context. This prevents accidental
/// magnitude comparisons with band values, etc.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum DecodeContext {
    /// `F(a) * F(b)` — raw semantic weight / coordinate in 1.8T-point space.
    Magnitude,
    /// `F(a) / F(b)` — directional slope / ratio between the two Fibonacci axes.
    Directionality,
    /// `a + b` — coarse frequency band (0..62). Cheap proximity measure.
    Band,
    /// `a − b` — signed asymmetry. Positive = skewed toward high-frequency axis.
    Asymmetry,
    /// `F(b) * coarse_scale + F(a)` — gap-filling address for sparse slots.
    GapFill,
    /// All five dimensions at once. Use when you need the full geometry.
    FullManifold,
    /// Raw 10-bit passthrough. No Fibonacci math applied.
    Flat,
}

// ============================================================================
// RESULT TYPES
// ============================================================================

/// Full geometric state for a single 10-bit slot value.
#[derive(Debug, Clone, PartialEq)]
pub struct ManifoldState {
    /// `F(a) * F(b)` — semantic weight in [4 .. ~1.8 trillion].
    pub magnitude: u64,
    /// `F(a) / F(b)` — directional ratio.
    pub directionality: f64,
    /// `a + b` — coarse band (0..62).
    pub band: u16,
    /// `a − b` — signed asymmetry.
    pub asymmetry: i16,
    /// `F(b) * coarse_scale + F(a)` — gap-fill address.
    pub exact_address: u64,
    /// The raw 5-bit indices that produced this state.
    pub a: u8,
    pub b: u8,
}

/// Type-safe return value from `SuperpositionDecoder::decode`.
///
/// Different lenses return different types. Pattern-match on this to extract
/// only what you need — the compiler will enforce exhaustiveness.
#[derive(Debug, Clone, PartialEq)]
pub enum DecodeResult {
    /// Semantic weight: `F(a) * F(b)` as u64.
    Magnitude(u64),
    /// Directional ratio: `F(a) as f64 / F(b) as f64`.
    Directionality(f64),
    /// Coarse band: `a + b` as u16.
    Band(u16),
    /// Asymmetry: `a as i16 − b as i16`.
    Asymmetry(i16),
    /// Gap-fill address: `F(b) * coarse_scale + F(a)`.
    GapFill(u64),
    /// All dimensions. See [`ManifoldState`].
    FullManifold(ManifoldState),
    /// Raw 10-bit value unchanged.
    Flat(u16),
}

// ============================================================================
// DECODER
// ============================================================================

/// Multi-lens decoder for 10-bit carousel slot values.
///
/// Construct once (cheap — just the Fibonacci table + a scale constant)
/// and reuse across all slot reads. The Fibonacci table is a compile-time
/// constant so `new()` essentially just stores the coarse scale.
///
/// # Example
/// ```rust
/// use carousel_hash::superposition_decoder::{SuperpositionDecoder, DecodeContext, DecodeResult};
///
/// let dec = SuperpositionDecoder::new();
/// // slot_data: bits [9:5] = a=13, bits [4:0] = b=19  → decimal 435
/// let slot_data: u16 = 0b01101_10011;
///
/// if let DecodeResult::Magnitude(w) = dec.decode(slot_data, DecodeContext::Magnitude) {
///     println!("Semantic weight: {}", w);
/// }
/// ```
pub struct SuperpositionDecoder {
    /// Scale factor used in GapFill lens. Controls address density.
    /// Default: 100. Higher values spread addresses further apart.
    pub coarse_scale: u64,
}

impl Default for SuperpositionDecoder {
    fn default() -> Self {
        Self::new()
    }
}

impl SuperpositionDecoder {
    /// Create a decoder with default coarse scale (100).
    #[inline]
    pub fn new() -> Self {
        Self { coarse_scale: 100 }
    }

    /// Create a decoder with a custom coarse scale for GapFill.
    #[inline]
    pub fn with_scale(coarse_scale: u64) -> Self {
        Self { coarse_scale }
    }

    /// Decode a 10-bit slot value through the given context lens.
    ///
    /// Bits [9:5] → index `a` (high axis).
    /// Bits [4:0] → index `b` (low axis).
    ///
    /// Both indices must be < 32 or this will panic in debug, wrap in release.
    #[inline]
    pub fn decode(&self, ten_bit_val: u16, context: DecodeContext) -> DecodeResult {
        let a = ((ten_bit_val >> 5) & 0x1F) as usize;
        let b = (ten_bit_val & 0x1F) as usize;

        let f_a = FIB[a];
        let f_b = FIB[b];

        match context {
            DecodeContext::Magnitude => {
                DecodeResult::Magnitude(f_a.saturating_mul(f_b))
            }
            DecodeContext::Directionality => {
                DecodeResult::Directionality(f_a as f64 / f_b as f64)
            }
            DecodeContext::Band => {
                DecodeResult::Band((a + b) as u16)
            }
            DecodeContext::Asymmetry => {
                DecodeResult::Asymmetry(a as i16 - b as i16)
            }
            DecodeContext::GapFill => {
                DecodeResult::GapFill(f_b.saturating_mul(self.coarse_scale).saturating_add(f_a))
            }
            DecodeContext::FullManifold => {
                DecodeResult::FullManifold(ManifoldState {
                    magnitude: f_a.saturating_mul(f_b),
                    directionality: f_a as f64 / f_b as f64,
                    band: (a + b) as u16,
                    asymmetry: a as i16 - b as i16,
                    exact_address: f_b.saturating_mul(self.coarse_scale).saturating_add(f_a),
                    a: a as u8,
                    b: b as u8,
                })
            }
            DecodeContext::Flat => {
                DecodeResult::Flat(ten_bit_val)
            }
        }
    }

    /// Decode all seven lenses at once.
    ///
    /// Convenience wrapper around `FullManifold` + `Flat`.
    #[inline]
    pub fn full_decode(&self, ten_bit_val: u16) -> (ManifoldState, u16) {
        let state = match self.decode(ten_bit_val, DecodeContext::FullManifold) {
            DecodeResult::FullManifold(s) => s,
            _ => unreachable!(),
        };
        (state, ten_bit_val)
    }

    /// Quick magnitude — no enum wrapping overhead in hot paths.
    #[inline(always)]
    pub fn magnitude(&self, ten_bit_val: u16) -> u64 {
        let a = ((ten_bit_val >> 5) & 0x1F) as usize;
        let b = (ten_bit_val & 0x1F) as usize;
        FIB[a].saturating_mul(FIB[b])
    }

    /// Quick band — no enum wrapping.
    #[inline(always)]
    pub fn band(&self, ten_bit_val: u16) -> u16 {
        let a = ((ten_bit_val >> 5) & 0x1F) as usize;
        let b = (ten_bit_val & 0x1F) as usize;
        (a + b) as u16
    }

    /// Quick asymmetry — no enum wrapping.
    #[inline(always)]
    pub fn asymmetry(&self, ten_bit_val: u16) -> i16 {
        let a = ((ten_bit_val >> 5) & 0x1F) as usize;
        let b = (ten_bit_val & 0x1F) as usize;
        a as i16 - b as i16
    }

    /// Semantic similarity between two slot values using cosine-inspired band proximity.
    ///
    /// Returns a score in [0.0, 1.0]. Higher = more similar frequency band.
    #[inline]
    pub fn band_similarity(&self, a_val: u16, b_val: u16) -> f64 {
        let band_a = self.band(a_val) as f64;
        let band_b = self.band(b_val) as f64;
        let max_band = 62.0_f64; // maximum possible: a=31, b=31
        1.0 - (band_a - band_b).abs() / max_band
    }

    /// Magnitude ratio between two slot values.
    ///
    /// Returns the ratio `magnitude(a) / magnitude(b)`.
    /// Values near 1.0 indicate similar semantic weight.
    #[inline]
    pub fn magnitude_ratio(&self, a_val: u16, b_val: u16) -> f64 {
        let ma = self.magnitude(a_val) as f64;
        let mb = self.magnitude(b_val) as f64;
        if mb == 0.0 { return f64::INFINITY; }
        ma / mb
    }

    /// Positional interference: spatial resonance between hash address and slot value.
    ///
    /// Computes the harmonic resonance between WHERE a triple lives in the carousel
    /// (encoded in the hash address) and WHAT it contains (encoded in the slot value).
    ///
    /// This is the third layer that neither address nor value contains alone:
    ///   - `address_meaning = magnitude((address % 1024) as u16)` — where in Fibonacci space
    ///   - `value_meaning = magnitude(value)` — what in Fibonacci space
    ///   - `interference = address_meaning × value_meaning` — their harmonic product
    ///
    /// Triples with high positional interference are "perfect memories" — they have
    /// natural resonance between their position and their content. These should rise
    /// to the top during synthesis (via Fibonacci sampling weights).
    ///
    /// # Arguments
    ///   - `address`: Hash table memory address or position (u64)
    ///   - `value`: Slot value (u16) to compare against
    ///
    /// # Returns
    ///   - Interference score: `u64` product of both magnitudes, saturating on overflow
    ///
    /// # Example
    /// ```rust
    /// use carousel_hash::superposition_decoder::SuperpositionDecoder;
    ///
    /// let dec = SuperpositionDecoder::new();
    /// let hash_address: u64 = 12345;
    /// let slot_value: u16 = 0b01101_10011; // a=13, b=19
    ///
    /// let resonance = dec.interference(hash_address, slot_value);
    /// // Higher resonance = better "memory fit" at this position
    /// ```
    #[inline]
    pub fn interference(&self, address: u64, value: u16) -> u64 {
        // Extract positional component: fold address into 10-bit space
        let addr_slot = (address % 1024) as u16;
        
        // Get magnitude of positional component
        let addr_mag = self.magnitude(addr_slot);
        
        // Get magnitude of value component
        let value_mag = self.magnitude(value);
        
        // Interference is their product — harmonic resonance
        addr_mag.saturating_mul(value_mag)
    }
}

// ============================================================================
// UTILITY: Pack two 5-bit indices into a 10-bit slot value
// ============================================================================

/// Pack two 5-bit indices into a 10-bit slot value.
///
/// Both `a` and `b` must be in [0, 31].
#[inline(always)]
pub fn pack_slot(a: u8, b: u8) -> u16 {
    debug_assert!(a < 32, "a must be < 32, got {}", a);
    debug_assert!(b < 32, "b must be < 32, got {}", b);
    ((a as u16) << 5) | (b as u16)
}

/// Unpack a 10-bit slot value into (a, b) 5-bit indices.
#[inline(always)]
pub fn unpack_slot(val: u16) -> (u8, u8) {
    (((val >> 5) & 0x1F) as u8, (val & 0x1F) as u8)
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fib_starts_at_two_three() {
        assert_eq!(FIB[0], 2);
        assert_eq!(FIB[1], 3);
        assert_eq!(FIB[2], 5);
        assert_eq!(FIB[3], 8);
    }

    #[test]
    fn fib_no_identity_collapse() {
        // F(0)*F(0) must not be zero
        assert_ne!(FIB[0].saturating_mul(FIB[0]), 0);
    }

    #[test]
    fn pack_unpack_roundtrip() {
        for a in 0u8..32 {
            for b in 0u8..32 {
                let packed = pack_slot(a, b);
                let (ra, rb) = unpack_slot(packed);
                assert_eq!((ra, rb), (a, b));
            }
        }
    }

    #[test]
    fn magnitude_lens() {
        let dec = SuperpositionDecoder::new();
        let slot = pack_slot(0, 0); // F(0)*F(0) = 2*2 = 4
        assert_eq!(dec.magnitude(slot), 4);

        let slot2 = pack_slot(1, 1); // F(1)*F(1) = 3*3 = 9
        assert_eq!(dec.magnitude(slot2), 9);
    }

    #[test]
    fn band_lens() {
        let dec = SuperpositionDecoder::new();
        let slot = pack_slot(10, 5);
        if let DecodeResult::Band(b) = dec.decode(slot, DecodeContext::Band) {
            assert_eq!(b, 15);
        } else {
            panic!("Expected Band result");
        }
    }

    #[test]
    fn asymmetry_lens() {
        let dec = SuperpositionDecoder::new();
        let slot = pack_slot(10, 5);
        assert_eq!(dec.asymmetry(slot), 5); // 10 - 5

        let slot2 = pack_slot(3, 7);
        assert_eq!(dec.asymmetry(slot2), -4); // 3 - 7
    }

    #[test]
    fn full_manifold() {
        let dec = SuperpositionDecoder::new();
        let slot = pack_slot(2, 3); // a=2→F=5, b=3→F=8
        if let DecodeResult::FullManifold(m) = dec.decode(slot, DecodeContext::FullManifold) {
            assert_eq!(m.magnitude, 5 * 8);   // 40
            assert_eq!(m.band, 5);             // 2 + 3
            assert_eq!(m.asymmetry, -1);       // 2 - 3
            assert_eq!(m.a, 2);
            assert_eq!(m.b, 3);
        } else {
            panic!("Expected FullManifold");
        }
    }

    #[test]
    fn flat_passthrough() {
        let dec = SuperpositionDecoder::new();
        let raw: u16 = 0b01101_10011; // 435
        if let DecodeResult::Flat(v) = dec.decode(raw, DecodeContext::Flat) {
            assert_eq!(v, 435);
        } else {
            panic!("Expected Flat result");
        }
    }

    #[test]
    fn band_similarity_same_slot() {
        let dec = SuperpositionDecoder::new();
        let slot = pack_slot(5, 10);
        assert!((dec.band_similarity(slot, slot) - 1.0).abs() < 1e-9);
    }

    #[test]
    fn example_from_docs() {
        // The exact same 10-bit pattern from the original proposal: 01101_10011 = 435
        let dec = SuperpositionDecoder::new();
        let slot_data: u16 = 0b01101_10011; // a=13, b=19

        let weight = dec.magnitude(slot_data);
        assert!(weight > 0, "weight must be non-zero");

        if let DecodeResult::Directionality(dir) = dec.decode(slot_data, DecodeContext::Directionality) {
            assert!(dir > 0.0);
        }

        if let DecodeResult::FullManifold(m) = dec.decode(slot_data, DecodeContext::FullManifold) {
            assert_eq!(m.a, 13);
            assert_eq!(m.b, 19);
            assert_eq!(m.band, 32);
        }
    }

    #[test]
    fn positional_interference_basic() {
        let dec = SuperpositionDecoder::new();
        let slot = pack_slot(5, 8); // F(5)*F(8) = 13*34 = 442

        // Address that folds to slot (5, 8)
        let address_resonant = 0x58; // 88 % 1024 = 88, packs to something
        let interference = dec.interference(address_resonant, slot);

        // Interference should be non-zero and > either individual magnitude
        assert!(interference > 0, "interference must be positive");
        assert!(interference >= dec.magnitude(slot), "resonance should boost magnitude");
    }

    #[test]
    fn interference_perfect_resonance() {
        let dec = SuperpositionDecoder::new();
        
        // Same slot value used for both address and value → perfect resonance
        let slot = pack_slot(3, 7); // F(3)*F(7) = 8*21 = 168
        let address_same = slot as u64;
        
        let interference = dec.interference(address_same, slot);
        let individual_mag = dec.magnitude(slot);
        
        // Perfect resonance: mag(address) * mag(value) = 168 * 168 = 28224
        assert_eq!(interference, individual_mag.saturating_mul(individual_mag));
    }

    #[test]
    fn interference_comparison() {
        let dec = SuperpositionDecoder::new();
        let slot1 = pack_slot(2, 3);
        let slot2 = pack_slot(10, 15);
        
        let addr = 5000u64;
        
        let i1 = dec.interference(addr, slot1);
        let i2 = dec.interference(addr, slot2);
        
        // Both should have positive interference
        assert!(i1 > 0);
        assert!(i2 > 0);
        
        // Higher value magnitude should yield higher interference
        // (since address component is the same)
        if dec.magnitude(slot2) > dec.magnitude(slot1) {
            assert!(i2 > i1);
        }
    }
}
