//! # Synsets
//!
//! Synonym group management. Each group gets a stable integer ID.
//! Words can belong to only one synset (first-writer wins) to prevent
//! megamerge cascades where every word ends up in the same set.
//!
//! File format: one comma-separated synonym group per line (Moby-style).
//! Example: "canine,dog,hound,pooch,mutt"

use std::collections::{HashMap, HashSet};
use std::io::{BufRead, BufReader, Write, BufWriter};
use std::fs::File;
use std::path::Path;

/// Core synset store.
/// `word_to_synset`: word → synset_id
/// `synset_to_words`: synset_id → {words}
#[derive(Debug, Clone, Default)]
pub struct Synsets {
    pub word_to_synset: HashMap<String, u32>,
    pub synset_to_words: HashMap<u32, HashSet<String>>,
    next_id: u32,
}

impl Synsets {
    pub fn new() -> Self {
        Self::default()
    }

    /// Add a synonym group. Returns the new synset_id, or u32::MAX if skipped.
    /// First-writer wins: words already assigned to a synset are NOT moved.
    pub fn add_group(&mut self, words: &[&str]) -> u32 {
        let clean: Vec<String> = words
            .iter()
            .map(|w| w.trim().to_lowercase())
            .filter(|w| !w.is_empty())
            .collect();

        if clean.len() < 2 {
            return u32::MAX;
        }

        let syn_id = self.next_id;
        self.next_id += 1;

        for w in &clean {
            if !self.word_to_synset.contains_key(w) {
                self.word_to_synset.insert(w.clone(), syn_id);
                self.synset_to_words
                    .entry(syn_id)
                    .or_insert_with(HashSet::new)
                    .insert(w.clone());
            }
        }
        syn_id
    }

    /// Add an owned-string group (convenience wrapper).
    pub fn add_group_owned(&mut self, words: &[String]) -> u32 {
        let refs: Vec<&str> = words.iter().map(|s| s.as_str()).collect();
        self.add_group(&refs)
    }

    /// Get all synonyms for a word (including itself).
    /// Returns a set containing just the word if it has no synset.
    pub fn expand(&self, word: &str) -> HashSet<String> {
        let w = word.trim().to_lowercase();
        if let Some(&sid) = self.word_to_synset.get(&w) {
            if let Some(set) = self.synset_to_words.get(&sid) {
                return set.clone();
            }
        }
        let mut s = HashSet::new();
        s.insert(w);
        s
    }

    /// Expand a collection of words with all their synonyms.
    pub fn expand_words<'a, I>(&self, words: I) -> HashSet<String>
    where
        I: IntoIterator<Item = &'a str>,
    {
        let mut out = HashSet::new();
        for w in words {
            out.extend(self.expand(w));
        }
        out
    }

    /// Load synsets from a comma-separated file (Moby-style, one group per line).
    /// Returns number of groups loaded.
    pub fn load_from_file(&mut self, path: impl AsRef<Path>) -> std::io::Result<usize> {
        let file = File::open(path)?;
        let reader = BufReader::new(file);
        let mut count = 0;

        for line in reader.lines() {
            let line = line?;
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let parts: Vec<&str> = line.split(',').map(|s| s.trim()).filter(|s| !s.is_empty()).collect();
            if parts.len() >= 2 {
                self.add_group(&parts);
                count += 1;
            }
        }
        Ok(count)
    }

    /// Save synsets to a JSON file.
    pub fn save_json(&self, path: impl AsRef<Path>) -> std::io::Result<()> {
        let file = File::create(path)?;
        let mut w = BufWriter::new(file);
        writeln!(w, "{{")?;
        writeln!(w, "  \"next_id\": {},", self.next_id)?;
        writeln!(w, "  \"groups\": [")?;
        let ids: Vec<u32> = {
            let mut v: Vec<u32> = self.synset_to_words.keys().copied().collect();
            v.sort();
            v
        };
        for (i, id) in ids.iter().enumerate() {
            let words: Vec<String> = {
                let mut v: Vec<String> = self.synset_to_words[id].iter().cloned().collect();
                v.sort();
                v
            };
            let encoded: Vec<String> = words.iter().map(|w| format!("\"{}\"", w)).collect();
            let comma = if i + 1 < ids.len() { "," } else { "" };
            writeln!(w, "    [{}]{}", encoded.join(","), comma)?;
        }
        writeln!(w, "  ]")?;
        writeln!(w, "}}")?;
        Ok(())
    }

    /// Merge another Synsets store into this one (first-writer wins).
    pub fn merge(&mut self, other: &Synsets) {
        for (_, words) in &other.synset_to_words {
            let refs: Vec<&str> = words.iter().map(|s| s.as_str()).collect();
            self.add_group(&refs);
        }
    }

    /// Total number of synsets loaded.
    pub fn synset_count(&self) -> usize {
        self.synset_to_words.len()
    }

    /// Total number of indexed words.
    pub fn word_count(&self) -> usize {
        self.word_to_synset.len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_basic_expand() {
        let mut s = Synsets::new();
        s.add_group(&["dog", "canine", "hound"]);
        let expanded = s.expand("dog");
        assert!(expanded.contains("canine"));
        assert!(expanded.contains("hound"));
        assert!(expanded.contains("dog"));
    }

    #[test]
    fn test_first_writer_wins() {
        let mut s = Synsets::new();
        s.add_group(&["dog", "canine"]);
        s.add_group(&["canine", "wolf"]); // "canine" already assigned, won't move
        // "wolf" gets a new synset, "canine" stays with first group
        let dog_syns = s.expand("dog");
        assert!(dog_syns.contains("canine"));
        // wolf is in its own group
        let wolf_syns = s.expand("wolf");
        assert!(wolf_syns.contains("wolf"));
    }

    #[test]
    fn test_expand_unknown_word() {
        let s = Synsets::new();
        let result = s.expand("xyzzy");
        assert!(result.contains("xyzzy"));
        assert_eq!(result.len(), 1);
    }

    #[test]
    fn test_expand_words_multi() {
        let mut s = Synsets::new();
        s.add_group(&["happy", "glad", "joyful"]);
        s.add_group(&["sad", "unhappy", "sorrowful"]);
        let expanded = s.expand_words(["happy", "sad"].iter().copied());
        assert!(expanded.contains("glad"));
        assert!(expanded.contains("unhappy"));
    }
}
