//! # 24-Bit Hash Table (16,777,216 slots)
//!
//! Architecture:
//! - 3-byte (24-bit) address space = 16M slots
//! - Input: raw carousel-encoded bytes (no UTF, no abstraction)
//! - Hash: XOR/multiply chain across encoded bytes
//! - Collision: golden ratio stepping (φ-based linear probing)
//!
//! Slot layout (first 1M reserved for vocabulary):
//! - Slots 0..1_000_000: single words, bigrams, trigrams, phrases
//! - Slots 1_000_000..16_777_216: relational data, program structures
//!
//! Memory: each slot is 32 bytes → total ~512 MB for full table.
//! For lighter usage, use the compact 8-byte-per-slot variant (~128 MB).

use crate::carousel;

/// Total slots in the 24-bit address space.
pub const TABLE_SIZE: usize = 1 << 24; // 16,777,216
pub const TABLE_MASK: u32 = (TABLE_SIZE as u32) - 1;

/// Golden ratio constant for probe stepping.
/// φ = (1 + √5) / 2 ≈ 1.618033988749895
/// We use the integer approximation: floor(2^24 / φ) = 10,368,890
/// This is coprime to 2^24, guaranteeing full table coverage.
pub const GOLDEN_STEP: u32 = 10_368_890;

/// Vocabulary region boundary.
pub const VOCAB_REGION_END: u32 = 1_000_000;

/// Sentinel: end of relation chain (no next link).
pub const CHAIN_END: u32 = u32::MAX;

/// Key prefix for subject-chain head Meta slots.
/// Lookup: [0xFD] + carousel(word) → Meta slot whose value = first relation idx
pub const SUBJECT_HEAD_PREFIX: u8 = 0xFD;

/// Key prefix for object-chain head Meta slots.
/// Lookup: [0xFC] + carousel(word) → Meta slot whose value = first relation idx
pub const OBJECT_HEAD_PREFIX: u8 = 0xFC;

// ============================================================================
// HASH FUNCTION: XOR-multiply chain on carousel bytes
// ============================================================================

/// Primary hash: XOR-multiply-shift chain.
/// Takes raw carousel-encoded bytes and produces a 24-bit index.
///
/// This is the hot path. Every nanosecond counts.
#[inline(always)]
pub fn hash_carousel(bytes: &[u8]) -> u32 {
    // Seed prevents zero-lock and adds initial entropy
    let mut h: u64 = 0x517cc1b727220a95; // large prime seed

    for &b in bytes {
        // XOR the byte in, multiply by a prime, fold
        h ^= b as u64;
        h = h.wrapping_mul(0x2545F4914F6CDD1D); // 64-bit prime
        h ^= h >> 17;
    }

    // Final mix to ensure good distribution across 24 bits
    h ^= h >> 13;
    h = h.wrapping_mul(0xC4CEB9FE1A85EC53);
    h ^= h >> 16;

    (h as u32) & TABLE_MASK
}

/// Division chain hash (from your existing code) — alternative hash.
/// Good for short keys. We use this as a secondary hash for double-hashing.
#[inline(always)]
pub fn division_chain_hash(bytes: &[u8]) -> u32 {
    let mut h: u64 = 1;
    for &b in bytes {
        h = (h / (b as u64 + 2)) ^ (b as u64);
    }
    (h as u32) & TABLE_MASK
}

// ============================================================================
// SLOT TYPES
// ============================================================================

/// What kind of entry lives in a slot.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u8)]
pub enum SlotKind {
    Empty = 0,
    Word = 1,      // single word
    Bigram = 2,    // word pair
    Trigram = 3,   // word triplet
    Phrase = 4,    // multi-word phrase
    Relation = 5,  // relational data (subject-verb-object triple)
    Code = 6,      // programming structure
    Meta = 7,      // metadata / index entry
}

impl SlotKind {
    /// Convert a u8 to a SlotKind enum value.
    #[inline]
    pub fn from_u8(value: u8) -> Option<Self> {
        match value {
            0 => Some(SlotKind::Empty),
            1 => Some(SlotKind::Word),
            2 => Some(SlotKind::Bigram),
            3 => Some(SlotKind::Trigram),
            4 => Some(SlotKind::Phrase),
            5 => Some(SlotKind::Relation),
            6 => Some(SlotKind::Code),
            7 => Some(SlotKind::Meta),
            _ => None,
        }
    }
}

/// 100+ semantic relation types for transforming knowledge.
/// These are encoded in the padding bytes of Slot structures.
/// Each opcode (u16) represents a different transformation or semantic relationship.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u16)]
#[allow(non_camel_case_types)]
pub enum RelationType {
    // Identity relations (0x00xx)
    IS = 0x0001,
    IS_A = 0x0002,
    IS_NOT = 0x0003,
    IS_SAME_AS = 0x0004,
    IS_DIFFERENT_FROM = 0x0005,
    
    // Capability relations (0x01xx)
    CAN = 0x0110,
    CAN_BE = 0x0111,
    CAN_NOT = 0x0112,
    ABLE_TO = 0x0113,
    CAPABLE_OF = 0x0114,
    
    // Possession relations (0x02xx)
    HAS = 0x0220,
    HAS_A = 0x0221,
    HAS_NOT = 0x0222,
    OWNS = 0x0223,
    POSSESSES = 0x0224,
    
    // Location relations (0x03xx)
    IS_IN = 0x0330,
    IS_ON = 0x0331,
    IS_UNDER = 0x0332,
    IS_NEAR = 0x0333,
    IS_AT = 0x0334,
    IS_BETWEEN = 0x0335,
    
    // Action relations (0x04xx)
    DOES = 0x0440,
    DID = 0x0441,
    WILL_DO = 0x0442,
    ACTION = 0x0443,
    PERFORMED = 0x0444,
    
    // Attribute relations (0x05xx)
    HAS_ATTRIBUTE = 0x0550,
    HAS_PROPERTY = 0x0551,
    HAS_QUALITY = 0x0552,
    IS_DESCRIBED_BY = 0x0553,
    IS_CHARACTERIZED_BY = 0x0554,
    
    // Comparison relations (0x06xx)
    EQUALS = 0x0660,
    GREATER_THAN = 0x0661,
    LESS_THAN = 0x0662,
    SIMILAR_TO = 0x0663,
    OPPOSITE_OF = 0x0664,
    LIKE = 0x0665,
    
    // Causal relations (0x07xx)
    CAUSES = 0x0770,
    CAUSED_BY = 0x0771,
    BECAUSE = 0x0772,
    PREVENTS = 0x0775,
    ENABLES = 0x0776,
    REQUIRES = 0x0777,
    EFFECT_OF = 0x0773,
    REASON_FOR = 0x0774,
    
    // Part-whole relations (0x08xx)
    PART_OF = 0x0880,
    CONTAINS = 0x0881,
    MADE_OF = 0x0882,
    COMPONENT_OF = 0x0883,
    INCLUDES = 0x0884,
    
    // Family relations (0x09xx)
    PARENT_OF = 0x0990,
    CHILD_OF = 0x0991,
    SIBLING_OF = 0x0992,
    SPOUSE_OF = 0x0993,
    RELATED_TO = 0x0994,
    DESCENDANT_OF = 0x0995,
    
    // Temporal relations (0x0Axx)
    BEFORE = 0x0AA0,
    AFTER = 0x0AA1,
    DURING = 0x0AA2,
    CONCURRENT_WITH = 0x0AA3,
    PRECEDES = 0x0AA4,
    FOLLOWS = 0x0AA5,
    
    // Purpose relations (0x0Bxx)
    PURPOSE_OF = 0x0BB0,
    GOAL_OF = 0x0BB1,
    MEANS_FOR = 0x0BB2,
    INTENDED_FOR = 0x0BB3,
    
    // Role relations (0x0Cxx)
    ROLE_OF = 0x0CC0,
    FUNCTION_OF = 0x0CC1,
    AGENT_IN = 0x0CC2,
    PATIENT_OF = 0x0CC3,
    INSTRUMENT_FOR = 0x0CC4,
    
    // Source/Medium relations (0x0Dxx)
    ORIGIN_OF = 0x0DD0,
    SOURCE_OF = 0x0DD1,
    DERIVED_FROM = 0x0DD2,
    MEDIUM_FOR = 0x0DD3,
    
    // Knowledge relations (0x0Exx)
    KNOWS = 0x0EE0,
    BELIEVES = 0x0EE1,
    THINKS = 0x0EE2,
    UNDERSTANDS = 0x0EE3,
    AWARE_OF = 0x0EE4,
    
    // Association relations (0x0Fxx)
    ASSOCIATED_WITH = 0x0FF0,
    RELATED_BY = 0x0FF1,
    LINKED_TO = 0x0FF2,
    CONNECTED_TO = 0x0FF3,
    CORRELATED_WITH = 0x0FF4,
    
    // Negation and uncertainty (0x10xx)
    NOT = 0x1010,
    MAYBE = 0x1011,
    POSSIBLY = 0x1012,
    LIKELY = 0x1013,
    UNCERTAIN = 0x1014,
    
    // IS-domain modifiers (0x11xx) — what follows IS collapses the superposition
    IS_SOMETIMES    = 0x1110,  // "X is sometimes Y"       — frequency domain
    IS_NORMATIVE    = 0x1111,  // "X should/ought to be Y" — normative domain
    IS_QUALIFIED    = 0x1112,  // "True X is Y"            — scoped subject
    IS_CONDITIONAL  = 0x1113,  // "X is when Y"            — conditional definition
    IS_ATTRIBUTED   = 0x1114,  // "X is described as Y"    — cited, not owned
    IS_INTENSITY    = 0x1115,  // "X is such a Y"          — intensified attribution

    // Constraint/conflict operators (0x12xx)
    BUT             = 0x1210,  // constraint injection: [intention] BUT [blocker]
    DESPITE         = 0x1211,  // constraint override: intention wins despite constraint
    UNLESS          = 0x1212,  // conditional blocker
    ALTHOUGH        = 0x1213,  // acknowledged contradiction

    // Equivalence/binding (0x13xx)
    OR_SYNONYM      = 0x1310,  // "X or Y" — bind as interchangeable before predicate
    EITHER_OR       = 0x1311,  // exclusive choice
    NEITHER_NOR     = 0x1312,  // joint negation

    // Emotional/motivational operators (0x14xx)
    FEELS           = 0x1410,
    FEARS           = 0x1411,
    HOPES           = 0x1412,
    CARES           = 0x1413,
    RESENTS         = 0x1414,

    // Extended causal (0x15xx)
    LEADS_TO        = 0x1510,  // indirect causation (multi-hop)
    TRIGGERS        = 0x1511,  // event-driven causation
    
    // Special markers (0xFFxx)
    UNKNOWN = 0xFFFF,
}

/// Relation types walk_transitive should follow when no caller-specific
/// filter is given -- i.e. "reason across anything that behaves like
/// an is-a / has-a / can chain." Deliberately excludes IS_NOT/CAN_NOT/
/// HAS_NOT and other negations, since a BFS that walks through a
/// negated edge as if it were a positive one would silently invert
/// meaning mid-chain. Extend this list as new relation families prove
/// safe to chain through; do not just default to "every variant."
pub const ALL_REASONING_TYPES: [RelationType; 14] = [
    RelationType::IS,
    RelationType::IS_A,
    RelationType::IS_SAME_AS,
    RelationType::CAN,
    RelationType::CAN_BE,
    RelationType::ABLE_TO,
    RelationType::CAPABLE_OF,
    RelationType::HAS,
    RelationType::HAS_A,
    RelationType::OWNS,
    RelationType::POSSESSES,
    RelationType::PART_OF,
    RelationType::CAUSES,
    RelationType::LEADS_TO,
];

/// Which domain IS collapsed into based on what follows it.
/// IS is a superposition operator; the token(s) after it select the domain.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IsDomain {
    Definition,    // "X is Y"              — plain noun phrase
    Comparison,    // "X is like Y"
    Negation,      // "X is not Y"
    Frequency,     // "X is sometimes Y"
    Conditional,   // "X is when Y"
    Normative,     // "X should/ought be Y"
    Attribution,   // "X is described as Y"
    Modal,         // "X could/might be Y"
    Functional,    // "X is for Y"
    Causal,        // "X is why Y"
    Equivalence,   // "X or Y" — OR binding before predicate fires
    Consequence,   // "X is harmful" — outcome/result asserted
    Identity,      // uncollapsed raw IS (default)
}

/// How the assertion is made — orthogonal to what it asserts.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AssertionModality {
    Asserted,      // "X is Y"
    Questioned,    // "Is X Y?"
    Conditional,   // "If X is Y"
    Hypothetical,  // "X would be Y"
    Negated,       // "X is not Y"
}

/// Weight vector for IS-family conjugation members.
/// Each member of the IS family carries its own certainty + obligation.
#[derive(Debug, Clone, Copy)]
pub struct ConjugationWeights {
    pub certainty:       f32,   // 0.0–1.0
    pub obligation:      f32,   // 0.0–1.0
    pub temporal_offset: i8,    // -1 = past, 0 = present, +1 = future
}

/// Lookup table for IS-family members.
/// These ARE IS — conjugated, not combined.
pub const CONJUGATION_TABLE: &[(&str, ConjugationWeights)] = &[
    ("is",     ConjugationWeights { certainty: 1.0, obligation: 0.0, temporal_offset:  0 }),
    ("are",    ConjugationWeights { certainty: 1.0, obligation: 0.0, temporal_offset:  0 }),
    ("was",    ConjugationWeights { certainty: 1.0, obligation: 0.0, temporal_offset: -1 }),
    ("were",   ConjugationWeights { certainty: 1.0, obligation: 0.0, temporal_offset: -1 }),
    ("will",   ConjugationWeights { certainty: 0.8, obligation: 0.0, temporal_offset:  1 }),
    ("must",   ConjugationWeights { certainty: 1.0, obligation: 1.0, temporal_offset:  0 }),
    ("should", ConjugationWeights { certainty: 0.8, obligation: 0.7, temporal_offset:  0 }),
    ("ought",  ConjugationWeights { certainty: 0.8, obligation: 0.9, temporal_offset:  0 }),
    ("could",  ConjugationWeights { certainty: 0.5, obligation: 0.0, temporal_offset:  0 }),
    ("might",  ConjugationWeights { certainty: 0.3, obligation: 0.0, temporal_offset:  0 }),
    ("can",    ConjugationWeights { certainty: 0.9, obligation: 0.0, temporal_offset:  0 }),
];

/// Look up conjugation weights for a copula token.
/// Returns IS (certainty 1.0) as the default if token not recognized.
pub fn conjugation_weights(token: &str) -> ConjugationWeights {
    let lower = token.to_lowercase();
    CONJUGATION_TABLE.iter()
        .find(|(t, _)| *t == lower.as_str())
        .map(|(_, w)| *w)
        .unwrap_or(ConjugationWeights { certainty: 1.0, obligation: 0.0, temporal_offset: 0 })
}

/// TransformParams: metadata for semantic transformations.
/// Packed into the 8 padding bytes of a Slot.
///
/// Layout (8 bytes total):
/// - opcode (2 bytes): RelationType
/// - confidence (1 byte): 0-255 representing confidence 0.0-1.0
/// - propagation_depth (1 byte): max hops for transitive inference
/// - flags (2 bytes): inheritable, temporal, derived, etc.
/// - reserved (2 bytes): for future use
#[derive(Clone, Copy, Debug)]
#[repr(C)]
pub struct TransformParams {
    pub opcode: u16,                // RelationType as u16
    pub confidence: u8,             // 0-255 confidence score
    pub propagation_depth: u8,      // 0-255 hops for transitive relations
    pub flags: u16,                 // bit flags
}

impl Default for TransformParams {
    fn default() -> Self {
        Self {
            opcode: RelationType::UNKNOWN as u16,
            confidence: 255,        // high confidence by default
            propagation_depth: 0,   // not propagated by default
            flags: 0,
        }
    }
}

impl TransformParams {
    /// Create new transform params with given opcode
    pub fn new(opcode: RelationType) -> Self {
        Self {
            opcode: opcode as u16,
            confidence: 255,
            propagation_depth: 0,
            flags: 0,
        }
    }
    
    /// Set confidence (0-255)
    pub fn with_confidence(mut self, conf: u8) -> Self {
        self.confidence = conf;
        self
    }
    
    /// Set propagation depth for transitive inference
    pub fn with_propagation(mut self, depth: u8) -> Self {
        self.propagation_depth = depth;
        self
    }
    
    /// Mark as inheritable (for subclass inference)
    pub fn mark_inheritable(mut self) -> Self {
        self.flags |= 0x0001;
        self
    }
    
    /// Mark as temporal (time-dependent)
    pub fn mark_temporal(mut self) -> Self {
        self.flags |= 0x0002;
        self
    }
    
    /// Mark as derived (inferred, not explicit)
    pub fn mark_derived(mut self) -> Self {
        self.flags |= 0x0004;
        self
    }
    
    pub fn is_inheritable(&self) -> bool {
        self.flags & 0x0001 != 0
    }
    
    pub fn is_temporal(&self) -> bool {
        self.flags & 0x0002 != 0
    }
    
    pub fn is_derived(&self) -> bool {
        self.flags & 0x0004 != 0
    }
}

// ============================================================================
// RELATION DATA: packed subject/object indices + metadata in value field
// ============================================================================

/// Packed relation metadata stored in a Relation slot's `value` field.
///
/// Layout (64 bits):
/// - bits  0..23: subject slot index (24-bit, max 16M)
/// - bits 24..47: object slot index (24-bit, max 16M)
/// - bits 48..55: confidence (0-255)
/// - bits 56..63: propagation depth (0-255 hops)
///
/// Both endpoints live right in the slot. No external index.
/// Follow the chain, read the data, done.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RelationData {
    pub subject_idx: u32,
    pub object_idx: u32,
    pub confidence: u8,
    pub propagation_depth: u8,
}

impl RelationData {
    /// Pack into a u64 for storage in Slot.value
    #[inline(always)]
    pub fn pack(&self) -> u64 {
        (self.subject_idx as u64 & 0x00FF_FFFF)
            | ((self.object_idx as u64 & 0x00FF_FFFF) << 24)
            | ((self.confidence as u64) << 48)
            | ((self.propagation_depth as u64) << 56)
    }

    /// Unpack from a Slot.value u64
    #[inline(always)]
    pub fn unpack(value: u64) -> Self {
        Self {
            subject_idx: (value & 0x00FF_FFFF) as u32,
            object_idx: ((value >> 24) & 0x00FF_FFFF) as u32,
            confidence: ((value >> 48) & 0xFF) as u8,
            propagation_depth: ((value >> 56) & 0xFF) as u8,
        }
    }
}

/// Compact slot: 40 bytes per entry (with alignment padding).
///
/// Layout:
/// - kind (1 byte): SlotKind
/// - key_len (1 byte): length of the carousel-encoded key
/// - padding (2 bytes): reserved for future use (transformation opcodes)
/// - key (16 bytes): carousel-encoded key (up to 16 chars)
/// - value (8 bytes): payload — can be a u64 position, pointer, packed data
/// - next_pos (4 bytes): position of next token (for generative chains)
/// - score (2 bytes): frequency/importance score (f16-style or just u16)
/// - padding (6 bytes): available for TransformParams
///
/// Total: 40 bytes with proper alignment. The 8 padding bytes (2+6) can hold
/// transformation opcode metadata.
#[derive(Clone, Copy)]
#[repr(C)]
pub struct Slot {
    pub kind: u8,
    pub key_len: u8,
    pub _reserved: [u8; 2],  // Reserved for transformation opcodes
    pub key: [u8; 16],
    pub value: u64,
    pub next_pos: u32,
    pub score: u16,
    pub _padding: [u8; 6],   // Additional padding for future use (TransformParams)
}

impl Default for Slot {
    fn default() -> Self {
        Self {
            kind: SlotKind::Empty as u8,
            key_len: 0,
            _reserved: [0u8; 2],
            key: [0u8; 16],
            value: 0,
            next_pos: 0,
            score: 0,
            _padding: [0u8; 6],
        }
    }
}

impl Slot {
    #[inline(always)]
    pub fn is_empty(&self) -> bool {
        self.kind == SlotKind::Empty as u8
    }

    #[inline(always)]
    pub fn key_matches(&self, needle: &[u8]) -> bool {
        let stored_len = self.key_len as usize;
        let needle_len = needle.len().min(16);
        if stored_len != needle_len {
            return false;
        }
        // Compare bytes directly — no string operations
        self.key[..stored_len] == needle[..needle_len]
    }
    
    /// Get transformation parameters from the padding bytes.
    /// The first 8 bytes (_reserved[2] + _padding[6]) hold TransformParams.
    #[inline]
    pub fn get_transform(&self) -> TransformParams {
        // Read opcode from _reserved (2 bytes)
        let opcode = u16::from_le_bytes([
            self._reserved[0],
            self._reserved[1],
        ]);
        
        // Read confidence, propagation_depth, flags from _padding
        let confidence = self._padding[0];
        let propagation_depth = self._padding[1];
        let flags = u16::from_le_bytes([
            self._padding[2],
            self._padding[3],
        ]);
        
        TransformParams {
            opcode,
            confidence,
            propagation_depth,
            flags,
        }
    }
    
    /// Set transformation parameters into the padding bytes.
    /// NOTE: For Relation slots, prefer the chain-threaded accessors below.
    #[inline]
    pub fn set_transform(&mut self, params: TransformParams) {
        let opcode_bytes = params.opcode.to_le_bytes();
        self._reserved[0] = opcode_bytes[0];
        self._reserved[1] = opcode_bytes[1];
        self._padding[0] = params.confidence;
        self._padding[1] = params.propagation_depth;
        let flags_bytes = params.flags.to_le_bytes();
        self._padding[2] = flags_bytes[0];
        self._padding[3] = flags_bytes[1];
    }

    // ================================================================
    // Chain-threaded relation accessors
    // ================================================================
    // For Relation slots, the padding bytes are repurposed:
    //   next_pos        → next_by_subject (next relation with same subject)
    //   _padding[0..4]  → next_by_object  (next relation with same object)
    //   _padding[4..6]  → relation flags
    //   _reserved[0..2] → RelationType opcode (same as TransformParams)
    //   value           → packed RelationData (subject_idx, object_idx, confidence, propagation)
    // ================================================================

    /// For Relation slots: next relation with the same subject.
    /// Stored in `next_pos`. Returns CHAIN_END if end of chain.
    #[inline(always)]
    pub fn next_by_subject(&self) -> u32 {
        self.next_pos
    }

    /// For Relation slots: set the next-by-subject chain pointer.
    #[inline(always)]
    pub fn set_next_by_subject(&mut self, idx: u32) {
        self.next_pos = idx;
    }

    /// For Relation slots: next relation with the same object.
    /// Stored in `_padding[0..4]`. Returns CHAIN_END if end of chain.
    #[inline(always)]
    pub fn next_by_object(&self) -> u32 {
        u32::from_le_bytes([
            self._padding[0], self._padding[1],
            self._padding[2], self._padding[3],
        ])
    }

    /// For Relation slots: set the next-by-object chain pointer.
    #[inline(always)]
    pub fn set_next_by_object(&mut self, idx: u32) {
        let b = idx.to_le_bytes();
        self._padding[0] = b[0];
        self._padding[1] = b[1];
        self._padding[2] = b[2];
        self._padding[3] = b[3];
    }

    /// For Relation slots: unpack the RelationData from value.
    #[inline(always)]
    pub fn relation_data(&self) -> RelationData {
        RelationData::unpack(self.value)
    }

    /// For Relation slots: get the RelationType from _reserved.
    #[inline(always)]
    pub fn relation_type(&self) -> RelationType {
        let opcode = u16::from_le_bytes([self._reserved[0], self._reserved[1]]);
        // Safety: RelationType is repr(u16), we only store valid opcodes
        unsafe { std::mem::transmute(opcode) }
    }

    /// For Relation slots: get flags from _padding[4..6].
    #[inline(always)]
    pub fn relation_flags(&self) -> u16 {
        u16::from_le_bytes([self._padding[4], self._padding[5]])
    }

    /// For Relation slots: set flags in _padding[4..6].
    #[inline(always)]
    pub fn set_relation_flags(&mut self, flags: u16) {
        let b = flags.to_le_bytes();
        self._padding[4] = b[0];
        self._padding[5] = b[1];
    }
}

// ============================================================================
// THE TABLE
// ============================================================================

/// The 24-bit hash table. 16M slots with golden ratio probing.
pub struct HashTable24 {
    pub slots: Vec<Slot>,
    pub count: usize,
    pub max_probe_depth: usize, // track worst-case for diagnostics
}

impl HashTable24 {
    /// Allocate the full 16M-slot table.
    /// Memory: 16M × 32 bytes = 512 MB.
    pub fn new() -> Self {
        let mut slots = Vec::with_capacity(TABLE_SIZE);
        slots.resize(TABLE_SIZE, Slot::default());
        Self {
            slots,
            count: 0,
            max_probe_depth: 0,
        }
    }

    /// Allocate a smaller table for testing (e.g., 2^20 = 1M slots = 32 MB).
    pub fn new_sized(bits: u32) -> Self {
        let size = 1usize << bits;
        let mut slots = Vec::with_capacity(size);
        slots.resize(size, Slot::default());
        Self {
            slots,
            count: 0,
            max_probe_depth: 0,
        }
    }

    #[inline(always)]
    fn mask(&self) -> u32 {
        (self.slots.len() as u32) - 1
    }

    #[inline(always)]
    fn golden_step(&self) -> u32 {
        // φ-based step scaled to table size
        // For power-of-2 sizes: floor(size / φ) | 1  (ensure odd for coprimality)
        let size = self.slots.len() as u64;
        let step = (size * 10_368_890 / TABLE_SIZE as u64) as u32;
        step | 1 // ensure odd
    }

    /// Insert a key-value pair. Key is carousel-encoded bytes.
    /// Returns the slot index where it was inserted, or the existing slot if key exists.
    pub fn insert(&mut self, key: &[u8], kind: SlotKind, value: u64, next_pos: u32, score: u16) -> u32 {
        let mask = self.mask();
        let step = self.golden_step();
        let mut idx = hash_carousel(key) & mask;
        let mut probes = 0usize;

        loop {
            let slot = &self.slots[idx as usize];
            if slot.is_empty() {
                // Found empty slot — insert here
                let s = &mut self.slots[idx as usize];
                s.kind = kind as u8;
                s.key_len = key.len().min(16) as u8;
                s.key[..key.len().min(16)].copy_from_slice(&key[..key.len().min(16)]);
                s.value = value;
                s.next_pos = next_pos;
                s.score = score;
                self.count += 1;
                if probes > self.max_probe_depth {
                    self.max_probe_depth = probes;
                }
                return idx;
            }
            if slot.key_matches(key) {
                // Key already exists — update value
                let s = &mut self.slots[idx as usize];
                s.value = value;
                s.next_pos = next_pos;
                s.score = score;
                return idx;
            }
            // Collision — golden ratio step
            idx = (idx.wrapping_add(step)) & mask;
            probes += 1;

            // Safety: if table is full, bail (should never happen at < 80% load)
            if probes > self.slots.len() {
                panic!("Hash table full — cannot insert");
            }
        }
    }

    /// Lookup a key. Returns the slot reference if found.
    /// This is THE hot path. Must be as fast as physically possible.
    #[inline(always)]
    pub fn get(&self, key: &[u8]) -> Option<&Slot> {
        self.get_index(key).map(|idx| &self.slots[idx as usize])
    }

    /// Lookup a key. Returns the slot INDEX if found.
    /// Used by the token stream compressor to encode references.
    #[inline(always)]
    pub fn get_index(&self, key: &[u8]) -> Option<u32> {
        let mask = self.mask();
        let step = self.golden_step();
        let mut idx = hash_carousel(key) & mask;
        let mut probes = 0usize;
        let max_probes = 128;

        loop {
            let slot = unsafe { self.slots.get_unchecked(idx as usize) };
            if slot.is_empty() {
                return None;
            }
            if slot.key_matches(key) {
                return Some(idx);
            }
            idx = (idx.wrapping_add(step)) & mask;
            probes += 1;
            if probes >= max_probes {
                return None;
            }
        }
    }

    /// Lookup returning mutable reference.
    #[inline(always)]
    pub fn get_mut(&mut self, key: &[u8]) -> Option<&mut Slot> {
        let mask = self.mask();
        let step = self.golden_step();
        let mut idx = hash_carousel(key) & mask;
        let mut probes = 0usize;

        loop {
            if probes >= 64 {
                return None;
            }
            if self.slots[idx as usize].is_empty() {
                return None;
            }
            if self.slots[idx as usize].key_matches(key) {
                return Some(&mut self.slots[idx as usize]);
            }
            idx = (idx.wrapping_add(step)) & mask;
            probes += 1;
        }
    }

    /// Convenience: insert a word with automatic carousel encoding.
    pub fn insert_word(&mut self, word: &str, value: u64) -> u32 {
        let encoded = carousel::encode_string(word);
        self.insert(&encoded, SlotKind::Word, value, 0, 1)
    }

    /// Convenience: lookup a word with automatic carousel encoding.
    #[inline]
    pub fn get_word(&self, word: &str) -> Option<&Slot> {
        let mut buf = [0u8; 64];
        let len = carousel::encode_string_fixed(word, &mut buf);
        self.get(&buf[..len])
    }

    /// Lookup a word, returning the slot INDEX.
    #[inline]
    pub fn get_word_index(&self, word: &str) -> Option<u32> {
        let mut buf = [0u8; 64];
        let len = carousel::encode_string_fixed(word, &mut buf);
        self.get_index(&buf[..len])
    }

    /// Radial lookup: probe `radius` bins on either side of the hash-address
    /// computed for `word` using a selectable hash method.
    ///
    /// Returns a `Vec` of `(slot_index, cosine_weight)` for every **occupied**
    /// slot in the range `[centre − radius, centre + radius]` (wrapping around
    /// the table).  The centre bin itself is included with weight `1.0`.
    ///
    /// This implements the "one bin over" finding from bench7.rs: Method 7
    /// (Tribonacci) places continuation tokens at Δ±1 relative to the query
    /// word's hash address.
    ///
    /// `radius = 0` is equivalent to a plain `get_word_index` call and always
    /// returns at most one entry (the exact slot, weight 1.0).
    ///
    /// # Example
    /// ```ignore
    /// use carousel_hash::hash_methods::{HashMethod, cosine_weight};
    /// let hits = table.lookup_radial("is", HashMethod::Tribonacci, 1);
    /// // hits includes the slot for "is" and neighbours at Δ±1
    /// ```
    /// Build a reverse map: natural_hash_address → Vec<slot_index>.
    /// Called once after a corpus load; the result is stored in `WordEngine`
    /// and passed to `lookup_radial` via `addr_index`.
    ///
    /// Only `SlotKind::Word` slots are included.
    pub fn build_addr_index(&self, method: crate::hash_methods::HashMethod) -> std::collections::HashMap<u32, Vec<u32>> {
        let mask = self.mask();
        let mut map: std::collections::HashMap<u32, Vec<u32>> = std::collections::HashMap::new();

        for (phys_idx, slot) in self.slots.iter().enumerate() {
            if slot.is_empty() || slot.kind != SlotKind::Word as u8 { continue; }
            // Recompute the natural address from the stored key bytes using the selected method.
            let klen = slot.key_len as usize;
            let natural_addr = (crate::hash_methods::hash_raw(&slot.key[..klen], method, mask as u64) as u32) & mask;
            map.entry(natural_addr).or_default().push(phys_idx as u32);
        }
        map
    }

    pub fn lookup_radial(
        &self,
        word: &str,
        method: crate::hash_methods::HashMethod,
        chain_depth: u8,
        _probe_cap: u16,
        window: u16,
        addr_index: &std::collections::HashMap<u32, Vec<u32>>,
    ) -> Vec<(u32, f32)> {
        use crate::hash_methods::cosine_weight;
        use crate::carousel;

        let mask = self.mask();
        let want = (chain_depth as usize).max(1) + 1;

        // Compute centre address using the selected hash method
        let mut buf = [0u8; 64];
        let encoded_len = carousel::encode_string_fixed(word, &mut buf);
        let encoded = &buf[..encoded_len];
        let centre_addr = (crate::hash_methods::hash_raw(encoded, method, mask as u64) as u32) & mask;

        // Radial probe: scan adjacent addresses [centre - window, centre + window]
        // This implements the "one bin over" finding: continuation words land at
        // Δ±1 or Δ±2 in address space, not at the exact centre address (Δ0).
        let mut results: Vec<(u32, f32)> = Vec::with_capacity(want);
        let table_len = mask as i64 + 1;
        let eff_window = window.max(1) as i64;

        for delta in -(eff_window as i64)..=(eff_window as i64) {
            if results.len() >= want { break; }
            let addr = (((centre_addr as i64 + delta).rem_euclid(table_len)) as u32) & mask;
            
            if let Some(bucket) = addr_index.get(&addr) {
                for &slot_idx in bucket {
                    if results.len() >= want { break; }
                    let slot = unsafe { self.slots.get_unchecked(slot_idx as usize) };
                    if slot.kind == SlotKind::Word as u8 {
                        let weight = cosine_weight(delta as i32, eff_window as u16);
                        results.push((slot_idx, weight));
                    }
                }
            }
        }

        results
    }

    /// Insert a bigram (two words).
    pub fn insert_bigram(&mut self, w1: &str, w2: &str, value: u64) -> u32 {
        let mut key = carousel::encode_string(w1);
        key.push(0xFF); // separator byte (no cartridge uses 0xFF)
        key.extend(carousel::encode_string(w2));
        self.insert(&key, SlotKind::Bigram, value, 0, 1)
    }

    /// Lookup a bigram.
    pub fn get_bigram(&self, w1: &str, w2: &str) -> Option<&Slot> {
        let mut key = carousel::encode_string(w1);
        key.push(0xFF);
        key.extend(carousel::encode_string(w2));
        self.get(&key)
    }

    /// Lookup a bigram, returning the slot INDEX.
    pub fn get_bigram_index(&self, w1: &str, w2: &str) -> Option<u32> {
        let mut key = carousel::encode_string(w1);
        key.push(0xFF);
        key.extend(carousel::encode_string(w2));
        self.get_index(&key)
    }

    /// Insert a trigram.
    pub fn insert_trigram(&mut self, w1: &str, w2: &str, w3: &str, value: u64) -> u32 {
        let mut key = carousel::encode_string(w1);
        key.push(0xFF);
        key.extend(carousel::encode_string(w2));
        key.push(0xFF);
        key.extend(carousel::encode_string(w3));
        self.insert(&key, SlotKind::Trigram, value, 0, 1)
    }

    /// Lookup a trigram.
    pub fn get_trigram(&self, w1: &str, w2: &str, w3: &str) -> Option<&Slot> {
        let mut key = carousel::encode_string(w1);
        key.push(0xFF);
        key.extend(carousel::encode_string(w2));
        key.push(0xFF);
        key.extend(carousel::encode_string(w3));
        self.get(&key)
    }

    /// Lookup a trigram, returning the slot INDEX.
    pub fn get_trigram_index(&self, w1: &str, w2: &str, w3: &str) -> Option<u32> {
        let mut key = carousel::encode_string(w1);
        key.push(0xFF);
        key.extend(carousel::encode_string(w2));
        key.push(0xFF);
        key.extend(carousel::encode_string(w3));
        self.get_index(&key)
    }

    /// Insert a semantic relation triple: subject --[rel]--> object.
    ///
    /// Chain-threaded: the relation slot is automatically linked into
    /// both the subject chain and the object chain via intrusive linked lists.
    /// No external indexes — the table IS the index.
    ///
    /// Key = carousel(subject) + 0xFE + carousel(object)
    /// Value = packed RelationData (subject_idx, object_idx, confidence, propagation)
    /// next_pos = next_by_subject chain pointer
    /// _padding[0..4] = next_by_object chain pointer
    /// _reserved = RelationType opcode
    pub fn insert_relation(
        &mut self,
        subject: &str,
        relation: RelationType,
        object: &str,
        confidence: u8,
    ) -> u32 {
        // Ensure subject and object exist as Word slots — get their indices
        let subj_idx = self.insert_word(subject, 0);
        let obj_idx = self.insert_word(object, 0);

        // Build the relation key
        let mut full_key = carousel::encode_string(subject);
        full_key.push(0xFE);
        full_key.extend(carousel::encode_string(object));
        let key: Vec<u8> = if full_key.len() <= 16 {
            full_key
        } else {
            Self::hash_key_to_16(&full_key)
        };

        // Pack relation data into value
        let rel_data = RelationData {
            subject_idx: subj_idx,
            object_idx: obj_idx,
            confidence,
            propagation_depth: 0,
        };

        let rel_idx = self.insert(&key, SlotKind::Relation, rel_data.pack(), 0, 1);

        // Set RelationType in _reserved
        let opcode_bytes = (relation as u16).to_le_bytes();
        self.slots[rel_idx as usize]._reserved = [opcode_bytes[0], opcode_bytes[1]];

        // Initialize chain pointers to end-of-chain
        self.slots[rel_idx as usize].set_next_by_subject(CHAIN_END);
        self.slots[rel_idx as usize].set_next_by_object(CHAIN_END);

        // Thread into subject chain (prepend — O(1))
        self.thread_into_chain(SUBJECT_HEAD_PREFIX, subject, rel_idx, true);

        // Thread into object chain (prepend — O(1))
        self.thread_into_chain(OBJECT_HEAD_PREFIX, object, rel_idx, false);

        rel_idx
    }

    /// Thread a relation slot into a chain (subject or object).
    /// `is_subject_chain`: true = set next_by_subject, false = set next_by_object
    fn thread_into_chain(&mut self, prefix: u8, word: &str, rel_idx: u32, is_subject_chain: bool) {
        let mut head_key = vec![prefix];
        head_key.extend(carousel::encode_string(word));
        let head_key = if head_key.len() <= 16 {
            head_key
        } else {
            Self::hash_key_to_16(&head_key)
        };

        match self.get_index(&head_key) {
            Some(head_idx) => {
                // Chain exists — prepend: new.next = old_first, head = new
                let old_first = self.slots[head_idx as usize].value as u32;
                if is_subject_chain {
                    self.slots[rel_idx as usize].set_next_by_subject(old_first);
                } else {
                    self.slots[rel_idx as usize].set_next_by_object(old_first);
                }
                self.slots[head_idx as usize].value = rel_idx as u64;
            }
            None => {
                // No chain yet — create Meta head slot
                self.insert(&head_key, SlotKind::Meta, rel_idx as u64, 0, 0);
            }
        }
    }

    /// Lookup a relation by subject and object.
    /// Returns the slot with TransformParams containing the relation type.
    pub fn get_relation(&self, subject: &str, object: &str) -> Option<&Slot> {
        let mut full_key = carousel::encode_string(subject);
        full_key.push(0xFE);
        full_key.extend(carousel::encode_string(object));
        let key = if full_key.len() <= 16 {
            full_key
        } else {
            Self::hash_key_to_16(&full_key)
        };
        self.get(&key)
    }

    /// Hash an arbitrarily long key down to exactly 16 bytes.
    /// Uses two independent XOR-multiply chains to produce 128 bits.
    /// This gives us collision resistance while fitting the slot key field.
    fn hash_key_to_16(data: &[u8]) -> Vec<u8> {
        // Chain 1: produces 8 bytes
        let mut h1: u64 = 0x517cc1b727220a95;
        for &b in data {
            h1 ^= b as u64;
            h1 = h1.wrapping_mul(0x2545F4914F6CDD1D);
            h1 ^= h1 >> 17;
        }
        // Chain 2: different seed + different prime
        let mut h2: u64 = 0x9E3779B97F4A7C15;
        for &b in data {
            h2 ^= b as u64;
            h2 = h2.wrapping_mul(0xC4CEB9FE1A85EC53);
            h2 ^= h2 >> 13;
        }
        let mut out = Vec::with_capacity(16);
        out.extend_from_slice(&h1.to_le_bytes());
        out.extend_from_slice(&h2.to_le_bytes());
        out
    }

    /// Find all relations where `word` is the subject.
    /// Uses chain threading — O(1) head lookup + O(k) chain walk.
    /// Returns (RelationType, object_slot_idx, confidence) for each relation.
    pub fn relations_where_subject(&self, word: &str) -> Vec<(RelationType, u32, u8)> {
        self.walk_chain(SUBJECT_HEAD_PREFIX, word, true)
    }

    /// Find all relations where `word` is the object.
    /// Uses chain threading — O(1) head lookup + O(k) chain walk.
    /// Returns (RelationType, subject_slot_idx, confidence) for each relation.
    pub fn relations_where_object(&self, word: &str) -> Vec<(RelationType, u32, u8)> {
        self.walk_chain(OBJECT_HEAD_PREFIX, word, false)
    }

    /// Internal: walk a chain (subject or object) and collect results.
    fn walk_chain(&self, prefix: u8, word: &str, is_subject_chain: bool) -> Vec<(RelationType, u32, u8)> {
        let mut head_key = vec![prefix];
        head_key.extend(carousel::encode_string(word));
        let head_key = if head_key.len() <= 16 {
            head_key
        } else {
            Self::hash_key_to_16(&head_key)
        };

        let head = match self.get(&head_key) {
            Some(h) => h,
            None => return Vec::new(),
        };

        let mut results = Vec::new();
        let mut current = head.value as u32;
        let mut safety = 0u32;

        while current != CHAIN_END && safety < 10_000 {
            if current as usize >= self.slots.len() { break; }
            let slot = &self.slots[current as usize];
            if slot.kind != SlotKind::Relation as u8 { break; }

            let data = slot.relation_data();
            let rel_type = slot.relation_type();

            if is_subject_chain {
                // Walking subject chain → return object endpoint
                results.push((rel_type, data.object_idx, data.confidence));
                current = slot.next_by_subject();
            } else {
                // Walking object chain → return subject endpoint
                results.push((rel_type, data.subject_idx, data.confidence));
                current = slot.next_by_object();
            }
            safety += 1;
        }
        results
    }

    /// Backward-compatible wrapper. Now chain-threaded instead of O(n) scan.
    pub fn relations_for_subject(&self, subject: &str) -> Vec<(String, RelationType, String, u64)> {
        self.relations_where_subject(subject)
            .into_iter()
            .map(|(rel_type, obj_idx, confidence)| {
                let obj_word = self.word_at(obj_idx).unwrap_or_default();
                (subject.to_string(), rel_type, obj_word, confidence as u64)
            })
            .collect()
    }

    /// Read the decoded word from a slot index.
    pub fn word_at(&self, idx: u32) -> Option<String> {
        if idx as usize >= self.slots.len() { return None; }
        let slot = &self.slots[idx as usize];
        if slot.is_empty() { return None; }
        Some(carousel::decode_bytes(&slot.key[..slot.key_len as usize]))
    }

    /// Transitive chain walk: follow relations of given types from `start`
    /// up to `max_depth` hops via BFS.
    ///
    /// Example: walk_transitive("spot", &[IS, IS_A], 3)
    ///   → Spot --IS--> Dog --IS--> Animal --IS_A--> LivingThing
    ///
    /// Returns (slot_idx, depth, relation_path) for each reachable node.
    pub fn walk_transitive(
        &self,
        start: &str,
        relation_types: &[RelationType],
        max_depth: usize,
    ) -> Vec<(u32, usize, Vec<RelationType>)> {
        use std::collections::{HashSet, VecDeque};

        let start_idx = match self.get_word_index(start) {
            Some(idx) => idx,
            None => return Vec::new(),
        };

        let mut results = Vec::new();
        let mut visited = HashSet::new();
        let mut queue = VecDeque::new();

        queue.push_back((start_idx, 0usize, Vec::<RelationType>::new()));
        visited.insert(start_idx);

        while let Some((current_idx, depth, path)) = queue.pop_front() {
            if depth >= max_depth { continue; }

            // Read the word's key bytes to build the subject head key
            let slot = &self.slots[current_idx as usize];
            if slot.is_empty() { continue; }
            let word_key = &slot.key[..slot.key_len as usize];

            let mut head_key = vec![SUBJECT_HEAD_PREFIX];
            head_key.extend_from_slice(word_key);
            let head_key = if head_key.len() <= 16 {
                head_key
            } else {
                Self::hash_key_to_16(&head_key)
            };

            let head = match self.get(&head_key) {
                Some(h) => h,
                None => continue,
            };

            let mut chain_idx = head.value as u32;
            let mut safety = 0u32;

            while chain_idx != CHAIN_END && safety < 10_000 {
                if chain_idx as usize >= self.slots.len() { break; }
                let rel_slot = &self.slots[chain_idx as usize];
                if rel_slot.kind != SlotKind::Relation as u8 { break; }

                let rel_type = rel_slot.relation_type();
                let data = rel_slot.relation_data();

                if relation_types.contains(&rel_type) && !visited.contains(&data.object_idx) {
                    visited.insert(data.object_idx);
                    let mut new_path = path.clone();
                    new_path.push(rel_type);
                    results.push((data.object_idx, depth + 1, new_path.clone()));
                    queue.push_back((data.object_idx, depth + 1, new_path));
                }

                chain_idx = rel_slot.next_by_subject();
                safety += 1;
            }
        }
        results
    }

    /// Rebuild all subject/object chains by scanning existing Relation slots.
    /// Call after loading a .crsl file to reconstruct chain threading.
    pub fn rebuild_chains(&mut self) {
        // Clear existing Meta head slots (subject/object chain heads)
        for i in 0..self.slots.len() {
            if self.slots[i].kind == SlotKind::Meta as u8
                && self.slots[i].key_len > 0
                && (self.slots[i].key[0] == SUBJECT_HEAD_PREFIX
                    || self.slots[i].key[0] == OBJECT_HEAD_PREFIX)
            {
                self.slots[i] = Slot::default();
                self.count = self.count.saturating_sub(1);
            }
            // Reset chain pointers on all relation slots
            if self.slots[i].kind == SlotKind::Relation as u8 {
                self.slots[i].set_next_by_subject(CHAIN_END);
                self.slots[i].set_next_by_object(CHAIN_END);
            }
        }

        // Collect relation slot indices
        let relation_indices: Vec<u32> = (0..self.slots.len() as u32)
            .filter(|&i| {
                let s = &self.slots[i as usize];
                s.kind == SlotKind::Relation as u8 && !s.is_empty()
            })
            .collect();

        // Re-thread each relation into both chains
        for &rel_idx in &relation_indices {
            let data = self.slots[rel_idx as usize].relation_data();

            // Thread by subject
            let subj_slot = &self.slots[data.subject_idx as usize];
            let subj_key_bytes = subj_slot.key[..subj_slot.key_len as usize].to_vec();
            let mut head_key = vec![SUBJECT_HEAD_PREFIX];
            head_key.extend_from_slice(&subj_key_bytes);
            let head_key = if head_key.len() <= 16 {
                head_key
            } else {
                Self::hash_key_to_16(&head_key)
            };
            match self.get_index(&head_key) {
                Some(head_idx) => {
                    let old_first = self.slots[head_idx as usize].value as u32;
                    self.slots[rel_idx as usize].set_next_by_subject(old_first);
                    self.slots[head_idx as usize].value = rel_idx as u64;
                }
                None => {
                    self.insert(&head_key, SlotKind::Meta, rel_idx as u64, 0, 0);
                }
            }

            // Thread by object
            let obj_slot = &self.slots[data.object_idx as usize];
            let obj_key_bytes = obj_slot.key[..obj_slot.key_len as usize].to_vec();
            let mut head_key = vec![OBJECT_HEAD_PREFIX];
            head_key.extend_from_slice(&obj_key_bytes);
            let head_key = if head_key.len() <= 16 {
                head_key
            } else {
                Self::hash_key_to_16(&head_key)
            };
            match self.get_index(&head_key) {
                Some(head_idx) => {
                    let old_first = self.slots[head_idx as usize].value as u32;
                    self.slots[rel_idx as usize].set_next_by_object(old_first);
                    self.slots[head_idx as usize].value = rel_idx as u64;
                }
                None => {
                    self.insert(&head_key, SlotKind::Meta, rel_idx as u64, 0, 0);
                }
            }
        }
    }

    /// Load factor.
    pub fn load_factor(&self) -> f64 {
        self.count as f64 / self.slots.len() as f64
    }

    /// Diagnostics.
    pub fn stats(&self) -> TableStats {
        let mut probe_histogram = [0u32; 65];
        let mask = self.mask();
        let step = self.golden_step();

        for slot in &self.slots {
            if slot.is_empty() { continue; }
            let key = &slot.key[..slot.key_len as usize];
            let mut idx = hash_carousel(key) & mask;
            let mut probes = 0u32;
            loop {
                if self.slots[idx as usize].key_matches(key) {
                    break;
                }
                idx = (idx.wrapping_add(step)) & mask;
                probes += 1;
                if probes > 64 { break; }
            }
            probe_histogram[probes.min(64) as usize] += 1;
        }

        let total_probes: u64 = probe_histogram.iter().enumerate()
            .map(|(depth, &count)| depth as u64 * count as u64)
            .sum();
        let avg_probes = if self.count > 0 {
            total_probes as f64 / self.count as f64
        } else {
            0.0
        };

        TableStats {
            count: self.count,
            capacity: self.slots.len(),
            load_factor: self.load_factor(),
            avg_probes,
            max_probes: self.max_probe_depth,
            probe_histogram,
        }
    }
}

#[derive(Debug)]
pub struct TableStats {
    pub count: usize,
    pub capacity: usize,
    pub load_factor: f64,
    pub avg_probes: f64,
    pub max_probes: usize,
    pub probe_histogram: [u32; 65],
}

impl std::fmt::Display for TableStats {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        writeln!(f, "=== HashTable24 Stats ===")?;
        writeln!(f, "Entries:     {} / {} ({:.2}% full)", self.count, self.capacity, self.load_factor * 100.0)?;
        writeln!(f, "Avg probes:  {:.3}", self.avg_probes)?;
        writeln!(f, "Max probes:  {}", self.max_probes)?;
        writeln!(f, "Probe distribution:")?;
        for (depth, &count) in self.probe_histogram.iter().enumerate() {
            if count > 0 {
                writeln!(f, "  depth {}: {} ({:.1}%)", depth, count, count as f64 / self.count as f64 * 100.0)?;
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_insert_and_lookup() {
        let mut table = HashTable24::new_sized(20); // 1M slots for testing
        table.insert_word("hello", 42);
        table.insert_word("world", 99);

        let slot = table.get_word("hello").unwrap();
        assert_eq!(slot.value, 42);

        let slot = table.get_word("world").unwrap();
        assert_eq!(slot.value, 99);

        assert!(table.get_word("missing").is_none());
    }

    #[test]
    fn test_bigram() {
        let mut table = HashTable24::new_sized(20);
        table.insert_bigram("the", "dog", 100);
        assert_eq!(table.get_bigram("the", "dog").unwrap().value, 100);
        assert!(table.get_bigram("the", "cat").is_none());
    }

    #[test]
    fn test_golden_ratio_probing() {
        // Insert enough entries to force collisions
        let mut table = HashTable24::new_sized(16); // 65K slots
        for i in 0..50_000u64 {
            let key = format!("word_{}", i);
            table.insert_word(&key, i);
        }
        // Verify all lookups still work at ~76% load
        for i in 0..50_000u64 {
            let key = format!("word_{}", i);
            let slot = table.get_word(&key).expect(&format!("Missing: {}", key));
            assert_eq!(slot.value, i);
        }
        let stats = table.stats();
        println!("{}", stats);
        assert!(stats.avg_probes < 3.0, "Average probes too high: {}", stats.avg_probes);
    }

    #[test]
    fn test_relation_chain_subject() {
        let mut table = HashTable24::new_sized(16);

        // dog IS animal, dog HAS fur, dog CAN bark
        table.insert_relation("dog", RelationType::IS, "animal", 200);
        table.insert_relation("dog", RelationType::HAS, "fur", 180);
        table.insert_relation("dog", RelationType::CAN, "bark", 200);

        let rels = table.relations_where_subject("dog");
        assert_eq!(rels.len(), 3, "Expected 3 relations for dog, got {}", rels.len());

        let types: Vec<RelationType> = rels.iter().map(|(r, _, _)| *r).collect();
        assert!(types.contains(&RelationType::IS));
        assert!(types.contains(&RelationType::HAS));
        assert!(types.contains(&RelationType::CAN));

        // Verify object endpoints resolve to correct words
        for (rel_type, obj_idx, _conf) in &rels {
            let obj = table.word_at(*obj_idx).unwrap();
            match rel_type {
                &RelationType::IS => assert_eq!(obj, "animal"),
                &RelationType::HAS => assert_eq!(obj, "fur"),
                &RelationType::CAN => assert_eq!(obj, "bark"),
                _ => panic!("Unexpected relation type"),
            }
        }
    }

    #[test]
    fn test_relation_chain_object() {
        let mut table = HashTable24::new_sized(16);

        // dog IS animal, cat IS animal, bird IS animal
        table.insert_relation("dog", RelationType::IS, "animal", 200);
        table.insert_relation("cat", RelationType::IS, "animal", 200);
        table.insert_relation("bird", RelationType::IS, "animal", 200);

        let rels = table.relations_where_object("animal");
        assert_eq!(rels.len(), 3, "Expected 3 relations pointing to animal, got {}", rels.len());

        // All should be IS relations
        for (rel_type, _, _) in &rels {
            assert_eq!(*rel_type, RelationType::IS);
        }

        // Subject endpoints should be dog, cat, bird
        let subjects: Vec<String> = rels.iter()
            .map(|(_, subj_idx, _)| table.word_at(*subj_idx).unwrap())
            .collect();
        assert!(subjects.contains(&"dog".to_string()));
        assert!(subjects.contains(&"cat".to_string()));
        assert!(subjects.contains(&"bird".to_string()));
    }

    #[test]
    fn test_relation_data_pack_unpack() {
        let data = RelationData {
            subject_idx: 0x00ABCDEF,
            object_idx: 0x00123456,
            confidence: 200,
            propagation_depth: 3,
        };
        let packed = data.pack();
        let unpacked = RelationData::unpack(packed);
        assert_eq!(data, unpacked);
    }

    #[test]
    fn test_transitive_walk() {
        let mut table = HashTable24::new_sized(16);

        // spot IS dog, dog IS animal, animal IS living thing
        table.insert_relation("spot", RelationType::IS, "dog", 200);
        table.insert_relation("dog", RelationType::IS, "animal", 200);
        table.insert_relation("animal", RelationType::IS, "living thing", 200);

        let chain = table.walk_transitive("spot", &[RelationType::IS], 5);
        assert!(chain.len() >= 3, "Expected 3 hops, got {}: {:?}", chain.len(),
            chain.iter().map(|(idx, d, _)| (table.word_at(*idx), d)).collect::<Vec<_>>());

        // Verify the chain resolves: spot → dog → animal → living thing
        let words: Vec<String> = chain.iter()
            .map(|(idx, _, _)| table.word_at(*idx).unwrap())
            .collect();
        assert!(words.contains(&"dog".to_string()));
        assert!(words.contains(&"animal".to_string()));
        assert!(words.contains(&"living thing".to_string()));
    }

    #[test]
    fn test_backward_compat_relations_for_subject() {
        let mut table = HashTable24::new_sized(16);
        table.insert_relation("rust", RelationType::IS, "language", 200);
        table.insert_relation("rust", RelationType::CAN, "compile", 180);

        let rels = table.relations_for_subject("rust");
        assert_eq!(rels.len(), 2);

        let has_lang = rels.iter().any(|(s, r, o, _)| s == "rust" && *r == RelationType::IS && o == "language");
        let has_comp = rels.iter().any(|(s, r, o, _)| s == "rust" && *r == RelationType::CAN && o == "compile");
        assert!(has_lang, "Missing IS relation");
        assert!(has_comp, "Missing CAN relation");
    }

    #[test]
    fn test_rebuild_chains() {
        let mut table = HashTable24::new_sized(16);
        table.insert_relation("fire", RelationType::CAUSES, "heat", 200);
        table.insert_relation("ice", RelationType::CAUSES, "cold", 200);

        // Verify chains work
        assert_eq!(table.relations_where_subject("fire").len(), 1);
        assert_eq!(table.relations_where_subject("ice").len(), 1);

        // Rebuild and verify chains still work
        table.rebuild_chains();
        assert_eq!(table.relations_where_subject("fire").len(), 1);
        assert_eq!(table.relations_where_subject("ice").len(), 1);
        assert_eq!(table.relations_where_object("heat").len(), 1);
        assert_eq!(table.relations_where_object("cold").len(), 1);
    }

    #[test]
    fn test_hash_distribution() {
        // Verify the hash spreads well across the 24-bit space
        let mut buckets = [0u32; 256];
        for i in 0..10_000u32 {
            let key = format!("word_{}", i);
            let encoded = carousel::encode_string(&key);
            let h = hash_carousel(&encoded);
            buckets[(h >> 16) as usize] += 1; // top 8 bits
        }
        let min = *buckets.iter().min().unwrap();
        let max = *buckets.iter().max().unwrap();
        let expected = 10_000.0 / 256.0; // ~39
        // Should be within 3x of expected (very loose)
        assert!(min > 0, "Hash has dead buckets");
        assert!((max as f64) < expected * 4.0, "Hash has hot buckets: max={}", max);
    }
}
