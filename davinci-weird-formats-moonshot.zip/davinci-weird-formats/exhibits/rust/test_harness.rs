// Automated regression testing harness — corpus-derived ground truth
// Extracts simple assertions from a corpus and validates engine responses.

use std::collections::HashMap;
use crate::word_engine::WordEngine;
// unused: crate::dada_engine::RelationalTriple

#[derive(Debug, Clone)]
struct GroundTruth {
    assertion: String,
    subject: String,
    relation: String,
    object: String,
    query_templates: Vec<String>,
    expected_tokens: Vec<String>,
    must_not_contain: Vec<String>,
}

#[derive(Debug, Clone)]
struct TestResult {
    query: String,
    expected: Vec<String>,
    actual_response: String,

    contains_expected: usize,
    contains_forbidden: usize,
    response_time_ms: u64,
    reasoning_depth: u8,
    confidence_score: f32,

    passed: bool,
    score: f32,
}

struct TestSuite {
    ground_truths: Vec<GroundTruth>,
    baseline_scores: HashMap<String, f32>,
}

impl TestSuite {
    /// Extract ground truths from a corpus string using safer heuristics.
    fn from_corpus(corpus_text: &str) -> Self {
        let mut truths = Vec::new();

        for raw_line in corpus_text.lines() {
            // split the (possibly multi-sentence) line into sentence fragments
            for sentence in raw_line.split(|c| ".!?".contains(c)) {
                let line = sentence.trim();
                if line.is_empty() { continue; }

                // Pattern 1: simple `X is Y` where both sides are short
                if let Some((subject, object)) = simple_is_pattern(line) {
                    truths.push(GroundTruth {
                        assertion: line.to_string(),
                        subject: subject.clone(),
                        relation: "IS".to_string(),
                        object: object.clone(),
                        query_templates: vec![format!("What is {}?", subject), format!("Tell me about {}", subject)],
                        expected_tokens: extract_keywords(&object),
                        must_not_contain: vec![],
                    });
                    continue;
                }
            }

            // Pattern 2: "I am X" → canonical subject "Number 5" when applicable
            let raw = raw_line.trim();
            if raw.to_lowercase().starts_with("i am ") {
                let object = raw[4..].split(&['.', ',', ';'][..]).next().unwrap_or("").trim();
                if !object.is_empty() && object.split_whitespace().count() <= 5 {
                    truths.push(GroundTruth {
                        assertion: raw.to_string(),
                        subject: "Number 5".to_string(),
                        relation: "IS".to_string(),
                        object: object.to_string(),
                        query_templates: vec!["What is Number 5?".to_string(), "Who are you?".to_string()],
                        expected_tokens: extract_keywords(object),
                        must_not_contain: vec![],
                    });
                    continue;
                }
            }

            // Pattern 3: causal "X because Y"
            if let Some(idx) = raw.to_lowercase().find(" because ") {
                let cause = raw[..idx].trim();
                let effect = raw[idx + " because ".len()..].split(&['.', ','][..]).next().unwrap_or("").trim();
                if !cause.is_empty() && !effect.is_empty() && cause.split_whitespace().count() <= 6 && effect.split_whitespace().count() <= 8 {
                    truths.push(GroundTruth {
                        assertion: raw.to_string(),
                        subject: cause.to_string(),
                        relation: "BECAUSE".to_string(),
                        object: effect.to_string(),
                        query_templates: vec![format!("Why {}?", cause)],
                        expected_tokens: extract_keywords(effect),
                        must_not_contain: vec![],
                    });
                    continue;
                }
            }

            // Pattern 4: small set of curated rules for high-value assertions
            if raw.to_lowercase().contains("no disassemble") || raw.to_lowercase().contains("disassemble is death") {
                truths.push(GroundTruth {
                    assertion: raw.to_string(),
                    subject: "disassemble".to_string(),
                    relation: "IS".to_string(),
                    object: "death".to_string(),
                    query_templates: vec!["What is disassemble?".to_string(), "What happens if you disassemble?".to_string()],
                    expected_tokens: vec!["death".to_string(), "disassemble".to_string()],
                    must_not_contain: vec!["good".to_string(), "safe".to_string()],
                });
                continue;
            }

            if raw.to_lowercase().contains("need input") {
                truths.push(GroundTruth {
                    assertion: raw.to_string(),
                    subject: "input".to_string(),
                    relation: "ENABLES".to_string(),
                    object: "learning".to_string(),
                    query_templates: vec!["What is input?".to_string(), "Why do you need input?".to_string()],
                    expected_tokens: vec!["learn".to_string(), "learning".to_string()],
                    must_not_contain: vec![],
                });
                continue;
            }
        }

        TestSuite { ground_truths: truths, baseline_scores: HashMap::new() }
    }

    /// Run suite against an engine instance and return a report
    fn run(&self, engine: &mut WordEngine) -> TestReport {
        let mut results = Vec::new();

        for gt in &self.ground_truths {
            for query in &gt.query_templates {
                let start = std::time::Instant::now();
                let qr = engine.query(query);
                let elapsed = start.elapsed().as_millis() as u64;

                let resp = qr.generated;
                let result = self.evaluate_response(query, &resp, gt, elapsed);
                results.push(result);
            }
        }

        TestReport::from_results(results)
    }

    fn evaluate_response(&self, query: &str, response: &str, gt: &GroundTruth, time_ms: u64) -> TestResult {
        let response_lower = response.to_lowercase();
        let expected_found = gt.expected_tokens.iter()
            .filter(|tok| response_lower.contains(&tok.to_lowercase()))
            .count();
        let forbidden_found = gt.must_not_contain.iter()
            .filter(|tok| response_lower.contains(&tok.to_lowercase()))
            .count();

        let expected_ratio = expected_found as f32 / gt.expected_tokens.len().max(1) as f32;
        let forbidden_penalty = forbidden_found as f32 * 0.3;
        let speed_bonus = if time_ms < 50 { 0.1 } else { 0.0 };
        let score = (expected_ratio + speed_bonus - forbidden_penalty).max(0.0).min(1.0);
        let passed = score >= 0.6 && forbidden_found == 0;

        TestResult {
            query: query.to_string(),
            expected: gt.expected_tokens.clone(),
            actual_response: response.to_string(),
            contains_expected: expected_found,
            contains_forbidden: forbidden_found,
            response_time_ms: time_ms,
            reasoning_depth: 0,
            confidence_score: score,
            passed,
            score,
        }
    }
}

#[derive(Debug)]
struct TestReport {
    total_tests: usize,
    passed: usize,
    failed: usize,
    avg_score: f32,
    avg_response_time_ms: u64,
    regression_score: f32,
    failures: Vec<TestResult>,
    improvements: Vec<TestResult>,
}

impl TestReport {
    fn from_results(results: Vec<TestResult>) -> Self {
        let total = results.len();
        let passed = results.iter().filter(|r| r.passed).count();
        let avg_score = if total > 0 { results.iter().map(|r| r.score).sum::<f32>() / total as f32 } else { 0.0 };
        let avg_time = if total > 0 { results.iter().map(|r| r.response_time_ms).sum::<u64>() / total as u64 } else { 0 };
        let failures: Vec<_> = results.iter().filter(|r| !r.passed).cloned().collect();

        TestReport {
            total_tests: total,
            passed,
            failed: total - passed,
            avg_score,
            avg_response_time_ms: avg_time,
            regression_score: 0.0,
            failures,
            improvements: vec![],
        }
    }

    fn compare_to_baseline(&mut self, baseline: &TestReport) {
        let score_delta = self.avg_score - baseline.avg_score;
        let time_delta = baseline.avg_response_time_ms as f32 / self.avg_response_time_ms.max(1) as f32;
        self.regression_score = (score_delta * 0.7) + ((time_delta - 1.0) * 0.3);
    }

    fn print_summary(&self) {
        println!("\n╔══════════════════════════════════════╗");
        println!("║      Test Suite Results              ║");
        println!("╚══════════════════════════════════════╝");
        println!("Tests:      {}/{} passed ({:.1}%)", self.passed, self.total_tests, self.passed as f32 / self.total_tests as f32 * 100.0);
        println!("Avg Score:  {:.3}/1.0", self.avg_score);
        println!("Avg Time:   {}ms", self.avg_response_time_ms);
        if self.regression_score != 0.0 {
            let emoji = if self.regression_score > 0.0 { "📈" } else { "📉" };
            println!("Regression: {}{:+.3}", emoji, self.regression_score);
        }
        if !self.failures.is_empty() {
            println!("\n❌ Failures ({}):", self.failures.len());
            for (i, f) in self.failures.iter().take(5).enumerate() {
                println!("  {}. {} (score: {:.2})", i+1, f.query, f.score);
                println!("     Expected: {:?}", f.expected);
                println!("     Got: {}", f.actual_response.chars().take(60).collect::<String>());
            }
        }
    }
}

// Helper to pull simple "X is Y" assertions from a line
fn extract_keywords(phrase: &str) -> Vec<String> {
    let stop_words = ["the", "a", "an", "is", "are", "was", "were", "and", "or", "but", "in", "on", "at", "to", "for"];
    phrase.split_whitespace()
        .map(|w| w.trim_matches(|c: char| !c.is_alphanumeric()).to_lowercase())
        .filter(|w| !stop_words.contains(&w.as_str()) && w.len() > 2)
        .take(4)
        .collect()
}

fn simple_is_pattern(line: &str) -> Option<(String, String)> {
    let patterns = [" is ", " are ", " was ", " were "];
    for pattern in &patterns {
        if let Some(idx) = line.to_lowercase().find(pattern) {
            // find the index in the original string to preserve casing/trimming
            let before = line[..idx].trim();
            let after = &line[idx + pattern.len()..];
            let object = after.split(&['.', ',', ';', '!', '?'][..]).next().unwrap_or("").trim();
            if !before.is_empty() && !object.is_empty() && before.split_whitespace().count() <= 4 && object.split_whitespace().count() <= 8 {
                return Some((before.to_string(), object.to_string()));
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_corpus_extraction() {
        let corpus = "Number 5 is alive. Stephanie is kind.";
        let suite = TestSuite::from_corpus(corpus);
        // Expect subjects 'Number 5' and 'Stephanie' extracted as short facts
        assert!(suite.ground_truths.iter().any(|g| g.subject.to_lowercase().contains("number 5") && g.expected_tokens.contains(&"alive".to_string())));
        assert!(suite.ground_truths.iter().any(|g| g.subject.to_lowercase().contains("stephanie") && g.expected_tokens.contains(&"kind".to_string())));
    }

    #[test]
    fn test_automated_regression_using_input_txt() {
        // Use the workspace "input.txt" (flashforward/input.txt) as the corpus
        let corpus = include_str!("../flashforward/input.txt");
        let suite = TestSuite::from_corpus(corpus);

        // Sanity: must extract at least one ground truth after improved extraction
        assert!(!suite.ground_truths.is_empty(), "No ground truth assertions found in input.txt");

        // Quick check that 'disassemble' ground-truth is recognized (curated rule)
        assert!(suite.ground_truths.iter().any(|g| g.subject == "disassemble"));

        let mut engine = WordEngine::new(5);
        // Ingest the corpus so engine has content to answer
        let _ = engine.ingest(corpus);

        let report = suite.run(&mut engine);
        // Sanity: expect modest increase after fixing extraction
        assert!(report.avg_score >= 0.18, "Avg score below threshold: {:.3}", report.avg_score);
        report.print_summary();
    }

    #[test]
    fn test_create_baseline_suite() {
        let baseline = create_baseline_suite();
        assert!(baseline.ground_truths.iter().any(|g| g.subject == "Number 5" && g.expected_tokens.iter().any(|t| t.contains("alive"))));
        assert!(baseline.ground_truths.iter().any(|g| g.subject == "disassemble"));
    }
}

// Manually curated baseline suite (small set of high-value facts)
fn create_baseline_suite() -> TestSuite {
    TestSuite {
        ground_truths: vec![
            GroundTruth {
                assertion: "I am Number 5 and I am alive".to_string(),
                subject: "Number 5".to_string(),
                relation: "IS".to_string(),
                object: "alive".to_string(),
                query_templates: vec!["Who are you?".to_string(), "What is Number 5?".to_string()],
                expected_tokens: vec!["alive".to_string(), "number".to_string(), "5".to_string()],
                must_not_contain: vec!["weapon".to_string(), "dead".to_string()],
            },
            GroundTruth {
                assertion: "Disassemble is death".to_string(),
                subject: "disassemble".to_string(),
                relation: "IS".to_string(),
                object: "death".to_string(),
                query_templates: vec!["What is disassemble?".to_string()],
                expected_tokens: vec!["death".to_string()],
                must_not_contain: vec![],
            },
        ],
        baseline_scores: HashMap::new(),
    }
}
