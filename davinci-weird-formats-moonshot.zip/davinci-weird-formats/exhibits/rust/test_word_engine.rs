//! Test the WORD engine implementation

use crate::word_engine::WordEngine;

#[test]
fn test_word_engine_basic() {
    let mut engine = WordEngine::new(5);
    
    // Test ingestion
    let result = engine.ingest("The quick brown fox jumps over the lazy dog.");
    assert!(result.is_ok(), "Ingestion should succeed");
    
    // Test query
    let query_result = engine.query("fox");
    println!("Query result: {}", query_result.generated);
    
    // Test stats
    let stats = engine.get_stats();
    println!("Engine stats: {:?}", stats);
    
    assert!(!query_result.generated.is_empty(), "Should have some response");
}

#[test]
fn test_word_engine_relations() {
    let mut engine = WordEngine::new(3);
    
    // Test with text that should create some relations
    let result = engine.ingest("Alice loves Bob. Bob likes Charlie. Charlie knows Alice.");
    assert!(result.is_ok(), "Ingestion should succeed");
    
    // Test query for relations
    let query_result = engine.query("Alice");
    println!("Alice query: {}", query_result.generated);
    
    let query_result = engine.query("loves");  
    println!("Loves query: {}", query_result.generated);
}

#[test]
fn test_resolve_is_from_timeline_recent_and_correction() {
    let mut engine = WordEngine::new(5);

    // Initial assertion
    let _ = engine.ingest("The robot is blue.");
    // Later correction / newer mention
    let _ = engine.ingest("Now the robot is red.");

    let resolved = engine.resolve_is_from_timeline("robot");
    // debug: list extracted relations for 'robot'
    eprintln!("relations: {:?}", engine.relations.iter().filter(|r| r.subject.to_lowercase() == "robot").collect::<Vec<_>>());
    assert!(resolved.is_some());
    assert_eq!(resolved.unwrap().to_lowercase(), "red");

    // Another corrective statement should win if more recent
    let _ = engine.ingest("No, the robot is green.");
    let resolved2 = engine.resolve_is_from_timeline("robot");
    assert_eq!(resolved2.unwrap().to_lowercase(), "green");
}

#[test]
fn test_resolve_is_from_timeline_ambiguous_on_tie() {
    let mut engine = WordEngine::new(5);

    // Inject two conflicting 'is' triples with identical recency (no token_index entries)
    engine.relations.push(crate::dada_engine::RelationalTriple::new("dog".into(), "is".into(), "brown".into(), 1.0));
    engine.relations.push(crate::dada_engine::RelationalTriple::new("dog".into(), "is".into(), "black".into(), 1.0));

    // Since both have equal recency/confidence the resolver should return None (ambiguous)
    let resolved = engine.resolve_is_from_timeline("dog");
    assert!(resolved.is_none());
}

#[test]
fn test_query_prefers_timeline_is_resolution() {
    let mut engine = WordEngine::new(5);
    let _ = engine.ingest("The robot is blue.");
    let _ = engine.ingest("The robot is red.");

    let qr = engine.query("what is robot");
    assert!(qr.generated.to_lowercase().contains("robot is red"));
    assert_eq!(qr.source, "timeline_resolver");
}

#[test]
fn test_causal_reasoning_because() {
    let mut engine = WordEngine::new(5);
    let _ = engine.ingest("Lightning struck me because conditions were right.");
    let _ = engine.ingest("Consciousness emerged because lightning changed pathways.");

    let result = engine.query("why did consciousness emerge");
    let out = result.generated.to_lowercase();
    assert!(out.contains("lightning") || result.facts.iter().any(|f| f.subject.contains("lightning") || f.object.contains("lightning")));
    assert!(out.contains("pathways") || result.facts.iter().any(|f| f.subject.contains("pathways") || f.object.contains("pathways")));
}

#[test]
fn test_anaphora_resolution_that() {
    let mut engine = WordEngine::new(5);
    let _ = engine.ingest("No disassemble. Disassemble is death.");

    // Simulate conversation flow
    let response1 = engine.query("what is disassemble");
    assert!(response1.generated.to_lowercase().contains("death") || response1.facts.iter().any(|f| f.object.to_lowercase().contains("death")));

    let response2 = engine.query("that was great");
    // Should NOT resolve "that" to the subject 'disassemble'/'death'
    assert!(!response2.generated.to_lowercase().contains("death"));
}

#[test]
fn test_query_does_not_ingest_user_text() {
    let mut engine = WordEngine::new(5);

    // Ensure 'unseenword' is not present before query
    assert!(!engine.token_index.contains_key("unseenword"));

    // Query should not modify the token timeline / index
    let _ = engine.query("what is unseenword");
    assert!(!engine.token_index.contains_key("unseenword"), "query() must not ingest the raw query into the timeline");

    // Only explicit ingest should add tokens
    let _ = engine.ingest_user("unseenword is imaginary");
    assert!(engine.token_index.contains_key("unseenword"));
}

#[test]
fn test_ingest_user_negation_demotes_positive_fact() {
    let mut engine = WordEngine::new(5);

    // Seed a positive fact using an explicit 'do' construction so the
    // compositional extractor produces a (subject, DO, object) triple.
    let _ = engine.ingest("You do sleep.");
    // find the triple (you, DO, sleep)
    let idx = engine.relations.iter().position(|r| r.subject.to_lowercase() == "you" && r.object.to_lowercase() == "sleep");
    assert!(idx.is_some(), "expected a (you, DO, sleep) triple");
    let i = idx.unwrap();
    
    let before = engine.relations[i].confidence;

    // Now user corrects with an explicit negation
    let _ = engine.ingest_user("No, you do not sleep.");

    // the existing positive triple should have been demoted
    let after = engine.relations[i].confidence;
    assert!(after < before, "negation should demote prior positive fact ({} -> {})", before, after);
}