//! # Transitive Reasoner
//!
//! Multi-hop inference over the relation graph built by WordEngine/RelationEngine.
//! Finds chains like:
//!   spot --IS--> dog --IS--> animal --CAN--> run
//!
//! Key features:
//! - BFS `find_chain`: shortest path to target (stops at first hit)
//! - DFS `find_all_chains`: all paths up to max_depth (sorted shortest-first)
//! - Synset ghost edges: synonyms are traversed as implicit IS_SIMILAR hops,
//!   so if the graph contains "dog" but the query asks about "canine", it still
//!   walks through dog's edges.
//! - `answer_property_question`: direct + transitive property lookup with
//!   confidence decay proportional to chain length.
//!
//! Graph is read-only borrows of WordEngine's index maps — no copies made.

use std::collections::{HashMap, HashSet, VecDeque};
use crate::synsets::Synsets;

/// One hop in a reasoning chain.
#[derive(Debug, Clone)]
pub struct ChainHop {
    pub source: String,
    pub relation: String,
    pub target: String,
}

impl ChainHop {
    pub fn new(source: impl Into<String>, relation: impl Into<String>, target: impl Into<String>) -> Self {
        Self {
            source: source.into(),
            relation: relation.into(),
            target: target.into(),
        }
    }
}

/// A full reasoning chain — ordered list of hops from start to target.
pub type Chain = Vec<ChainHop>;

/// Result of a property question.
#[derive(Debug, Clone)]
pub struct PropertyAnswer {
    pub found: bool,
    pub answer: &'static str, // "yes" | "no" | "unknown"
    pub direct: bool,
    pub chain: Chain,
    pub confidence: f32,
}

/// Graph edge as stored in the adjacency list.
/// `(relation_type, target_node)`
pub type Edge = (String, String);

/// Build the adjacency list from WordEngine's index structures.
/// Caller passes subject_index (subject → triple indices) and
/// the flat triples slice as `(subject, relation, object)`.
pub fn build_outgoing(
    triples: &[(String, String, String)], // (s, r, o)
) -> HashMap<String, Vec<Edge>> {
    let mut out: HashMap<String, Vec<Edge>> = HashMap::new();
    for (s, r, o) in triples {
        out.entry(s.clone())
            .or_insert_with(Vec::new)
            .push((r.clone(), o.clone()));
    }
    out
}

/// The reasoner. Holds borrowed references to the outgoing adjacency list
/// and optional synset expansion.
pub struct TransitiveReasoner<'a> {
    /// subject → [(relation, object)]
    outgoing: &'a HashMap<String, Vec<Edge>>,
    /// optional synset expansion for ghost IS_SIMILAR edges
    synsets: Option<&'a Synsets>,
    /// print trace steps (for debugging)
    pub trace: bool,
}

impl<'a> TransitiveReasoner<'a> {
    pub fn new(outgoing: &'a HashMap<String, Vec<Edge>>) -> Self {
        Self {
            outgoing,
            synsets: None,
            trace: false,
        }
    }

    pub fn with_synsets(mut self, synsets: &'a Synsets) -> Self {
        self.synsets = Some(synsets);
        self
    }

    /// Get all outgoing edges from a node, including synset ghost edges.
    fn edges_from(&self, node: &str) -> Vec<Edge> {
        let mut edges: Vec<Edge> = self
            .outgoing
            .get(node)
            .cloned()
            .unwrap_or_default();

        // Synset ghost edges: treat synonyms as implicit IS_SIMILAR hops.
        if let Some(syns) = self.synsets {
            for synonym in syns.expand(node) {
                if synonym != node {
                    edges.push(("IS_SIMILAR".to_string(), synonym));
                }
            }
        }
        edges
    }

    /// BFS: find the SHORTEST chain from `start` to `target`.
    /// Returns an empty Vec if no path exists within `max_depth` hops.
    pub fn find_chain(&self, start: &str, target: &str, max_depth: usize) -> Chain {
        if start == target {
            return vec![];
        }

        let mut visited: HashSet<String> = HashSet::new();
        // queue: (current_node, path_so_far)
        let mut queue: VecDeque<(String, Chain)> = VecDeque::new();
        queue.push_back((start.to_string(), vec![]));

        while let Some((current, path)) = queue.pop_front() {
            if visited.contains(&current) {
                continue;
            }
            visited.insert(current.clone());

            if path.len() >= max_depth {
                continue;
            }

            for (rel, next_node) in self.edges_from(&current) {
                let hop = ChainHop::new(current.clone(), rel, next_node.clone());
                let mut new_path = path.clone();
                new_path.push(hop);

                if next_node == target {
                    return new_path;
                }

                if new_path.len() < max_depth && !visited.contains(&next_node) {
                    queue.push_back((next_node, new_path));
                }
            }
        }
        vec![]
    }

    /// DFS: find ALL chains from `start` to `target`, sorted shortest-first.
    pub fn find_all_chains(&self, start: &str, target: &str, max_depth: usize) -> Vec<Chain> {
        let mut results: Vec<Chain> = Vec::new();
        let mut visited: HashSet<String> = HashSet::new();

        self.dfs(start, target, &mut vec![], &mut visited, max_depth, &mut results);

        results.sort_by_key(|c| c.len());
        results
    }

    fn dfs(
        &self,
        current: &str,
        target: &str,
        path: &mut Chain,
        visited: &mut HashSet<String>,
        max_depth: usize,
        results: &mut Vec<Chain>,
    ) {
        if path.len() >= max_depth {
            return;
        }
        if visited.contains(current) {
            return;
        }
        visited.insert(current.to_string());

        for (rel, next_node) in self.edges_from(current) {
            let hop = ChainHop::new(current.to_string(), rel, next_node.clone());
            path.push(hop);

            if next_node == target {
                results.push(path.clone());
            } else {
                self.dfs(&next_node, target, path, visited, max_depth, results);
            }

            path.pop();
        }

        visited.remove(current);
    }

    /// Pretty-print a chain for display or debugging.
    pub fn format_chain(chain: &Chain) -> String {
        if chain.is_empty() {
            return "[no chain]".to_string();
        }
        let mut parts = vec![chain[0].source.clone()];
        for hop in chain {
            parts.push(format!("--{}-->", hop.relation));
            parts.push(hop.target.clone());
        }
        parts.join(" ")
    }

    /// Answer "Is X [property]?" with direct check + transitive fallback.
    /// Confidence = 1.0 for direct, 1/√chain_length for transitive.
    pub fn answer_property_question(&self, subject: &str, property: &str) -> PropertyAnswer {
        // 1. Direct check
        for (rel, obj) in self.edges_from(subject) {
            if obj == property {
                return PropertyAnswer {
                    found: true,
                    answer: "yes",
                    direct: true,
                    chain: vec![ChainHop::new(subject, rel, property)],
                    confidence: 1.0,
                };
            }
            // Explicit negation: "not_fast"
            if obj.starts_with("not_") && &obj[4..] == property {
                return PropertyAnswer {
                    found: true,
                    answer: "no",
                    direct: true,
                    chain: vec![ChainHop::new(subject, rel, obj)],
                    confidence: 1.0,
                };
            }
        }

        // 2. Transitive search
        let chains = self.find_all_chains(subject, property, 4);
        if let Some(best) = chains.into_iter().next() {
            let confidence = 1.0 / (best.len() as f32).sqrt();
            return PropertyAnswer {
                found: true,
                answer: "yes",
                direct: false,
                chain: best,
                confidence,
            };
        }

        PropertyAnswer {
            found: false,
            answer: "unknown",
            direct: false,
            chain: vec![],
            confidence: 0.0,
        }
    }

    /// Answer "Is X [relation] Y?" by comparing property sets of both subjects.
    /// Returns (answer, inference_note).
    pub fn answer_comparison_question(
        &self,
        subject1: &str,
        subject2: &str,
        relation: &str,
    ) -> (&'static str, String) {
        let props1: HashSet<String> = self
            .edges_from(subject1)
            .into_iter()
            .map(|(_, obj)| obj)
            .collect();
        let props2: HashSet<String> = self
            .edges_from(subject2)
            .into_iter()
            .map(|(_, obj)| obj)
            .collect();

        // Explicit size comparison heuristic
        if relation.contains("bigger") || relation.contains("larger") {
            if props1.contains("big") && props2.contains("little") {
                return ("yes", format!("{} is big, {} is little", subject1, subject2));
            }
            if props1.contains("little") && props2.contains("big") {
                return ("no", format!("{} is little, {} is big", subject1, subject2));
            }
        }

        // Shared properties
        let common: HashSet<&String> = props1.intersection(&props2).collect();
        if !common.is_empty() {
            let words: Vec<String> = common.iter().map(|s| s.to_string()).collect();
            return ("similar", format!("both share: {}", words.join(", ")));
        }

        ("unknown", String::new())
    }
}

/// Convenience: build an outgoing adjacency list from RelationalTriple-like data.
/// Accepts any iterator of (subject, relation, object) string triples.
pub fn triples_to_outgoing<I, S>(triples: I) -> HashMap<String, Vec<Edge>>
where
    I: IntoIterator<Item = (S, S, S)>,
    S: AsRef<str>,
{
    let mut out: HashMap<String, Vec<Edge>> = HashMap::new();
    for (s, r, o) in triples {
        out.entry(s.as_ref().to_string())
            .or_insert_with(Vec::new)
            .push((r.as_ref().to_string(), o.as_ref().to_string()));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn build_test_graph() -> HashMap<String, Vec<Edge>> {
        triples_to_outgoing(vec![
            ("spot", "IS", "dog"),
            ("dog", "IS", "animal"),
            ("animal", "CAN", "run"),
            ("dog", "HAS", "fur"),
            ("fur", "IS", "soft"),
            ("cat", "IS", "animal"),
            ("spot", "IS", "fast"),
        ])
    }

    #[test]
    fn test_find_chain_direct() {
        let graph = build_test_graph();
        let tr = TransitiveReasoner::new(&graph);
        let chain = tr.find_chain("spot", "dog", 3);
        assert_eq!(chain.len(), 1);
        assert_eq!(chain[0].relation, "IS");
    }

    #[test]
    fn test_find_chain_multi_hop() {
        let graph = build_test_graph();
        let tr = TransitiveReasoner::new(&graph);
        // spot -> dog -> animal -> run
        let chain = tr.find_chain("spot", "run", 5);
        assert!(!chain.is_empty(), "Should find path spot -> ... -> run");
        assert!(chain.len() <= 3);
    }

    #[test]
    fn test_no_path() {
        let graph = build_test_graph();
        let tr = TransitiveReasoner::new(&graph);
        let chain = tr.find_chain("spot", "nonexistent", 5);
        assert!(chain.is_empty());
    }

    #[test]
    fn test_answer_property_direct() {
        let graph = build_test_graph();
        let tr = TransitiveReasoner::new(&graph);
        let ans = tr.answer_property_question("spot", "fast");
        assert!(ans.found);
        assert_eq!(ans.answer, "yes");
        assert!(ans.direct);
        assert!((ans.confidence - 1.0).abs() < 0.001);
    }

    #[test]
    fn test_answer_property_transitive() {
        let graph = build_test_graph();
        let tr = TransitiveReasoner::new(&graph);
        // spot -> dog -> animal -> run (transitive)
        let ans = tr.answer_property_question("spot", "run");
        assert!(ans.found);
        assert!(!ans.direct);
        assert!(ans.confidence < 1.0);
    }

    #[test]
    fn test_synset_ghost_edges() {
        let graph = triples_to_outgoing(vec![
            ("dog", "CAN", "bark"),
        ]);
        let mut syns = Synsets::new();
        syns.add_group(&["dog", "canine"]);
        let tr = TransitiveReasoner::new(&graph).with_synsets(&syns);
        // "canine" is a synonym for "dog" — ghost IS_SIMILAR edge should connect them
        let chain = tr.find_chain("canine", "bark", 3);
        assert!(!chain.is_empty(), "Ghost edge via synset should bridge canine -> bark");
    }

    #[test]
    fn test_format_chain() {
        let chain = vec![
            ChainHop::new("spot", "IS", "dog"),
            ChainHop::new("dog", "IS", "animal"),
        ];
        let formatted = TransitiveReasoner::format_chain(&chain);
        assert!(formatted.contains("--IS-->"));
        assert!(formatted.contains("spot"));
        assert!(formatted.contains("animal"));
    }

    #[test]
    fn test_find_all_chains_sorted() {
        let graph = build_test_graph();
        let tr = TransitiveReasoner::new(&graph);
        let chains = tr.find_all_chains("spot", "run", 5);
        if chains.len() > 1 {
            // Should be sorted shortest-first
            for i in 1..chains.len() {
                assert!(chains[i].len() >= chains[i - 1].len());
            }
        }
    }
}
