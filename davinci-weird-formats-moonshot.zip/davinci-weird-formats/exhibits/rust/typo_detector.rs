// Typo Detection via Orphan Analysis
// Detects likely typos by finding low-frequency words that are edit-distance-1
// from more frequent words, with confidence scoring.

use std::collections::HashMap;

/// Result of typo detection
#[derive(Debug, Clone)]
pub struct TypoCandidate {
    pub typo: String,
    pub correction: String,
    pub typo_freq: usize,
    pub correction_freq: usize,
    pub confidence: f32,
}

/// Detects typos using orphan analysis
pub struct TypoDetector {
    pub min_freq_threshold: usize,    // Words below this frequency are candidates
    pub max_edit_distance: usize,     // Max allowed edit distance (usually 1)
    pub min_freq_ratio: f32,          // Correction must be N times more frequent
}

impl TypoDetector {
    pub fn new() -> Self {
        Self {
            min_freq_threshold: 5,
            max_edit_distance: 1,
            min_freq_ratio: 2.0,
        }
    }

    /// Calculate edit distance (Levenshtein) between two strings
    fn edit_distance(a: &str, b: &str) -> usize {
        let a_chars: Vec<char> = a.chars().collect();
        let b_chars: Vec<char> = b.chars().collect();
        let a_len = a_chars.len();
        let b_len = b_chars.len();

        if a_len == 0 {
            return b_len;
        }
        if b_len == 0 {
            return a_len;
        }

        // Damerau-Levenshtein distance (Optimal String Alignment variant)
        // Allows: insertion, deletion, substitution, and transposition
        let mut matrix = vec![vec![0; b_len + 1]; a_len + 1];

        for i in 0..=a_len {
            matrix[i][0] = i;
        }
        for j in 0..=b_len {
            matrix[0][j] = j;
        }

        for i in 1..=a_len {
            for j in 1..=b_len {
                let cost = if a_chars[i - 1] == b_chars[j - 1] { 0 } else { 1 };
                matrix[i][j] = std::cmp::min(
                    std::cmp::min(
                        matrix[i - 1][j] + 1,      // deletion
                        matrix[i][j - 1] + 1,      // insertion
                    ),
                    matrix[i - 1][j - 1] + cost,   // substitution
                );
                
                // Transposition: if this char and previous char in a match
                // previous char and current char in b (swapped)
                if i > 1 && j > 1
                    && a_chars[i - 1] == b_chars[j - 2]
                    && a_chars[i - 2] == b_chars[j - 1]
                {
                    matrix[i][j] = std::cmp::min(
                        matrix[i][j],
                        matrix[i - 2][j - 2] + cost,  // transposition
                    );
                }
            }
        }

        let result = matrix[a_len][b_len];
        result
    }

    /// Calculate confidence score for a typo correction
    /// Higher frequency ratio and closer edit distance = higher confidence
    fn compute_confidence(
        &self,
        typo_freq: usize,
        correction_freq: usize,
        edit_dist: usize,
    ) -> f32 {
        if typo_freq == 0 || correction_freq == 0 {
            return 0.0;
        }

        let freq_ratio = correction_freq as f32 / typo_freq as f32;
        
        // Base confidence from frequency ratio
        let freq_confidence = (freq_ratio.min(10.0) / 10.0).min(1.0);
        
        // Boost for edit distance 1 (much more likely than dist 2+)
        let edit_confidence = match edit_dist {
            1 => 1.0,
            2 => 0.5,
            _ => 0.1,
        };
        
        (freq_confidence * 0.7 + edit_confidence * 0.3).min(0.99)
    }

    /// Calculate context overlap between two words using timeline neighbors
    /// Uses hash table to find positions, then crawls timeline ±1 to get adjacent words
    /// BOUNDS-CHECKED: Returns 0.0 if any position is invalid
    pub fn compute_context_overlap(
        &self,
        word1: &str,
        word2: &str,
        token_index: &HashMap<String, Vec<u32>>,
        tokens: &[String],
    ) -> f32 {
        // Get all positions for both words
        let positions_word1 = token_index.get(&word1.to_lowercase()).map(|v| v.as_slice()).unwrap_or(&[]);
        let positions_word2 = token_index.get(&word2.to_lowercase()).map(|v| v.as_slice()).unwrap_or(&[]);

        if positions_word1.is_empty() || positions_word2.is_empty() {
            return 0.0;
        }

        // Collect neighbors for word1 by crawling timeline
        let mut neighbors_word1 = std::collections::HashSet::new();
        for &pos in positions_word1 {
            let pos_usize = pos as usize;
            // BOUNDS CHECK: Skip if position is out of range
            if pos_usize >= tokens.len() {
                continue;
            }
            // Look backwards
            if pos_usize > 0 {
                neighbors_word1.insert(tokens[pos_usize - 1].to_lowercase());
            }
            // Look forwards
            if pos_usize < tokens.len() - 1 {
                neighbors_word1.insert(tokens[pos_usize + 1].to_lowercase());
            }
        }

        // Collect neighbors for word2 by crawling timeline
        let mut neighbors_word2 = std::collections::HashSet::new();
        for &pos in positions_word2 {
            let pos_usize = pos as usize;
            // BOUNDS CHECK: Skip if position is out of range
            if pos_usize >= tokens.len() {
                continue;
            }
            // Look backwards
            if pos_usize > 0 {
                neighbors_word2.insert(tokens[pos_usize - 1].to_lowercase());
            }
            // Look forwards
            if pos_usize < tokens.len() - 1 {
                neighbors_word2.insert(tokens[pos_usize + 1].to_lowercase());
            }
        }

        // Calculate overlap
        if neighbors_word1.is_empty() || neighbors_word2.is_empty() {
            return 0.0;
        }

        let intersection: usize = neighbors_word1.intersection(&neighbors_word2).count();
        let union: usize = neighbors_word1.union(&neighbors_word2).count();

        if union == 0 {
            0.0
        } else {
            (intersection as f32) / (union as f32)
        }
    }

    /// Find typo candidates in word frequency map
    pub fn find_candidates(&self, freq_map: &HashMap<String, usize>) -> Vec<TypoCandidate> {
        let mut candidates = Vec::new();

        // For each low-frequency word
        for (typo, &typo_freq) in freq_map {
            if typo_freq >= self.min_freq_threshold {
                continue; // Not an orphan
            }

            // Find potential corrections (higher frequency, close edit distance)
            let mut best_correction = None;
            let mut best_confidence = 0.0;

            for (potential, &potential_freq) in freq_map {
                if potential == typo {
                    continue;
                }

                // Skip if frequency ratio is too low
                let freq_ratio = potential_freq as f32 / typo_freq as f32;
                if freq_ratio < self.min_freq_ratio {
                    continue;
                }

                // Check edit distance
                let dist = Self::edit_distance(typo, potential);
                if dist > self.max_edit_distance {
                    continue;
                }

                // Calculate confidence
                let confidence = self.compute_confidence(typo_freq, potential_freq, dist);

                if confidence > best_confidence {
                    best_confidence = confidence;
                    best_correction = Some((potential.clone(), potential_freq, confidence));
                }
            }

            // If we found a good candidate, add it
            if let Some((correction, correction_freq, confidence)) = best_correction {
                if confidence > 0.7 {
                    // Only keep high-confidence suggestions
                    candidates.push(TypoCandidate {
                        typo: typo.clone(),
                        correction,
                        typo_freq,
                        correction_freq,
                        confidence,
                    });
                }
            }
        }

        // Sort by confidence descending
        candidates.sort_by(|a, b| b.confidence.partial_cmp(&a.confidence).unwrap());
        candidates
    }

    /// Find typo candidates with context-based confidence boosting
    /// Uses timeline neighbors to increase confidence when two words share context
    pub fn find_candidates_with_context(
        &self,
        freq_map: &HashMap<String, usize>,
        token_index: &HashMap<String, Vec<u32>>,
        tokens: &[String],
    ) -> Vec<TypoCandidate> {
        let mut candidates = self.find_candidates(freq_map);
        
        // Boost confidence based on context overlap
        for candidate in &mut candidates {
            let context_overlap = self.compute_context_overlap(
                &candidate.typo,
                &candidate.correction,
                token_index,
                tokens,
            );
            
            // Apply context boost: up to 0.15 additional confidence for strong overlap
            if context_overlap > 0.3 {
                let context_boost = (context_overlap * 0.15).min(0.15);
                candidate.confidence = (candidate.confidence + context_boost).min(0.99);
            }
        }
        
        // Re-sort by updated confidence
        candidates.sort_by(|a, b| b.confidence.partial_cmp(&a.confidence).unwrap());
        candidates
    }

    /// Apply typo corrections to a string
    /// Returns (corrected_string, list_of_corrections)
    pub fn correct_text(&self, text: &str, candidates: &[TypoCandidate]) -> (String, Vec<(String, String)>) {
        let mut result = text.to_string();
        let mut corrections = Vec::new();

        // Build a correction map (typo -> correction)
        let mut correction_map = HashMap::new();
        for candidate in candidates {
            correction_map.insert(candidate.typo.to_lowercase(), candidate.correction.clone());
        }

        // Split into words, correct, rejoin
        let tokens: Vec<&str> = text.split_whitespace().collect();
        let corrected_tokens: Vec<String> = tokens
            .iter()
            .map(|token| {
                let token_lower = token.to_lowercase();
                // Remove trailing punctuation for matching
                let word_part = token_lower.trim_end_matches(|c: char| !c.is_alphabetic());
                
                if let Some(correction) = correction_map.get(word_part) {
                    corrections.push((token.to_string(), correction.clone()));
                    // Preserve trailing punctuation
                    let punct_part = &token_lower[word_part.len()..];
                    format!("{}{}", correction, punct_part)
                } else {
                    token.to_string()
                }
            })
            .collect();

        (corrected_tokens.join(" "), corrections)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_edit_distance() {
        assert_eq!(TypoDetector::edit_distance("goddess", "godess"), 1);
        assert_eq!(TypoDetector::edit_distance("conscious", "consicous"), 1);
        assert_eq!(TypoDetector::edit_distance("hello", "hello"), 0);
        assert_eq!(TypoDetector::edit_distance("cat", "dog"), 3);
    }

    #[test]
    fn test_typo_detection() {
        let mut freq_map = HashMap::new();
        freq_map.insert("goddess".to_string(), 100);
        freq_map.insert("godess".to_string(), 3);
        freq_map.insert("conscious".to_string(), 80);
        freq_map.insert("consicous".to_string(), 2);

        let detector = TypoDetector::new();
        let candidates = detector.find_candidates(&freq_map);

        assert!(!candidates.is_empty());
        // Both "godess" and "consicous" have the same confidence (1.0)
        // so order is unstable. Check that both are present in results.
        assert_eq!(candidates.len(), 2);
        assert!(candidates.iter().any(|c| c.typo == "godess" && c.correction == "goddess"));
        assert!(candidates.iter().any(|c| c.typo == "consicous" && c.correction == "conscious"));
        // Both should have high confidence
        for candidate in &candidates {
            assert!(candidate.confidence > 0.7);
        }
    }

    #[test]
    fn test_correct_text() {
        let mut freq_map = HashMap::new();
        freq_map.insert("goddess".to_string(), 100);
        freq_map.insert("godess".to_string(), 3);

        let detector = TypoDetector::new();
        let candidates = detector.find_candidates(&freq_map);

        let (corrected, corrections) = detector.correct_text("The godess is wise", &candidates);
        assert!(corrected.contains("goddess"));
        assert_eq!(corrections.len(), 1);
    }
}
