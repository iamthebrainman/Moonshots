//! # Universal Resolver
//!
//! Resolves discourse pointers — deictics, anaphors, and quantifiers — to
//! concrete referents using recent relation triples as context.
//!
//! Handled expressions:
//!   this / here / now  → most recent subject (or object if subject is deictic)
//!   that / there / then → second-most-recent non-deictic subject
//!   it                  → first singular candidate from recent triples
//!   they / them         → full set of recent candidates (plural)
//!   either / both       → two most salient recent noun phrases
//!   neither             → empty set (negation of salient pair)

use std::collections::HashSet;

/// A simplified triple snapshot used for resolution context.
/// Mirrors the 5-tuple from Python: (subject, relation, object, position, mods).
#[derive(Debug, Clone)]
pub struct ContextTriple {
    pub subject: String,
    pub relation: String,
    pub object: String,
    pub position: u32,
    pub mods: Vec<String>,
}

impl ContextTriple {
    pub fn new(subject: impl Into<String>, relation: impl Into<String>, object: impl Into<String>, position: u32) -> Self {
        Self {
            subject: subject.into(),
            relation: relation.into(),
            object: object.into(),
            position,
            mods: Vec::new(),
        }
    }
}

/// Result of a resolution call — either a single referent or a set.
#[derive(Debug, Clone)]
pub enum Resolved {
    /// Single concrete referent (deictics, 'it', singular anaphora)
    One(String),
    /// Set of referents ('either', 'both', 'they', 'them')
    Many(HashSet<String>),
    /// Could not resolve
    None,
}

impl Resolved {
    /// Unwrap to a single string (first element for Many).
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Resolved::One(s) => Some(s.as_str()),
            Resolved::Many(set) => set.iter().next().map(|s| s.as_str()),
            Resolved::None => None,
        }
    }
}

/// Words that are themselves discourse pointers — not useful as referents.
const DEICTICS: &[&str] = &[
    "this", "here", "now", "that", "there", "then",
    "it", "they", "them", "either", "both", "neither",
];

fn is_deictic(word: &str) -> bool {
    DEICTICS.contains(&word.to_lowercase().as_str())
}

/// The resolver. Takes a snapshot of recent triples each time you call `resolve`.
pub struct UniversalResolver;

impl UniversalResolver {
    pub fn new() -> Self {
        Self
    }

    /// Resolve `expression` against `recent_triples` (newest-first order).
    ///
    /// `n` limits how many recent triples to consider.
    /// `skip` skips the first N triples (used when the current sentence has
    /// already contributed new triples that shouldn't self-resolve).
    pub fn resolve(
        &self,
        expression: &str,
        recent_triples: &[ContextTriple],
        n: usize,
        skip: usize,
    ) -> Resolved {
        let expr = expression.trim().to_lowercase();
        let window: &[ContextTriple] = {
            let start = skip.min(recent_triples.len());
            let end = (start + n).min(recent_triples.len());
            &recent_triples[start..end]
        };

        match expr.as_str() {
            "this" | "here" | "now" => self.resolve_deictic_this(window),
            "that" | "there" | "then" => self.resolve_deictic_that(window),
            "either" | "both" => Resolved::Many(self.resolve_quantifier_either(window)),
            "neither" => Resolved::Many(HashSet::new()),
            "it" => self.resolve_anaphor_it(window),
            "they" | "them" => self.resolve_anaphor_plural(window),
            _ => Resolved::One(expression.to_string()), // literal passthrough
        }
    }

    // --- Deictic resolution ---

    /// "this" → most recent subject, falling back to object if subject is itself deictic.
    fn resolve_deictic_this(&self, window: &[ContextTriple]) -> Resolved {
        if window.is_empty() {
            return Resolved::None;
        }
        let t = &window[0];
        if is_deictic(&t.subject) {
            if !t.object.is_empty() {
                return Resolved::One(t.object.clone());
            }
        }
        if !t.subject.is_empty() {
            return Resolved::One(t.subject.clone());
        }
        if !t.object.is_empty() {
            return Resolved::One(t.object.clone());
        }
        Resolved::None
    }

    /// "that" → second-most-recent non-empty subject/object.
    /// If the most recent subject is deictic, prefer its object.
    fn resolve_deictic_that(&self, window: &[ContextTriple]) -> Resolved {
        if let Some(first) = window.first() {
            if is_deictic(&first.subject) && !first.object.is_empty() {
                return Resolved::One(first.object.clone());
            }
        }
        // Walk triples looking for the second non-deictic referent
        for triple in window.iter().skip(1) {
            if !triple.subject.is_empty() && !is_deictic(&triple.subject) {
                return Resolved::One(triple.subject.clone());
            }
            if !triple.object.is_empty() && !is_deictic(&triple.object) {
                return Resolved::One(triple.object.clone());
            }
        }
        // Fallback: most recent
        if let Some(first) = window.first() {
            if !first.subject.is_empty() {
                return Resolved::One(first.subject.clone());
            }
            if !first.object.is_empty() {
                return Resolved::One(first.object.clone());
            }
        }
        Resolved::None
    }

    // --- Quantifier resolution ---

    fn resolve_quantifier_either(&self, window: &[ContextTriple]) -> HashSet<String> {
        let mut items: Vec<String> = Vec::new();
        for triple in window {
            if !triple.subject.is_empty() && !is_deictic(&triple.subject) && !items.contains(&triple.subject) {
                items.push(triple.subject.clone());
            }
            if !triple.object.is_empty() && !is_deictic(&triple.object) && !items.contains(&triple.object) {
                items.push(triple.object.clone());
            }
            if items.len() >= 2 {
                break;
            }
        }
        items.into_iter().collect()
    }

    // --- Anaphora resolution ---

    fn resolve_anaphor_it(&self, window: &[ContextTriple]) -> Resolved {
        // "it" → first singular-sounding candidate
        let candidates = self.flatten_candidates(window);
        match candidates.into_iter().next() {
            Some(c) => Resolved::One(c),
            None => Resolved::None,
        }
    }

    fn resolve_anaphor_plural(&self, window: &[ContextTriple]) -> Resolved {
        let candidates = self.flatten_candidates(window);
        Resolved::Many(candidates.into_iter().collect())
    }

    fn flatten_candidates(&self, window: &[ContextTriple]) -> Vec<String> {
        let mut cand: Vec<String> = Vec::new();
        for triple in window {
            if !triple.subject.is_empty() && !is_deictic(&triple.subject) && !cand.contains(&triple.subject) {
                cand.push(triple.subject.clone());
            }
            if !triple.object.is_empty() && !is_deictic(&triple.object) && !cand.contains(&triple.object) {
                cand.push(triple.object.clone());
            }
        }
        cand
    }
}

impl Default for UniversalResolver {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn triples(data: &[(&str, &str, &str)]) -> Vec<ContextTriple> {
        data.iter()
            .enumerate()
            .map(|(i, (s, r, o))| ContextTriple::new(*s, *r, *o, i as u32))
            .collect()
    }

    #[test]
    fn test_this_resolves_to_most_recent_subject() {
        let recent = triples(&[("dog", "IS", "animal"), ("cat", "HAS", "fur")]);
        let r = UniversalResolver::new();
        // Newest-first: "dog" triple is [0], "cat" is [1]
        match r.resolve("this", &recent, 5, 0) {
            Resolved::One(s) => assert_eq!(s, "dog"),
            other => panic!("Expected One, got {:?}", other),
        }
    }

    #[test]
    fn test_this_skips_deictic_subject() {
        let recent = triples(&[("this", "IS", "bolt")]);
        let r = UniversalResolver::new();
        match r.resolve("this", &recent, 5, 0) {
            Resolved::One(s) => assert_eq!(s, "bolt"),
            other => panic!("Expected One(bolt), got {:?}", other),
        }
    }

    #[test]
    fn test_that_returns_second_most_recent() {
        let recent = triples(&[("dog", "IS", "animal"), ("cat", "HAS", "fur"), ("bird", "CAN", "fly")]);
        let r = UniversalResolver::new();
        match r.resolve("that", &recent, 5, 0) {
            Resolved::One(s) => assert_eq!(s, "cat"),
            other => panic!("Expected One(cat), got {:?}", other),
        }
    }

    #[test]
    fn test_either_returns_two_items() {
        let recent = triples(&[("dog", "IS", "animal"), ("cat", "IS", "animal")]);
        let r = UniversalResolver::new();
        match r.resolve("either", &recent, 5, 0) {
            Resolved::Many(set) => assert_eq!(set.len(), 2),
            other => panic!("Expected Many(2), got {:?}", other),
        }
    }

    #[test]
    fn test_neither_returns_empty() {
        let recent = triples(&[("dog", "IS", "animal")]);
        let r = UniversalResolver::new();
        match r.resolve("neither", &recent, 5, 0) {
            Resolved::Many(set) => assert!(set.is_empty()),
            other => panic!("Expected empty Many, got {:?}", other),
        }
    }

    #[test]
    fn test_it_returns_first_candidate() {
        let recent = triples(&[("engine", "IS", "running"), ("pump", "HAS", "motor")]);
        let r = UniversalResolver::new();
        match r.resolve("it", &recent, 5, 0) {
            Resolved::One(s) => assert_eq!(s, "engine"),
            other => panic!("Expected One, got {:?}", other),
        }
    }

    #[test]
    fn test_literal_passthrough() {
        let recent = triples(&[("dog", "IS", "animal")]);
        let r = UniversalResolver::new();
        match r.resolve("robot", &recent, 5, 0) {
            Resolved::One(s) => assert_eq!(s, "robot"),
            other => panic!("Expected passthrough, got {:?}", other),
        }
    }
}
