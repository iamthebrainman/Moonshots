//! # WASM Bindings
//!
//! Exposes the carousel encoder + hash table to JavaScript/TypeScript
//! via wasm-bindgen.
//!
//! Build with: `wasm-pack build --target web --release`

use wasm_bindgen::prelude::*;
use crate::carousel;
use crate::table::{HashTable24, SlotKind};
use crate::ingest;
use crate::persist;

/// The WASM-accessible hash table wrapper.
#[wasm_bindgen]
pub struct WasmHashTable {
    table: HashTable24,
    tokens: Vec<String>, // keep token strings for generation
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extract_semantic_triples_binary_roundtrip() {
        let mut wh = WasmHashTable::new(20);
        let text = "the dog is an animal and the dog can bark";
        wh.ingest(text);

        let bin = wh.extract_semantic_triples_binary(text);
        let dv = std::io::Cursor::new(&bin);
        // Read count
        let count = u32::from_le_bytes([bin[0], bin[1], bin[2], bin[3]]) as usize;
        assert!(count >= 1);

        // Very minimal parse to ensure buffer contains expected subject
        let mut offset = 4usize;
        // parse first triple
        let subj_len = bin[offset] as usize; offset += 1;
        let subj_bytes = &bin[offset..offset+subj_len]; offset += subj_len;
        let subj = crate::carousel::decode_bytes(subj_bytes);
        assert!(subj == "dog" || subj == "the");
    }

    #[test]
    fn test_get_top_n_words_with_frequency_binary() {
        let mut wh = WasmHashTable::new(20);
        let text = "the dog is an animal and the dog can bark";
        wh.ingest(text);

        let bin = wh.get_top_n_words_with_frequency_binary(10);
        let count = u32::from_le_bytes([bin[0], bin[1], bin[2], bin[3]]) as usize;
        assert!(count >= 1);

        // parse first word
        let mut offset = 4usize;
        let wlen = bin[offset] as usize; offset += 1;
        let wbytes = &bin[offset..offset+wlen]; offset += wlen;
        let w = crate::carousel::decode_bytes(wbytes);
        // 'the' or 'dog' should appear in top words
        assert!(w == "the" || w == "dog");
    }
}

#[wasm_bindgen]
impl WasmHashTable {
    /// Create a new table. `bits` controls size: 24 = full 16M, 20 = 1M, etc.
    #[wasm_bindgen(constructor)]
    pub fn new(bits: u32) -> Self {
        Self {
            table: HashTable24::new_sized(bits.min(24)),
            tokens: Vec::new(),
        }
    }

    /// Ingest a text corpus. Returns number of tokens processed.
    pub fn ingest(&mut self, text: &str) -> usize {
        // Store tokens for generation
        self.tokens = text.split_whitespace().map(|s| s.to_string()).collect();
        ingest::ingest_corpus(&mut self.table, text)
    }

    /// Look up a single word. Returns its corpus position, or -1 if not found.
    pub fn lookup_word(&self, word: &str) -> i64 {
        match self.table.get_word(word) {
            Some(slot) => slot.value as i64,
            None => -1,
        }
    }

    /// Look up a bigram. Returns position of second word, or -1.
    pub fn lookup_bigram(&self, w1: &str, w2: &str) -> i64 {
        match self.table.get_bigram(w1, w2) {
            Some(slot) => slot.value as i64,
            None => -1,
        }
    }

    /// Get word frequency (score) for a word. Returns 0 if not found.
    pub fn word_frequency(&self, word: &str) -> u16 {
        match self.table.get_word(word) {
            Some(slot) => slot.score,
            None => 0,
        }
    }

    /// Encode a string to carousel bytes, return as hex string for debugging.
    pub fn encode_hex(&self, text: &str) -> String {
        carousel::encode_string(text)
            .iter()
            .map(|b| format!("{:08b}", b))
            .collect::<Vec<_>>()
            .join(" ")
    }

    /// Encode a string and return the carousel binary as a string of 0s and 1s.
    pub fn encode_binary(&self, text: &str) -> String {
        carousel::encode_string(text)
            .iter()
            .map(|b| format!("{:08b}", b))
            .collect::<Vec<_>>()
            .join("")
    }

    /// Get the token at a corpus position.
    pub fn token_at(&self, pos: usize) -> Option<String> {
        self.tokens.get(pos).cloned()
    }

    /// Generate N tokens starting from a word (simple chain).
    pub fn generate(&self, start_word: &str, max_tokens: usize) -> String {
        let mut result = vec![start_word.to_string()];
        let mut current = start_word.to_string();

        for _ in 0..max_tokens {
            let encoded = carousel::encode_string(&current);
            if let Some(slot) = self.table.get(&encoded) {
                let next_pos = slot.value as usize + 1;
                if let Some(next) = self.tokens.get(next_pos) {
                    result.push(next.clone());
                    current = next.clone();
                } else {
                    break;
                }
            } else {
                break;
            }
        }
        result.join(" ")
    }

    /// Table statistics as a JSON string.
    pub fn stats_json(&self) -> String {
        let stats = self.table.stats();
        format!(
            r#"{{"count":{},"capacity":{},"load_factor":{:.6},"avg_probes":{:.4},"max_probes":{}}}"#,
            stats.count, stats.capacity, stats.load_factor, stats.avg_probes, stats.max_probes
        )
    }

    /// Number of entries in the table.
    pub fn count(&self) -> usize {
        self.table.count
    }

    /// Extract semantic triples from text and return a binary-packed Vec<u8>.
    /// Format: [u32 count] [triple1_bytes] [triple2_bytes] ...
    pub fn extract_semantic_triples_binary(&self, text: &str) -> Vec<u8> {
        let triples = crate::relations::extract_relations(text);
        let mut all_bytes = Vec::new();
        all_bytes.extend_from_slice(&(triples.len() as u32).to_le_bytes());
        for triple in triples {
            all_bytes.extend_from_slice(&triple.to_binary());
        }
        all_bytes
    }

    /// Get neighbor words for a given word from the hash table (bigram slots).
    /// Returns words that appear immediately before or after the word in the corpus.
    /// Format: [u32 count] [u8 word_len] [word_bytes] ... (same as top-words, no freq).
    /// No JSON — pure binary. Instant scan over Bigram slots.
    pub fn get_neighbor_words_binary(&self, word: &str, max_neighbors: usize) -> Vec<u8> {
        use std::collections::HashSet;
        let word_lower = word.to_lowercase();
        let mut seen: HashSet<String> = HashSet::new();
        let mut neighbors: Vec<Vec<u8>> = Vec::new();

        for slot in &self.table.slots {
            if slot.kind != SlotKind::Bigram as u8 {
                continue;
            }
            let key_len = slot.key_len as usize;
            if key_len == 0 {
                continue;
            }
            let key = &slot.key[..key_len.min(16)];
            let sep = match key.iter().position(|&b| b == 0xFF) {
                Some(i) => i,
                None => continue,
            };
            let (first, second) = key.split_at(sep);
            let second = &second[1..]; // skip 0xFF
            if first.is_empty() || second.is_empty() {
                continue;
            }
            let w1 = carousel::decode_bytes(first).to_lowercase();
            let w2 = carousel::decode_bytes(second).to_lowercase();
            if w1 == word_lower && seen.insert(w2.clone()) {
                neighbors.push(carousel::encode_string(&w2));
                if neighbors.len() >= max_neighbors {
                    break;
                }
            } else if w2 == word_lower && seen.insert(w1.clone()) {
                neighbors.push(carousel::encode_string(&w1));
                if neighbors.len() >= max_neighbors {
                    break;
                }
            }
        }

        let mut out = Vec::new();
        out.extend_from_slice(&(neighbors.len() as u32).to_le_bytes());
        for encoded in neighbors {
            out.push(encoded.len() as u8);
            out.extend_from_slice(&encoded);
        }
        out
    }

    /// Get top N words with their frequencies as a binary-packed Vec<u8>.
    /// Format: [u32 count] [u8 word_len] [word_bytes] [u16 freq] ...
    pub fn get_top_n_words_with_frequency_binary(&self, n: usize) -> Vec<u8> {
        let mut words_with_freq: Vec<(Vec<u8>, u16)> = Vec::new();

        for i in 0..self.table.slots.len() {
            let slot = &self.table.slots[i];
            if slot.kind == SlotKind::Word as u8 && slot.score > 0 {
                let encoded = slot.key[..slot.key_len as usize].to_vec();
                words_with_freq.push((encoded, slot.score));
            }
        }

        words_with_freq.sort_by(|a, b| b.1.cmp(&a.1));

        let mut all_bytes = Vec::new();
        // Only advertise the number of words we will actually serialize (take n)
        let take_count = std::cmp::min(words_with_freq.len(), n);
        all_bytes.extend_from_slice(&(take_count as u32).to_le_bytes());

        for (encoded_word, freq) in words_with_freq.into_iter().take(take_count) {
            all_bytes.push(encoded_word.len() as u8);
            all_bytes.extend_from_slice(&encoded_word);
            all_bytes.extend_from_slice(&freq.to_le_bytes());
        }
        all_bytes
    }

    /// Serialize table to binary and return as base64 for transmission to browser.
    /// Note: in browser context, use persist directly with File/Blob APIs.
    pub fn to_binary(&self) -> Result<Vec<u8>, JsValue> {
        let mut buf = Vec::new();
        // Write header manually for wasm context
        buf.extend_from_slice(b"CRSL\x00\x24\x00\x01"); // magic
        buf.extend_from_slice(&(1u32).to_le_bytes()); // version
        buf.extend_from_slice(&(self.table.slots.len() as u32).to_le_bytes()); // slot count
        buf.extend_from_slice(&(self.table.count as u64).to_le_bytes()); // entry count
        buf.extend_from_slice(&(self.table.max_probe_depth as u32).to_le_bytes()); // max probe
        
        // Compute checksum
        let slot_bytes: &[u8] = unsafe {
            std::slice::from_raw_parts(
                self.table.slots.as_ptr() as *const u8,
                self.table.slots.len() * 40,
            )
        };
        let mut checksum: u32 = 0;
        for chunk in slot_bytes.chunks(4) {
            let word = if chunk.len() == 4 {
                u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]])
            } else {
                chunk.iter().enumerate()
                    .map(|(i, &b)| (b as u32) << (i * 8))
                    .fold(0, |a, b| a ^ b)
            };
            checksum ^= word;
        }
        
        buf.extend_from_slice(&checksum.to_le_bytes());
        buf.extend_from_slice(&[0u8; 32]); // reserved
        buf.extend_from_slice(slot_bytes);
        
        Ok(buf)
    }
}

/// Load a table from binary data (used with persist module).
/// Returns a new WasmHashTable ready for queries.
#[wasm_bindgen]
pub fn load_from_binary(data: &[u8]) -> Result<WasmHashTable, JsValue> {
    // For now, in WASM context, you'd typically use the browser's IndexedDB
    // or upload a pre-serialized table. This is a placeholder for future enhancement.
    Err(JsValue::from_str(
        "load_from_binary not yet implemented in WASM context. \
         Use browser IndexedDB or upload pre-serialized tables.",
    ))
}

/// Standalone carousel encode for quick testing.
#[wasm_bindgen]
pub fn carousel_encode(text: &str) -> Vec<u8> {
    carousel::encode_string(text)
}

/// Standalone carousel decode.
#[wasm_bindgen]
pub fn carousel_decode(bytes: &[u8]) -> String {
    carousel::decode_bytes(bytes)
}
