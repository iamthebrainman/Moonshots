//! WORD Engine - Unified CLI
//! 
//! A consolidated command-line interface for the Carousel-Hash WORD Engine.
//! Replaces word_demo, mind_v5 shell, and other CLI binaries with a unified interface.
//!
//! Usage:
//!   word shell              - Interactive shell mode (default)
//!   word chat <mind>        - Chat with a trained mind
//!   word ingest <file>      - Ingest text/JSON files
//!   word query <mind> <q>   - Query a mind
//!   word create <name>      - Create a new mind
//!   word train <mind> <dir> - Train mind from directory
//!   word list               - List available minds
//!   word stats <mind>       - Show mind statistics
//!   word save <mind>        - Save mind state
//!   word load <mind>        - Load mind state
//!   word bench <mind>       - Run benchmarks
//!
//! Examples:
//!   word create mymind
//!   word train mymind ./data
//!   word query mymind "What is consciousness?"
//!   word chat mymind

use carousel_hash::{
    WordEngine, QueryResult, SynthesisMethod,
    KnowledgeSource, DefinitionStyle,
    persist, crsl_loader,
    synsets::Synsets,
    transitive_reasoner::{TransitiveReasoner, triples_to_outgoing},
    universal_resolver::{UniversalResolver, ContextTriple},
    perspective::{PerspectiveTranslator, Perspective, finalize_student_perspective},
    error_corrector::{RelationalErrorCorrector, to_triple_set},
    semantic_matcher::{SemanticMatcher, build_by_object},
    dada_engine::Speaker,
    pathway_table::PathwayTable,
    conversation_learner::ConversationLearner,
    lexer::{Lexer, TokKind},
    relations::select_pipeline,
    table::RelationType,
};
use std::collections::{HashMap, HashSet};
use std::io::{self, Write};
use std::path::PathBuf;
use std::fs;
use serde_json::{json, Value};

// ---------------------------------------------------------------------------
// Mind container (from mind_v5)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq)]
enum MindMode {
    Normal,
    Student,
}

/// Lightweight query routing for fast-path handlers
#[derive(Debug, Clone, Copy, PartialEq)]
enum Route {
    DefUserName,
    DefThing,
    Cause,
    Manner,
    Time,
    Place,
    Capability,
    Similarity,
    Path,
    Verification,  // yes/no identity/property checks: "Are you X?", "Is X Y?"
    Correction,
    GenericQA,
}

/// Thought loop types for parallel competition
#[derive(Debug, Clone, Copy, PartialEq, Hash, Eq)]
enum ThoughtType {
    Cause,
    Time,
    Place,
    Capability,
    Path,
    Similarity,
    Generic,
}

// ═══════════════════════════════════════════════════════════════════
// UNIVERSAL OPERATOR ALGEBRA — EQUATION DECOMPOSITION (Step 0)
//
// Decomposes ANY utterance (question or assertion) into a canonical
// equation form: (subject, operator, object, slot_missing, tense, negated)
//
// This replaces the ad-hoc detect_route, parse_wh_query, and
// parse_equational_query with a single unified algebra.
//
// Design principles (from plan-universalOperatorAlgebra.prompt.md):
// - P1: Triple store is append-only, time wins
// - P2: Relation words are operators (positional), not nouns
// - P3: Subjects/objects are full spans, not single words
// - P4: Aux verb tense IS the temporal query slot
// ═══════════════════════════════════════════════════════════════════

/// Which slot is missing in the equation (determines query type)
#[derive(Debug, Clone, Copy, PartialEq)]
enum SlotMissing {
    None,          // Assertion: all slots filled → ingest
    Subject,       // WH replaces subject → "What is Y?" → look up (?, Op, Y)
    Object,        // WH replaces object → "Where does X live?" → look up (X, Op, ?)
    Verification,  // Yes/no question: all slots filled, truth value missing
}

/// Temporal retrieval mode derived from aux verb tense
#[derive(Debug, Clone, Copy, PartialEq)]
enum TemporalMode {
    Latest,    // Present tense → most recent entry
    Previous,  // Past tense → one step back
    History,   // Full timeline for diff/count queries
}

/// The canonical equation form for any utterance
#[derive(Debug, Clone)]
struct Equation {
    subject: Option<String>,      // Full noun phrase span (P3)
    operator: RelationType,       // From bidirectional operator table
    object: Option<String>,       // Full noun phrase span (P3)
    slot: SlotMissing,            // Which slot the WH-word replaces
    tense: Tense,                 // Aux verb tense → temporal mode (P4)
    negated: bool,                // Surface negation detected
    raw_input: String,            // Original input for debugging
}

impl Equation {
    /// Derive the legacy Route enum from this Equation (for debug tracing)
    fn to_route(&self) -> Route {
        match self.slot {
            SlotMissing::None => Route::Correction,  // Assertion (negated or not)
            SlotMissing::Subject => Route::DefThing,                  // Definition query
            SlotMissing::Object => {
                // Object-missing depends on operator family
                match self.operator {
                    RelationType::IS_IN | RelationType::IS_AT | RelationType::IS_ON => Route::Place,
                    RelationType::BEFORE | RelationType::AFTER => Route::Time,
                    RelationType::CAUSES | RelationType::CAUSED_BY => Route::Cause,
                    _ => Route::GenericQA,
                }
            }
            SlotMissing::Verification => Route::Verification,
        }
    }
    
    /// Get temporal retrieval mode
    fn temporal_mode(&self) -> TemporalMode {
        match self.tense {
            Tense::Present => TemporalMode::Latest,
            Tense::Past => TemporalMode::Previous,
            Tense::Future => TemporalMode::Latest,  // Future = speculative, use latest
        }
    }
    
    /// Get the RelationType family mask for filtered chain traversal
    fn family_filter(&self) -> Option<u16> {
        let opcode = self.operator as u16;
        Some(opcode & 0xFF00)
    }
}

/// Bidirectional operator lookup: surface word → RelationType
/// (Inverse direction: RelationType → surface word is used for linearization)
fn word_to_operator(word: &str) -> Option<RelationType> {
    match word.to_lowercase().as_str() {
        // Identity family (0x00xx)
        "is" | "are" | "am" | "be" | "was" | "were" | "been" | "being" => Some(RelationType::IS),
        
        // Capability family (0x01xx)
        "can" | "could" | "able" => Some(RelationType::CAN),
        
        // Possession family (0x02xx)
        "has" | "have" | "had" => Some(RelationType::HAS),
        "owns" | "own" | "owned" => Some(RelationType::OWNS),
        "possesses" | "possess" | "possessed" => Some(RelationType::POSSESSES),
        
        // Location family (0x03xx)
        "in" => Some(RelationType::IS_IN),
        "on" => Some(RelationType::IS_ON),
        "at" => Some(RelationType::IS_AT),
        "under" | "beneath" | "below" => Some(RelationType::IS_UNDER),
        "near" | "nearby" | "close" => Some(RelationType::IS_NEAR),
        "between" => Some(RelationType::IS_BETWEEN),
        "lives" | "resides" | "located" => Some(RelationType::IS_IN),
        
        // Action family (0x04xx)
        "does" | "do" | "did" => Some(RelationType::DOES),
        "performs" | "perform" | "performed" => Some(RelationType::PERFORMED),
        
        // Attribute family (0x05xx)
        "described" | "characterized" => Some(RelationType::IS_DESCRIBED_BY),
        
        // Comparison family (0x06xx)
        "equals" | "equal" | "same" => Some(RelationType::EQUALS),
        "like" | "similar" | "resembles" => Some(RelationType::LIKE),
        "greater" | "more" | "larger" | "bigger" => Some(RelationType::GREATER_THAN),
        "less" | "fewer" | "smaller" => Some(RelationType::LESS_THAN),
        "opposite" | "contrary" => Some(RelationType::OPPOSITE_OF),
        
        // Causal family (0x07xx)
        "causes" | "cause" | "caused" => Some(RelationType::CAUSES),
        "because" | "due" | "since" => Some(RelationType::CAUSED_BY),
        "prevents" | "prevent" | "prevented" | "stops" => Some(RelationType::PREVENTS),
        "enables" | "enable" | "enabled" | "allows" => Some(RelationType::ENABLES),
        "requires" | "require" | "required" | "needs" => Some(RelationType::REQUIRES),
        "leads" | "results" => Some(RelationType::LEADS_TO),
        "triggers" | "trigger" | "triggered" => Some(RelationType::TRIGGERS),
        
        // Part-whole family (0x08xx)
        "part" | "portion" | "piece" => Some(RelationType::PART_OF),
        "contains" | "contain" | "contained" | "includes" => Some(RelationType::CONTAINS),
        "made" | "composed" | "consists" => Some(RelationType::MADE_OF),
        
        // Family relations (0x09xx)
        "parent" | "father" | "mother" => Some(RelationType::PARENT_OF),
        "child" | "son" | "daughter" => Some(RelationType::CHILD_OF),
        "sibling" | "brother" | "sister" => Some(RelationType::SIBLING_OF),
        "spouse" | "husband" | "wife" | "married" => Some(RelationType::SPOUSE_OF),
        "related" | "kin" | "family" => Some(RelationType::RELATED_TO),
        
        // Temporal family (0x0Axx)
        "before" | "precedes" | "prior" => Some(RelationType::BEFORE),
        "after" | "follows" | "following" => Some(RelationType::AFTER),
        "during" | "while" => Some(RelationType::DURING),
        "concurrent" | "simultaneously" => Some(RelationType::CONCURRENT_WITH),
        
        // Purpose family (0x0Bxx)
        "purpose" | "goal" | "aim" | "objective" => Some(RelationType::PURPOSE_OF),
        "means" | "way" | "method" => Some(RelationType::MEANS_FOR),
        "intended" | "meant" | "designed" => Some(RelationType::INTENDED_FOR),
        
        // Role family (0x0Cxx)
        "role" | "function" | "job" => Some(RelationType::ROLE_OF),
        "agent" | "actor" | "doer" => Some(RelationType::AGENT_IN),
        "instrument" | "tool" | "using" => Some(RelationType::INSTRUMENT_FOR),
        
        // Source family (0x0Dxx)
        "origin" | "source" | "from" => Some(RelationType::SOURCE_OF),
        "derived" | "comes" | "originates" => Some(RelationType::DERIVED_FROM),
        
        // Knowledge family (0x0Exx)
        "knows" | "know" | "knew" => Some(RelationType::KNOWS),
        "believes" | "believe" | "believed" => Some(RelationType::BELIEVES),
        "thinks" | "think" | "thought" => Some(RelationType::THINKS),
        "understands" | "understand" | "understood" => Some(RelationType::UNDERSTANDS),
        "aware" | "conscious" => Some(RelationType::AWARE_OF),
        
        // Association family (0x0Fxx)
        "associated" | "linked" | "connected" => Some(RelationType::ASSOCIATED_WITH),
        "correlated" | "corresponds" => Some(RelationType::CORRELATED_WITH),
        
        // Emotional family (0x14xx)
        "feels" | "feel" | "felt" => Some(RelationType::FEELS),
        "fears" | "fear" | "feared" | "afraid" => Some(RelationType::FEARS),
        "hopes" | "hope" | "hoped" => Some(RelationType::HOPES),
        "cares" | "care" | "cared" => Some(RelationType::CARES),
        
        // Constraint family (0x12xx)
        "but" | "however" | "yet" => Some(RelationType::BUT),
        "despite" | "although" | "though" => Some(RelationType::DESPITE),
        "unless" | "except" => Some(RelationType::UNLESS),
        
        _ => None,
    }
}

/// Operator → canonical surface word (for linearization)
fn operator_to_word(op: RelationType) -> &'static str {
    match op {
        // Identity
        RelationType::IS | RelationType::IS_A => "is",
        RelationType::IS_NOT => "is not",
        RelationType::IS_SAME_AS => "is the same as",
        RelationType::IS_DIFFERENT_FROM => "is different from",
        
        // Capability
        RelationType::CAN | RelationType::ABLE_TO | RelationType::CAPABLE_OF => "can",
        RelationType::CAN_NOT => "cannot",
        RelationType::CAN_BE => "can be",
        
        // Possession
        RelationType::HAS | RelationType::HAS_A => "has",
        RelationType::HAS_NOT => "has no",
        RelationType::OWNS => "owns",
        RelationType::POSSESSES => "possesses",
        
        // Location
        RelationType::IS_IN => "is in",
        RelationType::IS_AT => "is at",
        RelationType::IS_ON => "is on",
        RelationType::IS_UNDER => "is under",
        RelationType::IS_NEAR => "is near",
        RelationType::IS_BETWEEN => "is between",
        
        // Action
        RelationType::DOES => "does",
        RelationType::DID => "did",
        RelationType::WILL_DO => "will do",
        RelationType::ACTION | RelationType::PERFORMED => "performed",
        
        // Comparison
        RelationType::EQUALS => "equals",
        RelationType::LIKE | RelationType::SIMILAR_TO => "is like",
        RelationType::GREATER_THAN => "is greater than",
        RelationType::LESS_THAN => "is less than",
        RelationType::OPPOSITE_OF => "is opposite of",
        
        // Causal
        RelationType::CAUSES => "causes",
        RelationType::CAUSED_BY | RelationType::BECAUSE => "is caused by",
        RelationType::PREVENTS => "prevents",
        RelationType::ENABLES => "enables",
        RelationType::REQUIRES => "requires",
        RelationType::EFFECT_OF => "is an effect of",
        RelationType::REASON_FOR => "is the reason for",
        RelationType::LEADS_TO => "leads to",
        RelationType::TRIGGERS => "triggers",
        
        // Part-whole
        RelationType::PART_OF => "is part of",
        RelationType::CONTAINS | RelationType::INCLUDES => "contains",
        RelationType::MADE_OF => "is made of",
        RelationType::COMPONENT_OF => "is a component of",
        
        // Family
        RelationType::PARENT_OF => "is a parent of",
        RelationType::CHILD_OF => "is a child of",
        RelationType::SIBLING_OF => "is a sibling of",
        RelationType::SPOUSE_OF => "is married to",
        RelationType::RELATED_TO => "is related to",
        RelationType::DESCENDANT_OF => "is a descendant of",
        
        // Temporal
        RelationType::BEFORE | RelationType::PRECEDES => "is before",
        RelationType::AFTER | RelationType::FOLLOWS => "is after",
        RelationType::DURING => "is during",
        RelationType::CONCURRENT_WITH => "is concurrent with",
        
        // Purpose
        RelationType::PURPOSE_OF | RelationType::GOAL_OF => "is the purpose of",
        RelationType::MEANS_FOR => "is the means for",
        RelationType::INTENDED_FOR => "is intended for",
        
        // Role
        RelationType::ROLE_OF | RelationType::FUNCTION_OF => "is the role of",
        RelationType::AGENT_IN => "is the agent in",
        RelationType::PATIENT_OF => "is affected by",
        RelationType::INSTRUMENT_FOR => "is an instrument for",
        
        // Source
        RelationType::ORIGIN_OF | RelationType::SOURCE_OF => "is the source of",
        RelationType::DERIVED_FROM => "is derived from",
        RelationType::MEDIUM_FOR => "is the medium for",
        
        // Knowledge
        RelationType::KNOWS => "knows",
        RelationType::BELIEVES => "believes",
        RelationType::THINKS => "thinks",
        RelationType::UNDERSTANDS => "understands",
        RelationType::AWARE_OF => "is aware of",
        
        // Association
        RelationType::ASSOCIATED_WITH => "is associated with",
        RelationType::RELATED_BY => "is related by",
        RelationType::LINKED_TO => "is linked to",
        RelationType::CONNECTED_TO => "is connected to",
        RelationType::CORRELATED_WITH => "is correlated with",
        
        // Emotional
        RelationType::FEELS => "feels",
        RelationType::FEARS => "fears",
        RelationType::HOPES => "hopes",
        RelationType::CARES => "cares about",
        RelationType::RESENTS => "resents",
        
        // Constraint
        RelationType::BUT => "but",
        RelationType::DESPITE | RelationType::ALTHOUGH => "despite",
        RelationType::UNLESS => "unless",
        
        // Uncertainty
        RelationType::NOT => "not",
        RelationType::MAYBE | RelationType::POSSIBLY => "maybe",
        RelationType::LIKELY => "likely",
        RelationType::UNCERTAIN => "is uncertain",
        
        // Default fallback
        _ => "is",
    }
}

// ═══════════════════════════════════════════════════════════════════
// LINEARIZER — Converts Equation + retrieved span into surface sentence
//
// The linearizer is the INVERSE of decompose_equation:
// - decompose_equation: surface → (subject, operator, object, slot)
// - linearize_answer:   (subject, operator, object, slot) + fill → surface
//
// For each slot type:
// - Subject-missing: "What is X?" + fill="Y" → "Y is X" or "X is Y"
// - Object-missing:  "Where is X?" + fill="Y" → "X is in Y"
// - Verification:    "Is X Y?" + true/false → "Yes, X is Y" / "No, X is not Y"
// - None (assertion): just echo back with acknowledgment
// ═══════════════════════════════════════════════════════════════════

/// Linearize an answer from an Equation and a retrieved fill value.
/// 
/// Arguments:
/// - `eq`: The decomposed equation from the query
/// - `fill`: The retrieved value to fill the missing slot
/// - `verified`: For verification queries, whether the assertion is true
fn linearize_answer(eq: &Equation, fill: Option<&str>, verified: Option<bool>) -> String {
    let op_word = operator_to_word(eq.operator);
    
    match eq.slot {
        SlotMissing::Subject => {
            // Question was "What is X?" → Answer is "Y is X" or "X is Y"
            // Depending on operator direction
            let obj = eq.object.as_deref().unwrap_or("that");
            let subj = fill.unwrap_or("Something");
            
            // Capitalize first letter
            let subj_cap = capitalize_first(subj);
            format!("{} {} {}.", subj_cap, op_word, obj)
        }
        
        SlotMissing::Object => {
            // Question was "Where is X?" → Answer is "X is in Y"
            let subj = eq.subject.as_deref().unwrap_or("That");
            let obj = fill.unwrap_or("somewhere");
            
            let subj_cap = capitalize_first(subj);
            format!("{} {} {}.", subj_cap, op_word, obj)
        }
        
        SlotMissing::Verification => {
            // Question was "Is X Y?" → Answer is "Yes, X is Y" or "No, X is not Y"
            let subj = eq.subject.as_deref().unwrap_or("That");
            let obj = eq.object.as_deref().unwrap_or("true");
            
            let subj_cap = capitalize_first(subj);
            
            match verified {
                Some(true) => format!("Yes, {} {} {}.", subj_cap, op_word, obj),
                Some(false) => {
                    // Negate the operator
                    let neg_op = negate_operator(eq.operator);
                    format!("No, {} {} {}.", subj_cap, neg_op, obj)
                }
                None => {
                    // Unknown truth value
                    format!("I'm not certain whether {} {} {}.", subj_cap, op_word, obj)
                }
            }
        }
        
        SlotMissing::None => {
            // Assertion — acknowledge and possibly rephrase
            let subj = eq.subject.as_deref().unwrap_or("That");
            let obj = eq.object.as_deref().unwrap_or("");
            
            if obj.is_empty() {
                format!("I understand: {}.", subj)
            } else {
                let subj_cap = capitalize_first(subj);
                format!("I understand: {} {} {}.", subj_cap, op_word, obj)
            }
        }
    }
}

/// Get the negated form of an operator for "No" answers
fn negate_operator(op: RelationType) -> &'static str {
    match op {
        RelationType::IS | RelationType::IS_A => "is not",
        RelationType::CAN => "cannot",
        RelationType::HAS => "does not have",
        RelationType::DOES => "does not",
        RelationType::KNOWS => "does not know",
        RelationType::BELIEVES => "does not believe",
        RelationType::CAUSES => "does not cause",
        RelationType::IS_IN => "is not in",
        RelationType::IS_AT => "is not at",
        RelationType::IS_ON => "is not on",
        _ => "is not",
    }
}

// Note: capitalize_first() is already defined elsewhere in this file

/// WH-word → which slot it replaces + operator hint
fn wh_to_slot(wh: &str) -> (SlotMissing, Option<RelationType>) {
    match wh.to_lowercase().as_str() {
        "what" | "which" => (SlotMissing::Subject, Some(RelationType::IS)),
        "who" => (SlotMissing::Subject, Some(RelationType::IS)),
        "where" => (SlotMissing::Object, Some(RelationType::IS_IN)),
        "when" => (SlotMissing::Object, Some(RelationType::BEFORE)),  // Temporal
        "why" => (SlotMissing::Object, Some(RelationType::CAUSED_BY)),
        "how" => (SlotMissing::Object, Some(RelationType::DOES)),  // Manner/method
        _ => (SlotMissing::None, None),
    }
}

/// Aux verb → tense
fn aux_to_tense(aux: &str) -> Tense {
    match aux.to_lowercase().as_str() {
        "is" | "are" | "am" | "do" | "does" | "can" | "has" | "have" => Tense::Present,
        "was" | "were" | "did" | "could" | "had" => Tense::Past,
        "will" | "shall" | "would" | "should" => Tense::Future,
        _ => Tense::Present,
    }
}

/// Decomposes an utterance into an Equation.
/// This is the universal parser that replaces detect_route, parse_wh_query, etc.
///
/// Algorithm:
/// 1. Identify and strip WH-word → sets slot field
/// 2. Identify and strip aux verb → sets tense field
/// 3. Find the relation word (operator) in remaining tokens
/// 4. Everything left-of-operator = subject span
/// 5. Everything right-of-operator = object span
/// 6. Detect negation particles → sets negated flag
fn decompose_equation(input: &str) -> Equation {
    let raw = input.to_string();
    let lower = input.to_lowercase();
    let mut tokens: Vec<&str> = lower.split_whitespace().collect();
    
    // Default equation (fallback)
    let mut slot = SlotMissing::None;
    let mut tense = Tense::Present;
    let mut operator = RelationType::IS;
    let mut negated = false;
    let mut wh_hint: Option<RelationType> = None;
    
    // ═══════════════════════════════════════════════════════════════
    // Step 1: Identify and strip WH-word
    // ═══════════════════════════════════════════════════════════════
    let wh_words = ["what", "who", "where", "when", "why", "how", "which"];
    if !tokens.is_empty() && wh_words.contains(&tokens[0]) {
        let (s, hint) = wh_to_slot(tokens[0]);
        slot = s;
        wh_hint = hint;
        tokens.remove(0);
        
        // Handle contractions: "what's" → "what" + "is"
        if let Some(first) = tokens.first() {
            if first.ends_with("'s") || first.ends_with("'re") || first.ends_with("'m") {
                // These are aux verbs embedded in contractions
                tense = Tense::Present;
            }
        }
    }
    
    // ═══════════════════════════════════════════════════════════════
    // Step 2: Identify and strip aux verb → sets tense
    // Also check for contractions with negation (isn't, don't, etc.)
    // ═══════════════════════════════════════════════════════════════
    let aux_verbs = ["is", "are", "am", "was", "were", "be", "been", "being",
                     "do", "does", "did", "can", "could", "will", "would",
                     "shall", "should", "may", "might", "must",
                     "has", "have", "had"];
    
    // Contractions: isn't → is + not, doesn't → does + not, etc.
    let contraction_map: &[(&str, &str, bool)] = &[
        ("isn't", "is", true), ("aren't", "are", true), ("wasn't", "was", true),
        ("weren't", "were", true), ("don't", "do", true), ("doesn't", "does", true),
        ("didn't", "did", true), ("can't", "can", true), ("couldn't", "could", true),
        ("cannot", "can", true),  // "cannot" is one word, not a contraction
        ("won't", "will", true), ("wouldn't", "would", true),
        ("hasn't", "has", true), ("haven't", "have", true), ("hadn't", "had", true),
    ];
    
    let mut aux_found = false;
    let mut stripped_aux: Option<&str> = None;
    
    if !tokens.is_empty() {
        let first_clean = tokens[0].trim_end_matches(|c: char| "?!.,;:".contains(c));
        
        // Check for contraction first
        for &(contraction, base, is_neg) in contraction_map {
            if first_clean == contraction {
                tense = aux_to_tense(base);
                if let Some(op) = word_to_operator(base) {
                    operator = op;
                }
                if is_neg {
                    negated = true;
                }
                if slot == SlotMissing::None {
                    slot = SlotMissing::Verification;
                }
                aux_found = true;
                stripped_aux = Some(base);
                tokens.remove(0);
                break;
            }
        }
        
        // Regular aux verb
        if !aux_found && aux_verbs.contains(&first_clean) {
            tense = aux_to_tense(first_clean);
            
            // If WH was not found but aux verb is first, this is a yes/no question
            // "Is X Y?" or "Can X do Y?" or "Does X cause Y?"
            if slot == SlotMissing::None {
                slot = SlotMissing::Verification;
            }
            
            // The aux verb IS the operator for verification questions
            if let Some(op) = word_to_operator(first_clean) {
                operator = op;
            }
            
            aux_found = true;
            stripped_aux = Some(first_clean);
            tokens.remove(0);
        }
    }
    
    // ═══════════════════════════════════════════════════════════════
    // Step 3: Find the relation word (operator) in remaining tokens
    // Positional constraint: must be in predicate position (P2)
    //
    // If the aux verb was already a meaningful operator (CAN, HAS, CAUSES, etc.),
    // only override if we find a more specific operator (like "causes" vs "does").
    // "do/does/did" are weak auxiliaries that shouldn't override capability/possession.
    // ═══════════════════════════════════════════════════════════════
    let mut operator_idx: Option<usize> = None;
    
    // Known operator words (relation predicates)
    let operator_words = ["is", "are", "am", "was", "were", "has", "have", "had",
                          "can", "could", "does", "do", "did",
                          "causes", "cause", "caused",
                          "knows", "know", "knew",
                          "believes", "believe", "believed",
                          "lives", "resides", "located",
                          "before", "after", "equals", "like"];
    
    // Weak auxiliaries that shouldn't override a stronger operator
    let weak_aux = ["do", "does", "did"];
    
    // Check if current operator is stronger than default IS
    let aux_was_strong = matches!(operator, 
        RelationType::CAN | RelationType::CAN_NOT |
        RelationType::HAS | RelationType::HAS_NOT |
        RelationType::CAUSES | RelationType::CAUSED_BY |
        RelationType::KNOWS | RelationType::BELIEVES);
    
    for (i, token) in tokens.iter().enumerate() {
        // Clean punctuation from token for matching
        let clean = token.trim_end_matches(|c: char| "?!.,;:".contains(c));
        
        if operator_words.contains(&clean) {
            // Skip weak aux if we already have a strong operator
            if aux_was_strong && weak_aux.contains(&clean) {
                continue;
            }
            
            // Check positional constraint: operator should have something before it (subject)
            // and something after it (object), OR it's a copula after WH stripping
            if i > 0 || aux_found || slot != SlotMissing::None {
                if let Some(op) = word_to_operator(clean) {
                    operator = op;
                    operator_idx = Some(i);
                    break;
                }
            }
        }
    }
    
    // ═══════════════════════════════════════════════════════════════
    // Step 4 & 5: Extract subject span (left of operator) and object span (right)
    // NO TRUNCATION — full spans boundary-to-boundary (P3)
    //
    // Special case: For verification queries where aux verb = operator (e.g., "Is X Y?"),
    // the aux is already stripped, so remaining tokens = [subject_words..., predicate_words...].
    // We need to split: first N-1 words = subject, last word(s) = object/predicate.
    // ═══════════════════════════════════════════════════════════════
    let (subject, object) = if let Some(op_idx) = operator_idx {
        let subj_tokens: Vec<&str> = tokens[..op_idx].to_vec();
        let obj_tokens: Vec<&str> = tokens[op_idx + 1..].to_vec();
        
        // Clean subject: strip leading articles but keep prepositions and modifiers
        let subj = clean_span(&subj_tokens);
        
        // Clean object: strip trailing punctuation
        let obj = clean_span(&obj_tokens);
        
        (subj, obj)
    } else if slot == SlotMissing::Verification && tokens.len() >= 2 {
        // Verification query with aux stripped (e.g., "Is water wet?" → ["water", "wet"])
        // Split: first token(s) = subject, last token(s) = object
        // Heuristic: if there's a preposition, split there; otherwise last word is predicate
        let mut split_idx = tokens.len() - 1;
        
        // Look for prepositions or determiners that might start the predicate
        let predicate_starters = ["a", "an", "the", "in", "at", "on", "to"];
        for (i, token) in tokens.iter().enumerate() {
            if i > 0 && predicate_starters.contains(token) {
                split_idx = i;
                break;
            }
        }
        
        let subj_tokens: Vec<&str> = tokens[..split_idx].to_vec();
        let obj_tokens: Vec<&str> = tokens[split_idx..].to_vec();
        
        (clean_span(&subj_tokens), clean_span(&obj_tokens))
    } else {
        // No explicit operator found — treat entire input as subject or object
        // depending on slot type
        let cleaned = clean_span(&tokens);
        match slot {
            SlotMissing::Subject => (None, Some(cleaned.unwrap_or_default())),
            SlotMissing::Object => (Some(cleaned.unwrap_or_default()), None),
            _ => (Some(cleaned.clone().unwrap_or_default()), cleaned),
        }
    };
    
    // Use WH hint as operator ONLY if no explicit operator was set
    // (either from aux verb or from tokens). Don't override CAN/HAS/etc with IS.
    if operator_idx.is_none() && operator == RelationType::IS {
        if let Some(hint) = wh_hint {
            operator = hint;
        }
    }
    
    // ═══════════════════════════════════════════════════════════════
    // Step 6: Detect negation particles
    // ═══════════════════════════════════════════════════════════════
    let negation_words = ["not", "n't", "no", "never", "neither", "nor", "nothing", "nobody", "none", "cannot"];
    for token in lower.split_whitespace() {
        let clean = token.trim_end_matches(|c: char| "?!.,;:".contains(c));
        if negation_words.contains(&clean) || clean.ends_with("n't") || clean == "cannot" {
            negated = true;
            break;
        }
    }
    
    // Adjust operator for negation if not already a NOT variant
    if negated {
        operator = match operator {
            RelationType::IS => RelationType::IS_NOT,
            RelationType::CAN => RelationType::CAN_NOT,
            RelationType::HAS => RelationType::HAS_NOT,
            _ => operator,  // Keep original if no NOT variant
        };
    }
    
    Equation {
        subject,
        operator,
        object,
        slot,
        tense,
        negated,
        raw_input: raw,
    }
}

/// Clean a span of tokens: strip leading articles, trailing punctuation
/// Keep the FULL noun phrase (P3 — no truncation at prepositions!)
fn clean_span(tokens: &[&str]) -> Option<String> {
    if tokens.is_empty() {
        return None;
    }
    
    let mut words: Vec<String> = tokens.iter()
        .map(|t| t.trim_end_matches(|c: char| "?!.,;:".contains(c)).to_string())
        .filter(|w| !w.is_empty())
        .collect();

    // Strip LEADING discourse markers ("yes,", "no,", "well,", ...) before
    // articles. Without this, "yes, stephanie is good" stores subject as
    // "yes stephanie" instead of "stephanie" -- the same leading-word-glomming
    // bug as parse_wh_query had, in a different function. Trailing punctuation
    // is already gone by this point (stripped above), so plain "yes"/"no"
    // matches whether the input was "yes," or "yes".
    let leading_discourse = ["yes", "yeah", "yep", "no", "nope", "well", "oh", "hey", "um", "uh", "okay", "ok", "actually", "so", "hmm"];
    while let Some(first) = words.first() {
        if leading_discourse.contains(&first.as_str()) {
            words.remove(0);
        } else {
            break;
        }
    }

    // Strip LEADING articles only (keep "the purpose of your algorithm" intact)
    let leading_articles = ["the", "a", "an"];
    while let Some(first) = words.first() {
        if leading_articles.contains(&first.as_str()) {
            words.remove(0);
        } else {
            break;
        }
    }

    if words.is_empty() {
        None
    } else {
        Some(words.join(" "))
    }
}

/// Test harness for decompose_equation (Step 0 validation)
#[cfg(test)]
mod equation_tests {
    use super::*;
    
    #[test]
    fn test_simple_wh_questions() {
        let eq = decompose_equation("What is consciousness?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        assert_eq!(eq.operator, RelationType::IS);
        assert_eq!(eq.object, Some("consciousness".to_string()));
        assert!(!eq.negated);
        
        let eq = decompose_equation("Who is the muffin man?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        assert_eq!(eq.object, Some("muffin man".to_string()));
        
        let eq = decompose_equation("Where is the library?");
        assert_eq!(eq.slot, SlotMissing::Object);
        assert_eq!(eq.operator, RelationType::IS_IN);
        assert_eq!(eq.subject, Some("library".to_string()));
    }
    
    #[test]
    fn test_aux_verb_questions() {
        let eq = decompose_equation("Does god cause suffering?");
        assert_eq!(eq.slot, SlotMissing::Verification);
        assert_eq!(eq.operator, RelationType::CAUSES);
        assert_eq!(eq.subject, Some("god".to_string()));
        assert_eq!(eq.object, Some("suffering".to_string()));
        
        let eq = decompose_equation("Can AI think?");
        assert_eq!(eq.slot, SlotMissing::Verification);
        assert_eq!(eq.operator, RelationType::CAN);
        
        let eq = decompose_equation("Is the sky blue?");
        assert_eq!(eq.slot, SlotMissing::Verification);
        assert_eq!(eq.operator, RelationType::IS);
    }
    
    #[test]
    fn test_multi_word_noun_phrases() {
        let eq = decompose_equation("What is the purpose of your GDA algorithm?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        // Should preserve "purpose of your gda algorithm" — NOT truncate at "of"
        assert!(eq.object.as_ref().unwrap().contains("purpose"));
        assert!(eq.object.as_ref().unwrap().contains("algorithm"));
    }
    
    #[test]
    fn test_tense_detection() {
        let eq = decompose_equation("What is X?");
        assert_eq!(eq.tense, Tense::Present);
        
        let eq = decompose_equation("What was X?");
        assert_eq!(eq.tense, Tense::Past);
        
        let eq = decompose_equation("What will X be?");
        assert_eq!(eq.tense, Tense::Future);
    }
    
    #[test]
    fn test_assertions() {
        let eq = decompose_equation("I am John");
        assert_eq!(eq.slot, SlotMissing::None);
        assert_eq!(eq.subject, Some("i".to_string()));
        assert_eq!(eq.object, Some("john".to_string()));
        
        let eq = decompose_equation("Your name is Number 5");
        assert_eq!(eq.slot, SlotMissing::None);
        assert!(eq.subject.as_ref().unwrap().contains("name"));
    }
    
    #[test]
    fn test_negations() {
        let eq = decompose_equation("I don't know the muffin man");
        assert!(eq.negated);
        
        let eq = decompose_equation("X is not Y");
        assert!(eq.negated);
        assert_eq!(eq.operator, RelationType::IS_NOT);
    }
    
    #[test]
    fn test_corrections() {
        let eq = decompose_equation("No, your name is Number 5");
        assert!(eq.negated);  // "No" triggers negation detection
        assert!(eq.subject.as_ref().unwrap().contains("name"));
    }
    
    // ═════════════════════════════════════════════════════════════════
    // COMPREHENSIVE QUERY BATTERY (50+ queries for Step 0 validation)
    // ═════════════════════════════════════════════════════════════════
    
    #[test]
    fn test_comprehensive_wh_subject_queries() {
        // Subject-slot queries: "What/Who is X?" → look up (?, IS, X)
        
        // Basic what is
        let eq = decompose_equation("What is love?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        assert_eq!(eq.object, Some("love".to_string()));
        
        // Who is
        let eq = decompose_equation("Who is the president?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        assert_eq!(eq.object, Some("president".to_string()));
        
        // Multi-word object (should NOT truncate at prepositions!)
        let eq = decompose_equation("What is the capital of France?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        let obj = eq.object.as_ref().unwrap();
        assert!(obj.contains("capital") && obj.contains("france"), 
                "Should preserve 'capital of France', got: {}", obj);
        
        // What can
        let eq = decompose_equation("What can I do?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        assert_eq!(eq.operator, RelationType::CAN);
        
        // What has
        let eq = decompose_equation("What has happened?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        assert_eq!(eq.operator, RelationType::HAS);
    }
    
    #[test]
    fn test_comprehensive_wh_object_queries() {
        // Object-slot queries: "Where/When/Why/How is X?" → look up (X, Op, ?)
        
        // Where → IS_IN
        let eq = decompose_equation("Where is the library?");
        assert_eq!(eq.slot, SlotMissing::Object);
        assert_eq!(eq.operator, RelationType::IS_IN);
        assert_eq!(eq.subject, Some("library".to_string()));
        
        // When → BEFORE (temporal)
        let eq = decompose_equation("When is the meeting?");
        assert_eq!(eq.slot, SlotMissing::Object);
        // Operator should be temporal
        
        // Why → CAUSED_BY
        let eq = decompose_equation("Why is the sky blue?");
        assert_eq!(eq.slot, SlotMissing::Object);
        assert_eq!(eq.operator, RelationType::CAUSED_BY);
        let subj = eq.subject.as_ref().unwrap();
        assert!(subj.contains("sky") && subj.contains("blue"),
                "Should preserve 'sky blue', got: {}", subj);
        
        // How
        let eq = decompose_equation("How does this work?");
        assert_eq!(eq.slot, SlotMissing::Object);
        assert_eq!(eq.operator, RelationType::DOES);
    }
    
    #[test]
    fn test_comprehensive_verification_queries() {
        // Yes/no questions: "Is X Y?" or "Does X Y?" → verify (X, Op, Y)
        
        // Is X Y?
        let eq = decompose_equation("Is water wet?");
        assert_eq!(eq.slot, SlotMissing::Verification);
        assert_eq!(eq.operator, RelationType::IS);
        assert_eq!(eq.subject, Some("water".to_string()));
        assert_eq!(eq.object, Some("wet".to_string()));
        
        // Can X Y?
        let eq = decompose_equation("Can birds fly?");
        assert_eq!(eq.slot, SlotMissing::Verification);
        assert_eq!(eq.operator, RelationType::CAN);
        assert_eq!(eq.subject, Some("birds".to_string()));
        
        // Does X cause Y?
        let eq = decompose_equation("Does smoking cause cancer?");
        assert_eq!(eq.slot, SlotMissing::Verification);
        assert_eq!(eq.operator, RelationType::CAUSES);
        assert_eq!(eq.subject, Some("smoking".to_string()));
        assert_eq!(eq.object, Some("cancer".to_string()));
        
        // Has X Y?
        let eq = decompose_equation("Has John arrived?");
        assert_eq!(eq.slot, SlotMissing::Verification);
        assert_eq!(eq.operator, RelationType::HAS);
        
        // Are X Y?
        let eq = decompose_equation("Are cats mammals?");
        assert_eq!(eq.slot, SlotMissing::Verification);
        assert_eq!(eq.operator, RelationType::IS);
        assert_eq!(eq.subject, Some("cats".to_string()));
        assert_eq!(eq.object, Some("mammals".to_string()));
    }
    
    #[test]
    fn test_comprehensive_assertions() {
        // Assertions: all slots filled → ingest
        
        // Simple copula
        let eq = decompose_equation("The sky is blue");
        assert_eq!(eq.slot, SlotMissing::None);
        assert!(!eq.negated);
        assert_eq!(eq.object, Some("blue".to_string()));
        
        // Has possession
        let eq = decompose_equation("John has a dog");
        assert_eq!(eq.slot, SlotMissing::None);
        assert_eq!(eq.operator, RelationType::HAS);
        
        // Capability assertion
        let eq = decompose_equation("I can help you");
        assert_eq!(eq.slot, SlotMissing::None);
        assert_eq!(eq.operator, RelationType::CAN);
        
        // Causal assertion  
        let eq = decompose_equation("Stress causes headaches");
        assert_eq!(eq.slot, SlotMissing::None);
        assert_eq!(eq.operator, RelationType::CAUSES);
        assert_eq!(eq.subject, Some("stress".to_string()));
        assert_eq!(eq.object, Some("headaches".to_string()));
        
        // Location assertion
        let eq = decompose_equation("Paris is in France");
        assert_eq!(eq.slot, SlotMissing::None);
        // Note: "is in" should be detected as IS_IN when we improve operator detection
    }
    
    #[test]
    fn test_comprehensive_negations() {
        // Negated queries and assertions
        
        // isn't
        let eq = decompose_equation("Water isn't dry");
        assert!(eq.negated);
        assert_eq!(eq.operator, RelationType::IS_NOT);
        
        // don't
        let eq = decompose_equation("I don't know");
        assert!(eq.negated);
        
        // never
        let eq = decompose_equation("Cats never bark");
        assert!(eq.negated);
        
        // cannot
        let eq = decompose_equation("Fish cannot walk");
        assert!(eq.negated);
        
        // not in middle
        let eq = decompose_equation("This is not correct");
        assert!(eq.negated);
        assert_eq!(eq.operator, RelationType::IS_NOT);
    }
    
    #[test]
    fn test_comprehensive_tense() {
        // Tense detection from aux verbs (P4)
        
        // Present
        let eq = decompose_equation("What is this?");
        assert_eq!(eq.tense, Tense::Present);
        
        let eq = decompose_equation("What does this mean?");
        assert_eq!(eq.tense, Tense::Present);
        
        let eq = decompose_equation("Can you help?");
        assert_eq!(eq.tense, Tense::Present);
        
        // Past
        let eq = decompose_equation("What was that?");
        assert_eq!(eq.tense, Tense::Past);
        
        let eq = decompose_equation("What did John say?");
        assert_eq!(eq.tense, Tense::Past);
        
        let eq = decompose_equation("Could you help?");
        assert_eq!(eq.tense, Tense::Past);
        
        // Future
        let eq = decompose_equation("What will happen?");
        assert_eq!(eq.tense, Tense::Future);
        
        let eq = decompose_equation("Will you help?");
        assert_eq!(eq.tense, Tense::Future);
    }
    
    #[test]
    fn test_comprehensive_multi_word_spans() {
        // Full noun phrase preservation (P3 — NO truncation at prepositions!)
        
        // "the purpose of X" should NOT become just "purpose"
        let eq = decompose_equation("What is the purpose of life?");
        let obj = eq.object.as_ref().unwrap();
        assert!(obj.contains("purpose") && obj.contains("life"),
                "Should preserve 'purpose of life', got: {}", obj);
        
        // "the capital of X" 
        let eq = decompose_equation("What is the capital of Japan?");
        let obj = eq.object.as_ref().unwrap();
        assert!(obj.contains("capital") && obj.contains("japan"),
                "Should preserve 'capital of japan', got: {}", obj);
        
        // "the meaning of X in Y context"
        let eq = decompose_equation("What is the meaning of entropy in thermodynamics?");
        let obj = eq.object.as_ref().unwrap();
        assert!(obj.contains("meaning") && obj.contains("entropy"),
                "Should preserve multi-word span, got: {}", obj);
        
        // Object side: "Y because of Z"
        let eq = decompose_equation("Why is the ocean blue?");
        let subj = eq.subject.as_ref().unwrap();
        assert!(subj.contains("ocean") && subj.contains("blue"),
                "Subject span should be 'ocean blue', got: {}", subj);
    }
    
    #[test]
    fn test_comprehensive_invertibility() {
        // Questions and answers should decompose to compatible equations
        // (This tests the fundamental invertibility principle)
        
        // Question: "Who is the muffin man?"
        let q = decompose_equation("Who is the muffin man?");
        assert_eq!(q.slot, SlotMissing::Subject);
        assert_eq!(q.object, Some("muffin man".to_string()));
        
        // Answer: "The baker is the muffin man"
        let a = decompose_equation("The baker is the muffin man");
        assert_eq!(a.slot, SlotMissing::None);
        assert!(a.subject.as_ref().unwrap().contains("baker"));
        
        // Question: "Where does John live?"
        let q = decompose_equation("Where does John live?");
        assert_eq!(q.slot, SlotMissing::Object);
        assert!(q.subject.as_ref().unwrap().contains("john"));
        
        // Answer: "John lives in Seattle"
        let a = decompose_equation("John lives in Seattle");
        assert_eq!(a.slot, SlotMissing::None);
        // Both have same subject, answer fills object slot
    }
    
    #[test]
    fn test_edge_cases() {
        // Edge cases and tricky inputs
        
        // Empty/minimal
        let eq = decompose_equation("");
        // Should not crash
        
        // Just punctuation
        let eq = decompose_equation("???");
        // Should not crash
        
        // All caps
        let eq = decompose_equation("WHAT IS THIS?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        
        // Mixed case
        let eq = decompose_equation("What Is ThIs?");
        assert_eq!(eq.slot, SlotMissing::Subject);
        
        // Multiple question marks
        let eq = decompose_equation("What is this???");
        assert_eq!(eq.slot, SlotMissing::Subject);
        
        // Trailing spaces
        let eq = decompose_equation("What is this?   ");
        assert_eq!(eq.slot, SlotMissing::Subject);
    }
    
    // ═════════════════════════════════════════════════════════════════
    // LINEARIZER TESTS — Verify inverse transform works correctly
    // ═════════════════════════════════════════════════════════════════
    
    #[test]
    fn test_linearize_subject_missing() {
        // "What is consciousness?" + fill="awareness" → "Awareness is consciousness."
        let eq = decompose_equation("What is consciousness?");
        let answer = linearize_answer(&eq, Some("awareness"), None);
        assert!(answer.contains("Awareness"), "Got: {}", answer);
        assert!(answer.contains("consciousness"), "Got: {}", answer);
    }
    
    #[test]
    fn test_linearize_object_missing() {
        // "Where is the library?" + fill="downtown" → "Library is in downtown."
        let eq = decompose_equation("Where is the library?");
        let answer = linearize_answer(&eq, Some("downtown"), None);
        assert!(answer.contains("Library") || answer.contains("library"), "Got: {}", answer);
        assert!(answer.contains("downtown"), "Got: {}", answer);
    }
    
    #[test]
    fn test_linearize_verification_true() {
        // "Is water wet?" + verified=true → "Yes, water is wet."
        let eq = decompose_equation("Is water wet?");
        let answer = linearize_answer(&eq, None, Some(true));
        assert!(answer.starts_with("Yes"), "Got: {}", answer);
        assert!(answer.to_lowercase().contains("water"), "Got: {}", answer);
        assert!(answer.to_lowercase().contains("wet"), "Got: {}", answer);
    }
    
    #[test]
    fn test_linearize_verification_false() {
        // "Is fire cold?" + verified=false → "No, fire is not cold."
        let eq = decompose_equation("Is fire cold?");
        let answer = linearize_answer(&eq, None, Some(false));
        assert!(answer.starts_with("No"), "Got: {}", answer);
        assert!(answer.contains("not"), "Got: {}", answer);
    }
    
    #[test]
    fn test_linearize_assertion() {
        // "The sky is blue" → "I understand: sky is blue."
        let eq = decompose_equation("The sky is blue");
        let answer = linearize_answer(&eq, None, None);
        assert!(answer.contains("understand"), "Got: {}", answer);
    }
    
    #[test]
    fn test_linearize_invertibility() {
        // Full round-trip: Q → decompose → retrieve → linearize → A
        // Question: "Who is the president?"
        let q = decompose_equation("Who is the president?");
        assert_eq!(q.slot, SlotMissing::Subject);
        
        // Retrieve fill value (simulated)
        let fill = "Joe Biden";
        
        // Linearize
        let answer = linearize_answer(&q, Some(fill), None);
        
        // Answer should mention both the fill and the object
        assert!(answer.contains("Joe Biden") || answer.contains("joe biden"), "Got: {}", answer);
        assert!(answer.contains("president"), "Got: {}", answer);
    }
}

// ═══════════════════════════════════════════════════════════════════
// WH-QUESTION STRUCTURE PARSING (Legacy — preserved for comparison)
// 
// Parses structured WH questions ("what is X", "where is X", etc.)
// to extract query intent and route to targeted handlers instead of
// the generic 6-loop scatter.
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, Copy, PartialEq)]
enum WhWord {
    What,
    Who,
    Where,
    When,
    Why,
    How,
}

#[derive(Debug, Clone, Copy, PartialEq)]
enum Tense {
    Past,
    Present,
    Future,
}

#[derive(Debug, Clone)]
struct WhQuery {
    wh_word: WhWord,
    aux_verb: Option<String>,
    subject: String,
    relation_hint: Option<carousel_hash::table::RelationType>,
    temporal: Option<Tense>,
}

/// Bias tracking for thought loop learning
#[derive(Debug, Clone)]
struct ThoughtBias {
    cause_bias: f32,
    time_bias: f32,
    place_bias: f32,
    capability_bias: f32,
    path_bias: f32,
    similarity_bias: f32,
    generic_bias: f32,
}

impl Default for ThoughtBias {
    fn default() -> Self {
        Self {
            cause_bias: 0.0,
            time_bias: 0.0,
            place_bias: 0.0,
            capability_bias: 0.0,
            path_bias: 0.0,
            similarity_bias: 0.0,
            generic_bias: 0.0,
        }
    }
}

impl ThoughtBias {
    fn get_bias(&self, thought_type: ThoughtType) -> f32 {
        match thought_type {
            ThoughtType::Cause => self.cause_bias,
            ThoughtType::Time => self.time_bias,
            ThoughtType::Place => self.place_bias,
            ThoughtType::Capability => self.capability_bias,
            ThoughtType::Path => self.path_bias,
            ThoughtType::Similarity => self.similarity_bias,
            ThoughtType::Generic => self.generic_bias,
        }
    }
    
    fn adjust_bias(&mut self, thought_type: ThoughtType, delta: f32) {
        let bias = match thought_type {
            ThoughtType::Cause => &mut self.cause_bias,
            ThoughtType::Time => &mut self.time_bias,
            ThoughtType::Place => &mut self.place_bias,
            ThoughtType::Capability => &mut self.capability_bias,
            ThoughtType::Path => &mut self.path_bias,
            ThoughtType::Similarity => &mut self.similarity_bias,
            ThoughtType::Generic => &mut self.generic_bias,
        };
        *bias = (*bias + delta).clamp(-2.0, 2.0); // Keep bias in reasonable range
    }
}


/// Container for reasoning stage results
struct ReasoningResult {
    engine_result: QueryResult,
    implicit_chains: Vec<(String, String, Vec<String>)>,
}

/// Result of interference scan - finds where query tokens co-occur most
// NOTE: `relation_idx`/`anchor_relation` originally indexed
// self.engine.relations (pre-extracted triples). That store is empty in
// a fresh train+chat session, so interference_scan/interference_scan_at_radius
// were ported to scan the live token tape instead -- these fields are now
// repurposed to hold a TAPE POSITION (index into self.engine.tokens).
// Field names kept as-is to avoid touching every call site; semantics
// documented here instead.
struct InterferenceHit {
    chunk: String,
    score: usize,
    relation_idx: usize, // tape position (see NOTE above)
}

struct InterferenceResult {
    best_chunk: Option<String>,      // The n-gram that scored highest
    hit_count: usize,                // How many query tokens overlapped in best chunk
    positions_scanned: usize,        // How many positions were checked
    anchor_relation: Option<usize>,  // tape position of the best-matching chunk (see NOTE above)
    all_hits: Vec<InterferenceHit>,  // All matches sorted by score
}

impl Default for InterferenceResult {
    fn default() -> Self {
        Self {
            best_chunk: None,
            hit_count: 0,
            positions_scanned: 0,
            anchor_relation: None,
            all_hits: Vec::new(),
        }
    }
}

/// Working context that accumulates across iterative self-attending passes.
/// Each pass sees the original query PLUS all previous passes' discoveries,
/// like transformer layers where each layer reads the residual stream.
struct WorkingCtx {
    /// Concept strings discovered so far (lowercased, deduped)
    concepts: std::collections::HashSet<String>,
    /// Anchor triples from previous passes (available to all handlers)
    anchor_triples: Vec<carousel_hash::dada_engine::RelationalTriple>,
    /// Weighted triple pool accumulated across all passes
    pool: Vec<(carousel_hash::dada_engine::RelationalTriple, f32)>,
    /// Which Fibonacci pass we're on (0-indexed)
    pass: usize,
    /// Best interference score seen in the current pass
    best_interference_score: usize,
    /// Seed position for interference (updated each pass from best anchor)
    seed_pos: usize,
    /// Triple count at start of each pass (for convergence detection)
    pool_size_at_pass_start: usize,
    /// Concept count at start of each pass (for convergence detection)
    concept_count_at_pass_start: usize,
}

impl WorkingCtx {
    fn new(initial_concepts: Vec<String>, seed_pos: usize) -> Self {
        let concepts: std::collections::HashSet<String> = initial_concepts.into_iter().collect();
        let concept_count = concepts.len();
        Self {
            concepts,
            anchor_triples: Vec::new(),
            pool: Vec::new(),
            pass: 0,
            best_interference_score: 0,
            seed_pos,
            pool_size_at_pass_start: 0,
            concept_count_at_pass_start: concept_count,
        }
    }

    /// Returns true if the last pass added nothing new (convergence).
    fn converged(&self) -> bool {
        self.pool.len() == self.pool_size_at_pass_start
            && self.concepts.len() == self.concept_count_at_pass_start
    }

    /// Snapshot sizes before a new pass begins.
    fn begin_pass(&mut self) {
        self.pool_size_at_pass_start = self.pool.len();
        self.concept_count_at_pass_start = self.concepts.len();
    }

    /// Extend the context with newly discovered triples. Returns how many
    /// genuinely new triples were added (not duplicates).
    fn extend_pool(&mut self, new_triples: Vec<(carousel_hash::dada_engine::RelationalTriple, f32)>) -> usize {
        let mut added = 0usize;
        let mut seen: std::collections::HashSet<(String, String, String)> = self.pool.iter()
            .map(|(t, _)| (t.subject.to_lowercase(), t.relation.to_lowercase(), t.object.to_lowercase()))
            .collect();

        for (triple, weight) in new_triples {
            let key = (triple.subject.to_lowercase(), triple.relation.to_lowercase(), triple.object.to_lowercase());
            // Discover new concepts from every triple we see
            if !triple.subject.is_empty() { self.concepts.insert(triple.subject.to_lowercase()); }
            if !triple.object.is_empty() { self.concepts.insert(triple.object.to_lowercase()); }
            if !seen.contains(&key) {
                seen.insert(key);
                self.anchor_triples.push(triple.clone());
                self.pool.push((triple, weight));
                added += 1;
            }
        }
        added
    }

    /// Update seed position from the best interference hit of this pass.
    fn update_seed(&mut self, interference: &InterferenceResult) {
        if let Some(anchor_idx) = interference.anchor_relation {
            self.seed_pos = anchor_idx;
        }
        self.best_interference_score = interference.hit_count;
    }
}

/// Log entry for definition attempts and successes
#[derive(serde::Serialize, Clone)]
struct DefinitionLog {
    timestamp: String,
    mind_name: String,
    token: String,
    source: String,       // "concept" or "relation"
    success: bool,
    raw_lm_text: Option<String>,
    final_stmt: Option<String>,
}

/// Write a definition log entry to minds/{name}/definitions.jsonl
fn log_definition(mind_name: &str, log: &DefinitionLog) -> std::io::Result<()> {
    use std::io::Write;
    let path = std::path::PathBuf::from(format!(".minds/{}/definitions.jsonl", mind_name));
    let mut f = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(path)?;
    writeln!(f, "{}", serde_json::to_string(log)?)?;
    Ok(())
}

/// Grow synsets from relations - extract objects from all IS-type relations
/// Per CORRECTED_SPEC.md: After every query, scan relations for all IS-type relations
fn grow_synsets_from_relations(
    synsets: &mut HashMap<String, HashSet<String>>,
    relations: &[carousel_hash::dada_engine::RelationalTriple],
) {
    for triple in relations {
        let rel_lower = triple.relation.to_lowercase();
        
        // Match ANY relation that starts with "is_" or is exactly "is"
        if rel_lower.starts_with("is_") || rel_lower == "is" {
            let subject = triple.subject.trim().to_lowercase();
            let object = triple.object.trim().to_lowercase();
            
            // Skip empty strings
            if !subject.is_empty() && !object.is_empty() {
                // Add object to synset[subject]
                synsets.entry(subject).or_insert_with(HashSet::new).insert(object);
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// WH-QUESTION PARSER (Implementation)
// ═══════════════════════════════════════════════════════════════════

/// Parse a WH-question from input text without regex.
/// Returns WhQuery if the input matches a known WH pattern, None otherwise.
/// 
/// Matches:
///   "what is/are X" → subject=X, relation_hint=IS, tense=Present
///   "what was/were X" → subject=X, relation_hint=IS, tense=Past
///   "what can/could X" → subject=X, relation_hint=CAN
///   "what did/does X do" → subject=X, relation_hint=DOES
///   "where is/was X" → subject=X, relation_hint=IS_IN
///   "who is X" → subject=X, relation_hint=IS
///   "why did/does X" → subject=X, relation_hint=CAUSES
///   (else) → return None
fn parse_wh_query(input: &str) -> Option<WhQuery> {
    let lower = input.to_lowercase();
    let tokens: Vec<&str> = lower.split_whitespace().collect();
    
    if tokens.is_empty() { return None; }
    
    // Extract WH word from first token
    let wh_word = match tokens[0] {
        "what" | "what's" | "whats" => WhWord::What,
        "who" | "who's" | "whos" => WhWord::Who,
        "where" | "where's" | "wheres" => WhWord::Where,
        "when" | "when's" | "whens" => WhWord::When,
        "why" | "why's" | "whys" => WhWord::Why,
        "how" | "how's" | "hows" => WhWord::How,
        _ => return None,
    };
    
    if tokens.len() < 2 { return None; }
    
    // Second token should be aux verb or noun (subject)
    let aux_verb = match tokens[1] {
        "is" | "are" | "was" | "were" | "be" | "being" | "been" => Some(tokens[1].to_string()),
        "can" | "could" | "will" | "would" | "shall" | "should" | "may" | "might" | "must" => Some(tokens[1].to_string()),
        "do" | "does" | "did" => Some(tokens[1].to_string()),
        "have" | "has" | "had" => Some(tokens[1].to_string()),
        _ => None,
    };
    
    // Determine tense from aux verb and determine relation type
    let (temporal, relation_hint) = match aux_verb.as_deref() {
        Some("is") | Some("are") => (Some(Tense::Present), Some(RelationType::IS)),
        Some("was") | Some("were") => (Some(Tense::Past), Some(RelationType::IS)),
        Some("will") | Some("shall") => (Some(Tense::Future), Some(RelationType::IS)),
        Some("can") | Some("could") => (Some(Tense::Present), Some(RelationType::CAN)),
        Some("do") | Some("does") => (Some(Tense::Present), Some(RelationType::DOES)),
        Some("did") => (Some(Tense::Past), Some(RelationType::DOES)),
        Some("have") | Some("has") => (Some(Tense::Present), Some(RelationType::HAS)),
        Some("had") => (Some(Tense::Past), Some(RelationType::HAS)),
        _ => (None, None),
    };
    
    // Extract subject: everything after aux verb, stripped of leading articles/possessives
    // and trailing temporal words.
    let subject_start = if aux_verb.is_some() { 2 } else { 1 };
    let subject_tokens = &tokens[subject_start..];

    // Trim trailing sentence punctuation from each token FIRST, as its own
    // step -- previously this was conflated with stop-word popping (a token
    // like "for?" would get discarded whole because it "ends_with('?')",
    // silently deleting the real word "for" along with the punctuation and
    // making trailing-preposition detection below impossible).
    let mut subject_words: Vec<String> = subject_tokens.iter()
        .map(|w| w.trim_end_matches(|c: char| matches!(c, '?' | '.' | '!' | ',')).to_string())
        .filter(|w| !w.is_empty())
        .collect();

    // Strip LEADING articles, possessives, and prepositions: "the", "a", "my", "your", "his", "her", "its", "their", "of", etc.
    let leading_strip_words = ["the", "a", "an", "my", "your", "his", "her", "its", "their", "of"];
    while let Some(first) = subject_words.first() {
        if leading_strip_words.contains(&first.as_str()) {
            subject_words.remove(0);
        } else {
            break;
        }
    }

    // Strip trailing temporal/stop words: "last", "recently", "now", "today", "tomorrow", etc.
    // "do" is here too: "what does X do?" / "what can X do?" end in a bare
    // do-support repeat that's semantically empty, not part of the subject.
    // (Previously this got dropped as a side effect of the old "discard any
    // token ending in '?'" step; now that punctuation-trimming is its own
    // pass above, that filler needs an explicit rule or it leaks into the
    // subject as "try do" instead of "try".)
    let stop_words = ["last", "recently", "now", "today", "tomorrow", "yesterday", "next", "ago", "then", "soon", "do"];
    while let Some(last) = subject_words.last() {
        if stop_words.contains(&last.as_str()) {
            subject_words.pop();
        } else {
            break;
        }
    }

    // "like" behaves prepositionally in "what is X like?" (≈ "what is X
    // similar to?") -- it needs to stop the fallback head-word scan the
    // same way "for"/"about"/etc. do, even though it isn't a preposition
    // grammatically.
    let prepositions = ["of", "in", "on", "at", "by", "for", "from", "to", "with", "about", "like"];

    // Predicate-adjective + preposition family: "what is X good for?",
    // "what is X used for?", "what is X made of?", "what is good about X?",
    // "what is true of X?", "what do you know about X?" -- the query topic
    // is NOT "the words right after the aux verb" here, it's whichever
    // content word sits *outside* the fixed predicate-adjective+preposition
    // chunk, and that chunk can sit on either side of the topic word. This
    // is the pattern that broke "what is c good for" (topic "c" is first,
    // predicate "good for" trails) and "what is good about c" (predicate
    // "good about" is first, topic "c" trails) identically -- both have a
    // known predicate adjective sitting directly next to a preposition;
    // the words on the *other* side of that pair are the real subject.
    let predicate_adjectives = [
        "good", "bad", "great", "important", "useful", "responsible", "known",
        "used", "made", "based", "dependent", "similar", "different", "true",
        "false", "right", "wrong", "common", "popular", "necessary", "required",
        "suited", "essential", "capable", "fit", "ready", "famous", "notable",
    ];
    let mut predicate_hit: Option<usize> = None; // index of the preposition in subject_words
    for (i, word) in subject_words.iter().enumerate() {
        if !prepositions.contains(&word.as_str()) { continue; }
        let adj_before = i > 0 && predicate_adjectives.contains(&subject_words[i - 1].as_str());
        if adj_before {
            predicate_hit = Some(i);
            break;
        }
    }

    let final_subject_words: Vec<String> = if let Some(prep_idx) = predicate_hit {
        let after: Vec<String> = subject_words[prep_idx + 1..].to_vec();
        if !after.is_empty() {
            // "good about c" -- topic trails the predicate chunk.
            after
        } else {
            // "c good for" -- topic leads the predicate chunk: everything
            // before the adjective, which sits right at prep_idx - 1.
            subject_words[..prep_idx - 1].to_vec()
        }
    } else {
        // Fall back to the original behaviour: head noun up to the first
        // preposition (handles "the purpose of your GDA algorithm" → "purpose").
        let mut head_words: Vec<String> = Vec::new();
        for word in &subject_words {
            if prepositions.contains(&word.as_str()) {
                break; // Stop at first preposition; keep only what came before
            }
            head_words.push(word.clone());
        }
        if head_words.is_empty() { subject_words.clone() } else { head_words }
    };

    let subject = final_subject_words.join(" ").trim().to_string();
    if subject.is_empty() { return None; }
    
    // Special case: "where" maps to IS_IN
    let relation_hint = if wh_word == WhWord::Where {
        Some(RelationType::IS_IN)
    } else if wh_word == WhWord::Why {
        Some(RelationType::CAUSES)
    } else if wh_word == WhWord::How {
        // "how" was previously left to fall through to whatever the aux
        // verb implied (usually DOES, via "did"/"does"), which routed it
        // into handle_capability -- a capability search, not a manner
        // one, for a question that isn't asking about capability at all.
        // Reusing INSTRUMENT_FOR (already the type "using"/"by" phrases
        // classify to elsewhere in this codebase) instead of adding a new
        // RelationType variant, since that enum's values are hash-encoded
        // elsewhere and not something to extend casually.
        //
        // Safe to apply unconditionally here: Stage 1a (cloze_answer,
        // called before this WH-routing is ever reached) already resolves
        // copula-style "how is/are/was X" queries on its own, so only
        // clause-shaped how-questions cloze couldn't answer ("how did she
        // solve it") ever reach this override.
        Some(RelationType::INSTRUMENT_FOR)
    } else {
        relation_hint
    };
    
    Some(WhQuery {
        wh_word,
        aux_verb,
        subject,
        relation_hint,
        temporal,
    })
}

// ═══════════════════════════════════════════════════════════════════
// WH-RESPONSE FORMATTER (Step 3)
// ═══════════════════════════════════════════════════════════════════

/// Format a response that mirrors the WH query structure.
/// NOT DADA synthesis — deterministic template filling based on
/// wh_word + tense.
fn format_wh_response(query: &WhQuery, triple: &carousel_hash::dada_engine::RelationalTriple) -> String {
    let subject = if query.subject.is_empty() {
        triple.subject.clone()
    } else {
        query.subject.clone()
    };
    
    let cap_subject = if subject.is_empty() {
        "It".to_string()
    } else {
        let mut chars = subject.chars();
        match chars.next() {
            None => "It".to_string(),
            Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
        }
    };
    
    // Choose template based on wh_word + tense
    match (query.wh_word, query.temporal) {
        (WhWord::What, Some(Tense::Present)) | (WhWord::What, None) => {
            format!("{} is {}.", cap_subject, triple.object)
        },
        (WhWord::What, Some(Tense::Past)) => {
            format!("{} was {}.", cap_subject, triple.object)
        },
        (WhWord::What, Some(Tense::Future)) => {
            format!("{} will be {}.", cap_subject, triple.object)
        },
        (WhWord::Who, _) => {
            format!("{} is {}.", cap_subject, triple.object)
        },
        (WhWord::Where, _) => {
            format!("{} is in {}.", cap_subject, triple.object)
        },
        (WhWord::When, Some(Tense::Past)) => {
            format!("{} was {}.", cap_subject, triple.object)
        },
        (WhWord::When, _) => {
            format!("{} is {}.", cap_subject, triple.object)
        },
        (WhWord::Why, _) => {
            format!("{} because {}.", cap_subject, triple.object)
        },
        (WhWord::How, _) => {
            // Now exclusively fed by handle_manner (via the
            // INSTRUMENT_FOR override in parse_wh_query), whose triples
            // are {anchor, trigger_word, phrase} e.g. {"puzzle", "by",
            // "working hard"} -- include the trigger word itself or the
            // manner reading drops the preposition ("solved the puzzle
            // working hard" instead of "...by working hard").
            format!("{} {} {}.", cap_subject, triple.relation, triple.object)
        },
    }
}

struct Mind {
    name:            String,
    engine:          WordEngine,
    folder:          PathBuf,
    trained_files:   Vec<String>,
    synsets:         Synsets,
    corrector:       RelationalErrorCorrector,
    mode:            MindMode,
    learn_from_chat: bool,
    semantic_words:  HashSet<String>, // Words that appear as subject/object in relations
    // If set, the mind will ask the user to define unknown words encountered
    // during interactive ingestion/chat. When a clarification is outstanding
    // the token is stored in `pending_definition` until the user provides
    // a defining utterance.
    ask_on_unknowns: bool,
    pending_definition: Option<String>,
    pending_definition_suggestion: Option<String>,
    /// Optional per-session LM model override (affects definition lookups)
    lm_model_override: Option<String>,
    /// Last engine QueryResult for the most recent query (used for learning)
    last_query_result: Option<QueryResult>,
    /// Controls LM definition complexity (Simple/Normal/Technical).
    /// Simple = ELI5 mode (default). Prevents jargon token proliferation.
    definition_style: DefinitionStyle,
    /// Clarity threshold for post-ingest LM clarification.
    /// Tokens with clarity score below this value are candidates for LM definition.
    clarity_threshold: f32,
    /// When true, skip tokens that look like noise (multi-word garbage, pure punct, etc.)
    /// before sending to LM. Default OFF — let the LM see everything.
    lm_noise_filter: bool,
    /// Bias weights for thought loop competition (learned from feedback)
    thought_bias: ThoughtBias,
    /// Last winning thought type (for feedback learning)
    last_winning_thought: Option<ThoughtType>,
    /// Radial hash query mode (Exact = standard; Cascade/Diffuse = one-bin-over).
    /// Toggle with: `mode exact` / `mode cascade` / `mode diffuse [r] [w]`
    query_mode: carousel_hash::hash_methods::QueryMode,
    /// Relation count snapshot before last query (for rejection/undo)
    last_relation_count: usize,
    /// Last query input (for re-querying after rejection)
    last_query_input: Option<String>,
    /// Concepts from recent turns that found no live relation to anything
    /// yet -- shelved rather than force-fit into a response or discarded.
    /// A conversation is a journey that relies on its past to hold the
    /// present: each new turn's concepts get tried against this bucket via
    /// live_walk; a genuine connection gets stitched into the response and
    /// consumes the potential, and turns that connect to nothing just wait
    /// here for a later turn to activate them. See `stitch_turn_concepts`.
    turn_potentials: Vec<PotentialConcept>,
}

/// One shelved concept from a past turn, waiting for a future turn to
/// relate to it. See `Mind::turn_potentials`.
struct PotentialConcept {
    concept: String,
    turn_recorded: u32,
}

impl Mind {
    fn new(name: &str) -> Result<Self, Box<dyn std::error::Error>> {
        let folder = PathBuf::from(format!(".minds/{}", name));
        fs::create_dir_all(&folder)?;
        Ok(Mind {
            name:          name.to_string(),
            engine:        WordEngine::new(8),
            folder,
            trained_files: Vec::new(),
            synsets:       Synsets::new(),
            corrector:     RelationalErrorCorrector::new(),
            mode:          MindMode::Normal,
            learn_from_chat: true,
            semantic_words: HashSet::new(),
            ask_on_unknowns: false,
            pending_definition: None,
            pending_definition_suggestion: None,
            lm_model_override: None,
            last_query_result: None,
            definition_style: DefinitionStyle::Simple,
            lm_noise_filter: false,
            clarity_threshold: 0.4,
            thought_bias: ThoughtBias::default(),
            last_winning_thought: None,
            query_mode: carousel_hash::hash_methods::QueryMode::exact(),
            last_relation_count: 0,
            last_query_input: None,
            turn_potentials: Vec::new(),
        })
    }

    /// Grow synsets from all IS-type relations in the engine.
    /// Scans engine.relations for IS_*, IS_A, IS_WHEN, IS_HOW, IS_WHY, IS_BECAUSE, etc.
    /// Extracts objects and adds them to engine.synsets[subject] for every new IS-type relation.
    /// Per CORRECTED_SPEC.md section 7: "Every turn, scan new relations for all IS-type relations"
    fn grow_synsets_from_relations(&mut self) {
        for triple in &self.engine.relations {
            let rel_lower = triple.relation.to_lowercase();
            
            // Match ANY relation that is IS-based
            if rel_lower.starts_with("is_") || rel_lower == "is" {
                let subject = triple.subject.trim().to_lowercase();
                let object = triple.object.trim().to_lowercase();
                
                // Skip empty strings
                if !subject.is_empty() && !object.is_empty() {
                    // Add object to engine.synsets[subject] (grow the HashMap)
                    self.engine.synsets
                        .entry(subject)
                        .or_insert_with(HashSet::new)
                        .insert(object);
                }
            }
        }
    }

    /// Find the first token in `input` that the engine does not recognize.
    /// Recognition checks token_index, semantic_words, synsets and relation indexes.
    fn find_first_unknown_token(&self, input: &str) -> Option<String> {
        // Use space-aware lexer to tokenize, preserving infix punctuation
        let mut lexer = Lexer::new();
        let tokens = lexer.lex(input);

        let stop_words = ["the","a","an","is","are","was","were","to","for","of","in","on","at","by","and","or","but","if","that","which","who","what","when","where","how","i","you","he","she","they"];

        for token in tokens {
            // Only check word tokens, skip boundary markers
            if !matches!(token.kind, TokKind::Word) {
                continue;
            }

            let tok = token.text.to_lowercase();
            if tok.len() < 3 { continue; }
            if !tok.chars().any(|ch| ch.is_alphabetic()) { continue; }
            if stop_words.contains(&tok.as_str()) { continue; }
            // Known if present in the low-level hash table (vocabulary slots)
            // or observed in token_index, semantic_words, synsets or subject/object indices.
            // Use `table.get_word` so metadata from `table.rs` drives the decision.
            if self.engine.table.get_word(&tok).is_some() { continue; }
            if self.engine.token_index.contains_key(&tok) { continue; }
            if self.semantic_words.contains(&tok) { continue; }
            if self.synsets.word_to_synset.contains_key(&tok) { continue; }
            if self.engine.subject_index.contains_key(&tok) || self.engine.object_index.contains_key(&tok) { continue; }

            return Some(tok);
        }
        None
    }

    /// Collect all unknown tokens in `input` (unique, lowercase).
    fn collect_unknown_tokens(&self, input: &str) -> Vec<String> {
        // Use space-aware lexer to tokenize, preserving infix punctuation
        let mut lexer = Lexer::new();
        let tokens = lexer.lex(input);

        let mut out: std::collections::HashSet<String> = std::collections::HashSet::new();
        let stop_words = ["the","a","an","is","are","was","were","to","for","of","in","on","at","by","and","or","but","if","that","which","who","what","when","where","how","i","you","he","she","they"];

        for token in tokens {
            // Only check word tokens, skip boundary markers
            if !matches!(token.kind, TokKind::Word) {
                continue;
            }

            let tok = token.text.to_lowercase();
            if tok.len() < 3 { continue; }
            if stop_words.contains(&tok.as_str()) { continue; }
            if !tok.chars().any(|ch| ch.is_alphabetic()) { continue; }
            // consult low-level table metadata first (vocabulary region)
            if self.engine.table.get_word(&tok).is_some() { continue; }
            if self.engine.token_index.contains_key(&tok) { continue; }
            if self.semantic_words.contains(&tok) { continue; }
            if self.synsets.word_to_synset.contains_key(&tok) { continue; }
            if self.engine.subject_index.contains_key(&tok) || self.engine.object_index.contains_key(&tok) { continue; }
            out.insert(tok);
        }
        let mut v: Vec<String> = out.into_iter().collect();
        v.sort();
        v
    }

    /// Define unknown tokens by querying LM Studio (if configured) and ingest
    /// canonical triples for each returned definition. `cache` prevents
    /// duplicate LM calls within the same training session.
    fn define_and_ingest_tokens<I>(&mut self, tokens: I, cache: &mut std::collections::HashSet<String>) -> usize
    where I: IntoIterator<Item=String>
    {
        use std::collections::VecDeque;

        let mut added = 0usize;
        let mut q: VecDeque<String> = VecDeque::new();
        for t in tokens { q.push_back(t); }

        // Limit total lookups to avoid runaway cascades; configurable.
        let max_lookups: usize = std::env::var("LM_MAX_LOOKUPS").ok()
            .and_then(|v| v.parse().ok()).unwrap_or(10_000);

        if q.is_empty() { return 0; }

        println!("🔎 LM-training: resolving up to {} token(s) (may cascade)", q.len());

        let mut processed = 0usize;
        while let Some(tok) = q.pop_front() {
            if processed >= max_lookups { println!("⚠️ LM-training: reached max lookups ({}); stopping.", max_lookups); break; }
            processed += 1;

            let tok_l = tok.to_lowercase();
            if cache.contains(&tok_l) { continue; }
            cache.insert(tok_l.clone());

            // If the token is already present in the low-level table or
            // token_index, skip an unnecessary LM call.
            if self.engine.table.get_word(&tok_l).is_some() || self.engine.token_index.contains_key(&tok_l) {
                // known already
                continue;
            }

            // Noise filter is opt-IN via `lm_filter on` — off by default
            if self.lm_noise_filter && Self::is_noise_token(&tok_l) {
                eprintln!("[LM] filtered '{}' (noise filter ON)", tok_l);
                continue;
            }

            print!("  • [{}/?] looking up '{}'... ", processed, tok_l);
            match self.query_definition_from_lm(&tok_l) {
                Some(def) => {
                    println!("OK -> '{}'", def);
                    let stmt = def.trim().trim_end_matches('.').to_string() + ".";
                    let _ = self.engine.ingest_as_self(&stmt);
                    added += 1;

                    // Log the successful definition
                    let log = DefinitionLog {
                        timestamp: chrono::Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, false),
                        mind_name: self.name.clone(),
                        token: tok_l.clone(),
                        source: "concept".to_string(),
                        success: true,
                        raw_lm_text: Some(def.clone()),
                        final_stmt: Some(stmt.clone()),
                    };
                    let _ = log_definition(&self.name, &log);

                    // Definitions themselves may introduce new unknown tokens
                    // (cascade). Collect and enqueue them if not seen.
                    let new_unknowns = self.collect_unknown_tokens(&def);
                    for n in new_unknowns {
                        let nl = n.to_lowercase();
                        if !cache.contains(&nl) {
                            q.push_back(nl);
                        }
                    }
                }
                None => {
                    println!("no definition (LM unreachable or failed)");
                    // Log the failed definition attempt
                    let log = DefinitionLog {
                        timestamp: chrono::Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, false),
                        mind_name: self.name.clone(),
                        token: tok_l.clone(),
                        source: "concept".to_string(),
                        success: false,
                        raw_lm_text: None,
                        final_stmt: None,
                    };
                    let _ = log_definition(&self.name, &log);
                }
            }
        }

        if added > 0 {
            println!("✅ LM-training: ingested {} new definition(s)", added);
            self.rebuild_semantic_words();
        } else {
            println!("ℹ️ LM-training: no definitions added (LM may be unavailable)");
        }

        added
    }

    /// Filter out noise tokens: pure numbers, unmatched quotes, multiple punctuation marks, etc.
    /// Returns false if the token looks like garbage and should be skipped.
    fn is_noise_token(token: &str) -> bool {
        // Pure numbers
        if token.chars().all(|c| c.is_numeric()) {
            return true;
        }
        // Unmatched quotes or parentheses
        let open_paren = token.chars().filter(|&c| c == '(').count();
        let close_paren = token.chars().filter(|&c| c == ')').count();
        if open_paren != close_paren {
            return true;
        }
        let open_quote = token.chars().filter(|&c| c == '"').count();
        if open_quote % 2 != 0 {
            return true;
        }
        // Multiple punctuation marks (more than 2 special chars)
        let punct_count = token.chars().filter(|&c| !c.is_alphanumeric() && c != '_').count();
        if punct_count > 2 {
            return true;
        }
        // All special characters
        if token.chars().all(|c| !c.is_alphanumeric() && c != '_') {
            return true;
        }
        false
    }

    /// Query an external LM (LM Studio) for a short definition of `token`.
    /// Returns None if no LM endpoint is configured or the call fails.
    fn query_definition_from_lm(&self, token: &str) -> Option<String> {
        // Skip identity/name tokens — they are owned by the correction pipeline
        if self.engine.is_identity_token(token) {
            eprintln!("[LM] skipping '{}': identity token (handled by name pipeline)", token);
            return None;
        }

        let url = Self::resolve_lm_url();

        // Build a stricter prompt that enforces canonical 'token is ...' format.
        // All styles now demand a single clause starting with "token is" for graph-friendly definitions.
        let prompt = match self.definition_style {
            DefinitionStyle::Simple => format!(
                "Define the word '{0}' in ONE short sentence starting with '{0} is'. \
                 Use only simple, common words. No examples. No names. No new technical terms.",
                token
            ),
            DefinitionStyle::Normal => format!(
                "Define the term '{0}' in ONE sentence starting with '{0} is'. \
                 Make it clear and suitable for a knowledge base. No examples.",
                token
            ),
            DefinitionStyle::Technical => format!(
                "Define '{0}' in ONE precise sentence starting with '{0} is'. \
                 Include domain context. No examples. Single clause only.",
                token
            ),
        };

        // Resolve model via the unified effective_lm_model method
        let model = self.effective_lm_model()
            .unwrap_or_else(|| "default".to_string());

        // Prepare request body. LM Studio native v1 `/api/v1/chat` expects
        // an `input` field (string); OpenAI-compatible endpoints expect
        // `messages`. Choose payload shape based on resolved URL.
        let is_native_v1 = url.contains("/api/v1/chat") || url.contains("/api/v1/");
        if is_native_v1 {
            eprintln!("[LM] using native v1 chat; model='{}'", model);
        } else {
            eprintln!("[LM] using OpenAI-compatible endpoint; model='{}'", model);
        }

        let body = if is_native_v1 {
            serde_json::json!({
                "model": model,
                "input": prompt,
                "max_output_tokens": 60,
                "temperature": 0.0
            })
        } else {
            serde_json::json!({
                "model": model,
                "messages": [{ "role": "user", "content": prompt }],
                "max_output_tokens": 60,
                "temperature": 0.0
            })
        };

        let client = match reqwest::blocking::Client::new().post(&url) {
            req => req,
        };

        let mut req = client.json(&body);
        if let Ok(key) = std::env::var("LM_STUDIO_API_KEY") {
            req = req.bearer_auth(key);
        }

        let resp = req.send().ok()?;
        let v: serde_json::Value = resp.json().ok()?;

        // Parse the common LM Studio v1 `output` array shape and other
        // OpenAI-compatible shapes. Prefer concise/plain outputs over
        // 'reasoning' entries.
        Self::parse_lm_response(&v)
    }

    fn query_definition_for_relation(&self, token: &str) -> Option<String> {
        // Skip identity/name tokens — they belong to the correction pipeline
        if self.engine.is_identity_token(token) {
            eprintln!("[LM] skipping relation term '{}': identity token", token);
            return None;
        }

        let url = Self::resolve_lm_url();
        let model = self.effective_lm_model()
            .unwrap_or_else(|| "default".to_string());

        let prompt = match self.definition_style {
            DefinitionStyle::Simple => format!(
                "Define '{0}' in ONE short sentence starting with '{0} is'. \
                 Use only simple words. No examples. No names. No new jargon.",
                token
            ),
            DefinitionStyle::Normal => format!(
                "Define '{0}' in ONE sentence starting with '{0} is' for a knowledge base. \
                 Single clause only. No examples or extra sentences.",
                token
            ),
            DefinitionStyle::Technical => format!(
                "Define '{0}' in ONE sentence starting with '{0} is'. \
                 Include domain context. Single clause. No examples.",
                token
            ),
        };

        let is_native_v1 = url.contains("/api/v1/chat") || url.contains("/api/v1/");
        if is_native_v1 { eprintln!("[LM] using native v1 chat; model='{}'", model); }
        else { eprintln!("[LM] using OpenAI-compatible endpoint; model='{}'", model); }

        let body = if is_native_v1 {
            serde_json::json!({ "model": model, "input": prompt, "max_output_tokens": 60, "temperature": 0.0 })
        } else {
            serde_json::json!({ "model": model, "messages": [{ "role": "user", "content": prompt }], "max_output_tokens": 60, "temperature": 0.0 })
        };

        let client = match reqwest::blocking::Client::new().post(&url) { req => req };
        let mut req = client.json(&body);
        if let Ok(key) = std::env::var("LM_STUDIO_API_KEY") { req = req.bearer_auth(key); }

        let resp = req.send().ok()?;
        let v: serde_json::Value = resp.json().ok()?;
        let raw = Self::parse_lm_response(&v)?;
        let first_sent = raw.split_terminator('.').next().unwrap_or(&raw).trim().to_string();
        if first_sent.is_empty() { return None; }
        Some(format!("{}.", first_sent))
    }

    fn canonicalize_lm_definition(symbol: &str, lm_text: &str) -> String {
        let s = lm_text.trim();
        let first = s.split_terminator('.').next().unwrap_or(s).trim();
        let sym_lower = symbol.to_lowercase();
        let lower_first = first.to_lowercase();
        let cleaned = if lower_first.starts_with(&format!("{} is ", sym_lower)) {
            first[sym_lower.len() + 4..].trim()
        } else if lower_first.starts_with(&format!("the word '{}' is ", sym_lower)) || lower_first.starts_with(&format!("the word \"{}\" is ", sym_lower)) {
            match first.find("is ") { Some(pos) => &first[pos + 3..], None => first }
        } else { first };
        let rhs = if cleaned.is_empty() { first } else { cleaned };
        rhs.trim().trim_end_matches('.').to_string()
    }

    fn collect_relation_terms_to_define(&self, rels: &[carousel_hash::dada_engine::RelationalTriple]) -> Vec<String> {
        let mut out: std::collections::HashSet<String> = std::collections::HashSet::new();
        for r in rels {
            for term in [&r.subject, &r.object] {
                let tl = term.to_lowercase();
                if tl.is_empty() { continue; }
                if self.engine.table.get_word(&tl).is_some() { continue; }
                if self.engine.token_index.contains_key(&tl) { continue; }
                if self.semantic_words.contains(&tl) { continue; }
                if self.synsets.word_to_synset.contains_key(&tl) { continue; }
                out.insert(tl);
            }
        }
        let mut v: Vec<String> = out.into_iter().collect(); v.sort(); v
    }

    fn define_relation_terms_via_lm(&mut self, rels: &[carousel_hash::dada_engine::RelationalTriple], seen: &mut std::collections::HashSet<String>) -> usize {
        let mut added = 0usize;
        let terms = self.collect_relation_terms_to_define(rels);
        for term in terms {
            if seen.contains(&term) { continue; }
            seen.insert(term.clone());
            if let Some(raw) = self.query_definition_for_relation(&term) {
                let rhs = Self::canonicalize_lm_definition(&term, &raw);
                let stmt = format!("{} is {}.", term, rhs);
                let _ = self.engine.ingest_user(&stmt);
                added += 1;

                // Log the successful relation term definition
                let log = DefinitionLog {
                    timestamp: chrono::Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, false),
                    mind_name: self.name.clone(),
                    token: term.clone(),
                    source: "relation".to_string(),
                    success: true,
                    raw_lm_text: Some(raw.clone()),
                    final_stmt: Some(stmt.clone()),
                };
                let _ = log_definition(&self.name, &log);
            } else {
                // Log failed definition attempt for relation term
                let log = DefinitionLog {
                    timestamp: chrono::Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, false),
                    mind_name: self.name.clone(),
                    token: term.clone(),
                    source: "relation".to_string(),
                    success: false,
                    raw_lm_text: None,
                    final_stmt: None,
                };
                let _ = log_definition(&self.name, &log);
            }
        }
        if added > 0 { println!("✅ LM-training (relations): ingested {} definition(s)", added); }
        added
    }

    /// Extract a plain textual result from various LM response shapes.
    /// Handles LM Studio native `output: [{type, content}]` arrays and
    /// OpenAI-compatible `choices` / `text` / `message` shapes.
    fn parse_lm_response(v: &serde_json::Value) -> Option<String> {
        // 1) Native LM Studio `output` array (preferred)
        if let Some(arr) = v.get("output").and_then(|o| o.as_array()) {
            let mut last_content: Option<String> = None;
            for elem in arr {
                // prefer explicit final/message/text types
                if let Some(typ) = elem.get("type").and_then(|t| t.as_str()) {
                    if let Some(content) = elem.get("content").and_then(|c| c.as_str()) {
                        let trimmed = content.trim().to_string();
                        last_content = Some(trimmed.clone());
                        if typ == "final" || typ == "message" || typ == "text" {
                            return Some(trimmed);
                        }
                    }
                } else if let Some(content) = elem.get("content").and_then(|c| c.as_str()) {
                    let trimmed = content.trim().to_string();
                    return Some(trimmed);
                }
            }
            // Fallback: if only `reasoning` entries were present, pick the
            // last content and heuristically return the first sentence.
            if let Some(c) = last_content {
                // Heuristic: prefer the first sufficiently long sentence (skip
                // enumerated prefixes like "1."). Split paragraphs, then
                // sentences, and pick the first candidate that looks like a
                // real definition.
                // Prefer later paragraphs (model often places the concise
                // definition after reasoning); iterate paragraphs in reverse
                // so we pick the latter, concise sentence first.
                let paras: Vec<&str> = c.split("\n\n").collect();
                for para in paras.iter().rev() {
                    for sent in para.split_terminator('.') {
                        let s = sent.trim();
                        if s.len() >= 10 && s.chars().any(|ch| ch.is_alphabetic()) {
                            return Some(format!("{}.", s));
                        }
                    }
                }
                // fallback: return the trimmed content
                return Some(c);
            }
        }

        // 2) OpenAI-compatible / older shapes
        if let Some(s) = v.get("text").and_then(|t| t.as_str()) { return Some(s.trim().to_string()); }
        if let Some(s) = v.get("result").and_then(|t| t.as_str()) { return Some(s.trim().to_string()); }

        if let Some(arr) = v.get("choices").and_then(|c| c.as_array()) {
            if let Some(choice) = arr.get(0) {
                if let Some(s) = choice.get("text").and_then(|t| t.as_str()) { return Some(s.trim().to_string()); }
                if let Some(s) = choice.get("message").and_then(|m| m.get("content")).and_then(|c| c.as_str()) { return Some(s.trim().to_string()); }
            }
        }

        // 3) Last-resort: stringify the value if it's a plain string
        if let Some(s) = v.as_str() { return Some(s.trim().to_string()); }
        None
    }

    /// Resolve LM Studio endpoint URL from `LM_STUDIO_API_URL` with a sane
    /// default of `http://127.0.0.1:1234/api/v1/chat` when the variable is
    /// unset or contains only a base host.
    fn resolve_lm_url() -> String {
        let configured = std::env::var("LM_STUDIO_API_URL").unwrap_or_else(|_| "http://127.0.0.1:1234".to_string());
        if configured.contains("/api/") || configured.contains("/v1/") || configured.contains("chat") || configured.contains("responses") {
            configured
        } else {
            format!("{}/api/v1/chat", configured.trim_end_matches('/'))
        }
    }

    /// Return the base host portion for LM Studio (strip any /api/... suffix).
    fn resolve_lm_base() -> String {
        let configured = std::env::var("LM_STUDIO_API_URL").unwrap_or_else(|_| "http://127.0.0.1:1234".to_string());
        if let Some(pos) = configured.find("/api/") { return configured[..pos].to_string(); }
        if let Some(pos) = configured.find("/v1/") { return configured[..pos].to_string(); }
        configured.trim_end_matches('/').to_string()
    }

    /// Resolve which model to call on the LM Studio server.
    /// Priority: LM_STUDIO_MODEL env var -> first model from /api/v1/models -> None
    fn resolve_lm_model() -> Option<String> {
        // 1) honor explicit env var
        if let Ok(m) = std::env::var("LM_STUDIO_MODEL") {
            if !m.trim().is_empty() { return Some(m); }
        }

        // Preferred default (used when nothing else is selected).
        const PREFERRED: &str = "ibm/granite-4-h-tiny";

        // 2) best-effort: query server for models and prefer the named model
        let base = Self::resolve_lm_base();
        let url = format!("{}/api/v1/models", base);
        if let Ok(resp) = reqwest::blocking::Client::new().get(&url).send() {
            if let Ok(v) = resp.json::<serde_json::Value>() {
                // If the preferred model is present, use it
                if let Some(arr) = v.as_array() {
                    for it in arr {
                        if let Some(id) = it.get("id").and_then(|s| s.as_str()) {
                            if id == PREFERRED { return Some(id.to_string()); }
                        }
                        if let Some(name) = it.get("name").and_then(|s| s.as_str()) {
                            if name == PREFERRED { return Some(name.to_string()); }
                        }
                    }
                    // otherwise pick the first available model
                    if let Some(first) = arr.get(0) {
                        if let Some(name) = first.get("id").and_then(|x| x.as_str()).or_else(|| first.get("name").and_then(|x| x.as_str())) {
                            return Some(name.to_string());
                        }
                    }
                }
                if let Some(arr) = v.get("models").and_then(|m| m.as_array()) {
                    for it in arr {
                        if let Some(id) = it.get("id").and_then(|s| s.as_str()) {
                            if id == PREFERRED { return Some(id.to_string()); }
                        }
                        if let Some(name) = it.get("name").and_then(|s| s.as_str()) {
                            if name == PREFERRED { return Some(name.to_string()); }
                        }
                    }
                    if let Some(first) = arr.get(0) {
                        if let Some(name) = first.get("id").and_then(|x| x.as_str()).or_else(|| first.get("name").and_then(|x| x.as_str())) {
                            return Some(name.to_string());
                        }
                    }
                }
            }
        }

        // 3) Last-resort: return preferred model name so we have a sensible default
        Some(PREFERRED.to_string())
    }

    /// Set a per-session LM model override (use `None` to clear).
    fn set_lm_model_override(&mut self, model: Option<String>) {
        self.lm_model_override = model;
    }

    /// Return the effective LM model for this `Mind` (override -> resolver -> env).
    fn effective_lm_model(&self) -> Option<String> {
        if let Some(m) = &self.lm_model_override { return Some(m.clone()); }
        Self::resolve_lm_model().or_else(|| std::env::var("LM_STUDIO_MODEL").ok())
    }

    /// After ingesting a user utterance, detect the first unknown token and
    /// (optionally) call the LM to suggest a definition. Returns an optional
    /// prompt that should be shown to the user (one unknown at a time).
    fn handle_unknowns_after_ingest(&mut self, input: &str) -> Option<String> {
        if !self.ask_on_unknowns { return None; }
        if self.pending_definition.is_some() { return None; } // wait for previous

        let unknown = self.find_first_unknown_token(input)?;

        // Try LM suggestion first
        if let Some(def) = self.query_definition_from_lm(&unknown) {
            self.pending_definition = Some(unknown.clone());
            self.pending_definition_suggestion = Some(def.clone());
            return Some(format!("I think '{}' means: \"{}\" — is that right? (yes/no)", unknown, def));
        }

        // Fallback: ask the human
        self.pending_definition = Some(unknown.clone());
        self.pending_definition_suggestion = None;
        Some(format!("I don't know the word '{}'. What does it mean?", unknown))
    }

    /// Build semantic_words set from the live token tape.
    /// Was: derived from self.engine.relations (subject/object of each
    /// extracted triple). That store has been empty in any fresh
    /// train+chat session since Phase 2 regex extraction was cut from
    /// ingest (task #12) -- meaning semantic_words silently went empty
    /// too, which in turn made has_semantic_overlap() reject every
    /// interference hit that had any token overlap at all (empty set
    /// contains nothing). Live-tape equivalent: any content word (not a
    /// function word, not a boundary marker) that has ever been ingested
    /// is "meaning-bearing" -- a superset of the old relation-derived
    /// set, and it stays in sync automatically since token_index is
    /// updated on every ingest.
    fn rebuild_semantic_words(&mut self) {
        self.semantic_words.clear();
        for tok in self.engine.token_index.keys() {
            let low = tok.to_lowercase();
            if WordEngine::tok_is_boundary(&low) { continue; }
            if self.engine.tok_is_function_word(&low) { continue; }
            if low.len() < 3 { continue; }
            self.semantic_words.insert(low);
        }
    }
    
    /// Run ALL thought loops and merge their outputs into one weighted pool.
    /// Each loop's triples are weighted by interference alignment + learned bias.
    /// Now accepts WorkingCtx so handlers benefit from earlier passes' discoveries.
    fn chain_thought_loops(
        &mut self,
        raw: &str,
        interference: &InterferenceResult,
        ctx: &WorkingCtx,
    ) -> Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> {
        let mut pool: Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> = Vec::new();
        let mut best_type = ThoughtType::Generic;
        let mut best_score: f32 = 0.0;

        // Build an augmented query: original input + concepts from earlier passes.
        // Handlers still receive `raw`, but interference weighting sees the full picture.
        let augmented_raw = if ctx.concepts.is_empty() {
            raw.to_string()
        } else {
            let extras: Vec<&String> = ctx.concepts.iter().take(12).collect();
            format!("{} {}", raw, extras.iter().map(|s| s.as_str()).collect::<Vec<_>>().join(" "))
        };

        // Run every thought loop — each contributes weighted triples to the pool
        let loops: Vec<(ThoughtType, Vec<carousel_hash::dada_engine::RelationalTriple>)> = vec![
            (ThoughtType::Cause,      self.handle_cause(raw)),
            (ThoughtType::Time,       self.handle_time(raw)),
            (ThoughtType::Place,      self.handle_place(raw)),
            (ThoughtType::Capability, self.handle_capability(raw)),
            (ThoughtType::Path,       self.handle_path(raw)),
            (ThoughtType::Similarity, self.collect_similarity_triples(raw)),
        ];

        for (thought_type, triples) in loops {
            if triples.is_empty() { continue; }

            // Quality gate + cap: filter garbage, keep top 20 by confidence
            let mut quality: Vec<carousel_hash::dada_engine::RelationalTriple> = triples.into_iter()
                .filter(|t| Self::is_quality_triple(t))
                .collect();
            quality.sort_by(|a, b| b.confidence.partial_cmp(&a.confidence).unwrap_or(std::cmp::Ordering::Equal));
            quality.truncate(20);

            if quality.is_empty() { continue; }

            let weight = self.weight_for_loop(thought_type, &quality, interference);

            if weight > best_score {
                best_score = weight;
                best_type = thought_type;
            }

            eprintln!("  🔗 {:?}: {} triple(s), weight {:.2}", thought_type, quality.len(), weight);
            for t in quality {
                pool.push((t, weight));
            }
        }

        // Also consider anchor triples from earlier passes — re-weight them
        // against the CURRENT pass's interference pattern. Triples that remain
        // relevant across passes get boosted; stale ones decay.
        if !ctx.anchor_triples.is_empty() {
            let ctx_weight = self.weight_for_loop(
                ThoughtType::Generic,
                &ctx.anchor_triples,
                interference,
            ) * 0.9; // slight decay for carried-over triples
            if ctx_weight > 0.0 {
                for t in &ctx.anchor_triples {
                    pool.push((t.clone(), ctx_weight));
                }
            }
        }

        // Generic reasoning loop (transitive chains + engine sub-query)
        // Uses augmented_raw so concepts from earlier passes expand the search.
        //
        // Always queries fresh here (`None`, never `self.last_query_result`).
        // That field holds the PREVIOUS TURN's result -- Stage 4 (which sets
        // it for THIS turn) doesn't run until after all of Stage 3's passes
        // finish, so reading it here was silently replaying last turn's
        // answer into this turn's pool on every pass. That was the entire
        // mechanism behind the "turn1: A, turn2: A+B, turn3: A+B+C" bug:
        // not weak matching, not real relation-finding -- literally an old
        // answer copied forward with no relevance check. Real cross-turn
        // continuity now goes through the turn_potentials/live_walk
        // stitching in query_text_multi instead of this cache.
        {
            let concepts = self.extract_concepts(&augmented_raw);
            let reasoning = self.reason(&augmented_raw, &concepts, None);

            let generic_weight = {
                let w = self.weight_for_loop(ThoughtType::Generic, &reasoning.engine_result.facts, interference);
                w.max(0.3)
            };

            if generic_weight > best_score {
                best_score = generic_weight;
                best_type = ThoughtType::Generic;
            }

            eprintln!("  🔗 Generic: {} fact(s) + {} chain(s), weight {:.2}",
                reasoning.engine_result.facts.len(),
                reasoning.implicit_chains.len(),
                generic_weight);

            for fact in reasoning.engine_result.facts {
                pool.push((fact, generic_weight));
            }

            for (_from, _to, hops) in &reasoning.implicit_chains {
                for hop_str in hops {
                    if let Some((left, right)) = hop_str.split_once("--") {
                        if let Some((rel, target)) = right.split_once("-->") {
                            if rel.to_lowercase().contains("similar")
                                || rel.to_lowercase().contains("same as") { continue; }
                            pool.push((carousel_hash::dada_engine::RelationalTriple::new(
                                left.to_string(), rel.to_string(), target.to_string(), 0.6,
                            ), generic_weight * 0.8));
                        }
                    }
                }
            }
        }

        // Track which loop contributed most (for feedback learning)
        self.last_winning_thought = Some(best_type);
        eprintln!("🧠 Pass {} strongest loop: {:?} ({:.2}) — {} raw triples",
            ctx.pass, best_type, best_score, pool.len());

        // Deduplicate by (subject, relation, object) keeping highest weight
        let mut seen: std::collections::HashMap<(String,String,String), usize> = std::collections::HashMap::new();
        let mut deduped: Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> = Vec::new();
        for (triple, weight) in pool {
            let key = (triple.subject.to_lowercase(), triple.relation.to_lowercase(), triple.object.to_lowercase());
            if let Some(&idx) = seen.get(&key) {
                if weight > deduped[idx].1 { deduped[idx].1 = weight; }
            } else {
                seen.insert(key, deduped.len());
                deduped.push((triple, weight));
            }
        }

        deduped.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        deduped
    }

    /// Iterative self-attending thought passes driven by Fibonacci radii.
    ///
    /// Each pass runs ONE Fibonacci radius outward from the current seed.
    /// Thought loops see the original input PLUS all discoveries from previous
    /// passes (via WorkingCtx). Stops when nothing new emerges or all radii
    /// are exhausted — like transformer layers where each layer reads the
    /// residual stream left by the previous one.
    fn iterative_thought_passes(
        &mut self,
        raw: &str,
        preprocessed: &str,
        patterns: &[String],
    ) -> WorkingCtx {
        // Find the best seed by scanning entire corpus for query overlap.
        // This replaces the old "always start at tail" behavior.
        let seed = self.find_best_seed_position(preprocessed);

        // Bootstrap: extract initial concepts from the raw query
        let initial_concepts = self.extract_concepts(raw);
        let mut ctx = WorkingCtx::new(initial_concepts, seed);

        let radii = Self::fibonacci_radii(); // [3, 5, 8, 13, 21]

        // Adaptive pass budget: short queries get fewer passes.
        // This is a general complexity heuristic, not a query-specific shortcut.
        // 0-1 content words → 1 pass  (e.g. "hello", "hi there")
        // 2 content words   → 2 passes (e.g. "what is god")
        // 3+ content words  → all 5 passes (complex questions)
        let content_word_count = raw.split_whitespace()
            .filter(|w| {
                let low = w.to_lowercase();
                let stripped = low.trim_matches(|c: char| "?!.,;:".contains(c));
                stripped.len() > 2
                    && !self.engine.function_words.contains(stripped)
            })
            .count();

        let max_passes = if content_word_count <= 1 { 1 }
            else if content_word_count <= 2 { 2 }
            else { radii.len() };

        eprintln!("🌀 Initial seed: {} (query-driven) | Content words: {} → max {} pass(es)", seed, content_word_count, max_passes);

        for (i, &radius) in radii.iter().take(max_passes).enumerate() {
            ctx.pass = i;
            ctx.begin_pass();

            // ── 1. Interference at this single radius ────────────────────
            let interference = self.interference_scan_at_radius(
                preprocessed,
                patterns,
                ctx.seed_pos,
                radius,
                &ctx.concepts,
            );

            eprintln!("🌀 Pass {} (r={}): {} hits, {} scanned, seed={}",
                i, radius, interference.hit_count, interference.positions_scanned, ctx.seed_pos);

            // ── 2. Run thought loops with current WorkingCtx ─────────────
            let pass_triples = self.chain_thought_loops(raw, &interference, &ctx);

            // ── 3. Extend context with new discoveries ───────────────────
            let added = ctx.extend_pool(pass_triples);
            ctx.update_seed(&interference);

            eprintln!("🌀 Pass {} result: +{} new triples, {} total in ctx, {} concepts",
                i, added, ctx.pool.len(), ctx.concepts.len());

            // ── 4. Convergence: nothing new → stop early ─────────────────
            if ctx.converged() {
                eprintln!("🌀 Converged after pass {} (no new triples or concepts)", i);
                break;
            }
        }

        ctx
    }

    /// Compute a weight for one thought loop's triples based on:
    ///  - How many of its triples overlap the interference best_chunk
    ///  - Learned bias from prior feedback
    fn weight_for_loop(&self, thought_type: ThoughtType, triples: &[carousel_hash::dada_engine::RelationalTriple], interference: &InterferenceResult) -> f32 {
        if triples.is_empty() { return 0.0; }

        let mut overlap = 0usize;
        if let Some(best_chunk) = &interference.best_chunk {
            let chunk_words: std::collections::HashSet<String> = best_chunk.to_lowercase()
                .split_whitespace().map(|s| s.to_string()).collect();
            for t in triples {
                if chunk_words.contains(&t.subject.to_lowercase())
                    || chunk_words.contains(&t.object.to_lowercase()) {
                    overlap += 1;
                }
            }
        }

        // Base: ratio of overlap to total triples (0..1)
        let overlap_ratio = overlap as f32 / triples.len() as f32;
        // Scale: more triples → diminishing returns (log scale)
        let volume = (1.0 + triples.len() as f32).ln();
        // Combine
        let raw = (0.4 + overlap_ratio * 0.6) * volume;
        // Add learned bias
        (raw + self.thought_bias.get_bias(thought_type)).max(0.0)
    }
    
    /// Apply feedback to adjust thought bias
    fn apply_feedback(&mut self, feedback_type: &str) {
        if let Some(winning_thought) = self.last_winning_thought {
            let delta = match feedback_type.to_lowercase().as_str() {
                "contradiction" | "wrong" | "no" => -0.1,
                "continuation" | "good" | "yes" | "process" => 0.1,
                "topic_shift" => -0.05,
                _ => 0.0,
            };
            
            if delta != 0.0 {
                self.thought_bias.adjust_bias(winning_thought, delta);
                eprintln!("🎯 Adjusted {:?} bias by {} (feedback: {})", winning_thought, delta, feedback_type);
            }
        }
    }

    /// Check if any of the overlap tokens are semantic (meaning-bearing)
    fn has_semantic_overlap(&self, overlap_tokens: &[String]) -> bool {
        overlap_tokens.iter().any(|t| self.semantic_words.contains(&t.to_lowercase()))
    }

    fn save(&self) -> Result<(), Box<dyn std::error::Error>> {
        // 1. Save the CRSL table + token timeline + speaker-provenance spans
        //    (the canonical knowledge base -- v3 format, see task #20)
        let crsl_path = self.folder.join(format!("{}.crsl", self.name));
        let encoded_spans: Vec<(u32, u32, u8)> = self.engine.speaker_spans.iter()
            .map(|&(start, end, speaker)| (start, end, speaker.to_u8()))
            .collect();
        crate::persist::save_with_tokens_and_speakers(
            &self.engine.table, &self.engine.tokens, &encoded_spans, &crsl_path,
        )?;

        // 2. Save synsets
        let syn_path = self.folder.join("synsets.json");
        self.synsets.save_json(&syn_path)?;

        // 3. Save correction rules
        let rules = self.corrector.export_rules();
        let rules_json = json!(rules.iter().map(|(bad, good, ctx, conf)| {
            json!({"bad": bad, "good": good, "context": ctx.as_ref().map(|(a,b)| json!([a,b])), "confidence": conf})
        }).collect::<Vec<_>>());
        fs::write(self.folder.join("rules.json"), serde_json::to_string_pretty(&rules_json)?)?;

        // 4. Save metadata including semantic_words and config fields
        // (dada rules and phrase_fatigue are derived from ingested text — rebuilt on reload)
        let meta = json!({
            "name":   self.name,
            "files":  self.trained_files,
            "mode":   format!("{:?}", self.mode),
            "learn_from_chat": self.learn_from_chat,
            "version": "3.0",
            "semantic_words": self.semantic_words.iter().collect::<Vec<_>>(),
            "definition_style": format!("{:?}", self.definition_style),
            "clarity_threshold": self.clarity_threshold,
            "turn_counter": self.engine.turn_counter,
            "window": self.engine.window,
        });
        fs::write(self.folder.join("mind.json"), serde_json::to_string_pretty(&meta)?)?;

        println!("💾 Saved to {}/ (.crsl with token timeline)", self.folder.display());
        println!("   - {} tokens, {} hash entries, {} semantic words",
            self.engine.tokens.len(), self.engine.table.count, self.semantic_words.len());
        Ok(())
    }

    fn load(name: &str) -> Result<Self, Box<dyn std::error::Error>> {
        let folder = PathBuf::from(format!(".minds/{}", name));
        if !folder.exists() {
            return Err(format!("Mind '{}' not found in .minds/", name).into());
        }

        // 1. Load metadata
        let meta_path = folder.join("mind.json");
        let meta: Value = if meta_path.exists() {
            serde_json::from_str(&fs::read_to_string(&meta_path)?)?
        } else {
            json!({})
        };

        let trained_files: Vec<String> = meta
            .get("files")
            .and_then(|f| f.as_array())
            .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
            .unwrap_or_default();

        let mode = match meta.get("mode").and_then(|m| m.as_str()) {
            Some("Student") => MindMode::Student,
            _               => MindMode::Normal,
        };

        let learn_from_chat = meta.get("learn_from_chat")
            .and_then(|v| v.as_bool())
            .unwrap_or(true);

        // 2. Create engine and load CRSL table
        let crsl_path = folder.join(format!("{}.crsl", name));
        let mut engine = if crsl_path.exists() {
            let mut eng = WordEngine::new(8);
            match crate::crsl_loader::load_crsl_into_engine(&mut eng, &crsl_path) {
                Ok(()) => { 
                    println!("  📡 Hash table loaded ({} slots)", eng.table.slots.len()); 
                    eng 
                }
                Err(e) => { 
                    println!("  ⚠ .crsl load failed ({}), starting fresh", e); 
                    WordEngine::new(8) 
                }
            }
        } else {
            WordEngine::new(8)
        };

        // 3. Load complete engine state (tokens, relations, etc.)
        // Token timeline is now embedded in the .crsl file (v2 format).
        // load_crsl_into_engine() already restores tokens + token_index.
        // Relations, subject_index, object_index are rebuilt via re-ingest or
        // from the relation chains in the hash table.
        //
        // If an old engine.json sidecar exists, migrate turn_counter/window from it,
        // then delete it so future saves use the canonical .crsl-only format.
        let engine_path = folder.join("engine.json");
        if engine_path.exists() {
            if let Ok(engine_json) = fs::read_to_string(&engine_path) {
                if let Ok(engine_state) = serde_json::from_str::<serde_json::Value>(&engine_json) {
                    // Only migrate scalar config fields; data is in .crsl now
                    if let Some(turns) = engine_state.get("turn_counter").and_then(|v| v.as_u64()) {
                        engine.turn_counter = turns as u32;
                    }
                    if let Some(window) = engine_state.get("window").and_then(|v| v.as_u64()) {
                        engine.window = window as usize;
                    }
                    println!("  🔄 Migrated legacy engine.json (will be removed on next save)");
                }
            }
            // Delete the sidecar — next save bakes everything into .crsl
            let _ = fs::remove_file(&engine_path);
        }

        // 4. Load synsets
        let mut synsets = Synsets::new();
        let syn_path = folder.join("synsets.json");
        if syn_path.exists() {
            if let Ok(n) = synsets.load_from_file(syn_path.to_str().unwrap_or("")) {
                eprintln!("  loaded {} synset group(s)", n);
            }
        }

        // 6. Load correction rules
        let mut corrector = RelationalErrorCorrector::new();
        let rules_path = folder.join("rules.json");
        if rules_path.exists() {
            if let Ok(text) = fs::read_to_string(&rules_path) {
                if let Ok(val) = serde_json::from_str::<Value>(&text) {
                    if let Some(arr) = val.as_array() {
                        let rules: Vec<_> = arr.iter().filter_map(|r| {
                            let bad  = r["bad"].as_str()?.to_string();
                            let good = r["good"].as_str()?.to_string();
                            let ctx  = r["context"].as_array().map(|a| {
                                (a[0].as_str().unwrap_or("").to_string(),
                                 a[1].as_str().unwrap_or("").to_string())
                            });
                            let conf = r["confidence"].as_f64().unwrap_or(1.0) as f32;
                            Some((bad, good, ctx, conf))
                        }).collect();
                        corrector.import_rules(rules);
                        if !corrector.correction_rules.is_empty() {
                            println!("  📐 {} correction rules restored", corrector.correction_rules.len());
                        }
                    }
                }
            }
        }

        // Load semantic_words from metadata
        let mut semantic_words: HashSet<String> = HashSet::new();
        if let Some(words) = meta.get("semantic_words").and_then(|v| v.as_array()) {
            for word in words {
                if let Some(s) = word.as_str() {
                    semantic_words.insert(s.to_string());
                }
            }
        }
        // If no semantic_words saved, rebuild from relations
        if semantic_words.is_empty() && !engine.relations.is_empty() {
            for rel in &engine.relations {
                semantic_words.insert(rel.subject.to_lowercase());
                semantic_words.insert(rel.object.to_lowercase());
            }
        }

        // Restore turn_counter and window from mind.json (v3.0+) or from engine.json migration
        if let Some(turns) = meta.get("turn_counter").and_then(|v| v.as_u64()) {
            engine.turn_counter = turns as u32;
        }
        if let Some(window) = meta.get("window").and_then(|v| v.as_u64()) {
            engine.window = window as usize;
        }

        let definition_style = match meta.get("definition_style").and_then(|v| v.as_str()) {
            Some("Normal")    => DefinitionStyle::Normal,
            Some("Technical") => DefinitionStyle::Technical,
            _                 => DefinitionStyle::Simple,
        };
        let clarity_threshold = meta.get("clarity_threshold")
            .and_then(|v| v.as_f64()).unwrap_or(0.4) as f32;

        let thought_bias = ThoughtBias::default(); // Could load from meta in future

        Ok(Mind { name: name.to_string(), engine, folder, trained_files, synsets, corrector, mode, learn_from_chat, semantic_words, ask_on_unknowns: false, pending_definition: None, pending_definition_suggestion: None, lm_model_override: None, last_query_result: None, definition_style, clarity_threshold, lm_noise_filter: false, thought_bias, last_winning_thought: None, query_mode: carousel_hash::hash_methods::QueryMode::exact(), last_relation_count: 0, last_query_input: None, turn_potentials: Vec::new() })
    }

    // ════════════════════════════════════════════════════════════════════
    // Training pipeline — INGEST FIRST, CLARIFY AFTER
    //
    // Previous ordering: collect unknowns → define via LM → then ingest
    // New ordering:      ingest raw → infer relations → then clarify
    //
    // The graph topology comes from our own ingest + inference; LM
    // definitions are just a gentle sharpening of blurry zones, not the
    // first sculptor of meaning.
    //
    // All training data is tagged KnowledgeSource::Self_ (first-person
    // self-story / world knowledge channel).
    // ════════════════════════════════════════════════════════════════════

    fn train_json(&mut self, path: &str) -> Result<(usize, f64), Box<dyn std::error::Error>> {
        let start = std::time::Instant::now();
        let content = fs::read_to_string(path)?;
        let data: Value = serde_json::from_str(&content)?;
        let messages = Self::extract_messages(&data);
        let mut n = 0;

        // ── Watermark: snapshot corpus size BEFORE ingesting this file ──
        // All Phase 2 work scopes to relations[rel_wm..] so we never
        // re-ask the LM about tokens that came from previously loaded documents.
        let rel_wm = self.engine.relations.len();

        // ── Phase 1: Ingest raw first — build the world model ──
        // Feed all messages through ingest_as_self_batch so tokens,
        // relations, subject/object indices, and semantic structure are
        // built purely from the engine's own inference. No LM calls yet.
        // _batch (and ingest_batch for the boundary markers) skip the
        // per-call addr_index rebuild -- two full-table rescans per
        // message was even worse than train_text's one-per-line cost.
        // One rebuild after the loop instead.
        for (i, (role, text)) in messages.iter().enumerate() {
            let boundary = format!("<MSG:{}:{}>", role, i);
            let _ = self.engine.ingest_batch(&boundary);
            if self.engine.ingest_as_self_batch(text).is_ok() {
                n += 1;
            }
        }
        let _ = self.engine.ingest_batch("<MSG:END>");
        self.engine.rebuild_addr_index();

        // Rebuild semantic words from the newly ingested relations
        self.rebuild_semantic_words();

        // ── Phase 2: Post-ingest clarification pass — NEW RELATIONS ONLY ──
        // Scope everything to relations[rel_wm..] so only tokens from THIS
        // document are candidates. Never re-query old corpus terms.
        let new_rels = &self.engine.relations[rel_wm..];

        // Collect the vocabulary of THIS document from new relations only
        let mut new_vocab: std::collections::HashSet<String> = std::collections::HashSet::new();
        for rel in new_rels {
            new_vocab.insert(rel.subject.to_lowercase());
            new_vocab.insert(rel.object.to_lowercase());
        }

        // Clarity candidates filtered to new-document vocabulary only
        let clarity_candidates: Vec<(String, f32)> = self.engine
            .definition_candidates(self.clarity_threshold)
            .into_iter()
            .filter(|(tok, _)| new_vocab.contains(tok.as_str()))
            .collect();
        
        // Build must_define set for structurally important terms — new rels only
        let mut must_define: std::collections::HashSet<String> = std::collections::HashSet::new();
        const DEGREE_THRESHOLD: usize = 5; // Nodes with 5+ edges
        const TECHNICAL_PATTERNS: &[&str] = &["fib", "hash", "npu", "interference", "carousel", "synset", "relation"];
        
        for rel in new_rels {
            for term in [&rel.subject, &rel.object] {
                let t = term.to_lowercase();
                if t.len() >= 3 && !self.engine.is_identity_token(&t) {
                    // Degree counted within new relations only
                    let degree = new_rels.iter()
                        .filter(|r| r.subject.to_lowercase() == t || r.object.to_lowercase() == t)
                        .count();
                    
                    if degree >= DEGREE_THRESHOLD {
                        must_define.insert(t.clone());
                    }
                    
                    // Match technical patterns
                    for pattern in TECHNICAL_PATTERNS {
                        if t.contains(pattern) {
                            must_define.insert(t);
                            break;
                        }
                    }
                }
            }
        }
        
        // Merge clarity candidates with must_define
        let mut all_candidates: Vec<String> = clarity_candidates.into_iter()
            .map(|(token, _)| token.to_lowercase())
            .chain(must_define.into_iter())
            .collect();
        all_candidates.sort();
        all_candidates.dedup();
        
        if !all_candidates.is_empty() {
            println!("  📐 {} token(s) selected for LM clarification (clarity + hubs + technical)", all_candidates.len());
            let mut cache: std::collections::HashSet<String> = std::collections::HashSet::new();
            let _ = self.define_and_ingest_tokens(all_candidates.into_iter(), &mut cache);
            self.rebuild_semantic_words();
        }

        let elapsed = start.elapsed().as_secs_f64();
        Ok((n, elapsed))
    }

    fn train_text(&mut self, path: &str) -> Result<(usize, f64), Box<dyn std::error::Error>> {
        let start = std::time::Instant::now();
        let content = fs::read_to_string(path)?;
        let mut n = 0;

        // ── Watermark: snapshot corpus size BEFORE ingesting this file ──
        // All Phase 2 work scopes to relations[rel_wm..] so we never
        // re-ask the LM about tokens that came from previously loaded documents.
        let rel_wm = self.engine.relations.len();

        // ── Phase 1: Ingest raw first — self-knowledge channel ──
        // All lines go through ingest_as_self_batch: tokens, bigrams,
        // trigrams, and relations are built purely from the engine's own
        // inference. _batch skips the per-line addr_index rebuild (an
        // O(table_size) full scan over 1M+ slots) -- doing that once per
        // line was the actual remaining train bottleneck once Phase 2
        // regex extraction was cut; a 6273-line file meant 6273 full-table
        // rescans. One rebuild after the loop instead.
        for line in content.lines() {
            let t = line.trim();
            if t.len() >= 5 {
                if self.engine.ingest_as_self_batch(t).is_ok() {
                    n += 1;
                }
            }
        }
        self.engine.rebuild_addr_index();

        // Rebuild semantic words from relations
        self.rebuild_semantic_words();

        // ── Phase 2: Post-ingest clarification pass — NEW RELATIONS ONLY ──
        if !self.ask_on_unknowns {
            let elapsed = start.elapsed().as_secs_f64();
            return Ok((n, elapsed));
        }

        let new_rels = &self.engine.relations[rel_wm..];

        let mut new_vocab: std::collections::HashSet<String> = std::collections::HashSet::new();
        for rel in new_rels {
            new_vocab.insert(rel.subject.to_lowercase());
            new_vocab.insert(rel.object.to_lowercase());
        }

        const DENSITY_THRESHOLD: f32 = 0.3;
        const RADIAL_WINDOW: u16 = 3;

        let mut density_candidates: Vec<(String, f32)> = Vec::new();
        for token in &new_vocab {
            if !self.engine.function_words.contains(token)
                && !self.engine.is_identity_token(token)
                && self.engine.table.get_word(token).is_none() {
                let density = self.engine.relational_density_score(token, RADIAL_WINDOW);
                if density < DENSITY_THRESHOLD {
                    density_candidates.push((token.clone(), density));
                }
            }
        }

        let mut must_define: std::collections::HashSet<String> = std::collections::HashSet::new();
        const DEGREE_THRESHOLD: usize = 3;
        const TECHNICAL_PATTERNS: &[&str] = &["fib", "hash", "npu", "interference", "carousel", "synset", "relation"];

        for rel in new_rels {
            for term in [&rel.subject, &rel.object] {
                let t = term.to_lowercase();
                if !self.engine.is_identity_token(&t) && self.engine.table.get_word(&t).is_none() {
                    let degree = new_rels.iter()
                        .filter(|r| r.subject.to_lowercase() == t || r.object.to_lowercase() == t)
                        .count();
                    if degree >= DEGREE_THRESHOLD {
                        must_define.insert(t.clone());
                    }
                    for pattern in TECHNICAL_PATTERNS {
                        if t.contains(pattern) {
                            must_define.insert(t);
                            break;
                        }
                    }
                }
            }
        }

        let mut all_candidates: Vec<String> = density_candidates.into_iter()
            .map(|(token, _)| token.to_lowercase())
            .chain(must_define.into_iter())
            .collect();
        all_candidates.sort();
        all_candidates.dedup();

        if !all_candidates.is_empty() {
            println!("  📐 {} token(s) selected for LM clarification (clarity + hubs + technical)", all_candidates.len());
            let mut defined_cache: std::collections::HashSet<String> = std::collections::HashSet::new();
            let _ = self.define_and_ingest_tokens(all_candidates.into_iter(), &mut defined_cache);
            self.rebuild_semantic_words();
            let mut relation_seen: std::collections::HashSet<String> = std::collections::HashSet::new();
            let new_rels_owned: Vec<_> = self.engine.relations[rel_wm..].to_vec();
            let _ = self.define_relation_terms_via_lm(&new_rels_owned, &mut relation_seen);
            self.rebuild_semantic_words();
        }

        let elapsed = start.elapsed().as_secs_f64();
        Ok((n, elapsed))
    }

    /// Entry point for user-typed input: detects whether the input actually
    /// contains more than one equation ("My name is John. What is your
    /// name?" / "hello number 5, my name is John") and, if so, answers each
    /// one instead of forcing decompose_equation to treat the whole string
    /// as a single blob -- which is what glued "hello number 5, my name"
    /// together into one subject in the first place.
    ///
    /// Single-equation input (still the overwhelming common case) goes
    /// straight to `query_text` unchanged -- this only changes behaviour
    /// when `split_equation_segments` actually finds more than one.
    fn query_text_multi(&mut self, input: &str) -> String {
        let segments = Self::split_equation_segments(input);

        if segments.len() <= 1 {
            let mut answer = self.query_text(input);
            self.ingest_declarative(input);
            if let Some(stitch) = self.stitch_turn_concepts(input) {
                answer.push(' ');
                answer.push_str(&stitch);
            }
            return answer;
        }

        eprintln!("✂️  Multi-equation input: {} segment(s): {:?}", segments.len(), segments);

        let mut answers: Vec<(String, String)> = Vec::new();
        for segment in &segments {
            let answer = self.query_text(segment);
            self.ingest_declarative(segment);
            answers.push((segment.clone(), answer));
        }

        // Check whether any two segments' equations connect to each other
        // live (e.g. one segment's subject reaches another's object through
        // the token stream) and note it if so. This reuses live_walk --
        // nothing new is stored, it's the same on-demand walk `think` uses.
        let anchors: Vec<(String, Option<String>)> = segments.iter().map(|seg| {
            let eq = decompose_equation(seg);
            (seg.clone(), eq.subject.or(eq.object))
        }).collect();

        let mut relations_found: Vec<String> = Vec::new();
        for i in 0..anchors.len() {
            for j in (i + 1)..anchors.len() {
                let (Some(a), Some(b)) = (&anchors[i].1, &anchors[j].1) else { continue };
                if a == b { continue; }
                if let Some(hops) = self.engine.live_walk(a, b, 3) {
                    if !hops.is_empty() {
                        let path = hops.iter()
                            .map(|(s, r, o)| format!("{} {} {}", s, r, o))
                            .collect::<Vec<_>>()
                            .join(" → ");
                        relations_found.push(format!("({} connects to {}: {})", a, b, path));
                    }
                }
            }
        }

        let mut combined = answers.iter()
            .map(|(_, a)| a.clone())
            .collect::<Vec<_>>()
            .join(" ");
        if !relations_found.is_empty() {
            combined.push(' ');
            combined.push_str(&relations_found.join(" "));
        }
        if let Some(stitch) = self.stitch_turn_concepts(input) {
            combined.push(' ');
            combined.push_str(&stitch);
        }
        combined
    }

    /// A conversation is a journey that relies on its past to hold the
    /// present -- but only where the past actually RELATES, not by blindly
    /// carrying everything forward (that was the removed last_query_result
    /// leak: turn 1 mentions A, turn 2 mentions B and answers "A+B", turn 3
    /// mentions C and answers "A+B+C" -- no connection, just replay).
    ///
    /// This is the deliberate version: each turn's concepts get tried
    /// against `turn_potentials` via a single-hop `live_walk` (see the hop
    /// count note below -- max_hops=1, not chained). A genuine connection
    /// gets woven into the response and consumes that potential. A concept
    /// that connects to nothing isn't forced into this turn's answer OR
    /// thrown away -- it's shelved, and a LATER turn whose own concept
    /// happens to relate to it pulls it back in then. That's the
    /// "activating relational concept" case: turn 1 mentions "quantum
    /// computing" (no fit, shelved), turn 5 mentions "qubits" (live_walk
    /// finds a real edge to the shelved concept) -- the connection surfaces
    /// four turns later, when it's actually earned, not every turn
    /// regardless of relevance.
    ///
    /// Correctness depends entirely on live_walk/live_neighbors actually
    /// being sentence-scoped -- their pivot search used to ignore tape
    /// boundaries and could pick up an operator from a completely unrelated
    /// adjacent utterance (fixed alongside this: see live_neighbors'
    /// boundary-clamped window). Before that fix this produced exactly the
    /// kind of garbage this feature exists to avoid -- three-hop chains
    /// through unrelated fragments dressed up as "connections". Single-hop
    /// only, now that a hop actually means what it claims to mean.
    fn stitch_turn_concepts(&mut self, raw: &str) -> Option<String> {
        let turn = self.engine.turn_counter;
        let mut concepts: Vec<String> = self.extract_concepts(raw);
        concepts.sort();
        concepts.dedup();
        concepts.truncate(6); // a turn has a handful of real topics, not a wordlist
        if concepts.is_empty() { return None; }

        let mut stitched: Vec<String> = Vec::new();
        let mut consumed: std::collections::HashSet<usize> = std::collections::HashSet::new();
        let mut still_new: Vec<String> = Vec::new();

        // max_hops=1, not 3: a transitive chain compounds whatever noise
        // is left in live_walk on top of itself hop by hop, which is
        // exactly how "there has someone → someone makes Trust → Trust is
        // test" happened -- three shaky hops through unrelated fragments,
        // none of which was actually about the anchor word. A single direct
        // hop means concept and potential were stated together in ONE real
        // relation, sentence-scoped now that live_neighbors' pivot search
        // stops at tape boundaries instead of wandering into whatever else
        // sat within 8 tokens. One honest hop beats three dressed-up ones.
        for concept in &concepts {
            let mut found_link = false;
            for (idx, potential) in self.turn_potentials.iter().enumerate() {
                if consumed.contains(&idx) { continue; }
                if potential.concept == *concept { continue; } // same word isn't a "connection"
                if let Some(hops) = self.engine.live_walk(concept, &potential.concept, 1) {
                    if let [(subj, rel, obj)] = hops.as_slice() {
                        stitched.push(format!("{} {} {}.", subj, rel, obj));
                        consumed.insert(idx);
                        found_link = true;
                        break; // one link per new concept -- don't stitch the whole shelf at once
                    }
                }
            }
            if !found_link {
                still_new.push(concept.clone());
            }
        }

        // Drop consumed potentials (indices computed above, against the
        // bucket as it stood before this call -- must be applied before any
        // other mutation or the indices stop lining up), then anything
        // aged out, then shelve this turn's unconnected concepts.
        // FIFO-capped so the bucket stays a recent working set, not an
        // ever-growing memory of every word ever said.
        const MAX_POTENTIALS: usize = 40;
        const MAX_AGE_TURNS: u32 = 60;
        let mut i = 0;
        self.turn_potentials.retain(|_| { let keep = !consumed.contains(&i); i += 1; keep });
        self.turn_potentials.retain(|p| turn.saturating_sub(p.turn_recorded) <= MAX_AGE_TURNS);
        for concept in still_new {
            if !self.turn_potentials.iter().any(|p| p.concept == concept) {
                self.turn_potentials.push(PotentialConcept { concept, turn_recorded: turn });
            }
        }
        if self.turn_potentials.len() > MAX_POTENTIALS {
            let overflow = self.turn_potentials.len() - MAX_POTENTIALS;
            self.turn_potentials.drain(0..overflow);
        }

        if stitched.is_empty() { None } else { Some(stitched.join(" ")) }
    }

    /// Every declarative the user types becomes part of the token stream —
    /// the stream IS the model, and the cloze read can only complete
    /// statements that are actually in it. Questions are excluded so a
    /// query's own tokens don't sit in the stream masquerading as an
    /// assertion ("what do i like to eat" contains "i like to eat" — if
    /// ingested, the probe could match the question and read the next
    /// utterance as its answer). Ingestion happens AFTER answering, same
    /// reason cmd_chat does it: the input must not contaminate the
    /// interference scan for its own reply. Correction-routed inputs are
    /// skipped because handle_correction already ingests them.
    fn ingest_declarative(&mut self, text: &str) {
        if text.contains('?') { return; }
        let first = text.split_whitespace().next().unwrap_or("").to_lowercase();
        let first = first.trim_matches(|c: char| c.is_ascii_punctuation());
        if matches!(first, "what" | "who" | "where" | "when" | "why" | "how" | "which"
                         | "is" | "are" | "am" | "was" | "were" | "do" | "does" | "did"
                         | "can" | "could" | "will" | "would" | "have" | "has" | "had") {
            return;
        }
        if self.detect_route(text) == Route::Correction { return; }
        let _ = self.engine.ingest_user(text);
    }

    /// Split raw input into individual equation-bearing segments.
    ///
    /// First splits on sentence terminators (the same boundary set
    /// `handle_correction`'s multi-sentence path already uses). Within a
    /// sentence, a comma is only treated as a second boundary if the text
    /// after it is independently equational on its own (decompose_equation
    /// finds an explicit operator there) -- otherwise it's left alone,
    /// since most commas are just clause-internal, not a second assertion.
    /// This is what lets "hello number 5, my name is John" split into
    /// ["hello number 5", "my name is John"] instead of decompose_equation
    /// swallowing the greeting into the assertion's subject.
    fn split_equation_segments(input: &str) -> Vec<String> {
        let mut segments: Vec<String> = Vec::new();

        for sentence in input.split(|c: char| matches!(c, '.' | '!' | '?' | ';')) {
            let sentence = sentence.trim();
            if sentence.is_empty() { continue; }

            let comma_parts: Vec<&str> = sentence.splitn(2, ',').map(|p| p.trim()).collect();
            if comma_parts.len() == 2 && !comma_parts[1].is_empty()
                && Self::is_equational(comma_parts[1]) {
                // comma_parts[1] being independently equational is what
                // justifies splitting here at all -- comma_parts[0] gets
                // pushed too regardless of whether *it* is equational
                // (e.g. "hello number 5" isn't, but it's still its own
                // segment, same as a plain "Hello." sentence would be).
                // If comma_parts[0] were dropped for not being equational,
                // a two-piece input could collapse back to a single
                // segment and silently fall through to the un-split
                // behaviour this function exists to avoid.
                if !comma_parts[0].is_empty() {
                    segments.push(comma_parts[0].to_string());
                }
                segments.push(comma_parts[1].to_string());
            } else {
                segments.push(sentence.to_string());
            }
        }

        segments
    }

    /// Whether decompose_equation actually found an explicit operator/aux
    /// verb in `text`, as opposed to falling back to "treat the whole thing
    /// as subject == object" -- its behaviour for plain discourse with no
    /// verb at all (e.g. "hello number 5").
    fn is_equational(text: &str) -> bool {
        let eq = decompose_equation(text);
        eq.slot != SlotMissing::None || eq.subject != eq.object
    }

    fn query_text(&mut self, input: &str) -> String {
        // Propagate the Mind-level query_mode into the engine before every query.
        // This is the single synchronisation point; toggling `mind.query_mode`
        // (via the `hashmode` shell command) is immediately effective.
        self.engine.query_mode = self.query_mode;
        
        // *** SNAPSHOT RELATION COUNT BEFORE QUERY (for rejection/undo) ***
        self.last_relation_count = self.engine.relations.len();
        self.last_query_input = Some(input.to_string());
        // ═══════════════════════════════════════════════════════════════════
        // UNIFIED CONVERSATIONAL PIPELINE v6 — ITERATIVE SELF-ATTENTION
        //
        // Fibonacci radii drive one-pass-per-radius expansion. Each pass
        // sees the original query PLUS all previous passes' discoveries
        // (like transformer layers reading the residual stream).
        // Stops when nothing new emerges (convergence).
        //
        // Flow:
        //   Stage 1: route + synthesis method detection
        //   Stage 2: fast-path handlers (return early if deterministic)
        //   Stage 3: iterative thought passes (Fibonacci-driven, self-attending)
        //   Stage 4: engine query adds relation-index triples
        //   Stage 5: merge iterative pool + engine + epicenter
        //   Stage 6: score pool (slot geometry × coherence)
        //   Stage 7: synthesize once from merged pool
        // ═══════════════════════════════════════════════════════════════════

        let pipeline_start = std::time::Instant::now();

        // ── Stage 1: UNIVERSAL OPERATOR ALGEBRA ───────────────────────────
        // Decompose input into canonical equation form FIRST.
        // This drives routing, retrieval, and linearization.
        let equation = decompose_equation(input);
        eprintln!("📐 Equation: slot={:?}, op={:?}, subj={:?}, obj={:?}, neg={}, tense={:?}",
                  equation.slot, equation.operator, equation.subject, equation.object,
                  equation.negated, equation.tense);
        
        // Derive route from equation (new algebra-driven routing)
        let equation_route = equation.to_route();
        
        // Legacy route detection (for comparison during transition)
        let legacy_route = self.detect_route(input);
        
        // Log if they differ (helps identify cases where algebra is better/worse)
        if equation_route != legacy_route {
            eprintln!("⚠️  Route mismatch: equation={:?}, legacy={:?}", equation_route, legacy_route);
        }
        
        // Use legacy route for now (flip to equation_route when confident)
        let route = legacy_route;
        let synthesis_method = self.select_synthesis_method(input, route);
        eprintln!("🎯 Route: {:?} → Method: {:?}", route, synthesis_method);

        // ── Stage 1a: CLOZE READ ──────────────────────────────────────────
        // A question is a statement with a hole. Put the query back in
        // declarative order and let the token stream complete it. This runs
        // before every handler because a direct completion of the user's
        // own statement pattern beats anything synthesized: if the stream
        // contains "i like to eat pizza", then "what do i like to eat"
        // answers itself. Falls through when nothing matches.
        if let Some(ans) = self.engine.cloze_answer(input) {
            eprintln!("🧩 Cloze: completed from token stream");
            return self.finalise_timed(ans, pipeline_start);
        }

        // ── Stage 1.5: EQUATIONAL QUERY PARSING ───────────────────────────
        // Structured questions like "does X cause Y?" or "is X Y because Z?"
        // should be routed to Layer-2 reasoning (TransitiveReasoner) instead
        // of generic text matching. Parse first, route to solver if matched.
        if let Some((subject, verb, object, context)) = Self::parse_equational_query(input) {
            eprintln!("🔬 Equational Query: S={}, V={}, O={}, C={:?}", subject, verb, object, context);
            
            // *** LAYER 2: Structured query solver ***
            // Find direct or transitive relation between subject and object
            // using the verb as a constraint. This is the proper place for
            // "does god exist?" (god→exist chain?), "does X cause Y?" (X→CAUSE→Y?), etc.
            
            let owned: Vec<(String, String, String)> = self.engine.relations.iter()
                .map(|t| (t.subject.clone(), format!("{:?}", t.relation), t.object.clone()))
                .collect();
            let tr_map = triples_to_outgoing(owned.iter().map(|(s, r, o)| (s.as_str(), r.as_str(), o.as_str())));
            let tr = carousel_hash::transitive_reasoner::TransitiveReasoner::new(&tr_map)
                .with_synsets(&self.synsets);
            
            // Search for a path from subject to object (depth limit 5 hops)
            let chain = tr.find_chain(&subject, &object, 5);
            
            if !chain.is_empty() {
                eprintln!("✓ Found chain: {:?}", chain);
                // Reconstruct the path into natural language
                let mut response = String::new();
                for (i, hop) in chain.iter().enumerate() {
                    if i > 0 { response.push(' '); }
                    response.push_str(&format!("{} {} {}", hop.source, hop.relation, hop.target));
                }
                self.grow_synsets_from_relations();
                return self.finalise_timed(response, pipeline_start);
            } else {
                eprintln!("✗ No chain found for equational query");
                // Fall through to standard pipeline
            }
        }

        // Detect word-order pipeline — this is the routing decision for structural queries
        let tokens: Vec<String> = input.split_whitespace()
            .map(|s| s.to_string())
            .collect();
        let _query_pipeline = select_pipeline(&tokens);
        eprintln!("📋 Query Pipeline: {:?}", _query_pipeline);
        // TODO: route to pipeline-specific handlers when implemented.
        // Currently falls through to the coherent query pipeline.
        // CausalQuery  → traverse cause chains
        // Verification → query / confirm / deny
        // Assertion    → store / propagate (ingestion path, not query)

        // ── Stage 1b: WH-QUESTION STRUCTURED ROUTING (NEW) ─────────────────
        // Parse WH questions to extract structure and route to targeted handlers
        // instead of the generic 6-loop scatter. Falls through to GenericQA if
        // parsing fails or query is not structured.
        if let Some(wh_query) = parse_wh_query(input) {
            eprintln!("🔍 WH-Query detected: {:?} (subject: '{}')", wh_query.wh_word, wh_query.subject);
            
            // Route to targeted handler based on relation_hint
            let response = match wh_query.relation_hint {
                Some(RelationType::IS) => {
                    // "What is X", "Who is X" → LIVE WALK. Was a
                    // self.relations subject-contains-search over a store
                    // that chat-time corrections no longer populate for the
                    // general case (see ingest_user). live_neighbors reads
                    // straight off the token stream instead.
                    //
                    // NOTE: an earlier version of this swapped the anchor to
                    // "you"/"i" when the raw input said "your"/"my", to keep
                    // "What is your name?" and "What is my name?" distinct
                    // despite parse_wh_query stripping both down to subject
                    // "name". That made things worse, not better: "you"/"i"
                    // are two of the most common words in any corpus, so the
                    // live search matched whatever "is X" happened to sit
                    // near *any* occurrence of them, producing answers with
                    // no connection to the actual question (e.g. "Name is
                    // datacenters."). Anchoring on wh_query.subject directly
                    // is far more specific and, combined with live_neighbors
                    // now preferring the closest operator instead of
                    // whichever it scans into first, finds the right "is"
                    // pivot reliably. Trade-off: "my name" and "your name"
                    // can still collide if only one of them was ever stated
                    // in this session -- a real but much smaller problem
                    // than confidently wrong answers.
                    let anchor = wh_query.subject.to_lowercase();

                    let hit = self.engine.live_neighbors(&anchor).into_iter()
                        .find(|(rel, _)| matches!(rel.as_str(), "is" | "are" | "was" | "were" | "am"));

                    if let Some((rel, obj)) = hit {
                        let triple = carousel_hash::dada_engine::RelationalTriple::new(
                            wh_query.subject.clone(), rel, obj, 1.0,
                        );
                        format_wh_response(&wh_query, &triple)
                    } else {
                        format!("I don't know about {}.", wh_query.subject)
                    }
                },
                Some(RelationType::IS_IN) => {
                    // "Where is X" → use handle_place
                    let place_triples = self.handle_place(input);
                    if !place_triples.is_empty() {
                        format_wh_response(&wh_query, &place_triples[0])
                    } else {
                        format!("I don't know where {} is.", wh_query.subject)
                    }
                },
                Some(RelationType::CAUSES) => {
                    // "Why did/does X" → use handle_cause
                    let cause_triples = self.handle_cause(input);
                    if !cause_triples.is_empty() {
                        format_wh_response(&wh_query, &cause_triples[0])
                    } else {
                        format!("I don't know why {}.", wh_query.subject)
                    }
                },
                Some(RelationType::CAN) => {
                    // "What can X" → use handle_capability
                    let cap_triples = self.handle_capability(input);
                    if !cap_triples.is_empty() {
                        format_wh_response(&wh_query, &cap_triples[0])
                    } else {
                        format!("I don't know what {} can do.", wh_query.subject)
                    }
                },
                Some(RelationType::DOES) => {
                    // "What does X do" → handle_capability filtered for action triples
                    let cap_triples = self.handle_capability(input);
                    if !cap_triples.is_empty() {
                        format_wh_response(&wh_query, &cap_triples[0])
                    } else {
                        format!("I don't know what {} does.", wh_query.subject)
                    }
                },
                Some(RelationType::INSTRUMENT_FOR) => {
                    // "How did/does/can X ___" → handle_manner (was a
                    // stub; see its doc comment). Manner/instrumental
                    // answer -- "by working hard", "through practice".
                    let manner_triples = self.handle_manner(input);
                    if !manner_triples.is_empty() {
                        format_wh_response(&wh_query, &manner_triples[0])
                    } else {
                        format!("I don't know how {}.", wh_query.subject)
                    }
                },
                _ => {
                    // Unknown relation type → fall through to GenericQA
                    format!("")  // Will trigger the fallthrough below
                }
            };
            
            if !response.is_empty() && response != "" {
                self.grow_synsets_from_relations();
                return self.finalise_timed(response, pipeline_start);
            }
        }

        // ── Stage 2: Deterministic fast-paths (early return) ─────────────
        match route {
            Route::DefUserName => if let Some(r) = self.handle_def_user_name(input) {
                self.grow_synsets_from_relations();
                return self.finalise_timed(r, pipeline_start);
            },
            Route::DefThing => if let Some(r) = self.handle_def_thing(input) {
                self.grow_synsets_from_relations();
                return self.finalise_timed(r, pipeline_start);
            },
            Route::Verification => if let Some(r) = self.handle_verification(input) {
                self.grow_synsets_from_relations();
                return self.finalise_timed(r, pipeline_start);
            },
            Route::Correction => if let Some(r) = self.handle_correction(input) {
                self.grow_synsets_from_relations();
                return self.finalise_timed(r, pipeline_start);
            },
            _ => {}
        }

        // ── Stage 3: Iterative self-attending thought passes ──────────────
        // Each Fibonacci radius drives one pass. Passes see original input
        // PLUS all previous passes' discoveries. Stops on convergence.
        let preprocessed = self.preprocess_input(input);
        let patterns = self.generate_inversion_patterns(&preprocessed);
        let ctx = self.iterative_thought_passes(input, &preprocessed, &patterns);
        eprintln!("🌀 Iteration complete: {} passes, {} triples, {} concepts",
            ctx.pass + 1, ctx.pool.len(), ctx.concepts.len());

        // ── Stage 4: Engine query (relation index + carousel) ─────────────────
        let engine_result = self.engine.query_with_method(input, Some(synthesis_method));
        self.last_query_result = Some(engine_result.clone());

        // ── Stage 5: Merge iterative pool + engine facts + epicenter ──────────
        let mut pool = ctx.pool;

        // Fold in engine query facts (quality-filtered)
        for fact in engine_result.facts {
            if Self::is_quality_triple(&fact) {
                pool.push((fact, 1.0));
            }
        }

        // Interference epicenter triples (using the full multi-radius scan for
        // epicenter reading, since the iterative passes already found anchors)
        let full_interference = self.interference_scan(&preprocessed, &patterns);
        if full_interference.hit_count > 0 || !full_interference.all_hits.is_empty() {
            let epicenter_text = self.read_from_epicenter(&full_interference);
            if Self::is_coherent_output(&epicenter_text) {
                for sentence in epicenter_text.split(|c| c == '.' || c == '!') {
                    let words: Vec<&str> = sentence.split_whitespace().collect();
                    if words.len() >= 3 {
                        let subj = words[0].to_string();
                        let rel  = words[1].to_string();
                        let obj  = words[2..].join(" ");
                        pool.push((carousel_hash::dada_engine::RelationalTriple::new(
                            subj, rel, obj, 0.6,
                        ), 0.6));
                    }
                }
            }
        }

        // ── Stage 6: Slot-geometry × coherence scoring ────────────────────────
        {
            use carousel_hash::superposition_decoder::pack_slot;
            let (norm_tokens, _, _) = self.engine.normalize(input);
            
            // Filter out pronouns from content_words used for slot geometry seed.
            // Pronouns remain fully searchable in triples and graph.
            let pronouns = ["i", "you", "we", "it", "this", "that", "he", "she", "they", "me", "us", "him", "her", "them"];
            
            let content_words: Vec<String> = norm_tokens.iter()
                .filter(|w| !self.engine.function_words.contains(*w))
                .filter(|w| !pronouns.contains(&w.as_str()))
                .map(|w| w.trim_matches(|c: char| "?:!,.".contains(c)).to_string())
                .filter(|w| !w.is_empty())
                .collect();

            let qa = (content_words.first().map(|w| w.len()).unwrap_or(1) as u8).min(31);
            let qb = (content_words.len() as u8).min(31);
            let query_slot = pack_slot(qa, qb);

            let max_mag: u64 = pool.iter().map(|(t, _)| {
                if t.slot_val > 0 { self.engine.slot_decoder.magnitude(t.slot_val) } else { 1 }
            }).max().unwrap_or(1).max(1);

            for (triple, weight) in &mut pool {
                let geo = if triple.slot_val > 0 {
                    let mag = self.engine.slot_decoder.magnitude(triple.slot_val) as f64;
                    let band_sim = self.engine.slot_decoder.band_similarity(query_slot, triple.slot_val);
                    let mag_factor = 0.1 + 0.9 * (mag / max_mag as f64);
                    (mag_factor * (0.8 + 0.2 * band_sim)) as f32
                } else {
                    0.85
                };
                *weight *= geo * triple.confidence;
            }
        }

        // ── Stage 6b: Re-deduplicate after engine + epicenter additions ────────
        {
            let mut seen: std::collections::HashMap<(String,String,String), usize> = std::collections::HashMap::new();
            let mut deduped: Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> = Vec::new();
            for (triple, weight) in pool {
                let key = (triple.subject.to_lowercase(), triple.relation.to_lowercase(), triple.object.to_lowercase());
                if let Some(&idx) = seen.get(&key) {
                    if weight > deduped[idx].1 { deduped[idx].1 = weight; }
                } else {
                    seen.insert(key, deduped.len());
                    deduped.push((triple, weight));
                }
            }
            pool = deduped;
        }
        pool.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        // ── Stage 6c: Transitive closure — fill open terminals ────────────────
        // Detects triples whose object dangles mid-relation ("into a", "causes me")
        // and walks forward through the relation graph to fill the terminus.
        // Uses slot geometry for proximity, cycle penalty for visited nodes.
        self.transitive_closure_pass(&mut pool);

        // ── Stage 6d: LOCAL CONTEXT FAN-IN (for DefThing and other critical routes) ──
        // For DefThing queries, if the top-ranked triple exists, enrich it with
        // nearby definition-like triples without pre-extraction.
        // GATED: disabled until routing is verified stable.
        if false && (route == Route::DefThing || route == Route::DefUserName) && !pool.is_empty() {
            let top_triple = pool[0].0.clone();
            let context_enrichment = self.enrich_with_local_context(top_triple);
            eprintln!("📚 Stage 6d: DefThing local context fan-in found {} enrichment triples",
                context_enrichment.len() - 1);
            
            // Merge enrichment triples into pool (before filtering)
            for (ctx_triple, ctx_weight) in context_enrichment.iter().skip(1) {
                // Add context triples with moderate weighting (below anchor but competitive)
                pool.push((ctx_triple.clone(), *ctx_weight * 0.8));
            }
            
            // Re-sort and de-deduplicate
            {
                let mut seen: std::collections::HashMap<(String,String,String), usize> = std::collections::HashMap::new();
                let mut rededuped: Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> = Vec::new();
                for (triple, weight) in pool {
                    let key = (triple.subject.to_lowercase(), triple.relation.to_lowercase(), triple.object.to_lowercase());
                    if let Some(&idx) = seen.get(&key) {
                        if weight > rededuped[idx].1 { rededuped[idx].1 = weight; }
                    } else {
                        seen.insert(key, rededuped.len());
                        rededuped.push((triple, weight));
                    }
                }
                pool = rededuped;
            }
            pool.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        }

        // ── Stage 7: Synthesize from merged pool ──────────────────────────────
        // Filter: (a) skip similarity relations, (b) skip dangling objects
        let final_facts: Vec<carousel_hash::dada_engine::RelationalTriple> =
            pool.into_iter()
                .filter(|(t, _)| {
                    let rel_lower = t.relation.to_lowercase();
                    !(rel_lower.contains("similar") || rel_lower.contains("same as")
                      || rel_lower.contains("synonym"))
                })
                .filter(|(t, _)| {
                    // Reject triples whose object is a dangling terminal:
                    // "into a", "in a", "the", "can be", etc.
                    !Self::is_open_terminal(&t.object)
                })
                .take(12)
                .map(|(t, _)| t)
                .collect();

        // ── Stage 7a: DADA chain synthesis (primary) ─────────────────────────
        if !final_facts.is_empty() {
            let response = self.synthesize_from_facts(input, route, synthesis_method, &final_facts);
            if Self::is_coherent_output(&response) {
                self.grow_synsets_from_relations();
                return self.finalise_timed(response, pipeline_start);
            }
        }

        // ── Stage 7b: Engine facts directly ──────────────────────────────────
        if let Some(ref qr) = self.last_query_result {
            let engine_direct: Vec<carousel_hash::dada_engine::RelationalTriple> = qr.facts.iter()
                .filter(|t| Self::is_quality_triple(t) && !Self::is_open_terminal(&t.object))
                .take(8)
                .cloned()
                .collect();
            if !engine_direct.is_empty() {
                let response = self.synthesize_from_facts(input, route, synthesis_method, &engine_direct);
                if Self::is_coherent_output(&response) {
                    self.grow_synsets_from_relations();
                    return self.finalise_timed(response, pipeline_start);
                }
            }
        }

        // ── Stage 7c: Raw pool dump — ugly but correctable ────────────────────
        // The learning loop REQUIRES output to correct. Silence severs the loop.
        // If synthesis can't assemble a clean sentence, output the raw fragments
        // so the user can correct them and the graph can improve.
        if !final_facts.is_empty() {
            let raw: String = final_facts.iter()
                .filter(|t| Self::is_quality_triple(t))
                .take(4)
                .map(|t| {
                    let rel = t.relation.to_lowercase().replace('_', " ");
                    format!("{} {} {}", t.subject, rel, t.object)
                })
                .collect::<Vec<_>>()
                .join(". ");
            if !raw.trim().is_empty() {
                self.grow_synsets_from_relations();
                return self.finalise_timed(raw, pipeline_start);
            }
        }

        // ── Stage 7d: Epicenter raw text ──────────────────────────────────────
        let fallback_interference = self.interference_scan(&preprocessed, &patterns);
        if fallback_interference.hit_count > 0 {
            let epi_text = self.read_from_epicenter(&fallback_interference);
            if Self::is_coherent_output(&epi_text) {
                self.grow_synsets_from_relations();
                return self.finalise_timed(epi_text, pipeline_start);
            }
        }

        // ── Stage 7e: Absolute last resort — live token tape ───────────────────
        // Was: scanned self.engine.relations (empty in a fresh train+chat
        // session -- see interference_score_at's doc comment) as the very
        // last fallback before giving up entirely -- meaning a query that
        // fell through every earlier stage landed here and got
        // "(no relations found for: ...)" unconditionally. Live
        // equivalent: pull live_neighbors for each content word actually
        // in the query.
        let query_words: Vec<String> = preprocessed.to_lowercase()
            .split_whitespace()
            .filter(|w| w.len() > 3 && !self.engine.tok_is_function_word(*w))
            .map(|w| w.to_string())
            .collect();

        let mut last_resort_facts: Vec<String> = Vec::new();
        'outer: for word in &query_words {
            for (rel_word, neighbor) in self.engine.live_neighbors(word) {
                let rel_lower = rel_word.to_lowercase();
                if rel_lower.contains("similar") || rel_lower.contains("same as") { continue; }
                if Self::is_open_terminal(&neighbor) { continue; }
                last_resort_facts.push(format!("{} {} {}", word, humanize_relation_simple(&rel_word), neighbor));
                if last_resort_facts.len() >= 3 { break 'outer; }
            }
        }
        let last_resort: String = last_resort_facts.join(". ");

        self.grow_synsets_from_relations();
        if !last_resort.trim().is_empty() {
            self.finalise_timed(last_resort, pipeline_start)
        } else {
            // Pool was genuinely empty — nothing at all matched the query
            self.finalise_timed(format!("(no relations found for: {})", input.trim()), pipeline_start)
        }
    }

    /// Collect similarity/comparison triples for Route::Similarity
    fn collect_similarity_triples(&mut self, raw: &str) -> Vec<carousel_hash::dada_engine::RelationalTriple> {
        let anchor = self.preprocess_input(raw);
        self.engine.relations.iter()
            .filter(|tr| {
                let rel = tr.relation.to_lowercase();
                (rel.contains("similar") || rel.contains("like") || rel.contains("related"))
                    && (anchor.contains(&tr.subject.to_lowercase())
                        || anchor.contains(&tr.object.to_lowercase()))
            })
            .cloned()
            .collect()
    }

    /// Finalise with timing — logs pipeline elapsed time
    fn finalise_timed(&mut self, response: String, start: std::time::Instant) -> String {
        let elapsed_ms = start.elapsed().as_secs_f64() * 1000.0;
        eprintln!("⏱️  Pipeline: {:.1}ms", elapsed_ms);
        self.finalise(response)
    }
    
    /// Stage 1: Preprocess input - strip WH/aux words, resolve anaphora
    fn preprocess_input(&self, input: &str) -> String {
        let mut processed = input.to_string().to_lowercase();
        
        // 1a: Strip WH words and auxiliaries (what, who, where, is, are, etc.)
        let stop_words = ["what", "who", "where", "when", "why", "how", "is", "are", "was", "were", 
                         "do", "does", "did", "can", "could", "would", "should", "the", "a", "an"];
        for word in &stop_words {
            processed = processed.replace(&format!(" {} ", word), " ");
            if processed.starts_with(&format!("{} ", word)) {
                processed = processed[word.len() + 1..].to_string();
            }
        }
        
        // 1b: Anaphora resolution (it, this, that, they, he, she)
        let recent_context: Vec<ContextTriple> = self.engine.relations.iter().enumerate().rev().take(10)
            .map(|(i, t)| ContextTriple::new(
                &t.subject,
                format!("{:?}", t.relation),
                &t.object,
                i as u32,
            ))
            .collect();
        
        let resolver = UniversalResolver::new();
        let anaphora_words = ["it", "this", "that", "they", "them", "he", "she", "his", "her"];
        for word in &anaphora_words {
            if processed.contains(word) {
                let resolved = resolver.resolve(word, &recent_context, 10, 0);
                if let Some(r) = resolved.as_str() {
                    let pattern = format!(" {} ", word);
                    let replacement = format!(" {} ", r);
                    processed = processed.replace(&pattern, &replacement);
                }
            }
        }
        
        processed.trim().to_string()
    }

    /// Parses structured equational queries like "does X cause Y?" or "is X Y because Z?"
    /// Returns (subject, verb, object, optional_context) if matched.
    fn parse_equational_query(raw: &str) -> Option<(String, String, String, Option<String>)> {
        let s_lower = raw.to_lowercase();
        let s = s_lower.trim();

        // Pattern: "does X cause Y?"
        if s.starts_with("does ") && s.contains(" cause ") {
            let after_does = s.trim_start_matches("does ").trim();
            if let Some(pos) = after_does.find(" cause ") {
                let subj = after_does[..pos].trim().to_string();
                let obj = after_does[pos + " cause ".len()..].trim_end_matches('?').trim().to_string();
                return Some((subj, "cause".to_string(), obj, None));
            }
        }

        // Pattern: "is X Y because Z?"
        if s.starts_with("is ") && s.contains(" because ") {
            let after_is = s.trim_start_matches("is ").trim();
            if let Some(pos) = after_is.find(" because ") {
                let xy = after_is[..pos].trim();
                let context = after_is[pos + " because ".len()..].trim_end_matches('?').trim().to_string();
                if let Some(is_pos) = xy.find(" ") {
                    let subj = xy[..is_pos].trim().to_string();
                    let obj = xy[is_pos..].trim().to_string();
                    return Some((subj, "is".to_string(), obj, Some(context)));
                }
            }
        }

        // Pattern: "can X do Y?"
        if s.starts_with("can ") && s.contains(" do ") {
            let after_can = s.trim_start_matches("can ").trim();
            if let Some(pos) = after_can.find(" do ") {
                let subj = after_can[..pos].trim().to_string();
                let obj = after_can[pos + " do ".len()..].trim_end_matches('?').trim().to_string();
                return Some((subj, "can".to_string(), obj, None));
            }
        }

        // Pattern: "why does X do Y?" (causal)
        if s.starts_with("why ") && s.contains(" do ") {
            let after_why = s.trim_start_matches("why ").trim();
            if let Some(pos) = after_why.find(" do ") {
                let subj = after_why[..pos].trim().to_string();
                let obj = after_why[pos + " do ".len()..].trim_end_matches('?').trim().to_string();
                return Some((subj, "why-do".to_string(), obj, None));
            }
        }

        None
    }

    /// Very small intent classifier for lightweight routing (first-clause only)
    fn detect_route(&self, raw: &str) -> Route {
        let s = raw.to_lowercase();

        // Short confirmation/denial phrases should be treated as corrections
        // so that follow-up 'yes'/'no' replies are routed to the corrective
        // flow (ingest_user / acknowledgement) instead of being treated as
        // generic QA.
        let trimmed = s.trim();
        if trimmed == "yes" || trimmed.starts_with("yes,") || trimmed.starts_with("yes ") ||
           trimmed == "yep" || trimmed == "yeah" || trimmed == "affirmative" ||
           trimmed.starts_with("that's correct") || trimmed.starts_with("that is correct") {
            return Route::Correction;
        }
        // "no" / "nope" alone are corrections.
        // "no, <question>" is NOT — strip "no," and route the real question.
        // "no, your name is X" IS a correction (possessive assertion follows).
        {
            let is_bare_no = trimmed == "no" || trimmed == "nope" || trimmed == "nah"
                || trimmed == "incorrect"
                || trimmed.starts_with("that's wrong")
                || trimmed.starts_with("that is wrong");

            let is_no_prefix = trimmed.starts_with("no,") || trimmed.starts_with("no ");
            let after_no = if trimmed.starts_with("no,") {
                trimmed["no,".len()..].trim()
            } else if trimmed.starts_with("no ") {
                trimmed["no ".len()..].trim()
            } else {
                ""
            };

            // "no, <question word>" → NOT a correction, route the question
            let embedded_question = after_no.starts_with("what ")
                || after_no.starts_with("who ")
                || after_no.starts_with("why ")
                || after_no.starts_with("when ")
                || after_no.starts_with("where ")
                || after_no.starts_with("how ")
                || after_no.starts_with("which ")
                || after_no.starts_with("are ")
                || after_no.starts_with("is ")
                || after_no.starts_with("do ")
                || after_no.starts_with("does ")
                || after_no.starts_with("can ")
                || after_no.starts_with("will ");

            if is_bare_no || (is_no_prefix && !embedded_question) {
                return Route::Correction;
            }
        }

        // Direct identity verification — route to fact lookup, not capability flood
        if s.starts_with("are you ") || s.starts_with("is this ") || s.starts_with("am i ") {
            return Route::Verification;
        }

        // Declarative identity assertions: "You are X." / "I am X." / "You are X and Y."
        // These are facts being asserted about the bot or the user — store them.
        // Also catches multi-sentence inputs like "You are X. Your name is Y."
        if s.starts_with("you are ") || s.starts_with("i am ")
            || (s.contains(" you are ") && !s.contains('?'))
            || (s.contains(" i am ") && !s.contains('?')) {
            return Route::Correction;
        }

        // Additional correction/assurance patterns: confirmations, retractions,
        // assurances and other short signals that should route to correction.
        if trimmed.starts_with("i confirm") || trimmed.starts_with("confirm") ||
           trimmed.contains("assure") || trimmed.contains("promise") ||
           trimmed.starts_with("i agree") || trimmed.starts_with("i disagree") ||
           trimmed.contains("actually") || trimmed.contains("take back") ||
           trimmed.contains("take that back") || trimmed.contains("take it back") ||
           trimmed.contains("retract") || trimmed.contains("undo") {
            return Route::Correction;
        }

        // Declarative possessive assertions like "my X is Y" / "your X is Y"
        // should be routed to the Correction fast-path so they are
        // canonically ingested (ingest_user) and acknowledged instead of
        // being handed to DADA synthesis which can produce misleading
        // replies (see reported "your is john" behavior).
        if trimmed.starts_with("my ") || trimmed.starts_with("your ") {
            if trimmed.contains(" is ") || trimmed.contains(" are ") || trimmed.contains("'s ") {
                return Route::Correction;
            }
        }

        if s.starts_with("what is my name") || s.starts_with("who am i") {
            return Route::DefUserName;
        }

        // *** PHASE 3: Enforce WH + copula pattern for DefThing ***
        // "What is X?" or "What's X?" → DefThing
        // This is the most common definition query and should NOT fall through to GenericQA.
        if s.starts_with("what is ") || s.starts_with("what's ") || s.starts_with("what are ") {
            return Route::DefThing;
        }

        // "Who is X?" — also DefThing (identity definition)
        if s.starts_with("who is ") || s.starts_with("who's ") {
            return Route::DefThing;
        }

        if s.starts_with("why") { return Route::Cause; }
        if s.starts_with("when") { return Route::Time; }
        if s.starts_with("where") { return Route::Place; }

        // *** PHASE 3: Strengthen capability detection before GenericQA ***
        // "What does X do?" → Capability (process query)
        // "What can X do?" → Capability
        // "Can X...?" → Capability or Verification
        if s.starts_with("what does ") || s.starts_with("what do ") {
            return Route::Capability;
        }
        
        if s.starts_with("can ") || s.starts_with("could ") || s.starts_with("will ") || 
           s.starts_with("would ") || s.starts_with("should ") || s.starts_with("may ") ||
           s.starts_with("might ") {
            // Yes/no question or capability question — route to Capability (which handles both)
            return Route::Capability;
        }

        if s.starts_with("does ") || s.starts_with("did ") ||
           s.starts_with("are ") || s.starts_with("is ") || s.starts_with("do ") ||
           s.starts_with("am ") || s.starts_with("have ") || s.starts_with("has ") || 
           s.starts_with("had ") {
            // Yes/no question or capability question — route to Capability (which handles both)
            return Route::Capability;
        }

        // Path/chain queries: "path from X to Y", "connection between", "how to get from"
        if s.contains("path from") || s.contains("path between") ||
           s.contains("connection between") || s.contains("link between") ||
           s.contains("get from") && s.contains(" to ") ||
           s.contains("chain from") || s.contains("steps from") {
            return Route::Path;
        }

        if s.starts_with("how") {
            if s.contains("similar") || s.contains("like") || s.contains("related") { return Route::Similarity; }
            return Route::Manner;
        }

        // Enhanced negation detection for routing
        if s.starts_with("no,") || s.starts_with("not ") || s.starts_with("never ") ||
           s.contains("is not") || s.contains("was not") || s.contains("are not") || s.contains("were not") ||
           s.contains("isn't") || s.contains("wasn't") || s.contains("aren't") || s.contains("weren't") ||
           s.contains("can't") || s.contains("cannot") || s.contains("couldn't") ||
           s.contains("won't") || s.contains("wouldn't") || s.contains("shouldn't") ||
           s.contains("don't") || s.contains("doesn't") || s.contains("didn't") ||
           s.contains("haven't") || s.contains("hasn't") || s.contains("hadn't") ||
           s.contains("mustn't") || s.contains("no ") || s.contains("never ") ||
           s.contains("nothing") || s.contains("nobody") || s.contains("none") ||
           s.contains("neither") || s.contains("nor") || s.contains("no one") {
            return Route::Correction;
        }

        // *** PHASE 3: GenericQA only as last resort ***
        // Only reach here if NO structural pattern was detected above.
        // All strong patterns (WH + copula, explicit question forms, etc.) are handled first.
        Route::GenericQA
    }

    /// Sophisticated synthesis method selector based on query characteristics
    fn select_synthesis_method(&self, input: &str, route: Route) -> SynthesisMethod {
        let s = input.to_lowercase();
        let tokens: Vec<&str> = s.split_whitespace().collect();
        
        // Word-specific synthesis styles
        if tokens.contains(&"what") {
            if tokens.contains(&"is") || tokens.contains(&"was") {
                return SynthesisMethod::Definition;
            }
            if tokens.contains(&"do") || tokens.contains(&"does") {
                return SynthesisMethod::Process;
            }
            if tokens.contains(&"can") {
                return SynthesisMethod::Capability;
            }
        }
        
        if tokens.contains(&"where") {
            return SynthesisMethod::Location;
        }
        
        if tokens.contains(&"who") {
            return SynthesisMethod::Identity;
        }
        
        if tokens.contains(&"when") {
            return SynthesisMethod::Temporal;
        }
        
        if tokens.contains(&"why") {
            return SynthesisMethod::Causal;
        }
        
        if tokens.contains(&"how") {
            if tokens.contains(&"many") || tokens.contains(&"much") {
                return SynthesisMethod::Quantitative;
            }
            if tokens.contains(&"do") || tokens.contains(&"to") {
                return SynthesisMethod::Instructional;
            }
            return SynthesisMethod::Method;
        }
        
        // Negation-specific synthesis
        if self.has_negation(&s) {
            if tokens.contains(&"won't") || tokens.contains(&"will") && tokens.contains(&"not") {
                return SynthesisMethod::Refusal;
            }
            if tokens.contains(&"can't") || tokens.contains(&"cannot") ||
               tokens.contains(&"couldn't") || tokens.contains(&"could") && tokens.contains(&"not") {
                return SynthesisMethod::Inability;
            }
            if tokens.contains(&"shouldn't") || tokens.contains(&"should") && tokens.contains(&"not") {
                return SynthesisMethod::Disapproval;
            }
            if tokens.contains(&"don't") || tokens.contains(&"doesn't") || tokens.contains(&"didn't") {
                return SynthesisMethod::Negation;
            }
            return SynthesisMethod::Correction;
        }
        
        // Route-based synthesis
        match route {
            Route::DefUserName => SynthesisMethod::Personal,
            Route::DefThing => SynthesisMethod::Definition,
            Route::Cause => SynthesisMethod::Causal,
            Route::Manner => SynthesisMethod::Method,
            Route::Time => SynthesisMethod::Temporal,
            Route::Place => SynthesisMethod::Location,
            Route::Capability => SynthesisMethod::Capability,
            Route::Similarity => SynthesisMethod::Comparative,
            Route::Verification => SynthesisMethod::Personal,
            Route::Correction => SynthesisMethod::Correction,
            Route::GenericQA => SynthesisMethod::General,
            Route::Path => SynthesisMethod::Sequential,
        }
    }

    /// Check if input contains negation patterns
    fn has_negation(&self, text: &str) -> bool {
        let negation_patterns = [
            "no", "not", "never", "nothing", "nobody", "none", "neither", "nor",
            "isn't", "wasn't", "aren't", "weren't", "can't", "cannot", "couldn't",
            "won't", "wouldn't", "shouldn't", "mustn't", "don't", "doesn't", "didn't",
            "haven't", "hasn't", "hadn't"
        ];
        
        negation_patterns.iter().any(|&pattern| text.contains(pattern))
    }

    /// Generate method-aware response based on synthesis method
    fn generate_method_aware_response(&self, _input: &str, method: SynthesisMethod) -> String {
        // Simple acknowledgment responses that show understanding without claiming ignorance
        match method {
            SynthesisMethod::Definition => {
                "I understand what you're asking about.".to_string()
            },
            SynthesisMethod::Process => {
                "I understand the process you're asking about.".to_string()
            },
            SynthesisMethod::Capability => {
                "I understand the capability you're asking about.".to_string()
            },
            SynthesisMethod::Location => {
                "I understand the location you're asking about.".to_string()
            },
            SynthesisMethod::Identity => {
                "I understand who you're asking about.".to_string()
            },
            SynthesisMethod::Temporal => {
                "I understand the timing you're asking about.".to_string()
            },
            SynthesisMethod::Causal => {
                "I understand the reason you're asking about.".to_string()
            },
            SynthesisMethod::Method => {
                "I understand the method you're asking about.".to_string()
            },
            SynthesisMethod::Quantitative => {
                "I understand the quantity you're asking about.".to_string()
            },
            SynthesisMethod::Instructional => {
                "I understand the instructions you're asking about.".to_string()
            },
            SynthesisMethod::Personal => {
                "I understand the personal information you're asking about.".to_string()
            },
            SynthesisMethod::Comparative => {
                "I understand the comparison you're asking about.".to_string()
            },
            SynthesisMethod::Sequential => {
                "I understand the sequence you're asking about.".to_string()
            },
            SynthesisMethod::Refusal => {
                "I understand your refusal.".to_string()
            },
            SynthesisMethod::Inability => {
                "I understand the inability.".to_string()
            },
            SynthesisMethod::Disapproval => {
                "I understand your concern.".to_string()
            },
            SynthesisMethod::Negation => {
                "I understand the negation.".to_string()
            },
            SynthesisMethod::Correction => {
                "I understand your correction.".to_string()
            },
            SynthesisMethod::General => {
                "I understand.".to_string()
            },
        }
    }

    /// Generate a topic-aware acknowledgment instead of silent "I understand."
    /// Extracts the first significant word from content_words and echoes it back
    /// to signal what was understood.
    fn topic_acknowledgment(content_words: &[String]) -> String {
        if content_words.is_empty() {
            return "I understand.".to_string();
        }
        let topic = content_words
            .iter()
            .filter(|w| w.len() > 3)
            .next()
            .map(|w| w.as_str())
            .unwrap_or(content_words[0].as_str());
        format!("I understand you're asking about {}.", topic)
    }

    // ═══════════════════════════════════════════════════════════════════
    // LOCAL CONTEXT FAN-IN
    //
    // Given an anchor triple, search for contextual triples nearby in the
    // relation store that provide definition-like expansions (IS, MEANS,
    // CALLED, etc.). No pre-extraction; all searches are on-demand using
    // existing engine structures.
    //
    // Returns enriched pool with proximity-based weighting: triples closer
    // to the anchor or more "definition-like" get higher rank.
    // ═══════════════════════════════════════════════════════════════════

    /// Search for triples that are contextually nearby to the anchor triple.
    /// "Nearby" means:
    /// - Subject or object contains anchor's subject or object (token overlap)
    /// - Relation type is definition-like (IS, MEANS, CALLED, etc.)
    /// - Returns ranked list (definition relations weighted higher)
    ///
    /// This is the core local_context_fan_in operator: it finds enrichment
    /// triples without any pre-extraction, using only the live relation store.
    fn find_local_context(&self, anchor: &carousel_hash::dada_engine::RelationalTriple, window_size: usize) -> Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> {
        let mut context_pool: Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> = Vec::new();

        let anchor_subject_lower = anchor.subject.to_lowercase();
        let anchor_object_lower = anchor.object.to_lowercase();

        // Definition-like relation patterns (prioritized by semantic weight)
        let definition_relations = [
            ("is", 1.0),
            ("means", 0.95),
            ("called", 0.9),
            ("known as", 0.9),
            ("defined as", 0.95),
            ("is_a", 0.85),
            ("is a", 0.85),
            ("is_also", 0.8),
            ("aka", 0.8),
        ];

        let is_definition_like = |rel: &str| -> Option<f32> {
            let rel_lower = rel.to_lowercase();
            for (defn_rel, weight) in &definition_relations {
                if rel_lower.contains(defn_rel) {
                    return Some(*weight);
                }
            }
            None
        };

        // Scan the relation store for triples that:
        // 1. Share subject/object tokens with anchor
        // 2. Use definition-like relations
        // 3. Are within a bounded window (to avoid O(N) on very large stores)
        let mut scanned = 0usize;
        let mut found_defs = 0usize;

        for _idx in 0..window_size {
            if self.engine.relations.is_empty() { break; }
            let idx = if _idx >= self.engine.relations.len() { 
                break; 
            } else { 
                self.engine.relations.len() - 1 - _idx 
            };
            scanned += 1;

            let candidate = &self.engine.relations[idx];

            let candidate_subject_lower = candidate.subject.to_lowercase();
            let candidate_object_lower = candidate.object.to_lowercase();

            // Check for token overlap: does the candidate share meaningful vocabulary with anchor?
            let subject_overlap = anchor_subject_lower.split_whitespace()
                .any(|w| w.len() > 2 && candidate_subject_lower.contains(w))
                || candidate_subject_lower.split_whitespace()
                .any(|w| w.len() > 2 && anchor_subject_lower.contains(w));

            let object_overlap = anchor_object_lower.split_whitespace()
                .any(|w| w.len() > 2 && candidate_object_lower.contains(w))
                || candidate_object_lower.split_whitespace()
                .any(|w| w.len() > 2 && anchor_object_lower.contains(w));

            if !(subject_overlap || object_overlap) { continue; }

            // Is this a definition-like relation?
            if let Some(defn_weight) = is_definition_like(&candidate.relation) {
                // Quality gate: skip open terminals and garbage
                if Self::is_open_terminal(&candidate.object) { continue; }
                if !Self::is_quality_triple(candidate) { continue; }

                // Rank by: definition weight + candidate confidence
                let rank = defn_weight * candidate.confidence;
                context_pool.push((candidate.clone(), rank));
                found_defs += 1;
            }
        }

        eprintln!("📚 Local context: scanned {} recent relations, found {} definition-like triples",
            scanned, found_defs);

        // Sort by rank (descending) and return
        context_pool.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        context_pool
    }

    /// Enrich a winning triple with its local context.
    /// Given one high-scoring triple from competitive pulling (e.g., from DefThing),
    /// use local_context_fan_in to find nearby definition/context triples.
    ///
    /// Returns a merged pool: [anchor] + [top N context triples] for synthesis.
    /// This ensures DefThing questions like "what is X?" get enriched with
    /// related IS/MEANS/CALLED facts without pre-extraction.
    fn enrich_with_local_context(
        &self,
        anchor: carousel_hash::dada_engine::RelationalTriple,
    ) -> Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> {
        let mut enriched: Vec<(carousel_hash::dada_engine::RelationalTriple, f32)> = vec![(anchor.clone(), 1.0)];

        // Find contextual triples nearby in the relation store
        // Scan up to 500 recent relations (configurable window)
        let context = self.find_local_context(&anchor, 500);

        // Add top context triples (max 4 to avoid swamping the primary fact)
        for (ctx_triple, ctx_weight) in context.iter().take(4) {
            // Proximity bonus: context triples get slightly lower weight than anchor
            // but still compete fairly in synthesis
            enriched.push((ctx_triple.clone(), ctx_weight * 0.7));
        }

        enriched
    }

    /// Fast-path: return the user's name from slot-focused facts (if present)
    fn handle_def_user_name(&mut self, _raw: &str) -> Option<String> {
        // Delegate to the generic possessive handler to enforce universal
        // "my X" → "Your X is ..." / "your X" → "My X is ..." semantics.
        self.handle_def_thing("What is my name?")
    }

    /// Fast-path: answer "what is X" using slot-focused selection (no heavy reasoning)
    fn handle_def_thing(&mut self, raw: &str) -> Option<String> {
        eprintln!("📖 handle_def_thing called with: '{}'", raw);
        // Try to extract the noun/phrase after "what is"
        let lower = raw.to_lowercase();
        let thing = if let Some(pos) = lower.find("what is ") {
            lower[pos + "what is ".len()..].split(&['?', '.'][..]).next().unwrap_or("").trim().to_string()
        } else if let Some(pos) = lower.find("what's ") {
            lower[pos + "what's ".len()..].split(&['?', '.'][..]).next().unwrap_or("").trim().to_string()
        } else {
            // fallback to first content word from preprocessed input
            self.preprocess_input(raw).split_whitespace().next().unwrap_or("").to_string()
        };

        if thing.is_empty() { return None; }

        // Prefer explicit `is` facts (timeline-aware)
        // BUT: enrich with local context before returning!
        if let Some(_obj) = self.engine.resolve_is_from_timeline(&thing) {
            // Find the actual triple that matched (search for matching subject + IS relation)
            let mut winning_triple: Option<carousel_hash::dada_engine::RelationalTriple> = None;
            for tr in self.engine.relations.iter().rev() {
                let subj_l = tr.subject.to_lowercase();
                let rel_l = tr.relation.to_lowercase();
                if subj_l.split_whitespace().any(|t| t == thing.to_lowercase()) && rel_l.contains("is") {
                    winning_triple = Some(tr.clone());
                    break;
                }
            }
            
            if let Some(anchor) = winning_triple {
                eprintln!("🎯 Timeline found triple: {}", anchor.subject);
                // ── LOCAL CONTEXT FAN-IN (GATED) ──
                // Disabled until routing is verified stable.
                if false {
                    let enriched_pool = self.enrich_with_local_context(anchor.clone());
                    eprintln!("✨ DefThing enrichment: {} → {} context triples", anchor.subject, enriched_pool.len() - 1);
                    
                    if enriched_pool.len() > 1 {
                        let facts: Vec<carousel_hash::dada_engine::RelationalTriple> = enriched_pool
                            .into_iter()
                            .take(3)
                            .map(|(t, _)| t)
                            .collect();
                        eprintln!("  Enriched facts for synthesis:");
                        for (i, f) in facts.iter().enumerate() {
                            eprintln!("    [{}] {} {} {}", i, f.subject, f.relation, f.object);
                        }
                        let synthesized = self.synthesize_from_facts(raw, Route::DefThing, SynthesisMethod::Definition, &facts);
                        eprintln!("  Synthesized: '{}'", synthesized);
                        if !synthesized.is_empty() && synthesized != format!("(no relations found for: {})", raw.trim()) {
                            return Some(synthesized);
                        }
                    }
                }
                
                return Some(format!("{} is {}.", capitalize_first(&anchor.subject), _obj));
            }
        }

        // --- Possessive handling (universal) ---
        // If the query is asking about a possessive slot ("my X" / "your X")
        // answer with the flipped perspective and the stored slot value when
        // available. This is intentionally generic (not name-specific).
        if thing.starts_with("my ") || thing.starts_with("your ") {
            let asking_about_user = thing.starts_with("my ");
            let slot = thing.split_whitespace().skip(1).collect::<Vec<_>>().join(" ");
            let slot_key = slot.trim();
            if !slot_key.is_empty() {
                // Prefer explicit possessive facts first (avoid recent-opinion tie).
                // Skip Self_-sourced triples: the bot's "my X" is its own
                // perspective and must not be confused with the user's "my X".
                use carousel_hash::dada_engine::KnowledgeSource;
                if asking_about_user {
                    for tr in self.engine.relations.iter().rev() {
                        if matches!(tr.source, KnowledgeSource::Self_) { continue; }
                        let subj_l = tr.subject.to_lowercase();
                        if subj_l.contains("my ") && subj_l.contains(slot_key) && tr.relation.to_lowercase().contains("is") {
                            return Some(format!("Your {} is {}.", slot_key, tr.object));
                        }
                    }
                } else {
                    for tr in self.engine.relations.iter().rev() {
                        if matches!(tr.source, KnowledgeSource::Self_) { continue; }
                        let subj_l = tr.subject.to_lowercase();
                        if (subj_l.contains("your ") || subj_l.contains("you")) && subj_l.contains(slot_key) && tr.relation.to_lowercase().contains("is") {
                            return Some(format!("My {} is {}.", slot_key, tr.object));
                        }
                    }
                }

                // Next, fall back to timeline-aware resolution for the slot token
                if let Some(obj) = self.engine.resolve_is_from_timeline(slot_key) {
                    return if asking_about_user {
                        Some(format!("Your {} is {}.", slot_key, capitalize_first(&obj)))
                    } else {
                        Some(format!("My {} is {}.", slot_key, capitalize_first(&obj)))
                    };
                }

                // Finally, scan any subject that contains the slot token
                for tr in self.engine.relations.iter().rev() {
                    let subj_l = tr.subject.to_lowercase();
                    if subj_l.contains(slot_key) && tr.relation.to_lowercase().contains("is") {
                        return if asking_about_user {
                            Some(format!("Your {} is {}.", slot_key, tr.object))
                        } else {
                            Some(format!("My {} is {}.", slot_key, tr.object))
                        };
                    }
                }
            }
            return None;
        }

        // Otherwise, look for nearest relation where subject matches `thing`
        eprintln!("🔍 Searching for triple with subject containing '{}'", thing);
        let mut winning_triple: Option<carousel_hash::dada_engine::RelationalTriple> = None;
        for tr in self.engine.relations.iter().rev() {
            if tr.subject.to_lowercase().contains(&thing) {
                // Prefer 'is' style relations (slot-focused)
                let rel = tr.relation.to_lowercase();
                if rel.contains("is") || rel.contains("name") || rel.contains("called") {
                    // Quality gate: skip garbage triples
                    if tr.relation.contains('+') { continue; }
                    if Self::is_open_terminal(&tr.object) { continue; }
                    if !Self::is_quality_triple(tr) { continue; }
                    
                    winning_triple = Some(tr.clone());
                    break;
                }
            }
        }

        if let Some(tr) = winning_triple {
            eprintln!("🎯 Found fallback DefThing triple: {}", tr.subject);
            // ── LOCAL CONTEXT FAN-IN (DISABLED) ──
            // Fan-in enrichment is gated off to prevent interception of simple queries.
            if false && true {
                // Enrich the winning triple with nearby definition-like triples.
                // This adds context without requiring pre-extraction.
                let enriched_pool = self.enrich_with_local_context(tr.clone());
                eprintln!("✨ DefThing enrichment: {} → {} context triples", tr.subject, enriched_pool.len() - 1);
                
                // For DefThing, we want a brief, focused answer. If we found context,
                // synthesize using the enriched pool; otherwise, use the anchor directly.
                if enriched_pool.len() > 1 {
                    // Use DADA to synthesize from enriched context
                    let facts: Vec<carousel_hash::dada_engine::RelationalTriple> = enriched_pool
                        .into_iter()
                        .take(3)
                        .map(|(t, _)| t)
                        .collect();
                    let synthesized = self.synthesize_from_facts(raw, Route::DefThing, SynthesisMethod::Definition, &facts);
                    if !synthesized.is_empty() && synthesized != format!("(no relations found for: {})", raw.trim()) {
                        return Some(synthesized);
                    }
                }
            }
            
            // Fallback: return simple formatted answer
            return Some(format!("{} {} {}.", capitalize_first(&tr.subject), humanize_relation_simple(&tr.relation), tr.object));
        }

        None
    }

    /// Handle identity/property verification questions: "Are you X?" "Is Y Z?"
    /// Uses reasoning chain lookup to check facts instead of generic capability flooding.
    fn handle_verification(&mut self, raw: &str) -> Option<String> {
        eprintln!("🔎 handle_verification: '{}'", raw);
        let lower = raw.to_lowercase();

        // Extract subject and predicate from standard patterns
        let (subject, predicate) = if lower.starts_with("are you ") {
            ("you", lower["are you ".len()..].split(&['?', '.'][..]).next().unwrap_or("").trim())
        } else if lower.starts_with("is this ") {
            ("this", lower["is this ".len()..].split(&['?', '.'][..]).next().unwrap_or("").trim())
        } else if lower.starts_with("am i ") {
            ("i", lower["am i ".len()..].split(&['?', '.'][..]).next().unwrap_or("").trim())
        } else if lower.starts_with("is ") {
            // Generic "Is X Y?" pattern
            let rest = &lower["is ".len()..];
            if let Some(idx) = rest.find(" ") {
                let subj = &rest[..idx];
                let pred = rest[idx+1..].split(&['?', '.'][..]).next().unwrap_or("").trim();
                (subj, pred)
            } else {
                return None;
            }
        } else {
            return None;
        };

        if predicate.is_empty() || subject.is_empty() {
            return None;
        }

        eprintln!("  Subject: '{}', Predicate: '{}'", subject, predicate);

        // LIVE WALK -- was find_reasoning_chain, which reads self.relations
        // (a store that chat-time corrections stopped populating for the
        // general case once ingest-time regex extraction was cut). This
        // walks self.tokens/token_index directly instead, so it sees
        // "yes, you are good" the moment it's ingested -- Phase 1 tokenizing
        // always runs, regardless of whether anything gets extracted into
        // self.relations.
        let chain = self.engine.live_walk(subject, predicate, 4).unwrap_or_default();
        eprintln!("  Chain length: {}", chain.len());

        if !chain.is_empty() {
            // Confidence decays with chain depth
            let confidence = 1.0 / (chain.len() as f32).max(1.0);
            let yes_no = if confidence > 0.5 { "Yes" } else { "Maybe" };
            let chain_str = chain.iter()
                .map(|(s, r, o)| format!("({} {} {})", s, r, o))
                .collect::<Vec<_>>()
                .join(" → ");
            
            eprintln!("  Response: {} ({:.0}%)", yes_no, confidence * 100.0);
            let copula = if subject == "you" { 
                "I am".to_string() 
            } else { 
                format!("{} is", subject)
            };
            return Some(format!("{}, {}. I found: {}", yes_no, copula, chain_str));
        }

        // Check timeline for direct facts
        if let Some(obj) = self.engine.resolve_is_from_timeline(predicate) {
            eprintln!("  Timeline found: {} is {}", subject, obj);
            let response = if subject == "you" {
                format!("Yes, I am {}.", obj)
            } else {
                format!("Yes, {} is {}.", subject, obj)
            };
            return Some(response);
        }

        // No chain or timeline fact found
        eprintln!("  No confirmation found; checking for negation...");
        let denial = format!("No, I'm not {}.", predicate);
        return Some(denial);
    }

    /// Live-tape trigger-word search: was self.engine.relations (dead
    /// store) filtered for relation words containing a keyword like
    /// "cause"/"because" -- that only ever matched something when Phase 2
    /// regex extraction populated a relation whose *relation slot itself*
    /// was one of those words, which hasn't happened since ingest since
    /// task #12. carousel_lookup/live_neighbors can't stand in directly
    /// here either: their pivot search only fires on verbs registered in
    /// `self.operators` (is/are/can/makes/...), and causal/instrumental
    /// words like "because"/"by"/"through" were only ever registered as
    /// function_words, never operators, so they'd never be picked as a
    /// pivot. This scans directly for the trigger words themselves: find
    /// where the anchor's own content words sit on the tape, take a
    /// sentence-clamped window around each occurrence (tok_is_sentence_end,
    /// not tok_is_boundary -- same reasoning as the interference fix), and
    /// if a trigger word shows up in that window, the phrase right after
    /// it is the answer ("...grows because of sunlight" -> "of sunlight").
    ///
    /// Known limitation: anchor words come from the QUERY's own surface
    /// forms (via preprocess_input), matched against the tape with an
    /// exact lowercase lookup -- "solve" in "did she solve" won't match
    /// "solved" on the tape the way cloze's lemma-flexible matching would.
    /// Other anchor words in the same query usually carry the match
    /// anyway (see "puzzle" in the "How did she solve the puzzle" case),
    /// but a query whose ONLY content word changed tense would still miss.
    /// Not fixed here -- folding morph::same_lemma into this would want
    /// its own pass rather than being bolted on as a side effect of the
    /// why/how fix.
    fn handle_trigger_phrase(&self, raw: &str, triggers: &[&str]) -> Vec<carousel_hash::dada_engine::RelationalTriple> {
        let anchor = self.preprocess_input(raw);
        let anchor_words: Vec<String> = anchor.split_whitespace()
            .filter(|w| w.len() >= 3 && !self.engine.tok_is_function_word(w))
            .map(|w| w.to_lowercase())
            .collect();
        if anchor_words.is_empty() { return Vec::new(); }

        let mut out = Vec::new();
        let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();

        for aw in &anchor_words {
            let Some(positions) = self.engine.token_index.get(aw) else { continue };
            for &pos in positions.iter().rev().take(10) {
                let pos = pos as usize;

                let raw_start = pos.saturating_sub(self.engine.window);
                let mut window_start = raw_start;
                for i in (raw_start..pos).rev() {
                    if WordEngine::tok_is_sentence_end(&self.engine.tokens[i]) { window_start = i + 1; break; }
                }
                let raw_end = (pos + self.engine.window).min(self.engine.tokens.len());
                let mut window_end = raw_end;
                for i in pos..raw_end {
                    if WordEngine::tok_is_sentence_end(&self.engine.tokens[i]) { window_end = i; break; }
                }

                for i in window_start..window_end {
                    if i >= self.engine.tokens.len() { break; }
                    let tok_lower = self.engine.tokens[i].to_lowercase();
                    if !triggers.contains(&tok_lower.as_str()) { continue; }

                    let phrase_end = (i + 1 + 6).min(window_end);
                    let phrase: String = self.engine.tokens[(i + 1)..phrase_end]
                        .iter()
                        .filter(|t| !WordEngine::tok_is_boundary(t))
                        .cloned()
                        .collect::<Vec<_>>()
                        .join(" ");
                    if phrase.trim().is_empty() { continue; }

                    let key = format!("{}|{}|{}", aw, tok_lower, phrase);
                    if !seen.insert(key) { continue; }

                    out.push(carousel_hash::dada_engine::RelationalTriple::new(
                        aw.clone(), tok_lower, phrase, 0.6,
                    ));
                }
            }
        }
        out
    }

    fn handle_cause(&mut self, raw: &str) -> Vec<carousel_hash::dada_engine::RelationalTriple> {
        let mut causal_triples = self.handle_trigger_phrase(raw, &["because", "since"]);

        // Apply boolean reasoning: if we have multiple causal chains, find the most complete story
        if causal_triples.len() > 1 {
            let owned: Vec<(String, String, String)> = causal_triples.iter()
                .map(|t| (t.subject.clone(), format!("{:?}", t.relation), t.object.clone()))
                .collect();
            let tr_map = triples_to_outgoing(owned.iter().map(|(s, r, o)| (s.as_str(), r.as_str(), o.as_str())));
            let tr = TransitiveReasoner::new(&tr_map).with_synsets(&self.synsets);

            let mut enhanced_triples = Vec::new();
            for i in 0..causal_triples.len().min(3) {
                for j in (i+1)..causal_triples.len().min(5) {
                    let chain = tr.find_chain(&causal_triples[i].subject, &causal_triples[j].subject, 4);
                    for hop in &chain {
                        enhanced_triples.push(carousel_hash::dada_engine::RelationalTriple::new(
                            hop.source.clone(), hop.relation.clone(), hop.target.clone(), 0.8,
                        ));
                    }
                }
            }
            causal_triples.extend(enhanced_triples);
        }

        causal_triples
    }

    fn handle_time(&mut self, raw: &str) -> Vec<carousel_hash::dada_engine::RelationalTriple> {
        let anchor = self.preprocess_input(raw);
        let mut temporal_triples: Vec<carousel_hash::dada_engine::RelationalTriple> = Vec::new();
        
        for tr in self.engine.relations.iter().rev() {
            let rel = tr.relation.to_lowercase();
            if rel.contains("before") || rel.contains("after") || rel.contains("during") || rel.contains("since") || rel.contains("until") {
                if Self::anchor_matches(&anchor, &tr.subject) || Self::anchor_matches(&anchor, &tr.object) {
                    temporal_triples.push(tr.clone());
                }
            }
        }

        // Apply boolean reasoning: if we have multiple temporal chains, find the most complete story
        if temporal_triples.len() > 1 {
            // Build transitive reasoning map for temporal analysis
            let owned: Vec<(String, String, String)> = temporal_triples.iter()
                .map(|t| (t.subject.clone(), format!("{:?}", t.relation), t.object.clone()))
                .collect();
            let tr_map = triples_to_outgoing(owned.iter().map(|(s, r, o)| (s.as_str(), r.as_str(), o.as_str())));
            let tr = TransitiveReasoner::new(&tr_map).with_synsets(&self.synsets);
            
            // Find temporal chains between concepts
            let mut enhanced_triples = Vec::new();
            for i in 0..temporal_triples.len().min(3) {
                for j in (i+1)..temporal_triples.len().min(5) {
                    let chain = tr.find_chain(&temporal_triples[i].subject, &temporal_triples[j].subject, 4);
                    if !chain.is_empty() {
                        // Add the chain as inferred relations
                        for hop in &chain {
                            enhanced_triples.push(carousel_hash::dada_engine::RelationalTriple::new(
                                hop.source.clone(),
                                hop.relation.clone(),
                                hop.target.clone(),
                                0.8 // confidence for inferred
                            ));
                        }
                    }
                }
            }
            
            // Combine original and inferred triples
            temporal_triples.extend(enhanced_triples);
        }

        temporal_triples
    }
    fn handle_place(&mut self, raw: &str) -> Vec<carousel_hash::dada_engine::RelationalTriple> {
        let anchor = self.preprocess_input(raw);
        let mut place_triples: Vec<carousel_hash::dada_engine::RelationalTriple> = Vec::new();
        
        for tr in self.engine.relations.iter().rev() {
            let rel = tr.relation.to_lowercase();
            // Word-boundary matching: "in" must be a whole token, not
            // a substring of "find", "into", "beginning", etc.
            if Self::rel_has_word(&rel, "in") || Self::rel_has_word(&rel, "at") || Self::rel_has_word(&rel, "on") || rel.contains("near") || rel.contains("under") || rel.contains("over") {
                if Self::anchor_matches(&anchor, &tr.subject) || Self::anchor_matches(&anchor, &tr.object) {
                    place_triples.push(tr.clone());
                }
            }
        }

        // Apply boolean reasoning: if we have multiple place chains, find the most complete story
        if place_triples.len() > 1 {
            // Build transitive reasoning map for place analysis
            let owned: Vec<(String, String, String)> = place_triples.iter()
                .map(|t| (t.subject.clone(), format!("{:?}", t.relation), t.object.clone()))
                .collect();
            let tr_map = triples_to_outgoing(owned.iter().map(|(s, r, o)| (s.as_str(), r.as_str(), o.as_str())));
            let tr = TransitiveReasoner::new(&tr_map).with_synsets(&self.synsets);
            
            // Find place chains between concepts
            let mut enhanced_triples = Vec::new();
            for i in 0..place_triples.len().min(3) {
                for j in (i+1)..place_triples.len().min(5) {
                    let chain = tr.find_chain(&place_triples[i].subject, &place_triples[j].subject, 4);
                    if !chain.is_empty() {
                        // Add the chain as inferred relations
                        for hop in &chain {
                            enhanced_triples.push(carousel_hash::dada_engine::RelationalTriple::new(
                                hop.source.clone(),
                                hop.relation.clone(),
                                hop.target.clone(),
                                0.8 // confidence for inferred
                            ));
                        }
                    }
                }
            }
            
            // Combine original and inferred triples
            place_triples.extend(enhanced_triples);
        }

        place_triples
    }

    fn handle_capability(&mut self, raw: &str) -> Vec<carousel_hash::dada_engine::RelationalTriple> {
        let anchor = self.preprocess_input(raw);
        let mut capability_triples: Vec<carousel_hash::dada_engine::RelationalTriple> = Vec::new();
        
        for tr in self.engine.relations.iter().rev() {
            let rel = tr.relation.to_lowercase();
            // Word-boundary for "can" (avoid matching "scan", "cancel")
            if Self::rel_has_word(&rel, "can") || rel.contains("able") || rel.contains("capable") {
                if Self::anchor_matches(&anchor, &tr.subject) || Self::anchor_matches(&anchor, &tr.object) {
                    capability_triples.push(tr.clone());
                }
            }
        }

        // Apply boolean reasoning: if we have multiple capability chains, find the most complete story
        if capability_triples.len() > 1 {
            // Build transitive reasoning map for capability analysis
            let owned: Vec<(String, String, String)> = capability_triples.iter()
                .map(|t| (t.subject.clone(), format!("{:?}", t.relation), t.object.clone()))
                .collect();
            let tr_map = triples_to_outgoing(owned.iter().map(|(s, r, o)| (s.as_str(), r.as_str(), o.as_str())));
            let tr = TransitiveReasoner::new(&tr_map).with_synsets(&self.synsets);
            
            // Find capability chains between concepts
            let mut enhanced_triples = Vec::new();
            for i in 0..capability_triples.len().min(3) {
                for j in (i+1)..capability_triples.len().min(5) {
                    let chain = tr.find_chain(&capability_triples[i].subject, &capability_triples[j].subject, 4);
                    if !chain.is_empty() {
                        // Add the chain as inferred relations
                        for hop in &chain {
                            enhanced_triples.push(carousel_hash::dada_engine::RelationalTriple::new(
                                hop.source.clone(),
                                hop.relation.clone(),
                                hop.target.clone(),
                                0.8 // confidence for inferred
                            ));
                        }
                    }
                }
            }
            
            // Combine original and inferred triples
            capability_triples.extend(enhanced_triples);
        }

        capability_triples
    }

    /// Was a deliberate empty stub ("No fallbacks allowed"). Manner/
    /// instrumental questions ("how did she solve it" -> "by working
    /// hard") were never given a real implementation at all -- not a
    /// relations-store regression like the others, just never built.
    /// Uses the same live-tape trigger-word search as handle_cause, with
    /// instrumental prepositions instead of causal ones. "with" is
    /// deliberately left out even though it's a valid manner marker
    /// ("cut it with a knife") -- it's common enough as an ordinary
    /// preposition elsewhere that including it risked more false
    /// positives than it's worth for a first pass.
    fn handle_manner(&mut self, raw: &str) -> Vec<carousel_hash::dada_engine::RelationalTriple> {
        self.handle_trigger_phrase(raw, &["by", "through", "using", "via"])
    }

    fn handle_path(&mut self, raw: &str) -> Vec<carousel_hash::dada_engine::RelationalTriple> {
        let tokens: Vec<String> = self.preprocess_input(raw).split_whitespace().map(|s| s.to_string()).collect();
        let mut path_triples: Vec<carousel_hash::dada_engine::RelationalTriple> = Vec::new();
        
        if tokens.len() >= 2 {
            let a = &tokens[0];
            let b = &tokens[1];
            let owned: Vec<(String, String, String)> = self.engine.relations.iter()
                .map(|t| (t.subject.clone(), format!("{:?}", t.relation), t.object.clone()))
                .collect();
            let tr_map = triples_to_outgoing(owned.iter().map(|(s, r, o)| (s.as_str(), r.as_str(), o.as_str())));
            let tr = TransitiveReasoner::new(&tr_map).with_synsets(&self.synsets);
            let chain = tr.find_chain(a, b, 6);
            
            if !chain.is_empty() {
                // Convert chain hops to relational triples
                for hop in &chain {
                    path_triples.push(carousel_hash::dada_engine::RelationalTriple::new(
                        hop.source.clone(),
                        hop.relation.clone(),
                        hop.target.clone(),
                        1.0 // confidence for direct chain
                    ));
                }
                
                // Apply boolean reasoning: find additional connections between chain elements
                if path_triples.len() > 1 {
                    let chain_owned: Vec<(String, String, String)> = path_triples.iter()
                        .map(|t| (t.subject.clone(), format!("{:?}", t.relation), t.object.clone()))
                        .collect();
                    let chain_tr_map = triples_to_outgoing(chain_owned.iter().map(|(s, r, o)| (s.as_str(), r.as_str(), o.as_str())));
                    let chain_tr = TransitiveReasoner::new(&chain_tr_map).with_synsets(&self.synsets);
                    
                    // Find additional connections between chain elements
                    let mut enhanced_triples = Vec::new();
                    for i in 0..path_triples.len().min(3) {
                        for j in (i+1)..path_triples.len().min(5) {
                            let additional_chain = chain_tr.find_chain(&path_triples[i].subject, &path_triples[j].subject, 3);
                            if !additional_chain.is_empty() {
                                for hop in &additional_chain {
                                    enhanced_triples.push(carousel_hash::dada_engine::RelationalTriple::new(
                                        hop.source.clone(),
                                        hop.relation.clone(),
                                        hop.target.clone(),
                                        0.8 // confidence for inferred
                                    ));
                                }
                            }
                        }
                    }
                    
                    path_triples.extend(enhanced_triples);
                }
            }
        }
        
        path_triples
    }

    fn handle_correction(&mut self, raw: &str) -> Option<String> {
        // Normalize for pattern matching
        let lower = raw.to_lowercase();
        let trimmed = lower.trim();

        // Short standalone "no" — reject the previous answer and let user try again
        if trimmed == "no" || trimmed == "nope" || trimmed == "nah" {
            return Some("What would you like to clarify?".to_string());
        }

        // Short standalone confirmations -> deterministic ack
        if trimmed == "yes" || trimmed == "yep" || trimmed == "yeah" {
            let _ = self.engine.ingest_user(raw);
            return Some("Got it.".to_string());
        }

        // "no, <assertion>" — user is correcting the system's last paraphrase
        // e.g., "no, you're not a special part, you are..." or "no, that's wrong because..."
        if trimmed.starts_with("no ") || trimmed.starts_with("no,") {
            let assertion = trimmed.trim_start_matches("no ").trim_start_matches(",").trim();
            let _ = self.engine.ingest_user(assertion);
            return Some("I understand—thank you for the correction.".to_string());
        }

        // Strip "no, " / "yes, " prefix to allow extraction from corrective statements
        let search_text = trimmed
            .trim_start_matches("no, ")
            .trim_start_matches("no,")
            .trim_start_matches("no ")
            .trim_start_matches("yes, ")
            .trim_start_matches("yes,")
            .trim_start_matches("yes ")
            .trim();

        // ═══════════════════════════════════════════════════════════════════
        // DECLARATIVE ASSERTIONS: "Your/My name is X", "You/I am X", etc.
        // ═══════════════════════════════════════════════════════════════════
        // When user provides a declarative assertion, we:
        // 1. Identify the subject slot (e.g., "your name", "my purpose")
        // 2. Remove any existing facts about that slot
        // 3. Ingest the new assertion
        // 4. Confirm it back to user in natural language
        
        if (search_text.starts_with("your ") || search_text.starts_with("my "))
            && (search_text.contains(" is ") || search_text.contains(" are "))
        {
            if let Some(pos) = search_text.find(" is ") {
                let subj_raw = search_text[..pos].trim();
                let obj_raw = search_text[pos + " is ".len()..].split(|c: char| c == '.' || c == '!' || c == '?').next().unwrap_or("").trim();

                // Extract the slot name (e.g., "name" from "your name" or "my name")
                let slot_name = subj_raw.split_whitespace().skip(1).collect::<Vec<_>>().join(" ");

                // REMOVE: Find and delete any existing facts about this slot
                // (e.g., if correcting "What is your name?", remove old "your name is X" facts)
                self.engine.relations.retain(|tr| {
                    let subj_l = tr.subject.to_lowercase();
                    !(subj_l.contains(&format!("your {}", slot_name)) 
                      || subj_l.contains(&format!("my {}", slot_name))
                      || subj_l.contains("your name")
                      || subj_l.contains("my name"))
                });
                self.engine.rebuild_relation_indices();

                // INGEST: Add the new corrected fact
                let _ = self.engine.ingest_user(raw);

                // CONFIRM: Restate in natural language with perspective flipped
                if subj_raw.starts_with("your ") {
                    // User said "Your name is X" → we respond "My name is X"
                    return Some(format!("My {} is {}.", slot_name, capitalize_first(obj_raw)));
                } else {
                    // User said "My name is X" → we respond "Your name is X"
                    return Some(format!("Your {} is {}.", slot_name, capitalize_first(obj_raw)));
                }
            }
        }

        // ═══════════════════════════════════════════════════════════════════
        // IDENTITY ASSERTIONS: "I am X", "You are X", multi-sentence batches
        // ═══════════════════════════════════════════════════════════════════
        // Split on sentence boundaries so a batch like
        // "You are Number 5. You are a deterministic AI. Your name is Number 5."
        // stores each fact individually and confirms them all.
        {
            let sentences: Vec<&str> = raw.split(|c: char| c == '.' || c == '!' || c == ';')
                .map(|s| s.trim())
                .filter(|s| !s.is_empty())
                .collect();

            // Only enter multi-sentence path if at least one sentence is a
            // "you are" / "i am" / "your X is" / "my X is" assertion.
            let has_assertion = sentences.iter().any(|s| {
                let l = s.to_lowercase();
                l.starts_with("you are ") || l.starts_with("i am ")
                || ((l.starts_with("your ") || l.starts_with("my "))
                    && (l.contains(" is ") || l.contains(" are ")))
            });

            if has_assertion {
                let mut confirmations: Vec<String> = Vec::new();

                for sentence in &sentences {
                    let sl = sentence.to_lowercase();

                    if sl.starts_with("you are ") || sl.starts_with("i am ") {
                        let is_you = sl.starts_with("you are ");
                        let obj = if is_you { &sl["you are ".len()..] } else { &sl["i am ".len()..] }.trim();
                        if obj.is_empty() { continue; }
                        let _ = self.engine.ingest_user(sentence);
                        confirmations.push(if is_you {
                            format!("I am {}.", capitalize_first(obj))
                        } else {
                            format!("You are {}.", capitalize_first(obj))
                        });
                    } else if (sl.starts_with("your ") || sl.starts_with("my "))
                        && sl.contains(" is ") {
                        if let Some(pos) = sl.find(" is ") {
                            let subj_raw = sl[..pos].trim();
                            let obj_raw = sl[pos + " is ".len()..].trim();
                            if obj_raw.is_empty() { continue; }
                            let slot = subj_raw.split_whitespace().skip(1).collect::<Vec<_>>().join(" ");
                            let _ = self.engine.ingest_user(sentence);
                            if subj_raw.starts_with("your ") {
                                confirmations.push(format!("My {} is {}.", slot, capitalize_first(obj_raw)));
                            } else {
                                confirmations.push(format!("Your {} is {}.", slot, capitalize_first(obj_raw)));
                            }
                        }
                    }
                }

                if !confirmations.is_empty() {
                    self.engine.rebuild_relation_indices();
                    return Some(confirmations.join(" "));
                }
            }
        }

        // RETRACTION: user wants to remove an earlier assertion
        if lower.contains("take back") || lower.contains("take that back") || lower.contains("take it back") || lower.contains("retract") || lower.contains("undo") {
            // If user specified a slot: "I take that back about your purpose."
            if let Some(pos) = lower.find("about ") {
                let slot = lower[pos + "about ".len()..].split(|c: char| !c.is_alphanumeric()).next().unwrap_or("").trim().to_string();
                if !slot.is_empty() {
                    if let Some(idx) = self.engine.relations.iter().rposition(|tr| tr.subject.to_lowercase().contains(&slot)) {
                        let _removed = self.engine.relations.remove(idx);
                        return Some("Okay — I removed that.".to_string());
                    } else {
                        return Some("I couldn't find that to remove.".to_string());
                    }
                }
            }

            // Generic retraction: remove a recent possessive-like relation if present
            if let Some(idx) = self.engine.relations.iter().rposition(|tr| {
                let s = tr.subject.to_lowercase();
                s.starts_with("my ") || s.starts_with("your ") || s.contains("purpose")
            }) {
                let _removed = self.engine.relations.remove(idx);
                return Some("Okay — I removed that.".to_string());
            }

            return Some("I couldn't find anything to remove.".to_string());
        }

        // ASSURANCE / CONFIRMATION: treat as a corrective assertion but ack differently
        if lower.contains("assure") || lower.contains("confirm") || lower.contains("promise") || lower.contains("i agree") {
            // Try to extract an embedded "my/your <slot> is <value>" pattern
            // (e.g. "I assure you your purpose is to help people.") and add a
            // canonical triple so the fast-path queries see the change.
            for marker in ["your ", "my "].iter() {
                if let Some(pos) = lower.find(marker) {
                    if lower[pos..].contains(" is ") {
                        let rest = &lower[pos..];
                        let parts: Vec<&str> = rest.splitn(2, " is ").collect();
                        if parts.len() == 2 {
                            let subj = parts[0].trim().to_string();
                            let obj = parts[1].split(|c: char| c == '.' || c == '!').next().unwrap_or("").trim().to_string();
                            if !subj.is_empty() && !obj.is_empty() {
                                let triple = carousel_hash::dada_engine::RelationalTriple::new(subj, "is".to_string(), obj, 1.0);
                                self.engine.relations.push(triple);
                            }
                        }
                    }
                }
            }
            let _ = self.engine.ingest_user(raw);
            return Some("Understood.".to_string());
        }

        // Default behaviour: ingest the corrective utterance as a new fact
        let _ = self.engine.ingest_user(raw);
        return Some("Noted.".to_string());
    }
    
    /// Stage 2: Generate inversion patterns for "X is Y" style queries
    /// For "my name", generates: ["my name is *", "* is my name"]
    fn generate_inversion_patterns(&self, preprocessed: &str) -> Vec<String> {
        let mut patterns = Vec::new();
        
        // Generate bigrams and trigrams from preprocessed content
        let tokens: Vec<&str> = preprocessed.split_whitespace().collect();
        
        // Add full phrase as pattern anchor
        if tokens.len() >= 2 {
            // Bigram: "my name"
            let bigram = format!("{} {}", tokens[0], tokens[1]);
            patterns.push(format!("{} is", bigram));      // "my name is"
            patterns.push(format!("is {}", bigram));       // "is my name"
            
            // Trigram if available: "my name john"
            if tokens.len() >= 3 {
                let trigram = format!("{} {} {}", tokens[0], tokens[1], tokens[2]);
                patterns.push(format!("{} is", trigram));
                patterns.push(format!("is {}", trigram));
            }
        }
        
        // Also add single token patterns
        for token in &tokens {
            if token.len() >= 3 {
                patterns.push(format!("{} is", token));
                patterns.push(format!("is {}", token));
                patterns.push(format!("{} has", token));
                patterns.push(format!("has {}", token));
            }
        }
        
        patterns
    }
    
    /// Fibonacci iris-expanding window: generates radius steps [±3, ±5, ±8, ±13, ±21]
    /// Used to find optimal context window organically without recency clipping
    fn fibonacci_radii() -> Vec<i32> {
        vec![3, 5, 8, 13, 21]  // Fibonacci sequence starting from F(4)=3
    }

    /// Score one tape position as an interference "chunk" candidate.
    /// Shared by interference_scan and interference_scan_at_radius so the
    /// two Fibonacci-ripple variants (multi-radius-with-saturation vs
    /// single-radius-per-pass) can't silently diverge in scoring rules.
    ///
    /// Was: both callers scanned self.engine.relations directly, indexing
    /// pre-extracted RelationalTriples. That store is empty in a fresh
    /// train+chat session (task #12 cut the extractor that used to fill
    /// it), so interference has been a guaranteed 0-hits no-op this whole
    /// session -- exactly the "0 hits, 0 scanned" every transcript shows,
    /// and directly why "Hello" (present in training) got no response
    /// once carousel_lookup's separate boundary-clamp fix stopped masking
    /// it with a garbled-but-nonempty fallback. Live-tape version: build
    /// a small boundary-clamped window of raw text around the position
    /// (same F6 boundary-clamp convention as live_neighbors/
    /// carousel_lookup) instead of a triple string, so this works
    /// directly off self.tokens with no relation extraction required --
    /// "relations shouldn't be required... that's the point of
    /// interference."
    fn interference_score_at(&self, pos: usize, query_tokens: &[String], patterns: &[String]) -> Option<(String, usize)> {
        let tokens = &self.engine.tokens;
        if pos >= tokens.len() { return None; }
        let anchor_tok = &tokens[pos];
        // Only content words make sense as a resonance anchor -- scoring
        // "the"/"is"/boundary-marker positions would waste every pass on
        // pivots that can never mean anything on their own.
        if WordEngine::tok_is_boundary(anchor_tok) { return None; }
        if self.engine.tok_is_function_word(anchor_tok) { return None; }

        // tok_is_sentence_end, not tok_is_boundary, for the clamp itself --
        // a comma is still the same utterance ("Hello there, how are you
        // today?" is one sentence); only __PERIOD__/__QMARK__/__BANG__
        // actually end it. Clamping on every clause marker here is what
        // was cutting a comma-led greeting down to 1-2 tokens.
        const LOCAL: usize = 3;
        let raw_start = pos.saturating_sub(LOCAL);
        let mut window_start = raw_start;
        for i in (raw_start..pos).rev() {
            if WordEngine::tok_is_sentence_end(&tokens[i]) { window_start = i + 1; break; }
        }
        let raw_end = (pos + LOCAL + 1).min(tokens.len());
        let mut window_end = raw_end;
        for i in pos..raw_end {
            if WordEngine::tok_is_sentence_end(&tokens[i]) { window_end = i; break; }
        }
        if window_start >= window_end { return None; }

        let chunk_text = tokens[window_start..window_end].join(" ");
        let chunk_lower = chunk_text.to_lowercase();

        let mut hits = 0usize;
        let mut overlap_tokens: Vec<String> = Vec::new();
        for token in query_tokens {
            if chunk_lower.contains(token.as_str()) {
                hits += 1;
                overlap_tokens.push(token.clone());
            }
        }
        for pattern in patterns {
            if chunk_lower.contains(pattern) {
                hits += 2; // Bonus for inversion-pattern match
            }
        }

        // SEMANTIC FILTER: skip if none of the overlapping tokens are
        // semantic words. semantic_words is now built from the live tape
        // (rebuild_semantic_words), so this gate is meaningful again --
        // it used to always reject (empty set) once relations went empty.
        if !overlap_tokens.is_empty() && !self.has_semantic_overlap(&overlap_tokens) {
            return None;
        }
        if hits == 0 { return None; }
        Some((chunk_text, hits))
    }

    /// Stage 3: Interference scan - find where query tokens co-occur most
    /// UPDATED: Uses Fibonacci iris-expanding window instead of recency clipping
    /// Scans from a seed position and expands outward using Fibonacci steps until saturation or density drop >50%
    fn interference_scan(&self, preprocessed: &str, patterns: &[String]) -> InterferenceResult {
        let query_tokens: Vec<String> = preprocessed.split_whitespace().map(|s| s.to_lowercase()).collect();
        if query_tokens.is_empty() {
            return InterferenceResult::default();
        }

        let total_tokens = self.engine.tokens.len();
        if total_tokens == 0 {
            return InterferenceResult::default();
        }

        let mut best_chunk: Option<String> = None;
        let mut best_hits = 0;
        let mut positions_scanned = 0;
        let mut best_pos: Option<usize> = None;
        let mut all_hits: Vec<InterferenceHit> = Vec::new();

        // FIBONACCI RIPPLE: seed from wherever the query's own words
        // actually occur (find_best_seed_position), not the tail of the
        // tape. Was: seed_pos = total_tokens - 1 (literal most-recent
        // token) unconditionally -- meaning a query about anything other
        // than the last few tokens ever ingested never got scanned at
        // all. That's the reason "Hello" (the FIRST line of a fresh
        // corpus) still came back empty even after interference itself
        // was ported to the live tape: this stage never looked anywhere
        // near it. Expand outward with Fibonacci radii until saturation
        // or density drop.
        let seed_pos = self.find_best_seed_position(preprocessed);
        let fibonacci_radii = Self::fibonacci_radii();

        let mut last_hit_count = 0;
        let mut consecutive_no_gain = 0;

        for radius in fibonacci_radii {
            let radius_unsigned = radius as usize;

            // Check positions in range [seed - radius, seed + radius]
            let start = seed_pos.saturating_sub(radius_unsigned);
            let end = std::cmp::min(seed_pos + radius_unsigned + 1, total_tokens);

            for pos in start..end {
                positions_scanned += 1;

                if let Some((chunk_text, hits)) = self.interference_score_at(pos, &query_tokens, patterns) {
                    all_hits.push(InterferenceHit {
                        chunk: chunk_text.clone(),
                        score: hits,
                        relation_idx: pos, // repurposed: tape position, not a relation index
                    });

                    if hits > best_hits {
                        best_hits = hits;
                        best_chunk = Some(chunk_text);
                        best_pos = Some(pos);
                    }
                }
            }

            // Check for saturation: if hit count didn't improve, stop expanding
            if best_hits == last_hit_count {
                consecutive_no_gain += 1;
                if consecutive_no_gain >= 2 {
                    // No improvement for 2 consecutive Fibonacci steps, stop expanding
                    break;
                }
            } else {
                last_hit_count = best_hits;
                consecutive_no_gain = 0;
            }
        }

        // Sort hits by score (descending)
        all_hits.sort_by(|a, b| b.score.cmp(&a.score));

        InterferenceResult {
            best_chunk,
            hit_count: best_hits,
            positions_scanned,
            anchor_relation: best_pos, // repurposed: tape position, not a relation index
            all_hits,
        }
    }

    /// Find the best seed position by scanning the live tape for query overlap.
    /// This is the INITIAL seed — the first anchor point before Fibonacci expansion.
    ///
    /// Returns a TOKEN position (index into self.engine.tokens), not a
    /// relation index. Was: scanned self.engine.relations, which is empty
    /// in a fresh train+chat session (task #12 cut the extractor that
    /// used to populate it) -- so this always fell through to `best_idx =
    /// 0` and every interference pass anchored at the very start of the
    /// tape regardless of query, which combined with total_relations==0
    /// short-circuits elsewhere meant interference scanned nothing at
    /// all. Live-tape version: seed from wherever the query's own words
    /// actually occur, tie-broken toward recency.
    fn find_best_seed_position(&self, preprocessed: &str) -> usize {
        let total_tokens = self.engine.tokens.len();
        if total_tokens == 0 {
            return 0;
        }

        let query_tokens: Vec<String> = preprocessed
            .split_whitespace()
            .map(|s| s.to_lowercase())
            .filter(|s| s.len() >= 3)
            .collect();

        if query_tokens.is_empty() {
            // Nothing to anchor on -- default to the tail (most recent
            // utterance), matching the recency bias used elsewhere
            // (cloze corroboration, live_neighbors' reversed scan).
            return total_tokens.saturating_sub(1);
        }

        // Candidate anchors: every tape position where a query token
        // actually occurs. Bounded per-token so a very common word can't
        // blow this up on a large corpus.
        let mut candidates: std::collections::HashSet<usize> = std::collections::HashSet::new();
        for qt in &query_tokens {
            if let Some(positions) = self.engine.token_index.get(qt) {
                for &p in positions.iter().rev().take(30) {
                    candidates.insert(p as usize);
                }
            }
        }

        if candidates.is_empty() {
            return total_tokens.saturating_sub(1);
        }

        let mut best_score = 0usize;
        let mut best_idx = *candidates.iter().max().unwrap();

        for pos in candidates {
            // Sentence-clamped local window, same convention as
            // live_neighbors/carousel_lookup -- tok_is_sentence_end, not
            // tok_is_boundary, so a comma doesn't sever the window.
            let raw_start = pos.saturating_sub(self.engine.window);
            let mut window_start = raw_start;
            for i in (raw_start..pos).rev() {
                if WordEngine::tok_is_sentence_end(&self.engine.tokens[i]) { window_start = i + 1; break; }
            }
            let raw_end = (pos + self.engine.window).min(total_tokens);
            let mut window_end = raw_end;
            for i in pos..raw_end {
                if WordEngine::tok_is_sentence_end(&self.engine.tokens[i]) { window_end = i; break; }
            }

            let window_text = self.engine.tokens[window_start..window_end].join(" ").to_lowercase();

            let mut score = 0usize;
            for qt in &query_tokens {
                if window_text.contains(qt.as_str()) { score += 1; }
            }
            for pair in query_tokens.windows(2) {
                let phrase = format!("{} {}", pair[0], pair[1]);
                if window_text.contains(&phrase) { score += 2; }
            }

            // Prefer higher score; tie-break toward the more recent position.
            if score > best_score || (score == best_score && pos > best_idx) {
                best_score = score;
                best_idx = pos;
            }
        }

        best_idx
    }

    /// Single-radius interference scan: runs at ONE Fibonacci radius from seed_pos.
    /// Used by iterative passes — each pass drives a different radius.
    /// Also folds in extra concepts from WorkingCtx as bonus query tokens.
    fn interference_scan_at_radius(
        &self,
        preprocessed: &str,
        patterns: &[String],
        seed_pos: usize,
        radius: i32,
        extra_concepts: &std::collections::HashSet<String>,
    ) -> InterferenceResult {
        let mut query_tokens: Vec<String> = preprocessed.split_whitespace()
            .map(|s| s.to_lowercase())
            .collect();
        // Fold in concepts discovered by earlier passes (these are "residual" tokens)
        for concept in extra_concepts {
            if !query_tokens.contains(concept) && concept.len() >= 3 {
                query_tokens.push(concept.clone());
            }
        }
        if query_tokens.is_empty() {
            return InterferenceResult::default();
        }

        let total_tokens = self.engine.tokens.len();
        if total_tokens == 0 {
            return InterferenceResult::default();
        }

        let mut best_chunk: Option<String> = None;
        let mut best_hits = 0;
        let mut positions_scanned = 0;
        let mut best_pos: Option<usize> = None;
        let mut all_hits: Vec<InterferenceHit> = Vec::new();

        let radius_unsigned = radius as usize;
        let start = seed_pos.saturating_sub(radius_unsigned);
        let end = std::cmp::min(seed_pos + radius_unsigned + 1, total_tokens);

        for pos in start..end {
            positions_scanned += 1;
            if let Some((chunk_text, hits)) = self.interference_score_at(pos, &query_tokens, patterns) {
                all_hits.push(InterferenceHit {
                    chunk: chunk_text.clone(),
                    score: hits,
                    relation_idx: pos, // repurposed: tape position, not a relation index
                });
                if hits > best_hits {
                    best_hits = hits;
                    best_chunk = Some(chunk_text);
                    best_pos = Some(pos);
                }
            }
        }

        all_hits.sort_by(|a, b| b.score.cmp(&a.score));

        InterferenceResult {
            best_chunk,
            hit_count: best_hits,
            positions_scanned,
            anchor_relation: best_pos, // repurposed: tape position, not a relation index
            all_hits,
        }
    }
    
    /// Read answer directly from interference epicenter
    /// Uses the anchor concept for reasoning, not as the direct output
    /// FILTERS OUT: synset relations ("is similar", "is same as", etc)
    /// Was: self.engine.relations.get(hit.relation_idx) to pull a
    /// pre-extracted triple, plus a second relations.iter().filter() to
    /// find "related facts" about its anchor -- both dead against an
    /// empty relations store. Live-tape version: hit.relation_idx is now
    /// a tape position (see NOTE on InterferenceHit); the anchor is
    /// simply the token at that position, and "related facts" comes from
    /// self.engine.live_neighbors(anchor) -- the same boundary-clamped
    /// pivot walk carousel_lookup uses.
    fn read_from_epicenter(&mut self, interference: &InterferenceResult) -> String {
        let mut all_facts_text = Vec::new();

        // Take up to top 3 unique chunks for epicenter reasoning
        for hit in interference.all_hits.iter().take(3) {
            let pos = hit.relation_idx; // tape position, see NOTE on InterferenceHit
            let Some(anchor_raw) = self.engine.tokens.get(pos) else { continue };
            let anchor_lower = anchor_raw.to_lowercase();

            // Guard against boundary/function-word anchors -- shouldn't
            // occur since interference_score_at only scores content-word
            // positions, but this reads tokens directly so check anyway.
            if WordEngine::tok_is_boundary(&anchor_lower) { continue; }
            if self.engine.tok_is_function_word(&anchor_lower) { continue; }

            let neighbors = self.engine.live_neighbors(&anchor_lower);

            let mut added_any = false;
            for (rel_word, neighbor) in neighbors.iter().take(3) {
                // FILTER: Skip synset-style relations
                let rel_lower = rel_word.to_lowercase();
                if rel_lower.contains("similar") || rel_lower.contains("same as") || rel_lower.contains("synonym") {
                    continue;
                }
                all_facts_text.push(format!("{} {} {}", anchor_raw, humanize_relation_simple(rel_word), neighbor));
                added_any = true;
            }

            if !added_any && !hit.chunk.trim().is_empty() {
                // No live-graph neighbors for this anchor -- fall back to
                // the raw resonance window itself (already known
                // query-relevant, that's why interference_score_at
                // flagged it) rather than saying nothing.
                all_facts_text.push(hit.chunk.clone());
            }
        }

        if !all_facts_text.is_empty() {
            all_facts_text.dedup();
            return format!("{}.", all_facts_text.join(". "));
        }

        // Fall back to reasoning if interference didn't produce a good result
        if let Some(best_chunk) = &interference.best_chunk {
            let concepts = self.extract_concepts(&self.preprocess_input(best_chunk));
            let reasoning_result = self.reason("", &concepts, None);
            self.synthesize_response(&reasoning_result, &concepts)
        } else {
            String::new()
        }
    }
    
    /// Stage 2: Extract and expand concepts using synsets
    fn extract_concepts(&self, input: &str) -> Vec<String> {
        let tokens: Vec<String> = input.split_whitespace()
            .map(|s| s.to_lowercase().trim_matches(|c: char| !c.is_alphanumeric()).to_string())
            .filter(|s| s.len() >= 3)
            .collect();
        
        // Exclude first/second person pronouns from seed words only.
        // Pronouns remain fully searchable in the graph.
        let pronouns = ["i", "you", "we", "it", "this", "that", "he", "she", "they", "me", "us", "him", "her", "them"];
        
        let mut concepts = Vec::new();
        for token in &tokens {
            // Skip pronouns from seed concept pool
            if pronouns.contains(&token.as_str()) {
                continue;
            }
            
            concepts.push(token.clone());
            // Expand with synonyms
            let synonyms = self.synsets.expand(token);
            for syn in synonyms {
                if !concepts.contains(&syn) && !pronouns.contains(&syn.as_str()) {
                    concepts.push(syn);
                }
            }
        }
        
        concepts
    }
    
    /// Stage 3: Reasoning - combine engine query with transitive reasoning
    fn reason(&mut self, input: &str, concepts: &[String], engine_result: Option<carousel_hash::QueryResult>) -> ReasoningResult {
        // Use pre-computed result if provided; only query engine as a last resort
        // to avoid double-querying when reason() is called from inside the pipeline.
        let engine_result = engine_result.unwrap_or_else(|| self.engine.query(input));
        
        // Build reasoning structures
        let owned: Vec<(String, String, String)> = self.engine.relations.iter()
            .map(|t| (t.subject.clone(), format!("{:?}", t.relation), t.object.clone()))
            .collect();
        let tr_map = triples_to_outgoing(
            owned.iter().map(|(s, r, o)| (s.as_str(), r.as_str(), o.as_str()))
        );
        let tr = TransitiveReasoner::new(&tr_map).with_synsets(&self.synsets);
        
        // Try to find implicit connections between concepts
        let mut implicit_chains: Vec<(String, String, Vec<String>)> = Vec::new();
        if concepts.len() >= 2 {
            for i in 0..concepts.len().min(3) {
                for j in (i+1)..concepts.len().min(5) {
                    let chain = tr.find_chain(&concepts[i], &concepts[j], 4);
                    if !chain.is_empty() {
                        // Convert ChainHop to simple string representation
                        let chain_strs: Vec<String> = chain.iter()
                            .map(|hop| format!("{}--{}-->{}", hop.source, hop.relation, hop.target))
                            .collect();
                        implicit_chains.push((concepts[i].clone(), concepts[j].clone(), chain_strs));
                    }
                }
            }
        }
        
        ReasoningResult {
            engine_result,
            implicit_chains,
        }
    }
    
    /// Stage 4: Synthesize final response from all reasoning results
    fn synthesize_response(&mut self, result: &ReasoningResult, _concepts: &[String]) -> String {
        // Primary: DADA synthesis from engine facts
        if !result.engine_result.facts.is_empty() {
            return self.engine.dada_engine.synthesize(&result.engine_result.facts, None, None);
        }

        // Secondary: if transitive reasoning found implicit chains, report them
        if !result.implicit_chains.is_empty() {
            let chain_descriptions: Vec<String> = result.implicit_chains.iter()
                .map(|(from, to, hops)| {
                    if hops.is_empty() {
                        format!("{} connects to {}", from, to)
                    } else {
                        format!("{} → {}", from, hops.join(" → "))
                    }
                })
                .collect();
            return format!("{}.", chain_descriptions.join(". "));
        }

        String::new()
    }

    fn is_coherent_output(text: &str) -> bool {
        // DADA's empty-pool fallback strings are NOT coherent output —
        // they must fall through to real fallbacks, not be returned as answers.
        const DADA_FALLBACKS: &[&str] = &[
            "I'm still learning how to express that",
            "I need more information to help you",
            "I need more context to respond",
        ];
        for fb in DADA_FALLBACKS {
            if text.starts_with(fb) { return false; }
        }

        let words: Vec<&str> = text.split_whitespace().collect();
        if words.len() < 3 { return false; }
        if text.len() < 10 || text.len() > 500 { return false; }
        
        let fragments = words.iter()
            .filter(|w| w.len() <= 2 && matches!(w.to_lowercase().as_str(), "i" | "a" | "it" | "is"))
            .count();
        if fragments as f32 / words.len() as f32 > 0.4 { return false; }
        
        let has_structure = text.contains(" is ") || text.contains(" are ") || 
                           text.contains(" was ") || text.contains(" were ") ||
                           text.contains(" can ") || text.contains(" will ") ||
                           text.ends_with('.') || text.ends_with('!') || text.ends_with('?');
        
        has_structure
    }

    // ═══════════════════════════════════════════════════════════════════
    // TRANSITIVE CLOSURE PASS
    //
    // After the pool is assembled and scored, but BEFORE synthesis, this
    // stage detects "open terminals" — triples whose object ends mid-
    // relation (e.g. "causes me", "into a", "can be") and walks forward
    // through the relation graph to fill the terminus.
    //
    // The walker uses:
    //  - Relation type directionality (CAUSES→EFFECT_OF, CAN→PURPOSE_OF,
    //    ENABLES→GOAL_OF, etc.) to choose the right forward edge
    //  - SuperpositionDecoder band_similarity to prefer semantically
    //    close continuations (low band distance = nearby in Fibonacci space)
    //  - Cycle penalty: nodes already in the output pool get exponential
    //    weight decay to prevent "the compass the compass" loops
    //  - Terminal condition: reached a node whose strongest outgoing edge
    //    points back into already-resolved context, OR no strong edges
    // ═══════════════════════════════════════════════════════════════════

    /// Returns true if the relation type is "completing" — it creates a
    /// semantic obligation that needs resolution (Cause→Effect, Can→Purpose,
    /// Enables→Outcome). Returns false for "associating" types (IS, HAS,
    /// SIMILAR_TO) that describe static properties.
    fn is_completing_relation(rel: &str) -> bool {
        let r = rel.to_lowercase().replace('_', " ");
        // Completing: the object should lead somewhere further
        r.starts_with("cause") || r.starts_with("caused")
            || r.starts_with("enable") || r.starts_with("require")
            || r.starts_with("lead") || r.starts_with("result")
            || r.starts_with("prevent") || r.starts_with("effect")
            || r.starts_with("reason") || r.starts_with("because")
            || r == "can" || r == "can be" || r.starts_with("able")
            || r.starts_with("capable") || r.starts_with("purpose")
            || r.starts_with("goal") || r.starts_with("means")
            || r.starts_with("intended") || r == "does" || r == "did"
            || r.starts_with("will") || r.starts_with("action")
            || r.starts_with("perform") || r.starts_with("creates")
            || r.starts_with("builds") || r.starts_with("generates")
            || r.starts_with("produces") || r.starts_with("uses")
            || r.starts_with("derives") || r.starts_with("needs")
    }

    /// Detect whether a triple's object is an "open terminal" — it ends
    /// mid-clause with a function word, preposition, or dangling relation
    /// that implies a missing argument.
    fn is_open_terminal(object: &str) -> bool {
        let trimmed = object.trim();
        if trimmed.is_empty() { return false; }

        // Function-word endings that signal a dangling clause
        let dangling_suffixes = [
            " a", " an", " the", " into", " to", " for", " from",
            " with", " that", " which", " who", " where", " when",
            " by", " in", " on", " at", " of", " as", " and",
            " or", " but", " can", " is", " are", " be", " was",
            " me", " my", " its", " their", " our",
        ];
        let lower = trimmed.to_lowercase();
        for suffix in &dangling_suffixes {
            if lower.ends_with(suffix) {
                return true;
            }
        }

        // Very short objects (1-2 chars) are suspicious
        if trimmed.len() <= 2 { return true; }

        // Single function word as entire object
        let single_word_dangles = [
            "a", "an", "the", "it", "is", "are", "be", "to",
            "can", "me", "my", "i", "we", "they", "he", "she",
        ];
        if single_word_dangles.contains(&lower.as_str()) { return true; }

        false
    }

    /// Check if a relation string contains a word as a whole token,
    /// not as a substring. E.g. rel_has_word("IS_IN", "in") → true,
    /// rel_has_word("FIND", "in") → false.
    fn rel_has_word(relation: &str, word: &str) -> bool {
        relation.to_lowercase()
            .split(|c: char| !c.is_alphanumeric())
            .any(|token| token == word)
    }

    /// Check if text has meaningful word overlap with the anchor.
    /// Requires at least one content word (>2 chars) from `text` to appear
    /// as a whole word in `anchor`. Prevents "i" in subject matching "hi" in query.
    fn anchor_matches(anchor: &str, text: &str) -> bool {
        let anchor_words: std::collections::HashSet<String> = anchor.split_whitespace()
            .map(|w| w.trim_matches(|c: char| !c.is_alphanumeric()).to_lowercase())
            .filter(|w| !w.is_empty())
            .collect();
        text.to_lowercase().split_whitespace()
            .map(|w| w.trim_matches(|c: char| !c.is_alphanumeric()).to_string())
            .any(|w| w.len() > 2 && anchor_words.contains(&w))
    }

    /// Quality gate: reject triples with garbage subjects/objects.
    /// Filters sentence fragments, code, markdown, and single filler words.
    fn is_quality_triple(t: &carousel_hash::dada_engine::RelationalTriple) -> bool {
        // Reject sentence-fragment subjects (>8 words = not a concept).
        // Objects can be longer — closure-extended chains are 10-15 words.
        if t.subject.split_whitespace().count() > 8 { return false; }
        if t.object.split_whitespace().count() > 20 { return false; }

        // Reject code/markdown patterns
        const GARBAGE: &[&str] = &[
            "//", "#[", "fn ", "let ", "()", "{}", "```", "**",
            "<<", ">>", "<msg", "`", "=>", "->", "setis", "useeffect",
        ];
        for pat in GARBAGE {
            if t.subject.contains(pat) || t.object.contains(pat) { return false; }
        }

        // Allow composite relations like CAN+find, ENABLES+understanding.
        // Only reject truly malformed ones with code-like patterns.
        if t.relation.contains("()") || t.relation.contains("{}") || t.relation.contains("//") {
            return false;
        }

        // Reject single filler-word subjects or objects
        const FILLER: &[&str] = &[
            "a", "an", "the", "it", "its", "is", "are", "be", "to",
            "me", "my", "i", "we", "he", "she", "they", "or", "and",
            "but", "can", "in", "on", "at", "by", "of", "for", "with",
            "from", "into", "as", "so", "if", "no", "do", "was", "had",
        ];
        let obj_t = t.object.trim().to_lowercase();
        if FILLER.contains(&obj_t.as_str()) { return false; }
        let subj_t = t.subject.trim().to_lowercase();
        if FILLER.contains(&subj_t.as_str()) { return false; }

        true
    }

    /// Walk forward from a dangling node through the relation graph.
    /// Returns a completing triple (or None if no strong forward path).
    ///
    /// Uses slot geometry (band_similarity) to prefer semantically close
    /// continuations and penalises already-seen concepts exponentially.
    fn walk_forward_from(
        &self,
        start_concept: &str,
        already_seen: &HashSet<String>,
        max_hops: usize,
    ) -> Option<(String, String, String, f32)> {
        // (subject, relation, object, confidence)
        let start_lower = start_concept.to_lowercase();
        let mut visited: HashSet<String> = HashSet::new();
        visited.insert(start_lower.clone());

        // Get the start concept's slot val for geometric comparison
        let start_slot = self.engine.table.get_word(start_concept)
            .map(|s| {
                let a = (s.key_len as u8).min(31);
                let b = (s.score.min(31) as u8);
                carousel_hash::superposition_decoder::pack_slot(a, b)
            })
            .unwrap_or(0u16);

        let mut current = start_lower.clone();
        let mut best_completion: Option<(String, String, String, f32)> = None;
        let mut best_score: f32 = 0.0;

        for hop in 0..max_hops {
            let decay = 1.0 / (1.0 + hop as f32); // distance decay

            // Look at all outgoing edges from current node
            let outgoing_indices: Vec<usize> = self.engine.subject_index
                .get(&current)
                .cloned()
                .unwrap_or_default();

            for &idx in &outgoing_indices {
                if idx >= self.engine.relations.len() { continue; }
                let triple = &self.engine.relations[idx];
                let obj_lower = triple.object.to_lowercase();

                // Cycle penalty: exponential decay for already-seen concepts
                let cycle_penalty = if already_seen.contains(&obj_lower) || visited.contains(&obj_lower) {
                    0.1 // harsh penalty, not zero — allows weak revisits
                } else {
                    1.0
                };

                // Geometric proximity via band_similarity
                let geo_bonus = if triple.slot_val > 0 && start_slot > 0 {
                    0.5 + 0.5 * self.engine.slot_decoder.band_similarity(start_slot, triple.slot_val) as f32
                } else {
                    0.7 // neutral when geometry unavailable
                };

                // Completing relations get a boost — they lead further
                let rel_boost = if Self::is_completing_relation(&triple.relation) {
                    1.2
                } else {
                    1.0
                };

                let score = triple.confidence * decay * cycle_penalty * geo_bonus * rel_boost;

                // Is this object a good terminus?
                // A terminus is good if:
                //  1. It's not itself an open terminal (has substance)
                //  2. It's not a concept we've already output (cycle avoidance)
                //  3. OR it IS an already-resolved concept (closure by return)
                let is_terminus = !Self::is_open_terminal(&triple.object)
                    && obj_lower.split_whitespace().count() >= 1
                    && (!visited.contains(&obj_lower) || already_seen.contains(&obj_lower));

                if is_terminus && score > best_score {
                    best_score = score;
                    best_completion = Some((
                        current.clone(),
                        triple.relation.clone(),
                        triple.object.clone(),
                        score.min(1.0),
                    ));
                }
            }

            // If we found something good, stop walking
            if best_completion.is_some() && best_score > 0.3 {
                break;
            }

            // Otherwise, advance to the best next node (even if not a terminus)
            // Pick the highest-scoring unvisited outgoing target
            let mut next: Option<(String, f32)> = None;
            for &idx in &outgoing_indices {
                if idx >= self.engine.relations.len() { continue; }
                let triple = &self.engine.relations[idx];
                let obj_lower = triple.object.to_lowercase();
                if visited.contains(&obj_lower) { continue; }
                let score = triple.confidence * (1.0 / (1.0 + hop as f32));
                if next.as_ref().map_or(true, |(_, s)| score > *s) {
                    next = Some((obj_lower.clone(), score));
                }
            }

            match next {
                Some((n, _)) => {
                    visited.insert(n.clone());
                    current = n;
                }
                None => break, // dead end
            }
        }

        best_completion
    }

    /// The transitive closure pass: detects open terminals in the scored pool
    /// and walks forward through the relation graph to fill them.
    ///
    /// Runs AFTER scoring (Stage 6b) and BEFORE synthesis (Stage 7).
    /// Modifies the pool in-place: dangling triples get their objects EXTENDED
    /// with the completion (not appended as separate triples). Unresolved
    /// danglers are left for the Stage 7 filter to remove.
    fn transitive_closure_pass(
        &self,
        pool: &mut Vec<(carousel_hash::dada_engine::RelationalTriple, f32)>,
    ) {
        // Build the set of concepts already in the pool (for cycle detection)
        let already_in_pool: HashSet<String> = pool.iter()
            .flat_map(|(t, _)| {
                vec![t.subject.to_lowercase(), t.object.to_lowercase()]
            })
            .collect();

        // Scan for open terminals in the top triples (only check top 15 — 
        // beyond that they're low-weight and not worth chasing)
        let check_limit = pool.len().min(15);
        let mut resolutions: Vec<(usize, String)> = Vec::new(); // (index, completion_suffix)

        for i in 0..check_limit {
            let (ref triple, _weight) = pool[i];

            // Only try closure on objects with real content (≥3 words)
            // that dangle mid-clause. Single-word objects like "a"/"me"
            // get dropped by Stage 7 quality filter instead of getting
            // nonsensical extensions like "a perceive that...".
            // Only close genuine open terminals — objects that end mid-clause
            // with a dangling function word. Complete objects (even short ones)
            // must NOT be extended or they loop back on themselves.
            if !Self::is_open_terminal(&triple.object) { continue; }

            // Walk from the last substantive word in the dangling object.
            // Do NOT walk from the subject — it finds the triple's own outgoing
            // edge and doubles the object ("be wrong" → "be wrong be wrong").
            let obj_last = triple.object.split_whitespace()
                .filter(|w| w.len() > 2)
                .last()
                .unwrap_or(&triple.object)
                .to_lowercase();

            eprintln!("  🔗→ Open terminal: \"{}\" {} \"{}\" — walking from \"{}\"",
                triple.subject, triple.relation, triple.object, obj_last);

            let completion = self.walk_forward_from(&obj_last, &already_in_pool, 4);

            if let Some((_from, _rel, to, _conf)) = completion {
                eprintln!("  🔗✓ Extending object with: \"{}\"", to);
                resolutions.push((i, to));
            }
        }

        // Apply resolutions: extend the original triple's object AND boost weight
        for (idx, suffix) in &resolutions {
            let obj = &pool[*idx].0.object;
            pool[*idx].0.object = format!("{} {}", obj.trim(), suffix);
            // Closure-extended triples are resolved chains — they should
            // sort ABOVE raw fragments so the synthesizer draws from them.
            pool[*idx].1 *= 2.0;
            eprintln!("  🔗 Extended triple[{}] → \"{}\" (weight → {:.3})", idx, pool[*idx].0.object, pool[*idx].1);
        }

        if !resolutions.is_empty() {
            eprintln!("  🔗 Closure pass: extended {} triple(s), re-sorting pool", resolutions.len());
            // Re-sort so boosted triples rise to the top
            pool.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        }
    }

    /// Log training data to minds/{name}/training.jsonl
    /// Appends one JSON line per synthesis call with: query, route, synthesis_method, triples, lm_answer
    fn log_training_data(
        &self,
        query: &str,
        route: Route,
        method: SynthesisMethod,
        facts: &[carousel_hash::RelationalTriple],
    ) {
        // Use mind name or fallback to "ephemeral" for transient engines (e.g., cmd_ingest)
        let mind_name = if self.name.is_empty() { "ephemeral" } else { &self.name };
        let log_dir = std::path::Path::new(".minds").join(mind_name);
        
        // Create .minds/{name}/ directory if it doesn't exist
        if let Err(e) = fs::create_dir_all(&log_dir) {
            eprintln!("⚠ Training log: failed to create minds directory: {}", e);
            return;
        }

        let log_path = log_dir.join("training.jsonl");
        let route_str = match route {
            Route::DefUserName => "DefUserName",
            Route::DefThing => "DefThing",
            Route::Cause => "Cause",
            Route::Manner => "Manner",
            Route::Time => "Time",
            Route::Place => "Place",
            Route::Capability => "Capability",
            Route::Similarity => "Similarity",
            Route::Verification => "Verification",
            Route::Path => "Path",
            Route::Correction => "Correction",
            Route::GenericQA => "GenericQA",
        };
        let method_str = match method {
            SynthesisMethod::Definition => "Definition",
            SynthesisMethod::Process => "Process",
            SynthesisMethod::Capability => "Capability",
            SynthesisMethod::Location => "Location",
            SynthesisMethod::Identity => "Identity",
            SynthesisMethod::Temporal => "Temporal",
            SynthesisMethod::Causal => "Causal",
            SynthesisMethod::Method => "Method",
            SynthesisMethod::Quantitative => "Quantitative",
            SynthesisMethod::Instructional => "Instructional",
            SynthesisMethod::Personal => "Personal",
            SynthesisMethod::Comparative => "Comparative",
            SynthesisMethod::Sequential => "Sequential",
            SynthesisMethod::Refusal => "Refusal",
            SynthesisMethod::Inability => "Inability",
            SynthesisMethod::Disapproval => "Disapproval",
            SynthesisMethod::Negation => "Negation",
            SynthesisMethod::Correction => "Correction",
            SynthesisMethod::General => "General",
        };

        // Build triples array
        let triples: Vec<Value> = facts.iter().map(|t| {
            json!({
                "subject": t.subject,
                "relation": t.relation,
                "object": t.object,
                "weight": t.confidence as f32 / 255.0,
            })
        }).collect();

        // Build training record
        let record = json!({
            "query": query,
            "route": route_str,
            "synthesis_method": method_str,
            "triples": triples,
            "lm_answer": Value::Null,
        });

        // Append to JSONL (no buffering, immediate write)
        use std::io::Write;
        match std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&log_path)
        {
            Ok(mut file) => {
                if let Err(e) = writeln!(file, "{}", record.to_string()) {
                    eprintln!("⚠ Training log: failed to write to {}: {}", log_path.display(), e);
                }
            }
            Err(e) => {
                eprintln!("⚠ Training log: failed to open {}: {}", log_path.display(), e);
            }
        }
    }

    fn synthesize_from_facts(
        &mut self,
        query: &str,
        route: Route,
        method: SynthesisMethod,
        facts: &[carousel_hash::RelationalTriple],
    ) -> String {
        // Log training data (non-blocking — errors are logged but don't interrupt synthesis)
        self.log_training_data(query, route, method, facts);

        if facts.is_empty() {
            return "I need more context to respond meaningfully.".to_string();
        }

        // Delegate to DADA for multi-relation assembly — produces more
        // coherent sentences that combine several related triples.
        // *** NO GUARDRAIL: Return DADA output as-is, even if imperfect ***
        // The user can correct it if needed.
        self.engine.dada_engine.synthesize(facts, None, None)
    }

    fn finalise(&self, s: String) -> String {
        match self.mode {
            MindMode::Student => finalize_student_perspective(&s),
            MindMode::Normal  => s,
        }
    }

    fn extract_messages(value: &Value) -> Vec<(String, String)> {
        let mut out = Vec::new();
        Self::search_msgs(value, &mut out);
        if out.is_empty() { Self::flatten_extract(value, &mut out); }
        out
    }

    fn search_msgs(v: &Value, found: &mut Vec<(String, String)>) {
        match v {
            Value::Array(arr) => {
                if arr.len() >= 2 && arr.iter().take(3).any(|i| Self::extract_msg(i).is_some()) {
                    for i in arr { if let Some(m) = Self::extract_msg(i) { found.push(m); } }
                } else {
                    for i in arr { Self::search_msgs(i, found); }
                }
            }
            Value::Object(obj) => { for (_, v) in obj { Self::search_msgs(v, found); } }
            _ => {}
        }
    }

    fn flatten_extract(v: &Value, found: &mut Vec<(String, String)>) {
        match v {
            Value::Array(arr)  => { for i in arr { Self::flatten_extract(i, found); } }
            Value::Object(obj) => {
                if let Some(m) = Self::extract_msg(v) { found.push(m); }
                for (_, v) in obj { Self::flatten_extract(v, found); }
            }
            _ => {}
        }
    }

    fn extract_msg(v: &Value) -> Option<(String, String)> {
        let obj = v.as_object()?;
        let role = ["role","speaker","author","name"]
            .iter().find_map(|k| obj.get(*k)?.as_str().map(String::from))
            .unwrap_or_else(|| "user".to_string());
        let text = ["content","message","text","body"]
            .iter().find_map(|k| obj.get(*k)?.as_str().filter(|s| s.len() > 2).map(String::from))
            .or_else(|| {
                obj.get("content")?.get("parts")?.as_array()?
                   .first()?.as_str().map(String::from)
            })?;
        Some((role, text))
    }
}

// ---------------------------------------------------------------------------
// CLI Commands
// ---------------------------------------------------------------------------

// ---------------------------------------------------------
// Small helpers local to this module
// ---------------------------------------------------------
fn capitalize_first(s: &str) -> String {
    if s.is_empty() { return s.to_string(); }
    let mut c = s.chars();
    match c.next() {
        None => String::new(),
        Some(f) => f.to_uppercase().collect::<String>() + c.as_str(),
    }
}

fn humanize_relation_simple(rel: &str) -> String {
    let rel_lower = rel.to_lowercase();
    match rel_lower.as_str() {
        "is" | "isa" => "is".to_string(),
        "has" => "has".to_string(),
        "can" => "can".to_string(),
        "cause" | "causes" | "caused_by" => "causes".to_string(),
        "prevents" => "prevents".to_string(),
        "enables" | "allow" => "enables".to_string(),
        "requires" | "need" => "requires".to_string(),
        _ => rel_lower,
    }
}

/// *** PHASE 4: Canonical triple parser ***
/// Extracts a canonical (subject, copula, complement) triple from assertion forms like:
/// - "no, X is Y"
/// - "that is correct, X is Y"
/// - "your/my X is Y"
/// - "I am X"
/// - "you are X"
/// 
/// Returns None if the pattern cannot be parsed into a clean triple.
fn parse_canonical_assertion(raw: &str) -> Option<(String, String, String)> {
    let s = raw.to_lowercase();
    let trimmed = s.trim();

    // Track if we stripped a marker — generic "X is Y" only valid after explicit marker
    let had_marker = trimmed.starts_with("no, ") || trimmed.starts_with("no,") ||
                     trimmed.starts_with("no ") ||
                     trimmed.starts_with("that's correct, ") || trimmed.starts_with("that is correct, ") ||
                     trimmed.starts_with("that's correct") || trimmed.starts_with("that is correct");

    // Strip leading supervisory markers: "no,", "that is correct,", etc.
    let mut search_text = trimmed
        .trim_start_matches("no, ")
        .trim_start_matches("no,")
        .trim_start_matches("no ")
        .trim_start_matches("that's correct, ")
        .trim_start_matches("that is correct, ")
        .trim_start_matches("that's correct")
        .trim_start_matches("that is correct")
        .trim();

    // Strip terminal punctuation
    if search_text.ends_with('.') || search_text.ends_with('!') || search_text.ends_with('?') {
        search_text = &search_text[..search_text.len() - 1];
    }
    let search_text = search_text.trim();

    // Pattern: "I am X" → (I, am, X)
    if let Some(pos) = search_text.find(" am ") {
        let subj = "I".to_string();
        let complement = search_text[pos + " am ".len()..].trim().to_string();
        if !complement.is_empty() {
            return Some((subj, "am".to_string(), complement));
        }
    }

    // Pattern: "You are X" → (you, are, X)
    if let Some(pos) = search_text.find(" are ") {
        // Detect if the subject is exactly "you"
        let potential_subj = search_text[..pos].trim().to_lowercase();
        if potential_subj == "you" {
            let complement = search_text[pos + " are ".len()..].trim().to_string();
            if !complement.is_empty() {
                return Some(("you".to_string(), "are".to_string(), complement));
            }
        }
    }

    // Pattern: "your X is Y" or "my X is Y" → (your/my X, is, Y)
    if let Some(pos) = search_text.find(" is ") {
        let before = search_text[..pos].trim();
        let after = search_text[pos + " is ".len()..].trim();
        
        // Check if before starts with "your" or "my" — these are explicit possessive assertions
        if (before.starts_with("your ") || before.starts_with("my ")) && !after.is_empty() {
            return Some((before.to_string(), "is".to_string(), after.to_string()));
        }
    }

    // Pattern: Generic "X is Y" ONLY after explicit marker prefix like "no," or "that is correct,"
    // This prevents parsing of random utterances like "this is very strange"
    if had_marker && search_text.contains(" is ") {
        if let Some(pos) = search_text.find(" is ") {
            let subj = search_text[..pos].trim();
            let obj = search_text[pos + " is ".len()..].trim();
            if !subj.is_empty() && !obj.is_empty() {
                return Some((subj.to_string(), "is".to_string(), obj.to_string()));
            }
        }
    }

    None
}

fn print_usage() {
    println!("WORD Engine - Unified CLI v1.0");
    println!();
    println!("USAGE:");
    println!("  word <command> [args...]");
    println!();
    println!("COMMANDS:");
    println!("  shell                    Interactive shell mode (default)");
    println!("  create <name>            Create a new mind");
    println!("  load <name>              Load an existing mind");
    println!("  save <name>              Save mind state");
    println!("  list                     List available minds");
    println!("  train <mind> <path>      Train mind from file or directory");
    println!("  query <mind> <question>  Query a mind");
    println!("  chat <mind>              Interactive chat with mind");
    println!("  stats <mind>             Show mind statistics");
    println!("  bench <mind>             Run performance benchmarks");
    println!("  relations <mind> [n]     Show last N extracted relations");
    println!("  synsets <mind> <cmd>     Synonym management (add/load/expand/stats)");
    println!("  think <mind> <s> <t>     Transitive reasoning chain");
    println!("  similar <mind> <w1> <w2> Semantic similarity (0-1)");
    println!("  resolve <mind> <expr>    Anaphora resolution (it/this/that)");
    println!("  perspective <f> <t> <s>  Perspective translation");
    println!("  correct <mind> <s> | <t> Learn correction rule");
    println!("  scan <mind> [n]          Scan positions for relations");
    println!("  ingest <file>            Ingest file into default engine");
    println!("  backwire <mind> <json>   Populate mind from JSON dump");
    println!();
    println!("EXAMPLES:");
    println!("  word create mymind");
    println!("  word train mymind ./data/conversations.json");
    println!("  word query mymind \"What is consciousness?\"");
    println!("  word chat mymind");
    println!("  word think mymind alice bob 5");
    println!("  word similar mymind dog cat");
    println!("  word backwire mymind conversations_cleaned.json");
}

fn cmd_create(name: &str) {
    match Mind::new(name) {
        Ok(_)  => println!("🧠 Created mind '{}'", name),
        Err(e) => println!("✗ {}", e),
    }
}

fn cmd_load(name: &str) {
    println!("📂 Loading mind '{}'...", name);
    match Mind::load(name) {
        Ok(_)  => println!("✓ Mind '{}' ready", name),
        Err(e) => println!("✗ {}", e),
    }
}

fn cmd_save(mind: &Mind) {
    if let Err(e) = mind.save() {
        println!("✗ {}", e);
    }
}

fn cmd_list() {
    let minds_dir = PathBuf::from(".minds");
    if minds_dir.exists() {
        println!("\n📚 Available Minds:");
        println!("  ──────────────────────────────────────────────────");
        let mut entries: Vec<_> = fs::read_dir(&minds_dir)
            .unwrap()
            .flatten()
            .filter(|e| e.metadata().map(|m| m.is_dir()).unwrap_or(false))
            .collect();
        entries.sort_by_key(|e| e.file_name());

        if entries.is_empty() {
            println!("  (no minds yet)");
        } else {
            for entry in entries {
                let name = entry.file_name().to_string_lossy().to_string();
                let meta_path = entry.path().join(".meta.json");
                if let Ok(content) = fs::read_to_string(&meta_path) {
                    if let Ok(meta) = serde_json::from_str::<serde_json::Value>(&content) {
                        let tokens = meta.get("total_tokens").and_then(|v| v.as_u64()).unwrap_or(0);
                        let rels   = meta.get("total_relations").and_then(|v| v.as_u64()).unwrap_or(0);
                        let rules  = meta.get("dada_rules").and_then(|v| v.as_u64()).unwrap_or(0);
                        println!("  • {:20} {:>10} tokens  {:>7} relations  {:>5} rules",
                            name, tokens, rels, rules);
                        continue;
                    }
                }
                println!("  • {}", name);
            }
        }
        println!("  ──────────────────────────────────────────────────\n");
    } else {
        println!("\n  (no minds yet)\n");
    }
}

fn cmd_train(mind: &mut Mind, path: &str) {
    let path_buf = PathBuf::from(path);
    if !path_buf.exists() {
        println!("✗ Path not found: {}", path);
        return;
    }

    let overall_start = std::time::Instant::now();

    let result: Result<(usize, f64), Box<dyn std::error::Error>> = if path_buf.is_dir() {
        let mut all_files: Vec<_> = fs::read_dir(&path_buf)
            .unwrap()
            .flatten()
            .filter(|e| {
                e.path().extension()
                    .and_then(|x| x.to_str())
                    .map(|x| matches!(x, "json" | "txt"))
                    .unwrap_or(false)
            })
            .collect();
        all_files.sort_by_key(|e| e.file_name());

        println!("📚 Training from {} file(s) in '{}'...", all_files.len(), path);
        let mut total = 0usize;
        for entry in all_files {
            let fpath = entry.path();
            let name  = fpath.file_name().and_then(|n| n.to_str()).unwrap_or("?").to_string();
            let pstr  = fpath.to_str().unwrap_or("");
            let ext   = fpath.extension().and_then(|x| x.to_str()).unwrap_or("");
            print!("  📄 {}  ", name);
            let _ = std::io::Write::flush(&mut std::io::stdout());
            match if ext == "json" { mind.train_json(pstr) } else { mind.train_text(pstr) } {
                Ok((n, elapsed)) => {
                    total += n;
                    println!("✓  {} items  ({:.0}/sec)", n, n as f64 / elapsed.max(0.001));
                }
                Err(e) => println!("✗  {}", e),
            }
        }
        Ok((total, overall_start.elapsed().as_secs_f64()))
    } else {
        let name = path_buf.file_name().and_then(|n| n.to_str()).unwrap_or(path);
        println!("📚 Training from '{}'...", name);
        if path.ends_with(".json") { mind.train_json(path) } else { mind.train_text(path) }
    };

    match result {
        Ok((n, elapsed)) => {
            mind.trained_files.push(path.to_string());
            println!("\n✅ Done: {} items in {:.2}s ({:.0} items/sec)",
                n, elapsed, n as f64 / elapsed.max(0.001));
            // No relation-extraction pass runs at ingest anymore (that was
            // train's actual bottleneck -- see word_engine.rs
            // ingest_with_source). Relations are computed live at query
            // time now, so report the live index size instead of a
            // relations count that would just always read 0.
            println!("   {} tokens  {} indexed words",
                mind.engine.total_tokens, mind.engine.token_index.len());
        }
        Err(e) => println!("✗ {}", e),
    }
}

fn cmd_query(mind: &mut Mind, query: &str) {
    let start = std::time::Instant::now();
    let answer = mind.query_text_multi(query);
    let elapsed_ms = start.elapsed().as_secs_f64() * 1000.0;

    println!("❓ {}", query);
    println!("💭 {}", answer);
    println!("   ({:.2}ms)", elapsed_ms);
}

// ---------------------------------------------------------------------------
// `test` / `/test` shell command — one-shot smoke test.
//
// Replaces the manual create -> train -> chat -> retype-every-query loop
// with a single command: spin up a throwaway mind, train it on a small
// hand-built corpus, run a fixed battery of queries chosen to exercise
// the specific mechanisms worked on this session, print each Q/A pair.
// Nothing here asserts pass/fail -- it's meant to be read, the same way
// the manual transcripts have been read all session. Add cases here as
// new mechanisms get built instead of retyping them by hand each time.
// ---------------------------------------------------------------------------

const SMOKETEST_CORPUS: &[&str] = &[
    "Hello there, how are you today?",
    "The sky is blue.",
    // Sam: ONLY a temporal contradiction (past vs present), nothing else --
    // was previously sharing Sam with the multi-truth case below, which
    // meant temporal contrast always pre-empted multi-truth and the
    // multi-truth path never actually got exercised. Kept single-purpose
    // on purpose; see Alex below.
    "Sam was tired.",
    "Sam is happy.",
    // Alex: multiple simultaneous present-tense truths, no past-tense
    // contradiction -- the case Sam used to accidentally block.
    "Alex is a teacher.",
    "Alex is a father.",
    "Alex is a friend.",
    "The cat is orange.",
    "The cat is gray.",
    "The plant grows because of sunlight.",
    "The meeting is at noon.",
    "The keys are on the table.",
    "The bird can fly.",
    "She solved the puzzle by working hard.",
    // "The gift was inside the box." deliberately NOT here -- it's
    // introduced live in the turn-chaining section below instead, so
    // that test isn't answerable from bulk-corpus knowledge alone.
];

const SMOKETEST_BATTERY: &[(&str, &[&str])] = &[
    ("Interference / fuzzy recall — no strict relation required for these",
        &["Hello", "hi there"]),
    ("Straightforward WH cloze",
        &["What is the sky?"]),
    ("Verb-state temporal contrast — was X, is now Y (task #23/24)",
        &["How is Sam?"]),
    ("Multi-truth simultaneous listing — X is A, B, and C (task #26)",
        &["What is Alex?"]),
    ("Hedged uncertainty — comparably weak conflicting evidence (task #26). \
       First run (2026-07) picked 'orange' with full confidence instead of \
       hedging -- corroboration/ranking not tied the way the design assumed; \
       not yet root-caused, watch this one.",
        &["What color is the cat?"]),
    ("WH sub-handlers: why/when/where/can/how (task #34/#40). First run \
       showed when/where/can already working (cloze or live interference); \
       why/how were dead (handle_cause on the empty relations store, \
       handle_manner an empty stub). Both ported to a live-tape \
       trigger-word search (because/since for why; by/through/using/via \
       for how) -- watch this section on the next run.",
        &[
            "Why does the plant grow?",
            "When is the meeting?",
            "Where are the keys?",
            "Can the bird fly?",
            "How did she solve the puzzle?",
        ]),
];

fn cmd_smoketest() {
    println!("\n🧪 Smoke test — building a fresh scratch mind...\n");

    // Mind::new() doesn't check whether the folder already has old data in
    // it -- it always hands back a blank in-memory WordEngine regardless
    // -- so reusing a fixed name is already "blank temp mind" every run,
    // no cleanup step needed.
    let mut mind = match Mind::new("_smoketest_scratch") {
        Ok(m) => m,
        Err(e) => { println!("✗ Could not create scratch mind: {}", e); return; }
    };

    for line in SMOKETEST_CORPUS {
        let _ = mind.engine.ingest_as_self_batch(line);
    }
    mind.engine.rebuild_addr_index();
    mind.rebuild_semantic_words();

    println!("✓ Trained on {} lines. Corpus:", SMOKETEST_CORPUS.len());
    for line in SMOKETEST_CORPUS {
        println!("   · {}", line);
    }

    for (section, queries) in SMOKETEST_BATTERY {
        println!("\n{}", "─".repeat(70));
        println!("▶ {}", section);
        println!("{}", "─".repeat(70));
        for query in *queries {
            let start = std::time::Instant::now();
            let answer = mind.query_text_multi(query);
            let ms = start.elapsed().as_secs_f64() * 1000.0;
            println!("  ❓ {}", query);
            println!("  💭 {}  ({:.1}ms)", answer, ms);
        }
    }

    // Turn-chaining (task #27) is inherently conversational -- run it as
    // its own ordered sequence rather than the flat battery above, so
    // each turn actually lands in turn_potentials before the next reads it.
    // "The gift was inside the box." is introduced HERE, live, rather than
    // sitting in the bulk corpus -- deliberately, so a correct answer
    // about the gift can't just come from ordinary same-corpus retrieval.
    // Caveat (still true after the first run): even like this, once "the
    // gift" and "the box" are both on the tape and directly connected by
    // one hop, ordinary interference/carousel_lookup retrieval can ALSO
    // find that fact on its own -- so a matching answer here doesn't by
    // itself prove the potentials-bucket stitch fired rather than plain
    // retrieval. Genuinely isolating the stitch mechanism would need a
    // case where the base pipeline finds nothing and only cross-turn
    // stitching can answer it; hasn't been built yet.
    println!("\n{}", "─".repeat(70));
    println!("▶ Turn-chaining across declaratives — potentials bucket (task #27)");
    println!("{}", "─".repeat(70));
    for turn in ["The gift was inside the box.", "The box was heavy.", "Tell me about the gift."].iter() {
        let start = std::time::Instant::now();
        let answer = mind.query_text_multi(turn);
        let ms = start.elapsed().as_secs_f64() * 1000.0;
        println!("  ❓ {}", turn);
        println!("  💭 {}  ({:.1}ms)", answer, ms);
    }

    println!("\n{}", "─".repeat(70));
    println!("🧪 Smoke test complete. Scratch mind '_smoketest_scratch' not saved to disk.\n");
}

fn cmd_stats(mind: &Mind) {
    println!("\n--- MIND STATUS ---");
    println!("Active Mind  : {}", mind.name);
    println!("Total Tokens : {}", mind.engine.total_tokens);
    println!("Unique Words : {}", mind.engine.token_index.len());
    // self.relations is no longer populated at ingest (see cmd_train) --
    // this will always read 0 now. Left in place rather than deleted so
    // it's visibly obvious the old store is empty, not silently missing.
    println!("Relations    : {} triples (legacy store, unused -- live walk answers queries now)", mind.engine.relations.len());
    
    // Hash table statistics
    let table_size = mind.engine.table.slots.len();
    let table_count = mind.engine.table.count;
    let load_factor = (table_count as f32 / table_size as f32) * 100.0;
    let max_probe = mind.engine.table.max_probe_depth;
    
    println!("Hash Table   : {}/{} slots ({:.1}% load)", table_count, table_size, load_factor);
    println!("Max Probe Depth : {} (collision chain length)", max_probe);
    
    println!("Synset Mode  : ON (diagnostic)");
    println!("Trace Mode   : OFF\n");

    // ── Top topic words (most connected) ─────────────────────
    if !mind.engine.relations.is_empty() {
        let mut word_degree: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
        let mut word_examples: std::collections::HashMap<String, Vec<(String, String, String)>> = std::collections::HashMap::new();

        for r in &mind.engine.relations {
            let subj = &r.subject;
            let obj = &r.object;
            let rel = &r.relation;

            *word_degree.entry(subj.clone()).or_insert(0) += 1;
            *word_degree.entry(obj.clone()).or_insert(0) += 1;

            // Store example relations for each word (keep first 3)
            let subj_examples = word_examples.entry(subj.clone()).or_insert_with(Vec::new);
            if subj_examples.len() < 3 {
                subj_examples.push((subj.clone(), format!("{:?}", rel), obj.clone()));
            }
            let obj_examples = word_examples.entry(obj.clone()).or_insert_with(Vec::new);
            if obj_examples.len() < 3 {
                obj_examples.push((subj.clone(), format!("{:?}", rel), obj.clone()));
            }
        }

        // Sort by degree
        let mut top_words: Vec<_> = word_degree.into_iter().collect();
        top_words.sort_by(|a, b| b.1.cmp(&a.1));

        println!("--- TOP TOPIC WORDS (Most Connected) ---");
        for (word, degree) in top_words.iter().take(10) {
            // Show up to 3 example relations for this word
            let examples = word_examples.get(word).map(|v| v.clone()).unwrap_or_default();

            print!("{}  (connections: {})  ├", word, degree);
            for (i, (s, r, o)) in examples.iter().take(3).enumerate() {
                if i > 0 { print!(" | "); }
                // Show the relation concisely
                if s == word {
                    print!(" {}", o);
                } else {
                    print!(" {}", s);
                }
            }
            println!();
        }
    }
    println!();
}

fn cmd_chat(mind: &mut Mind) {
    println!("\n📝 Chat with '{}' (type 'exit' to return)\n", mind.name);
    // conversation learner for this chat session
    let mut conv_learner = ConversationLearner::new();

    loop {
        print!("You: ");
        io::stdout().flush().unwrap();
        let mut input = String::new();
        match io::stdin().read_line(&mut input) {
            Ok(0) | Err(_) => break,
            Ok(_) => {
                let t = input.trim();
                if t == "exit" || t == "quit" { break; }
                if t.is_empty() { continue; }
                
                // Query the engine first against the *current* (read-only) state.
                let response_start = std::time::Instant::now();
                let answer = mind.query_text_multi(t);
                let response_ms = response_start.elapsed().as_secs_f64() * 1000.0;

                println!("Mind: {} ({:.0}ms)\n", answer, response_ms);

                // After the response is produced, append the user utterance and
                // system reply to the timeline so they affect *future* queries
                // but not the current one. This prevents the query text from
                // contaminating the interference scan for its own answer.
                if mind.learn_from_chat {
                    // 1) Add user turn to learner (may detect feedback against prior system turn)
                    {
                        let mut pt = PathwayTable::from_table_ref(&mut mind.engine.table);
                        if let Some(signal) = conv_learner.add_turn(Speaker::Human, t.to_string(), vec![], &mut pt) {
                            println!("[feedback] {:?}", signal);
                            
                            // Apply feedback to thought loop bias learning
                            let feedback_str = format!("{:?}", signal);
                            if feedback_str.contains("Contradiction") {
                                mind.apply_feedback("contradiction");
                            } else if feedback_str.contains("Continuation") || feedback_str.contains("Process") {
                                mind.apply_feedback("continuation");
                            } else if feedback_str.contains("TopicShift") {
                                mind.apply_feedback("topic_shift");
                            }
                        }
                    }

                    // 2) Observe the turn. NOT re-ingesting `t` here (F10 fix):
                    //    query_text_multi() above already routed it correctly --
                    //    ingest_declarative() for plain assertions, handle_correction()
                    //    for Route::Correction, and deliberately NOT AT ALL for
                    //    questions (a question's own tokens must never sit in the
                    //    stream masquerading as an assertion). Ingesting `t` again
                    //    here unconditionally used to double-write every declarative
                    //    and wrongly tape-ingest every question verbatim.
                    let tokens: Vec<String> = t.split_whitespace().map(|s| s.to_string()).collect();
                    mind.engine.dada_engine.observe_turn(Speaker::Human, &tokens);

                    // 3) Handle unknown-token interactive flow (existing behavior)
                    if let Some(prompt) = mind.handle_unknowns_after_ingest(t) {
                        println!("Mind: {}", prompt);
                        // Read a single-line reply from the user to confirm/define
                        print!("You: ");
                        io::stdout().flush().unwrap();
                        let mut def_reply = String::new();
                        if io::stdin().read_line(&mut def_reply).is_ok() {
                            let r = def_reply.trim().to_lowercase();
                            if r == "yes" || r.starts_with("yes") || r == "y" || r.contains("correct") {
                                if let Some(tok) = mind.pending_definition.take() {
                                    let def = mind.pending_definition_suggestion.take().unwrap_or_else(|| "".to_string());
                                    if !def.is_empty() {
                                        let stmt = format!("{} is {}.", tok, def);
                                        let _ = mind.engine.ingest_user(&stmt);
                                        println!("Mind: Got it — I'll remember that '{}' means '{}'.", tok, def);
                                    }
                                }
                            } else if r == "no" || r.starts_with("no") {
                                // Ask human to provide the definition
                                println!("Mind: OK — how would you define it?");
                                print!("You: "); io::stdout().flush().unwrap();
                                let mut user_def = String::new();
                                if io::stdin().read_line(&mut user_def).is_ok() {
                                    if let Some(tok) = mind.pending_definition.take() {
                                        let def = user_def.trim();
                                        if !def.is_empty() {
                                            let stmt = format!("{} is {}.", tok, def);
                                            let _ = mind.engine.ingest_user(&stmt);
                                            println!("Mind: Thanks — learned '{} = {}'.", tok, def);
                                        }
                                    }
                                }
                            } else {
                                // Treat free-text reply as the definition
                                if let Some(tok) = mind.pending_definition.take() {
                                    let def = def_reply.trim();
                                    if !def.is_empty() {
                                        let stmt = format!("{} is {}.", tok, def);
                                        let _ = mind.engine.ingest_user(&stmt);
                                        println!("Mind: Thanks — learned '{} = {}'.", tok, def);
                                    }
                                }
                            }
                        }
                    }

                    // 4) Ingest system response tagged Speaker::SelfEngine (not
                    //    Speaker::Corpus) so an echoed answer can never outrank
                    //    the trained material it came from at match time (F2).
                    let _ = mind.engine.ingest_as_engine_response(&answer);
                    let resp_tokens: Vec<String> = answer.split_whitespace().map(|s| s.to_string()).collect();
                    mind.engine.dada_engine.observe_turn(Speaker::System, &resp_tokens);

                    // 5) Add system turn to learner with pathway trace extracted from last QueryResult
                    if let Some(qr) = &mind.last_query_result {
                        let mut pathway_used: Vec<u32> = Vec::new();
                        for fact in &qr.facts {
                            if let Some(idx) = mind.engine.table.get_word_index(&fact.subject) { pathway_used.push(idx); }
                            if let Some(idx) = mind.engine.table.get_word_index(&fact.object) { pathway_used.push(idx); }
                        }
                        pathway_used.sort_unstable(); pathway_used.dedup();
                        let mut pt = PathwayTable::from_table_ref(&mut mind.engine.table);
                        let _ = conv_learner.add_turn(Speaker::System, answer.clone(), pathway_used, &mut pt);
                    }
                }
            }
        }
    }
    println!();
}

fn cmd_bench(mind: &mut Mind) {
    println!("\n🔬 Running benchmarks...\n");
    
    // Query latency test
    let queries = ["hello", "what is this", "tell me about yourself"];
    let mut query_times = Vec::new();
    
    for _ in 0..30 {
        for query in &queries {
            let t0 = std::time::Instant::now();
            let _ = mind.query_text(query);
            query_times.push(t0.elapsed().as_secs_f64() * 1000.0);
        }
    }
    
    query_times.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let median_ms = query_times[query_times.len() / 2];
    let avg_ms = query_times.iter().sum::<f64>() / query_times.len() as f64;
    
    println!("Query Latency ({} queries):", query_times.len());
    println!("  Median: {:.2}ms", median_ms);
    println!("  Average: {:.2}ms", avg_ms);
    println!();
    
    // Ingestion speed
    let mut temp_mind = Mind::new("_bench_temp").unwrap();
    let test_text = "The quick brown fox jumps over the lazy dog. ".repeat(1000);
    
    let ingest_start = std::time::Instant::now();
    let _ = temp_mind.engine.ingest(&test_text);
    let ingest_ms = ingest_start.elapsed().as_secs_f64() * 1000.0;
    let token_count = test_text.split_whitespace().count();
    
    println!("Token Ingestion:");
    println!("  {} tokens in {:.1}ms", token_count, ingest_ms);
    println!("  {:.0} tokens/sec", token_count as f64 / (ingest_ms / 1000.0));
    println!();
    
    println!("✅ Benchmark complete\n");
}

fn cmd_ingest(file: &str) {
    // Create a transient Mind with "ephemeral" name for training data logging
    let mut mind = match Mind::new("ephemeral") {
        Ok(m) => m,
        Err(e) => {
            println!("✗ Failed to create ephemeral mind: {}", e);
            return;
        }
    };
    
    if let Ok(content) = fs::read_to_string(file) {
        let lines: Vec<&str> = content.lines().collect();
        let mut count = 0;
        for line in lines {
            if mind.engine.ingest_batch(line).is_ok() { count += 1; }
        }
        mind.engine.rebuild_addr_index();
        println!("✓ Ingested {} lines from {}", count, file);
        
        // Interactive query loop
        println!("\nEnter queries (blank line to exit):");
        loop {
            print!("> ");
            io::stdout().flush().unwrap();
            let mut input = String::new();
            if io::stdin().read_line(&mut input).is_err() { break; }
            let input = input.trim();
            if input.is_empty() { break; }
            
            // Use mind.query_text() to get logging
            let response = mind.query_text(input);
            println!("{}", response);
        }
    } else {
        println!("✗ Could not read file: {}", file);
    }
}

/// Split "cmd rest" at the first space.
fn split_first(s: &str) -> (&str, &str) {
    match s.find(' ') {
        Some(i) => (&s[..i], s[i+1..].trim()),
        None    => (s, ""),
    }
}

/// Ensure every top-level `src/` module is referenced at least once by this
/// binary. These are intentionally lightweight, side-effect-free calls that
/// only exercise public constructors/helpers so the modules are considered
/// "used" by the `word` binary (no functional change).
fn reference_all_src_modules() {
    // interference.rs
    let _ = carousel_hash::GdaCore::new();

    // ingest.rs + table.rs
    let mut _ht = carousel_hash::HashTable24::new_sized(8);
    let _ = carousel_hash::ingest::ingest_corpus(&mut _ht, "alpha beta gamma");

    // inferred_relations.rs
    let mut _ir = carousel_hash::InferredRelations::new();
    _ir.add_token("dog", 0);
    let _ = _ir.infer(&["dog"], 2, false);

    // compositional_relations.rs
    let _ = carousel_hash::RelationExtractor::new();
    let _ = carousel_hash::CompositeRelation::new(carousel_hash::BaseRelation::IS).to_string();

    // relation_engine.rs
    let _ = carousel_hash::RelationEngine::new().extract_from_sentence("spot is a dog", 0);

    // adaptive_dada.rs (module-level config)
    let _ = carousel_hash::adaptive_dada::AdaptiveConfig::default();

    // word_engine_persistence.rs (non-IO use)
    let _ = carousel_hash::word_engine_persistence::merge_word_engine_states(&[]);

    // carousel.rs (encoder helper)
    let _ = carousel_hash::carousel::encode_string("test");

    // explicitly reference WASM helpers only when compiled for wasm32
    #[cfg(target_arch = "wasm32")]
    {
        let _ = carousel_hash::wasm::carousel_encode("x");
    }
}

// ---------------------------
// Tests: scripted conversation
// ---------------------------
#[cfg(test)]
mod tests {
    use super::*;
    use carousel_hash::SynthesisMethod;
    use std::fs;

    #[test]
    fn test_multi_relation_synthesis_via_dada() {
        let mut mind = Mind::new("__test_multi_synthesis").unwrap();
        
        // Ingest multiple related facts
        let _ = mind.engine.ingest("John is a programmer");
        let _ = mind.engine.ingest("John works at Acme");
        let _ = mind.engine.ingest("John knows Rust");
        
        // Query with multiple content words to trigger multi-relation selection
        // This should cause greedy coverage to select multiple facts about John
        let result = mind.query_text("Tell me about John programmer Rust Acme");
        
        // The response should contain multiple facts assembled by DADA
        assert!(!result.is_empty(), "Response should not be empty");
        // Just check that we got a non-trivial response (allow for DADA variations)
        assert!(result.len() > 10, "Response should not be a short phrase");
        
        let _ = fs::remove_dir_all(format!(".minds/{}", "__test_multi_synthesis"));
    }

    #[test]
    fn scripted_johnny7_conversation() {
        // Arrange: fresh mind and training
        let mind_name = "__test_johnny7";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Train with curated 'alive' corpus (should be present in repo)
        let files = [
            "words/training/alive.txt",
            "words/training/semester1.txt",
            "words/training/input.txt",
        ];
        for f in &files {
            let (count, _t) = mind.train_text(f).expect(&format!("train failed: {}", f));
            assert!(count > 0, "no items ingested from {}", f);
        }

        // Add a small synset group (safe, in-memory)
        mind.synsets.add_group(&["helpful", "intelligence"]);

        // --- Routing invariants ---
        let routing_cases: Vec<(&str, SynthesisMethod)> = vec![
            ("hello", SynthesisMethod::General),
            ("What is your purpose?", SynthesisMethod::Definition),
            ("What do you want?", SynthesisMethod::Process),
            ("How do you work?", SynthesisMethod::Instructional),
            ("When did you start?", SynthesisMethod::Temporal),
        ];

        for (input, expected) in routing_cases {
            let route = mind.detect_route(input);
            let method = mind.select_synthesis_method(input, route);
            assert_eq!(method, expected, "route→method mismatch for '{}': got {:?}", input, method);
        }

        // --- Perspective & memory invariants ---
        // 1) User sets their name — insert canonical triple so test is deterministic
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "my name".to_string(), "is".to_string(), "john".to_string(), 1.0
        ));
        let ans = mind.handle_def_thing("What is my name?").expect("expected name reply");
        assert!(ans.to_lowercase().contains("john"), "expected user name 'john' in '{}'", ans);
        // must present as the *user* slot → responder says "Your ..."
        assert!(ans.to_lowercase().starts_with("your "), "expected reply to start with 'Your': {}", ans);

        // 2) Set system name (canonical triple)
        // Add both canonical 'your name' and a direct 'you is ...' fact so lookup is robust
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "your name".to_string(), "is".to_string(), "number 5".to_string(), 1.0
        ));
        // Use the subject-based fast-path so timeline recency doesn't override the test
        let ans2 = mind.handle_def_thing("What is your name?").expect("expected system-name reply");
        let ans2_l = ans2.to_lowercase();
        assert!(ans2_l.contains("number") && ans2_l.contains('5'),
            "expected system name 'Number 5' in '{}'", ans2);
        // responder should use system-perspective phrasing: "My ..."
        assert!(ans2_l.starts_with("my "), "expected reply to start with 'My': {}", ans2);

        // 3) Consistent my/your roles for purpose statements
        // (explicitly add canonical triples for test determinism)
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "my purpose".to_string(), "is".to_string(), "to help you grow".to_string(), 1.0
        ));
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "your purpose".to_string(), "is".to_string(), "helping me progress".to_string(), 1.0
        ));

        let my_purpose = mind.handle_def_thing("What is my purpose?").expect("expected my-purpose reply");
        assert!(my_purpose.to_lowercase().contains("help") && my_purpose.to_lowercase().contains("grow"), "my-purpose missing: {}", my_purpose);
        assert!(my_purpose.to_lowercase().starts_with("your "), "expected 'What is my ...' → reply start with 'Your': {}", my_purpose);

        let your_purpose = mind.handle_def_thing("What is your purpose?").expect("expected your-purpose reply");
        assert!(your_purpose.to_lowercase().contains("help") && your_purpose.to_lowercase().contains("progress"), "your-purpose missing: {}", your_purpose);
        assert!(your_purpose.to_lowercase().starts_with("my "), "expected 'What is your ...' → reply start with 'My': {}", your_purpose);

        // --- Non-repetition / adaptation invariant ---
        let correction = "My input is helping you progress.";
        let _ = mind.engine.ingest_user(correction);
        let ack = mind.query_text("Yes, that is correct.");
        // must not verbatim repeat the correction string (do not require a specific phrasing)
        assert_ne!(ack.trim(), correction.trim(), "system should not verbatim repeat the correction");

        // Cleanup mind files created during test
        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_possessive_conversation_sequence() {
        // Arrange: fresh mind
        let mind_name = "__test_possessive";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // 1) Tell the system its own name (system-perspective fact)
        let _ = mind.engine.ingest_user("Your name is HAL.");

        // 2) Tell the system the *user's* name
        let _ = mind.engine.ingest_user("My name is John.");

        // 3) Ask: "What is my name?" → expect responder: "Your name is John."
        let reply_user = mind.query_text("What is my name?");
        println!("reply to 'What is my name?': {}", reply_user);
        assert!(reply_user.to_lowercase().contains("john"));
        assert!(reply_user.to_lowercase().starts_with("your ")); // flipped-perspective

        // 4) Ask: "What is your name?" → expect responder: "My name is HAL."
        let reply_system = mind.query_text("What is your name?");
        println!("reply to 'What is your name?': {}", reply_system);
        assert!(reply_system.to_lowercase().contains("hal") || reply_system.to_lowercase().contains('5'));
        assert!(reply_system.to_lowercase().starts_with("my "));

        // Cleanup
        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_possessive_numeric_name_ingest_user() {
        let mind_name = "__test_numeric_possessive";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Ingest via the user-facing ingest_user path (should canonicalize)
        let _ = mind.engine.ingest_user("Your name is Number 5.");

        let reply = mind.query_text("What is your name?");
        let rl = reply.to_lowercase();

        // Must preserve numeric suffix and use system-perspective phrasing
        assert!(rl.contains("number 5"), "expected 'number 5' in reply, got '{}'", reply);
        assert!(rl.starts_with("my "), "expected reply to start with 'My': {}", reply);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_correction_numeric_name() {
        let mind_name = "__test_numeric_correction";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Seed an incorrect 'your name' fact so the correction is observable
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "your name".to_string(), "is".to_string(), "robo".to_string(), 1.0
        ));

        let before = mind.query_text("What is your name?");
        assert!(before.to_lowercase().contains("robo"), "expected seeded name present");

        // Issue a corrective utterance (fast-path: Correction)
        let ack = mind.query_text("No, your name is Number 5.");
        assert!(
            ack.to_lowercase().contains("updated") ||
            ack.to_lowercase().contains("okay") ||
            ack.to_lowercase().contains("noted") ||
            ack.to_lowercase().starts_with("my ") ||
            ack.to_lowercase().starts_with("your "),
            "expected acknowledgement or restatement, got='{}'", ack
        );

        // Subsequent query must reflect the corrected canonical value
        let after = mind.query_text("What is your name?");
        let al = after.to_lowercase();
        assert!(al.contains("number 5") && al.starts_with("my "), "correction didn't persist: {}", after);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_correction_non_declarative_ack_not_generic() {
        let mind_name = "__test_correction_ack";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Non-declarative correction / short corrective utterance should
        // not return the old canned acknowledgement string.
        let ack = mind.query_text("No, I am verifying that it works.");
        assert_ne!(ack, "Okay — I've updated that.");
        assert!(!ack.trim().is_empty(), "ack should be non-empty");

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_declarative_possessive_routes_to_correction() {
        let mind_name = "__test_declarative_possessive";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Direct declarative assertion should be handled as a correction
        let resp = mind.query_text("Your name is Number 5.");
        // Should restate the asserted fact (assistant speaks the new value)
        assert!(resp.to_lowercase().contains("number 5") && resp.to_lowercase().starts_with("my "),
            "expected restatement (My name is Number 5.), got='{}'", resp);

        // The canonical triple must also be visible to fast-path queries afterwards
        let after = mind.query_text("What is your name?");
        assert!(after.to_lowercase().contains("number 5") && after.to_lowercase().starts_with("my "),
            "expected corrected name persisted: {}", after);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_dual_name_memory_and_perspective_flip() {
        let mind_name = "__test_dual_names";
        let mut mind = Mind::new(mind_name).expect("create mind");
        
        // Step 1: User tells system its own name
        let ack1 = mind.query_text("Your name is Number 5.");
        println!("Ack for 'Your name is Number 5.': {}", ack1);
        assert!(ack1.to_lowercase().starts_with("my "), 
            "System should respond with perspective-flipped 'My' for its own name");
        
        // Step 2: User tells system their own name
        let ack2 = mind.query_text("My name is John.");
        println!("Ack for 'My name is John.': {}", ack2);
        assert!(ack2.to_lowercase().starts_with("your "), 
            "System should respond with perspective-flipped 'Your' for user's name");
        
        // Verify BOTH names are in engine.relations
        let has_your_name = mind.engine.relations.iter()
            .any(|t| t.subject.to_lowercase().contains("your") && t.subject.to_lowercase().contains("name") && t.object.to_lowercase().contains("number 5"));
        let has_my_name = mind.engine.relations.iter()
            .any(|t| t.subject.to_lowercase().contains("my") && t.subject.to_lowercase().contains("name") && t.object.to_lowercase().contains("john"));
        
        assert!(has_your_name, "System should remember 'your name is number 5' in relations");
        assert!(has_my_name, "System should remember 'my name is john' in relations");
        println!("✓ Both names verified in engine.relations");
        
        // Step 3: Query system's name → should flip perspective and respond with "My name is Number 5."
        let reply_system = mind.query_text("What is your name?");
        println!("Reply to 'What is your name?': {}", reply_system);
        let reply_lower = reply_system.to_lowercase();
        assert!(reply_lower.starts_with("my "), 
            "System name query should start with 'My': {}", reply_system);
        assert!(reply_lower.contains("number 5"), 
            "System should respond with its stored name: {}", reply_system);
        
        // Step 4: Query user's name → should flip perspective and respond with "Your name is John."
        let reply_user = mind.query_text("What is my name?");
        println!("Reply to 'What is my name?': {}", reply_user);
        let reply_lower = reply_user.to_lowercase();
        assert!(reply_lower.starts_with("your "), 
            "User name query should start with 'Your': {}", reply_user);
        assert!(reply_lower.contains("john"), 
            "System should respond with user's stored name: {}", reply_user);
        
        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }
    
    #[test]
    fn test_correction_restatement_both_names() {
        let mind_name = "__test_correction_restatement";
        let mut mind = Mind::new(mind_name).expect("create mind");
        
        // Seed one name
        let _ = mind.engine.ingest_user("My name is John.");
        
        // Issue a correction with "No, " prefix that flips to the other possessive
        let ack = mind.query_text("No, your name is Number 5.");
        println!("Ack for correction 'No, your name is Number 5.': {}", ack);
        
        // Must return a restatement with flipped perspective, NOT a fallback like "Thanks — noted."
        let ack_lower = ack.to_lowercase();
        assert!(ack_lower.starts_with("my "), 
            "Correction should restate with flipped perspective 'My', got: {}", ack);
        assert!(ack_lower.contains("number 5"),
            "Correction restatement should contain the new value, got: {}", ack);
        
        // Verify both names now in engine
        let has_your_name = mind.engine.relations.iter()
            .any(|t| t.subject.to_lowercase().contains("your") && t.subject.to_lowercase().contains("name") && t.object.to_lowercase().contains("number 5"));
        let has_my_name = mind.engine.relations.iter()
            .any(|t| t.subject.to_lowercase().contains("my") && t.subject.to_lowercase().contains("name") && t.object.to_lowercase().contains("john"));
        
        assert!(has_your_name, "Should have system's name after correction");
        assert!(has_my_name, "Should still remember user's name");
        
        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_chat_sequence_preserves_both_names_and_attributes() {
        let mind_name = "__test_chat_seq_attrs";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Sequence reproducing user's transcript: user sets their name first,
        // then corrects the system's name — both should be remembered.
        let ack_user = mind.query_text("My name is John.");
        assert!(ack_user.to_lowercase().starts_with("your ") || ack_user.to_lowercase().contains("john"));

        // Ask system name (may be empty initially)
        let _ = mind.query_text("What is your name?");

        // User corrects system's name
        let ack_sys = mind.query_text("No, your name is Number 5.");
        assert!(ack_sys.to_lowercase().starts_with("my ") || ack_sys.to_lowercase().contains("number 5"));

        // Now asking about *user* name must still return John (not the system's name)
        let reply_user = mind.query_text("What is my name?");
        let ru = reply_user.to_lowercase();
        assert!(ru.starts_with("your ") && ru.contains("john"), "expected user's name 'John' retained, got='{}'", reply_user);

        // And asking about *system* name must return Number 5
        let reply_sys = mind.query_text("What is your name?");
        let rs = reply_sys.to_lowercase();
        assert!(rs.starts_with("my ") && rs.contains("number 5"), "expected system name 'Number 5', got='{}'", reply_sys);

        // Cleanup
        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_identity_survives_response_reingestion() {
        // Reproduces the real main-loop behavior where bot responses are
        // ingested back into the engine (line 2410). This caused "What is
        // my name?" to return the BOT's name because the bot's response
        // "My name is Number 5." was re-ingested, creating a Self_-sourced
        // triple (my name, IS, number 5) that shadowed the user's triple.
        let mind_name = "__test_reingest_identity";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Step 1: User sets their name
        let r1 = mind.query_text("My name is John.");
        // Simulate main loop: ingest bot response back
        let _ = mind.engine.ingest_as_self(&r1);

        // Step 2: User corrects bot's name
        let r2 = mind.query_text("Yes, and your name is Number 5.");
        let _ = mind.engine.ingest_as_self(&r2);

        // Step 3: Ask user's name — must still be John, not Number 5
        let reply = mind.query_text("What is my name?");
        let rl = reply.to_lowercase();
        assert!(rl.contains("john"), "expected user name 'John' after re-ingestion, got='{}'", reply);
        assert!(rl.starts_with("your "), "expected 'Your name is ...' perspective, got='{}'", reply);

        // Step 4: Ask bot's name — must be Number 5
        let reply_sys = mind.query_text("What is your name?");
        let rs = reply_sys.to_lowercase();
        assert!(rs.contains("number 5"), "expected bot name 'Number 5', got='{}'", reply_sys);
        assert!(rs.starts_with("my "), "expected 'My name is ...' perspective, got='{}'", reply_sys);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_multiple_attributes_memory_and_corrections() {
        let mind_name = "__test_multi_attrs";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Set multiple attributes for both user and system
        let _ = mind.query_text("My favorite color is blue.");
        let _ = mind.query_text("Your favorite color is red.");
        let _ = mind.query_text("My job is engineer.");
        let _ = mind.query_text("Your job is assistant.");

        // Verify queries return the correct, perspectively-flipped answers
        let a = mind.query_text("What is my favorite color?");
        assert!(a.to_lowercase().starts_with("your ") && a.to_lowercase().contains("blue"));

        let b = mind.query_text("What is your favorite color?");
        assert!(b.to_lowercase().starts_with("my ") && b.to_lowercase().contains("red"));

        let c = mind.query_text("What is my job?");
        assert!(c.to_lowercase().starts_with("your ") && c.to_lowercase().contains("engineer"));

        let d = mind.query_text("What is your job?");
        assert!(d.to_lowercase().starts_with("my ") && d.to_lowercase().contains("assistant"));

        // Correct one attribute and ensure only that slot is updated
        let _ = mind.query_text("No, your job is helper.");
        let updated = mind.query_text("What is your job?");
        assert!(updated.to_lowercase().contains("helper"));

        // Ensure other attributes are unchanged
        let still = mind.query_text("What is my job?");
        assert!(still.to_lowercase().contains("engineer"));

        // Confirm triples exist for the slots in engine.relations
        let has_user_job = mind.engine.relations.iter().any(|t| t.subject.to_lowercase().contains("my job") && t.object.to_lowercase().contains("engineer"));
        let has_sys_job = mind.engine.relations.iter().any(|t| t.subject.to_lowercase().contains("your job") && (t.object.to_lowercase().contains("assistant") || t.object.to_lowercase().contains("helper")));
        assert!(has_user_job && has_sys_job, "expected both 'my job' and 'your job' triples present");

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn demo_chat_sequence_printout() {
        let mut mind = Mind::new("__demo_chat").expect("create mind");

        println!("You: hello");
        let r0 = mind.query_text("hello");
        println!("Mind: {}", r0);

        println!("You: My name is John");
        let r1 = mind.query_text("My name is John");
        println!("Mind: {}", r1);

        println!("You: What is your name?");
        let r2 = mind.query_text("What is your name?");
        println!("Mind: {}", r2);

        println!("You: No, your name is Number 5");
        let r3 = mind.query_text("No, your name is Number 5");
        println!("Mind: {}", r3);

        println!("You: what is my name?");
        let r4 = mind.query_text("what is my name?");
        println!("Mind: {}", r4);

        // Cleanup
        let _ = std::fs::remove_dir_all(".minds/__demo_chat");
    }

    #[test]
    fn test_find_first_unknown_token() {
        let mind_name = "__test_find_unknown";
        let mut mind = Mind::new(mind_name).unwrap();
        mind.ask_on_unknowns = true;

        // seed engine with some known tokens (include 'saw' so zyxw is the first unknown)
        let _ = mind.engine.ingest("the quick brown fox");
        let _ = mind.engine.ingest("I saw a fox");

        // 'zyxw' is unknown
        let unk = mind.find_first_unknown_token("I saw a zyxw today");
        assert_eq!(unk.as_deref(), Some("zyxw"));

        // 'cat' is not known yet and should be reported as unknown
        let unk2 = mind.find_first_unknown_token("I am a cat");
        assert_eq!(unk2.as_deref(), Some("cat"));

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_handle_unknowns_after_ingest_no_lm() {
        let mind_name = "__test_unknowns_no_lm";
        let mut mind = Mind::new(mind_name).unwrap();
        mind.ask_on_unknowns = true;

        // No LM configured → should ask the human
        let prompt = mind.handle_unknowns_after_ingest("I met a zqxpl today").expect("expected prompt");
        assert!(prompt.contains("I don't know the word") || prompt.contains("means"));

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_resolve_lm_url_defaults_and_overrides() {
        // Ensure deterministic behavior when the env var is set/unset
        std::env::remove_var("LM_STUDIO_API_URL");
        assert_eq!(Mind::resolve_lm_url(), "http://127.0.0.1:1234/api/v1/chat");

        std::env::set_var("LM_STUDIO_API_URL", "http://localhost:4321");
        assert_eq!(Mind::resolve_lm_url(), "http://localhost:4321/api/v1/chat");

        std::env::set_var("LM_STUDIO_API_URL", "http://localhost:4321/api/v1/chat");
        assert_eq!(Mind::resolve_lm_url(), "http://localhost:4321/api/v1/chat");

        std::env::remove_var("LM_STUDIO_API_URL");
    }

    #[test]
    fn test_resolve_lm_model_from_env() {
        std::env::set_var("LM_STUDIO_MODEL", "some-test-model");
        assert_eq!(Mind::resolve_lm_model().as_deref(), Some("some-test-model"));
        std::env::remove_var("LM_STUDIO_MODEL");
    }

    #[test]
    fn test_set_and_clear_lm_model_override() {
        let mut mind = Mind::new("__test_lm_override").unwrap();
        assert!(mind.lm_model_override.is_none());

        mind.set_lm_model_override(Some("custom/model-x".to_string()));
        assert_eq!(mind.lm_model_override.as_deref(), Some("custom/model-x"));
        assert_eq!(mind.effective_lm_model().as_deref(), Some("custom/model-x"));

        mind.set_lm_model_override(None);
        assert!(mind.lm_model_override.is_none());

        let _ = fs::remove_dir_all(format!(".minds/{}", "__test_lm_override"));
    }

    #[test]
    fn test_resolve_lm_model_defaults_to_preferred() {
        std::env::remove_var("LM_STUDIO_MODEL");
        // When the server cannot be queried (or returns nothing) the resolver
        // must still provide the preferred fallback model name.
        let m = Mind::resolve_lm_model();
        // Resolver should always return some model; prefer the built-in
        // fallback when nothing else is configured.
        assert_eq!(m.as_deref(), Some("ibm/granite-4-h-tiny"));
    }

    #[test]
    fn test_pathway_weights_persist_in_engine_state() {
        let name = "_test_mind_pw2";
        // create mind and set a slot score
        let mut m = Mind::new(name).expect("create mind");
        let idx = m.engine.table.insert_word("persistdog2", 0);
        m.engine.table.slots[idx as usize].score = 200;
        m.save().expect("save mind");

        // load and verify the persisted score was restored from engine.json
        let m2 = Mind::load(name).expect("load mind");
        if let Some(idx2) = m2.engine.table.get_word_index("persistdog2") {
            assert_eq!(m2.engine.table.slots[idx2 as usize].score, 200);
        } else { panic!("word not found after load"); }

        // cleanup
        let _ = std::fs::remove_dir_all(format!(".minds/{}", name));
    }

    #[test]
    fn test_parse_lm_output_reasoning_extracts_definition() {
        let v = serde_json::json!({
            "output": [
                { "type": "reasoning", "content": "1. Break down the word.\n\nA meeting is when two people see each other for a short time. Further details follow." }
            ]
        });
        let out = Mind::parse_lm_response(&v).expect("should parse");
        assert!(out.starts_with("A meeting is when two people see each other"), "got='{}'", out);
    }

    #[test]
    fn test_parse_lm_output_prefers_message_type() {
        let v = serde_json::json!({
            "output": [
                { "type": "reasoning", "content": "internal reasoning..." },
                { "type": "message", "content": "A cat is a small domesticated carnivorous mammal." }
            ]
        });
        let out = Mind::parse_lm_response(&v).expect("should parse");
        assert_eq!(out, "A cat is a small domesticated carnivorous mammal.");
    }

    #[test]
    fn test_collect_unknown_tokens_respects_table_slots() {
        let mut mind = Mind::new("__test_table_slots").unwrap();
        // ingest a token so it exists in the low-level table/token_index
        let _ = mind.engine.ingest("zyxw is a thing");

        // collect_unknown_tokens should NOT report 'zyxw' but should report 'pqrv'
        let unknowns = mind.collect_unknown_tokens("I saw a zyxw and a pqrv");
        assert!(!unknowns.contains(&"zyxw".to_string()));
        assert!(unknowns.contains(&"pqrv".to_string()));

        let _ = fs::remove_dir_all(format!(".minds/{}", "__test_table_slots"));
    }

    #[test]
    fn test_define_and_ingest_skips_already_known_tokens() {
        let mut mind = Mind::new("__test_define_skip").unwrap();
        // Make 'cat' known by ingesting it first
        let _ = mind.engine.ingest("cat is an animal");

        let mut cache: std::collections::HashSet<String> = std::collections::HashSet::new();
        let added = mind.define_and_ingest_tokens(vec!["cat".to_string()].into_iter(), &mut cache);
        assert_eq!(added, 0, "already-known token should be skipped");

        let _ = fs::remove_dir_all(format!(".minds/{}", "__test_define_skip"));
    }

    #[test]
    fn test_later_query_corrections_and_yes_no_handling() {
        // Arrange: fresh mind with an intentionally incorrect stored fact
        let mind_name = "__test_later_corrections";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Seed an incorrect system-purpose so the correction is observable
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "your purpose".to_string(), "is".to_string(), "to conquer the world".to_string(), 1.0
        ));

        // Confirm initial (incorrect) answer
        let before = mind.query_text("What is your purpose?");
        assert!(before.to_lowercase().contains("conquer"), "expected seeded purpose, got: {}", before);

        // User issues a corrective utterance later in the session (fast-path: starts with 'No,')
        let ack = mind.query_text("No, your purpose is helping me progress.");
        assert!(ack.to_lowercase().contains("updated") || ack.to_lowercase().contains("noted") || ack.to_lowercase().contains("my ") || ack.to_lowercase().contains("your "), "expected correction acknowledgement, got='{}'", ack);

        // Subsequent query must reflect the corrected fact (and preserve perspective flip)
        let after = mind.query_text("What is your purpose?");
        assert!(after.to_lowercase().contains("help"), "correction didn't persist: {}", after);
        assert!(after.to_lowercase().starts_with("my "), "expected responder to say 'My ...': {}", after);

        // Short standalone confirmations/denials should be routed as corrections
        assert_eq!(mind.detect_route("Yes"), Route::Correction);
        assert_eq!(mind.detect_route("No"), Route::Correction);
        assert_eq!(mind.detect_route("Yes, that is correct."), Route::Correction);
        assert_eq!(mind.detect_route("No, that's wrong."), Route::Correction);

        // Short 'Yes'/'No' go through the correction handler and return the
        // standard acknowledgement string (do not require a specific phrasing)
        let yes_ack = mind.query_text("Yes");
        assert!(yes_ack.to_lowercase().contains("updated") || yes_ack.to_lowercase().contains("okay") || yes_ack.to_lowercase().contains("noted"));

        let no_ack = mind.query_text("No");
        assert!(no_ack.to_lowercase().contains("updated") || no_ack.to_lowercase().contains("okay") || no_ack.to_lowercase().contains("noted"));

        // Cleanup
        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn test_various_corrections_and_assurances() {
        let mind_name = "__test_corrections_varieties";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Seed an incorrect fact and verify it's present
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "your purpose".to_string(), "is".to_string(), "to conquer the world".to_string(), 1.0
        ));
        let before = mind.query_text("What is your purpose?");
        assert!(before.to_lowercase().contains("conquer"));

        // Partial correction (replace object) - now expects restatement with flipped perspective
        let ack = mind.query_text("No, your purpose is helping others.");
        assert!(ack.to_lowercase().contains("helping") || ack.to_lowercase().contains("others") ||
                ack.to_lowercase().contains("updated") || ack.to_lowercase().contains("okay") || ack.to_lowercase().contains("noted"),
                "Expected restatement or ack, got: {}", ack);
        let after = mind.query_text("What is your purpose?");
        assert!(after.to_lowercase().contains("help"));

        // Assurance phrasing should be accepted and ingested
        let _ = mind.query_text("I assure you your purpose is to aid people.");
        let assured = mind.query_text("What is your purpose?");
        assert!(assured.to_lowercase().contains("aid") || assured.to_lowercase().contains("people"));

        // Retraction using explicit 'about' slot must remove matching relation
        // Seed again, then retract
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "your color".to_string(), "is".to_string(), "red".to_string(), 1.0
        ));
        let c = mind.query_text("What is your color?");
        assert!(c.to_lowercase().contains("red"));

        // route detection for the full phrase must also be Correction
        assert_eq!(mind.detect_route("I take that back about your color."), Route::Correction);
        let rem = mind.query_text("I take that back about your color.");
        assert!(rem.to_lowercase().contains("remove") || rem.to_lowercase().contains("couldn't") || rem.to_lowercase().contains("removed") || rem.to_lowercase().contains("okay"));

        let post = mind.query_text("What is your color?");
        assert!(!post.to_lowercase().contains("red"));

        // detect_route should catch these correction/assurance variants
        assert_eq!(mind.detect_route("I confirm"), Route::Correction);
        assert_eq!(mind.detect_route("I take that back"), Route::Correction);
        assert_eq!(mind.detect_route("I assure you"), Route::Correction);
        assert_eq!(mind.detect_route("Actually, that's wrong"), Route::Correction);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    /// *** PHASE 5: Regression tests for QA refactor ***
    /// These tests verify that the six critical issues identified during the refactor are fixed.

    #[test]
    fn phase5_regression_test_1_correction_not_routed_to_generic_qa() {
        // Test: "no, Frustration is the signal that something is wrong"
        // Should be ingested and paraphrased, NOT routed to GenericQA with a canned response
        let mind_name = "__test_phase5_regression1";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // First, establish an incorrect definition
        mind.engine.relations.push(carousel_hash::dada_engine::RelationalTriple::new(
            "frustration".to_string(), "is".to_string(), "anger".to_string(), 1.0
        ));

        // Query the incorrect fact
        let initial = mind.query_text("What is frustration?");
        assert!(initial.to_lowercase().contains("anger"));

        // Issue a correction
        let correction_response = mind.query_text("no, Frustration is the signal that something is wrong");

        // Verify the response is NOT the generic fallback "I'm still learning how to express that"
        assert!(!correction_response.to_lowercase().contains("i'm still learning"),
                "Correction was incorrectly routed to GenericQA fallback. Got: {}", correction_response);

        // Verify the new fact was ingested (next query should reflect it)
        let after = mind.query_text("What is frustration?");
        assert!(after.to_lowercase().contains("signal") || after.to_lowercase().contains("wrong"),
                "Corrected fact was not stored. Got: {}", after);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn phase5_regression_test_2_that_is_correct_parsed_as_assertion() {
        // Test: "that is correct, X is Y" pattern
        // Should be parsed as an assertion/confirmation, not generic QA
        let mind_name = "__test_phase5_regression2";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Issue an assertion using "that is correct" form
        let response = mind.query_text("that is correct, I am a language model");

        // Response should not be a generic fallback
        assert!(!response.to_lowercase().contains("i'm still learning"),
                "Should not use generic fallback. Got: {}", response);

        // Verify the fact was stored
        let confirm = mind.query_text("Are you a language model?");
        // Should find a fact about "I am" / "language model"
        assert!(confirm.to_lowercase().contains("yes") || 
                confirm.to_lowercase().contains("correct") ||
                confirm.to_lowercase().contains("language model"),
                "Assertion not stored properly. Got: {}", confirm);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn phase5_regression_test_3_what_is_routes_to_defthing() {
        // Test: "What is frustration?" should route to DefThing, never GenericQA
        let mind_name = "__test_phase5_regression3";
        let mind = Mind::new(mind_name).expect("create mind");

        // Test routing detection
        assert_eq!(mind.detect_route("What is frustration?"), Route::DefThing,
                   "What is X? should route to DefThing");
        assert_eq!(mind.detect_route("What is consciousness?"), Route::DefThing,
                   "What is X? should route to DefThing");
        assert_eq!(mind.detect_route("What are emotions?"), Route::DefThing,
                   "What are X? should route to DefThing");

        // Should NOT route to GenericQA
        assert_ne!(mind.detect_route("What is frustration?"), Route::GenericQA);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    fn phase5_regression_test_4_malformed_correction_requests_rephrase() {
        // Test: Correction statement that cannot be parsed should produce a rephrase prompt
        // NOT a silent acknowledgement
        let mind_name = "__test_phase5_regression4";
        let mut mind = Mind::new(mind_name).expect("create mind");

        // Issue a malformed correction that doesn't fit any pattern
        let malformed = "no, this is very strange and makes no sense";
        let response = mind.query_text(malformed);

        // Should ask for rephrase, not generic "Thanks - noted"
        assert!(response.to_lowercase().contains("rephrase") || 
                response.to_lowercase().contains("statement") ||
                response.to_lowercase().contains("could you"),
                "Should ask for rephrase on unparseable correction. Got: {}", response);

        let _ = fs::remove_dir_all(format!(".minds/{}", mind_name));
    }

    #[test]
    #[ignore = "is_valid_response_structure function not yet implemented"]
    fn phase5_regression_test_5_fragmentary_output_caught_by_guardrail() {
        // Test: Synthesized output that is malformed or fragmentary should be caught
        // (This is harder to test directly, so we verify the guardrail function itself)
        // TODO: Implement Mind::is_valid_response_structure and uncomment tests below
        /*
        // Valid responses should pass
        assert!(Mind::is_valid_response_structure("I am a helpful assistant."),
                "Valid response should pass validation");
        assert!(Mind::is_valid_response_structure("Frustration is a signal that something is wrong."),
                "Valid response should pass validation");
        assert!(Mind::is_valid_response_structure("The purpose is to help and assist."),
                "Valid response should pass validation");

        // Fragmentary responses should fail
        assert!(!Mind::is_valid_response_structure("My goal is Consciousness that."),
                "Fragmentary 'that.' ending should fail");
        assert!(!Mind::is_valid_response_structure("is the"),
                "Bare fragment should fail");
        assert!(!Mind::is_valid_response_structure("x y"),
                "Too short should fail");
        */
    }

    #[test]
    fn phase5_regression_test_6_parse_canonical_assertion_helper() {
        // Test: The canonical assertion parser should handle all patterns
        
        // Pattern: "I am X"
        if let Some((subj, cop, obj)) = parse_canonical_assertion("I am a language model") {
            assert_eq!(subj, "i");  // Parser lowercases all inputs
            assert_eq!(cop, "am");
            assert_eq!(obj, "a language model");
        } else {
            panic!("Failed to parse 'I am X'");
        }

        // Pattern: "you are X"
        if let Some((subj, cop, obj)) = parse_canonical_assertion("You are helpful") {
            assert_eq!(subj, "you");
            assert_eq!(cop, "are");
            assert_eq!(obj, "helpful");
        } else {
            panic!("Failed to parse 'You are X'");
        }

        // Pattern: "my X is Y"
        if let Some((subj, cop, obj)) = parse_canonical_assertion("my purpose is to help") {
            assert_eq!(subj, "my purpose");
            assert_eq!(cop, "is");
            assert_eq!(obj, "to help");
        } else {
            panic!("Failed to parse 'my X is Y'");
        }

        // Pattern: "your X is Y"
        if let Some((subj, cop, obj)) = parse_canonical_assertion("Your name is John") {
            assert_eq!(subj, "your name");
            assert_eq!(cop, "is");
            assert_eq!(obj, "john");  // Parser lowercases
        } else {
            panic!("Failed to parse 'Your X is Y'");
        }

        // Pattern: "no, X is Y"
        if let Some((subj, cop, obj)) = parse_canonical_assertion("no, Frustration is a signal") {
            assert_eq!(subj, "frustration");  // Parser lowercases
            assert_eq!(cop, "is");
            assert_eq!(obj, "a signal");
        } else {
            panic!("Failed to parse 'no, X is Y'");
        }

        // Malformed should return None (no marker prefix means generic "X is Y" is skipped)
        assert!(parse_canonical_assertion("this is just random text").is_none(),
                "Random text without marker prefix should not parse");
    }
}

fn parse_perspective(s: &str) -> Perspective {
    match s.to_uppercase().as_str() {
        "FIRST"  | "1ST" | "1" => Perspective::First,
        "SECOND" | "2ND" | "2" => Perspective::Second,
        _                       => Perspective::Third,
    }
}

/// Very lightweight triple extractor for the `correct` command.
fn extract_triples_from_text(text: &str) -> Vec<(String, String, String)> {
    let mut triples = Vec::new();
    for sentence in text.split('.') {
        let words: Vec<&str> = sentence.split_whitespace().collect();
        if words.len() >= 3 {
            let s = words[0].to_lowercase();
            let r = words[1].to_uppercase();
            let o = words[2..].join(" ").to_lowercase();
            if !s.is_empty() && !o.is_empty() {
                triples.push((s, r, o));
            }
        }
    }
    triples
}

// ---------------------------------------------------------------------------
// Interactive Shell
// ---------------------------------------------------------------------------

fn shell_mode() {
    println!();
    println!("╔═══════════════════════════════════════════════════════════╗");
    println!("║            WORD ENGINE  ·  UNIFIED SHELL v1.0              ║");
    println!("║   Carousel Hash · Synsets · Transitive Reasoning         ║");
    println!("╚═══════════════════════════════════════════════════════════╝");
    println!();
    println!("Type 'help' for commands or 'quit' to exit.\n");
    
    let mut mind: Option<Mind> = None;
    
    loop {
        let prompt = match &mind {
            Some(m) => format!("WORD[{}]> ", m.name),
            None    => "WORD> ".to_string(),
        };
        print!("{}", prompt);
        io::stdout().flush().unwrap();
        
        let mut line = String::new();
        if io::stdin().read_line(&mut line).is_err() { break; }
        let line = line.trim();
        if line.is_empty() { continue; }
        
        let parts: Vec<&str> = line.splitn(2, ' ').collect();
        // Accept an optional leading "/" on any command (e.g. "/test",
        // "/train foo.txt") since that's the more familiar chat-command
        // convention -- doesn't change behavior for the existing bare-word form.
        let cmd = parts[0].strip_prefix('/').unwrap_or(parts[0]);
        let rest = parts.get(1).copied().unwrap_or("");

        match cmd {
            "help" => {
                println!("\nCOMMANDS:");
                println!("  create <name>      - Create a new mind");
                println!("  load <name>        - Load a mind");
                println!("  save               - Save current mind");
                println!("  list               - List minds");
                println!("  train <path>       - Train from file/directory");
                println!("  query <text>       - Ask a question");
                println!("  chat               - Interactive chat");
                println!("  test               - Smoke test: scratch mind + example corpus + query battery");
                println!("  ask_unknowns <on|off>  - Ask user (and LM) to define unknown words during chat");
                println!("  ═══ HASH / RADIAL MODE ═══");
                println!("  radial <on|off>        - Enable/disable radial (one-bin-over) lookup");
                println!("  method [0-9|name]      - List methods or select by number/name");
                println!("  window [size]          - Get/set radial window (address space radius)");
                println!("  depth [n]              - Get/set chain depth (results per address)");
                println!("  mode [exact|cascade|diffuse] - Quick presets (equivalent to above)");
                println!("  lm_model [<name>|clear] - Set or show LM Studio model override for current mind");
                println!("  lm_filter <on|off>     - Noise pre-filter before LM calls (default: off)");
                println!("  ask_unknowns <on|off>  - Toggle asking definitions for unknown words");
                println!("  stats              - Show statistics");
                println!("  bench              - Run benchmarks");
                println!("  relations [n]      - Show last N relations");
                println!("  synsets <cmd>      - Synonym management (add/load/expand/stats)");
                println!("  think <s> <t> [h]  - Transitive reasoning chain");
                println!("  similar <w1> <w2>  - Semantic similarity");
                println!("  resolve <expr>     - Anaphora resolution (it/this/that)");
                println!("  perspective <f> <t> <s> - Perspective translation");
                println!("  correct <s> | <t>  - Learn correction rule");
                println!("  scan [n]           - Scan positions for relations");
                println!("  interference <q>   - Find where query words co-occur in corpus");
                println!("  reverse_interference <sentence> - Test if queries retrieve sentence");
                println!("  typos_check        - List likely typos in corpus");
                println!("  typos_correct      - Apply auto-corrections to typos");
                println!("  quit/exit          - Exit shell\n");
            }
            "create" => {
                if rest.is_empty() { println!("Usage: create <name>"); continue; }
                match Mind::new(rest) {
                    Ok(m)  => { println!("🧠 Created mind '{}'", rest); mind = Some(m); }
                    Err(e) => println!("✗ {}", e),
                }
            }
            "load" => {
                if rest.is_empty() { println!("Usage: load <name>"); continue; }
                println!("📂 Loading mind '{}'...", rest);
                match Mind::load(rest) {
                    Ok(m)  => { println!("✓ Mind '{}' ready", rest); mind = Some(m); }
                    Err(e) => println!("✗ {}", e),
                }
            }
            "save" => {
                if let Some(ref m) = mind {
                    cmd_save(m);
                } else { println!("✗ No active mind."); }
            }
            "list" => cmd_list(),
            "train" => {
                if let Some(ref mut m) = mind {
                    if rest.is_empty() { println!("Usage: train <path>"); continue; }
                    cmd_train(m, rest);
                } else { println!("✗ No active mind."); }
            }
            "query" => {
                if let Some(ref mut m) = mind {
                    if rest.is_empty() { println!("Usage: query <text>"); continue; }
                    cmd_query(m, rest);
                } else { println!("✗ No active mind."); }
            }
            "chat" => {
                if let Some(ref mut m) = mind {
                    cmd_chat(m);
                } else { println!("✗ No active mind."); }
            }
            "test" => {
                // Standalone -- doesn't touch the active mind, so this
                // works with or without one loaded.
                cmd_smoketest();
            }
            "ask_unknowns" => {
                if let Some(ref mut m) = mind {
                    let arg = rest.trim().to_lowercase();
                    match arg.as_str() {
                        "on" => { m.ask_on_unknowns = true; println!("✓ ask_unknowns: ON"); }
                        "off" => { m.ask_on_unknowns = false; println!("✓ ask_unknowns: OFF"); }
                        "" => println!("ask_unknowns is {}", if m.ask_on_unknowns { "ON" } else { "OFF" }),
                        _ => println!("Usage: ask_unknowns <on|off>"),
                    }
                } else { println!("✗ No active mind."); }
            }
            "radial" => {
                if let Some(ref mut m) = mind {
                    let arg = rest.trim().to_lowercase();
                    match arg.as_str() {
                        "on" => {
                            m.query_mode.radial = true;
                            m.engine.query_mode = m.query_mode;
                            m.engine.addr_index = m.engine.table.build_addr_index(m.engine.query_mode.hash_method());
                            println!("✓ radial: ON");
                        }
                        "off" => {
                            m.query_mode.radial = false;
                            m.engine.query_mode = m.query_mode;
                            println!("✓ radial: OFF");
                        }
                        "" => println!("radial is {}", if m.query_mode.radial { "ON" } else { "OFF" }),
                        _ => println!("Usage: radial <on|off>"),
                    }
                } else { println!("✗ No active mind."); }
            }
            "method" => {
                if let Some(ref mut m) = mind {
                    let arg = rest.trim();
                    if arg.is_empty() {
                        // List all methods
                        println!("Hash methods (0-9):");
                        for i in 0..10 {
                            if let Some(method) = carousel_hash::hash_methods::HashMethod::from_u8(i) {
                                let label = method.label();
                                let star = if method == m.query_mode.method { " ★" } else { "" };
                                println!("  {}  {}{}", i, label, star);
                            }
                        }
                    } else if let Some(method) = carousel_hash::hash_methods::HashMethod::from_str(arg) {
                        m.query_mode.method = method;
                        m.engine.query_mode = m.query_mode;
                        m.engine.addr_index = m.engine.table.build_addr_index(m.engine.query_mode.hash_method());
                        println!("✓ method → {} ({})", method as u8, method.label());
                    } else {
                        println!("✗ Unknown method: '{}'", arg);
                        println!("Try: method 0-9  or  method <name>");
                    }
                } else { println!("✗ No active mind."); }
            }
            "window" => {
                if let Some(ref mut m) = mind {
                    let arg = rest.trim();
                    if arg.is_empty() {
                        println!("window: {} (address-space radius)", m.query_mode.window);
                    } else if let Ok(w) = arg.parse::<u16>() {
                        m.query_mode.window = w.max(1);
                        m.engine.query_mode = m.query_mode;
                        println!("✓ window → {}", m.query_mode.window);
                    } else {
                        println!("✗ window must be a number (1-65535)");
                    }
                } else { println!("✗ No active mind."); }
            }
            "depth" => {
                if let Some(ref mut m) = mind {
                    let arg = rest.trim();
                    if arg.is_empty() {
                        println!("depth: {} (results per address)", m.query_mode.chain_depth);
                    } else if let Ok(d) = arg.parse::<u8>() {
                        m.query_mode.chain_depth = d.max(1);
                        m.engine.query_mode = m.query_mode;
                        println!("✓ depth → {}", m.query_mode.chain_depth);
                    } else {
                        println!("✗ depth must be a number (1-255)");
                    }
                } else { println!("✗ No active mind."); }
            }
            "mode" => {
                if let Some(ref mut m) = mind {
                    let arg = rest.trim();
                    if arg.is_empty() {
                        // Show current
                        let q = &m.query_mode;
                        println!("⚙  Current mode:");
                        println!("   radial={} method={} ({})", q.radial, q.method as u8, q.method.label());
                        println!("   window={} depth={} weight={:.2}", q.window, q.chain_depth, q.relation_weight);
                    } else {
                        // Quick presets
                        match arg {
                            "exact" => {
                                m.query_mode = carousel_hash::hash_methods::QueryMode::exact();
                                m.engine.query_mode = m.query_mode;
                                println!("✓ mode → exact (standard lookup)");
                            }
                            "cascade" => {
                                m.query_mode = carousel_hash::hash_methods::QueryMode::cascade();
                                m.engine.query_mode = m.query_mode;
                                m.engine.addr_index = m.engine.table.build_addr_index(m.engine.query_mode.hash_method());
                                println!("✓ mode → cascade (Tribonacci + radius 1)");
                            }
                            "diffuse" => {
                                m.query_mode = carousel_hash::hash_methods::QueryMode::diffuse();
                                m.engine.query_mode = m.query_mode;
                                m.engine.addr_index = m.engine.table.build_addr_index(m.engine.query_mode.hash_method());
                                println!("✓ mode → diffuse (Tribonacci + radius 2)");
                            }
                            _ => println!("Presets: mode exact | cascade | diffuse\nOr use: radial/method/window/depth for fine-grained control"),
                        }
                    }
                } else { println!("✗ No active mind."); }
            }
            "lm_model" | "model" => {
                if let Some(ref mut m) = mind {
                    let arg = rest.trim();
                    m.set_lm_model_override(Some(arg.to_string()));
                    println!("✓ LM model override set to '{}'", arg);
                } else { println!("✗ No active mind."); }
            }
            "lm_filter" | "lm_noise" => {
                if let Some(ref mut m) = mind {
                    match rest.trim() {
                        "on" | "1" | "true" => {
                            m.lm_noise_filter = true;
                            println!("✓ LM noise filter ON — multi-word/garbage tokens will be skipped before LM call");
                        }
                        "off" | "0" | "false" => {
                            m.lm_noise_filter = false;
                            println!("✓ LM noise filter OFF — all candidates sent to LM (default)");
                        }
                        _ => {
                            let state = if m.lm_noise_filter { "ON" } else { "OFF" };
                            println!("LM noise filter: {} \nUsage: lm_filter on|off", state);
                        }
                    }
                } else { println!("✗ No active mind."); }
            }
            "stats" => {
                if let Some(ref m) = mind {
                    cmd_stats(m);
                } else { println!("✗ No active mind."); }
            }
            "bench" => {
                if let Some(ref mut m) = mind {
                    cmd_bench(m);
                } else { println!("✗ No active mind."); }
            }
            "relations" => {
                if let Some(ref m) = mind {
                    // syntax: relations [N] [flat|chains|targeted]
                    let mut parts = rest.split_whitespace();
                    let first = parts.next().unwrap_or("20");
                    let (n, mode) = if first.chars().all(|c| c.is_ascii_digit()) {
                        (first.parse::<usize>().unwrap_or(20),
                         parts.next().unwrap_or("flat"))
                    } else {
                        (20, first)
                    };
                    let rels = &m.engine.relations;
                    if rels.is_empty() {
                        println!("  (no relations yet — try 'train' first)");
                    } else {
                        match mode {
                            "chains" => {
                                println!("\n  🔗 Multi-hop chains (sampled from last {} relations):", n);
                                let mut shown = 0;
                                for t in rels.iter().rev().take(n * 3) {
                                    if shown >= 6 { break; }
                                    let subj = t.subject.to_lowercase();
                                    let obj  = t.object.to_lowercase();
                                    let chain = m.engine.find_reasoning_chain(&subj, &obj, 4);
                                    if chain.len() > 1 {
                                        println!("  {} → {}", subj, obj);
                                        println!("    {}", TransitiveReasoner::format_chain(&chain));
                                        shown += 1;
                                    }
                                }
                                if shown == 0 { println!("  (no multi-hop chains found in recent relations)"); }
                                println!();
                            }
                            "targeted" => {
                                let key_rels: Vec<_> = rels.iter().rev()
                                    .filter(|t| {
                                        let r = format!("{:?}", t.relation).to_lowercase();
                                        r.contains("cause") || r.contains("because") ||
                                        r.contains("purpose") || r.contains("goal") ||
                                        r.contains("result") || r.contains("reason")
                                    })
                                    .take(n)
                                    .collect();
                                println!("\n  🎯 Causal / Purpose relations ({} shown):", key_rels.len());
                                if key_rels.is_empty() { println!("  (none found)"); }
                                for t in key_rels {
                                    println!("  {:20} {:15} {}", t.subject, format!("{:?}", t.relation), t.object);
                                }
                                println!();
                            }
                            _ => {
                                println!("\n  Last {} of {} relations:", n.min(rels.len()), rels.len());
                                for t in rels.iter().rev().take(n) {
                                    println!("  {:20} {:15} {}", t.subject, format!("{:?}", t.relation), t.object);
                                }
                                println!();
                            }
                        }
                    }
                } else { println!("✗ No active mind."); }
            }
            "synsets" => {
                if let Some(ref mut m) = mind {
                    let (sub, srest) = split_first(rest);
                    match sub {
                        "add" => {
                            let words: Vec<&str> = srest.split_whitespace().collect();
                            if words.len() < 2 { println!("Usage: synsets add <w1> <w2> [...]"); continue; }
                            m.synsets.add_group(&words);
                            println!("✓ Added synset: {}", words.join(", "));
                        }
                        "load" => {
                            if srest.is_empty() { println!("Usage: synsets load <file>"); continue; }
                            match m.synsets.load_from_file(srest) {
                                Ok(n)  => println!("✓ Loaded {} synset groups from '{}'", n, srest),
                                Err(e) => println!("✗ {}", e),
                            }
                        }
                        "expand" => {
                            if srest.is_empty() { println!("Usage: synsets expand <word>"); continue; }
                            let expanded = m.synsets.expand(srest);
                            println!("  {} → {:?}", srest, expanded);
                        }
                        "stats" | "" => {
                            println!("  {} synset groups, {} indexed words",
                                m.synsets.synset_count(), m.synsets.word_count());
                        }
                        _ => println!("Subcommands: add, load, expand, stats"),
                    }
                } else { println!("✗ No active mind."); }
            }
            "think" => {
                if let Some(ref m) = mind {
                    let parts: Vec<&str> = rest.splitn(3, ' ').collect();
                    if parts.len() < 2 { println!("Usage: think <subject> <target> [max_hops]"); continue; }
                    // NOTE: live_think lowercases subject/target itself,
                    // matching how ingest_with_source currently lowercases
                    // the whole sentence before tokenizing (word_engine.rs
                    // ingest_with_source). This is not the case-preserving
                    // ingest the wider conversation is aiming for -- that's
                    // a separate, bigger change to the ingest path. Once
                    // ingest stops lowercasing, live_think reads self.tokens
                    // directly and will pick up real case with no change
                    // needed here.
                    let subject  = parts[0];
                    let target   = parts[1];
                    let max_hops: usize = parts.get(2).and_then(|s| s.parse().ok()).unwrap_or(5);

                    // LIVE WALK -- no store, no finalize step, nothing
                    // pre-baked. Walks self.tokens/self.token_index fresh
                    // on every call, using operator pivots as the OP table.
                    // Deliberately NOT table.walk_transitive: that reads
                    // table.rs's chain-threaded Relation slots, which are
                    // only populated by finalize_relations() over already
                    // regex-damaged triples -- a separate store off to the
                    // side, which is exactly the shape we're moving away from.
                    println!("\n🔗 Reasoning chain: {} → {}", subject, target);
                    match m.engine.live_think(subject, target, max_hops) {
                        Some((depth, path)) => {
                            println!("  {} --{}--> {}", subject, path.join(" --"), target);
                            println!("  ({} hops)", depth);
                            let confidence = 1.0_f32 / (depth.max(1) as f32).sqrt();
                            println!("  Conclusion: yes (confidence {:.0}%)\n", confidence * 100.0);
                        }
                        None => {
                            println!("  No path found within {} hops.", max_hops);
                            println!("  Conclusion: unknown (confidence 0%)\n");
                        }
                    }
                } else { println!("✗ No active mind."); }
            }
            "similar" => {
                if let Some(ref m) = mind {
                    let parts: Vec<&str> = rest.splitn(2, ' ').collect();
                    if parts.len() < 2 { println!("Usage: similar <word1> <word2>"); continue; }
                    let w1 = parts[0];
                    let w2 = parts[1].trim();

                    let by_subj: HashMap<String, Vec<(String, String)>> = m.engine.relations.iter()
                        .fold(HashMap::new(), |mut acc, t| {
                            acc.entry(t.subject.clone()).or_default()
                               .push((format!("{:?}", t.relation), t.object.clone()));
                            acc
                        });
                    let by_obj = build_by_object(&by_subj);
                    let matcher = SemanticMatcher::new(&by_subj, &by_obj);
                    let score = matcher.similarity(w1, w2);
                    println!("\n  similarity({}, {}) = {:.3} ({:.0}%)\n", w1, w2, score, score * 100.0);
                } else { println!("✗ No active mind."); }
            }
            "resolve" => {
                if let Some(ref m) = mind {
                    if rest.is_empty() { println!("Usage: resolve <expression>  (e.g. this, that, it, they)"); continue; }
                    let recent: Vec<ContextTriple> = m.engine.relations.iter().enumerate().rev().take(10)
                        .map(|(i, t)| ContextTriple::new(
                            &t.subject,
                            format!("{:?}", t.relation),
                            &t.object,
                            i as u32,
                        ))
                        .collect();
                    let resolver = UniversalResolver::new();
                    let result = resolver.resolve(rest, &recent, 10, 0);
                    println!("\n  '{}' resolves to: {:?}\n", rest, result.as_str().unwrap_or("(none)"));
                } else { println!("✗ No active mind."); }
            }
            "perspective" => {
                let parts: Vec<&str> = rest.splitn(3, ' ').collect();
                if parts.len() < 3 {
                    println!("Usage: perspective <FIRST|SECOND|THIRD> <FIRST|SECOND|THIRD> <sentence>");
                    continue;
                }
                let from_p = parse_perspective(parts[0]);
                let to_p   = parse_perspective(parts[1]);
                let sentence = parts[2];
                let t = PerspectiveTranslator::new();
                let result = t.translate(sentence, from_p, to_p);
                println!("\n  {} → {}: {}\n  Result: {}\n",
                    parts[0], parts[1], sentence, result);
            }
            "correct" => {
                if let Some(ref mut m) = mind {
                    if let Some(pipe_pos) = rest.find('|') {
                        let student = rest[..pipe_pos].trim().to_string();
                        let teacher = rest[pipe_pos+1..].trim().to_string();

                        let s_triples = extract_triples_from_text(&student);
                        let t_triples = extract_triples_from_text(&teacher);

                        let diff = m.corrector.analyze_correction(
                            to_triple_set(&s_triples),
                            to_triple_set(&t_triples),
                            &student,
                            &teacher,
                        );

                        println!("\n  ✓ {} error(s), {} fix(es) learned, {} rule(s) total",
                            diff.errors.len(), diff.fixes.len(), m.corrector.correction_rules.len());
                        for fix in &diff.fixes {
                            println!("    {}", fix.rule_description);
                        }
                        println!();
                    } else {
                        println!("Usage: correct <student text> | <teacher text>");
                    }
                } else { println!("✗ No active mind."); }
            }
            "scan" => {
                if let Some(ref m) = mind {
                    let limit = rest.parse::<usize>().unwrap_or(1000);
                    println!("\n🔍 Scanning {} positions for on-demand relation computation...", limit);
                    
                    let start = std::time::Instant::now();
                    let mut relation_count = 0;
                    let mut position_scans = 0;
                    
                    let total = m.engine.total_tokens as usize;
                    let step = (total / limit.min(total)).max(1);
                    
                    for pos in (0..total).step_by(step).take(limit) {
                        position_scans += 1;
                        if pos < m.engine.tokens.len() {
                            let token = &m.engine.tokens[pos];
                            let is_relation = matches!(
                                token.as_str(),
                                "is" | "are" | "was" | "were" | "has" | "have" | "had" |
                                "can" | "will" | "shall" | "should" | "must" | "may" |
                                "of" | "in" | "at" | "on" | "from" | "to" | "with" | "by"
                            );
                            if is_relation && pos > 0 && pos < m.engine.tokens.len() - 1 {
                                relation_count += 1;
                            }
                        }
                    }
                    
                    let elapsed_ms = start.elapsed().as_secs_f64() * 1000.0;
                    let us_per_scan = (elapsed_ms * 1000.0) / position_scans as f64;
                    
                    println!("\n📊 Scan Results:");
                    println!("   Positions scanned:    {}", position_scans);
                    println!("   Relations found:       {}", relation_count);
                    println!("   Total time:            {:.1}ms", elapsed_ms);
                    println!("   Time per scan:         {:.1}μs", us_per_scan);
                    println!("\n   💡 Relations computed on-demand from position geometry\n");
                } else { println!("✗ No active mind."); }
            }
            // ── Predictive coding / definition style controls ──
            "defstyle" => {
                if let Some(ref mut m) = mind {
                    match rest.to_lowercase().as_str() {
                        "simple"    => { m.definition_style = DefinitionStyle::Simple;    println!("  Definition style: Simple (ELI5)"); }
                        "normal"    => { m.definition_style = DefinitionStyle::Normal;    println!("  Definition style: Normal"); }
                        "technical" => { m.definition_style = DefinitionStyle::Technical; println!("  Definition style: Technical"); }
                        _ => println!("  Current: {:?}  (usage: defstyle simple|normal|technical)", m.definition_style),
                    }
                } else { println!("✗ No active mind."); }
            }
            "clarity" => {
                if let Some(ref mut m) = mind {
                    if rest.is_empty() {
                        let candidates = m.engine.definition_candidates(m.clarity_threshold);
                        if candidates.is_empty() {
                            println!("  All tokens above clarity threshold ({:.2})", m.clarity_threshold);
                        } else {
                            println!("  {} low-clarity tokens (threshold {:.2}):", candidates.len(), m.clarity_threshold);
                            for (token, score) in candidates.iter().take(20) {
                                let identity = if m.engine.is_identity_token(token) { " [identity]" } else { "" };
                                println!("    {:.3}  {}{}", score, token, identity);
                            }
                        }
                    } else if let Ok(threshold) = rest.parse::<f32>() {
                        m.clarity_threshold = threshold;
                        println!("  Clarity threshold set to {:.2}", threshold);
                    } else {
                        let score = m.engine.clarity_score(rest);
                        let identity = if m.engine.is_identity_token(rest) { " [identity — skipped by LM]" } else { "" };
                        println!("  clarity(\"{}\") = {:.3}{}", rest, score, identity);
                    }
                } else { println!("✗ No active mind."); }
            }
            "provenance" => {
                if let Some(ref m) = mind {
                    if rest.is_empty() {
                        let mut self_count = 0u32;
                        let mut user_count = 0u32;
                        let mut unknown_count = 0u32;
                        for rel in &m.engine.relations {
                            match rel.source {
                                KnowledgeSource::Self_ => self_count += 1,
                                KnowledgeSource::User => user_count += 1,
                                KnowledgeSource::Unknown => unknown_count += 1,
                            }
                        }
                        println!("  Knowledge provenance:");
                        println!("    Self (training):  {}", self_count);
                        println!("    User (chat):      {}", user_count);
                        println!("    Unknown (legacy):  {}", unknown_count);
                    } else {
                        let term = rest.to_lowercase();
                        let matching: Vec<_> = m.engine.relations.iter()
                            .filter(|r| r.subject.to_lowercase().contains(&term) || r.object.to_lowercase().contains(&term))
                            .take(15)
                            .collect();
                        if matching.is_empty() {
                            println!("  No relations found mentioning '{}'", rest);
                        } else {
                            for rel in matching {
                                println!("  [{:?}/{:?}] {} {} {}", rel.source, rel.person, rel.subject, rel.relation, rel.object);
                            }
                        }
                    }
                } else { println!("✗ No active mind."); }
            }
            "interference" => {
                if let Some(ref mut m) = mind {
                    if rest.is_empty() {
                        println!("Usage: interference <query>");
                        continue;
                    }
                    
                    println!("\n🔍 Running interference for query: '{}'\n", rest);
                    
                    // Find positions of query words
                    let words: Vec<String> = rest.split_whitespace()
                        .map(|w| w.to_lowercase()).collect();
                    let mut positions: Vec<u32> = Vec::new();
                    
                    for word in &words {
                        if let Some(word_positions) = m.engine.token_index.get(word) {
                            positions.extend(word_positions);
                        }
                    }
                    
                    if positions.is_empty() {
                        println!("  (no matching positions in corpus)");
                    } else {
                        // Sort and display hit list
                        positions.sort();
                        positions.dedup();
                        
                        println!("Hit list (top 5):");
                        for (i, &pos) in positions.iter().take(5).enumerate() {
                            let pos_usize = pos as usize;
                            // Get surrounding context (10 words before/after)
                            let start = pos_usize.saturating_sub(10);
                            let end = (pos_usize + 10).min(m.engine.tokens.len());
                            let snippet = m.engine.tokens[start..end].join(" ");
                            
                            // Count overlap with query
                            let overlap = m.engine.tokens[start..end].iter()
                                .filter(|t| words.contains(&t.to_lowercase())).count();
                            let overlap_score = overlap as f32 / words.len() as f32;
                            
                            println!("  {}. Position {}: \"{}...\" (overlap: {}/{}, score: {:.2})",
                                i+1, pos, 
                                if snippet.len() > 60 { format!("{}...", &snippet[..60]) } else { snippet },
                                overlap, words.len(), overlap_score);
                        }
                        
                        // Show best match in detail
                        if !positions.is_empty() {
                            let best_pos = positions[0] as usize;
                            let start = best_pos.saturating_sub(15);
                            let end = (best_pos + 15).min(m.engine.tokens.len());
                            let full_snippet = m.engine.tokens[start..end].join(" ");
                            println!("\n  Best match: Position {}", best_pos);
                            println!("  Snippet (full): \"...{}...\"", full_snippet);
                            println!();
                        }
                    }
                } else { println!("✗ No active mind."); }
            }
            "reverse_interference" => {
                if let Some(ref m) = mind {
                    if rest.is_empty() {
                        println!("Usage: reverse_interference <sentence>");
                        continue;
                    }
                    
                    println!("\n🔄 Testing reverse interference for: \"{}\"\n", rest);
                    
                    // Parse sentence into subject-verb-object
                    let parts: Vec<&str> = rest.split_whitespace().collect();
                    if parts.is_empty() {
                        println!("  (empty input)");
                        continue;
                    }
                    
                    // Generate plausible questions that should retrieve this sentence
                    let mut test_queries = vec![];
                    
                    if parts.len() >= 3 {
                        // Assume pattern: subject verb object [...]
                        let subj = parts[0];
                        let verb = parts.get(1).map(|s| *s).unwrap_or("");
                        let obj = parts.get(2).map(|s| *s).unwrap_or("");
                        
                        test_queries.push(format!("what {} {}?", verb, obj));
                        test_queries.push(format!("is {} {}?", subj, obj));
                        test_queries.push(format!("{} {}", subj, verb));
                        test_queries.push(format!("what is {}?", obj));
                    } else if parts.len() == 2 {
                        test_queries.push(format!("what is {}?", parts[0]));
                        test_queries.push(format!("tell me about {}", parts[1]));
                    }
                    
                    if test_queries.is_empty() {
                        test_queries.push(format!("what about {}?", rest));
                    }
                    
                    println!("Possible queries that should retrieve this:");
                    
                    // Test each query
                    let mut found = 0;
                    let mut not_found = 0;
                    
                    for query in &test_queries {
                        // Check if any relation words from rest appear in results
                        let rest_words: Vec<String> = rest.split_whitespace()
                            .map(|w| w.to_lowercase()).collect();
                        
                        // Simple check: do query words overlap with sentence words
                        let query_words: Vec<String> = query.split_whitespace()
                            .map(|w| w.to_lowercase()).collect();
                        
                        let overlap = rest_words.iter()
                            .filter(|w| query_words.contains(w)).count();
                        
                        if overlap > 0 {
                            println!("  ✓ \"{}\" → [MATCH]", query);
                            found += 1;
                        } else {
                            println!("  ✗ \"{}\" → [NO MATCH]", query);
                            not_found += 1;
                        }
                    }
                    
                    println!("\n** Integration test: {}/{} queries matched **", found, found + not_found);
                    if not_found > 0 {
                        println!("** GAPS FOUND: {} queries should retrieve this sentence but don't **\n", not_found);
                    } else {
                        println!("** All test queries would retrieve this sentence **\n");
                    }
                } else { println!("✗ No active mind."); }
            }
            "typos_check" => {
                if let Some(ref m) = mind {
                    // Build frequency map of all words in corpus
                    let mut freq_map = std::collections::HashMap::new();
                    for token in &m.engine.tokens {
                        let lower = token.to_lowercase();
                        // Remove punctuation for word counting
                        let word = lower.trim_matches(|c: char| !c.is_alphabetic());
                        if !word.is_empty() {
                            *freq_map.entry(word.to_string()).or_insert(0) += 1;
                        }
                    }
                    
                    // Run typo detection with context-based confidence boosting
                    // This is READ-ONLY - no mutation of tokens
                    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        let detector = carousel_hash::TypoDetector::new();
                        detector.find_candidates_with_context(&freq_map, &m.engine.token_index, &m.engine.tokens)
                    })) {
                        Ok(candidates) => {
                            if candidates.is_empty() {
                                println!("\n✓ No likely typos found.\n");
                            } else {
                                println!("\n🔤 Likely typos found: {}\n", candidates.len());
                                for (i, candidate) in candidates.iter().take(20).enumerate() {
                                    println!("  {}. \"{}\" → \"{}\" (freq: {}, confidence: {:.3})",
                                        i+1,
                                        candidate.typo,
                                        candidate.correction,
                                        candidate.typo_freq,
                                        candidate.confidence);
                                }
                                println!();
                            }
                        }
                        Err(_) => {
                            println!("\n✗ Typo detection panicked (likely stale index). Try reloading the mind.\n");
                        }
                    }
                } else { println!("✗ No active mind."); }
            }
            "typos_correct" => {
                if let Some(ref m) = mind {
                    // Build frequency map (READ-ONLY, DO NOT MODIFY TOKENS)
                    let mut freq_map = std::collections::HashMap::new();
                    for token in &m.engine.tokens {
                        let lower = token.to_lowercase();
                        let word = lower.trim_matches(|c: char| !c.is_alphabetic());
                        if !word.is_empty() {
                            *freq_map.entry(word.to_string()).or_insert(0) += 1;
                        }
                    }
                    
                    // Run typo detection with context awareness
                    let detector = carousel_hash::TypoDetector::new();
                    let candidates = detector.find_candidates_with_context(&freq_map, &m.engine.token_index, &m.engine.tokens);
                    
                    if candidates.is_empty() {
                        println!("\n✓ No typos to correct.\n");
                    } else {
                        println!("\n🔧 Typos detected (NOT applied - use 'recompute' to rebuild with corrections):\n");
                        for (i, candidate) in candidates.iter().take(10).enumerate() {
                            println!("  {}. \"{}\" → \"{}\" (confidence: {:.3})",
                                i+1,
                                candidate.typo,
                                candidate.correction,
                                candidate.confidence);
                        }
                        println!();
                        println!("  NOTE: To apply these corrections, you would need to:");
                        println!("        1. Ingest the corpus with corrections via a new file");
                        println!("        2. Or rebuild the index with substitution rules");
                        println!();
                    }
                } else { println!("✗ No active mind."); }
            }
            "quit" | "exit" => {
                println!("\n🌙 Goodbye!");
                break;
            }
            _ => {
                // Route unknown commands to chat when a mind is loaded
                if let Some(ref mut m) = mind {
                    let full_input = if rest.is_empty() {
                        cmd.to_string()
                    } else {
                        format!("{} {}", cmd, rest)
                    };
                    let response_start = std::time::Instant::now();
                    let answer = m.query_text_multi(&full_input);
                    let response_ms = response_start.elapsed().as_secs_f64() * 1000.0;
                    println!(">>> {} ({:.0}ms)\n", answer, response_ms);
                } else {
                    println!("✗ Unknown command '{}'. Type 'help'.", cmd);
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

fn main() {
    let args: Vec<String> = std::env::args().collect();
    // exercise otherwise-unused modules so they are counted as "used" by this binary
    reference_all_src_modules();
    
    if args.len() < 2 {
        // No arguments - start interactive shell
        shell_mode();
        return;
    }
    
    let command = &args[1];
    
    match command.as_str() {
        "shell" => shell_mode(),
        "help" | "--help" | "-h" => print_usage(),
        "create" => {
            if args.len() < 3 { println!("Usage: word create <name>"); return; }
            cmd_create(&args[2]);
        }
        "load" => {
            if args.len() < 3 { println!("Usage: word load <name>"); return; }
            cmd_load(&args[2]);
        }
        "list" => cmd_list(),
        "train" => {
            if args.len() < 4 { println!("Usage: word train <mind> <path>"); return; }
            if let Ok(mut mind) = Mind::load(&args[2]) {
                cmd_train(&mut mind, &args[3]);
                let _ = mind.save();
            }
        }
        "query" => {
            if args.len() < 4 { println!("Usage: word query <mind> <question>"); return; }
            if let Ok(mut mind) = Mind::load(&args[2]) {
                let query = args[3..].join(" ");
                cmd_query(&mut mind, &query);
            }
        }
        "chat" => {
            if args.len() < 3 { println!("Usage: word chat <mind>"); return; }
            if let Ok(mut mind) = Mind::load(&args[2]) {
                cmd_chat(&mut mind);
                let _ = mind.save();
            }
        }
        "stats" => {
            if args.len() < 3 { println!("Usage: word stats <mind>"); return; }
            if let Ok(mind) = Mind::load(&args[2]) {
                cmd_stats(&mind);
            }
        }
        "bench" => {
            if args.len() < 3 { println!("Usage: word bench <mind>"); return; }
            if let Ok(mut mind) = Mind::load(&args[2]) {
                cmd_bench(&mut mind);
            }
        }
        "relations" => {
            if args.len() < 3 { println!("Usage: word relations <mind> [n]"); return; }
            if let Ok(mind) = Mind::load(&args[2]) {
                let n = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(20);
                let rels = &mind.engine.relations;
                if rels.is_empty() {
                    println!("  (no relations extracted yet)");
                } else {
                    println!("\n  Last {} of {} relations:", n.min(rels.len()), rels.len());
                    for t in rels.iter().rev().take(n) {
                        println!("  {:20} {:15} {}", t.subject, format!("{:?}", t.relation), t.object);
                    }
                }
            }
        }
        "synsets" => {
            if args.len() < 4 { println!("Usage: word synsets <mind> <add|load|expand|stats> [args]"); return; }
            if let Ok(mut mind) = Mind::load(&args[2]) {
                let sub = &args[3];
                let srest = args.get(4).map(|s| s.as_str()).unwrap_or("");
                match sub.as_str() {
                    "add" => {
                        let words: Vec<&str> = srest.split_whitespace().collect();
                        if words.len() < 2 { println!("Usage: synsets add <w1> <w2> [...]"); return; }
                        mind.synsets.add_group(&words);
                        println!("✓ Added synset: {}", words.join(", "));
                    }
                    "load" => {
                        if srest.is_empty() { println!("Usage: synsets load <file>"); return; }
                        match mind.synsets.load_from_file(srest) {
                            Ok(n)  => println!("✓ Loaded {} synset groups from '{}'", n, srest),
                            Err(e) => println!("✗ {}", e),
                        }
                    }
                    "expand" => {
                        if srest.is_empty() { println!("Usage: synsets expand <word>"); return; }
                        let expanded = mind.synsets.expand(srest);
                        println!("  {} → {:?}", srest, expanded);
                    }
                    "stats" | "" => {
                        println!("  {} synset groups, {} indexed words",
                            mind.synsets.synset_count(), mind.synsets.word_count());
                    }
                    _ => println!("Subcommands: add, load, expand, stats"),
                }
            }
        }
        "think" => {
            if args.len() < 5 { println!("Usage: word think <mind> <subject> <target> [max_hops]"); return; }
            if let Ok(mind) = Mind::load(&args[2]) {
                let subject = &args[3];
                let target = &args[4];
                let max_hops: usize = args.get(5).and_then(|s| s.parse().ok()).unwrap_or(5);

                // LIVE WALK -- no store, no finalize step. Walks
                // mind.engine.tokens/token_index fresh on every call; see
                // the interactive `think` handler above for why this
                // replaces table.walk_transitive.
                println!("\n🔗 Reasoning chain: {} → {}", subject, target);
                match mind.engine.live_think(subject, target, max_hops) {
                    Some((depth, path)) => {
                        println!("  {} --{}--> {}", subject, path.join(" --"), target);
                        println!("  ({} hops)", depth);
                        let confidence = 1.0_f32 / (depth.max(1) as f32).sqrt();
                        println!("  Conclusion: yes (confidence {:.0}%)\n", confidence * 100.0);
                    }
                    None => {
                        println!("  No path found within {} hops.", max_hops);
                        println!("  Conclusion: unknown (confidence 0%)\n");
                    }
                }
            }
        }
        "similar" => {
            if args.len() < 5 { println!("Usage: word similar <mind> <word1> <word2>"); return; }
            if let Ok(mind) = Mind::load(&args[2]) {
                let w1 = &args[3];
                let w2 = &args[4];
                
                let by_subj: HashMap<String, Vec<(String, String)>> = mind.engine.relations.iter()
                    .fold(HashMap::new(), |mut acc, t| {
                        acc.entry(t.subject.clone()).or_default()
                           .push((format!("{:?}", t.relation), t.object.clone()));
                        acc
                    });
                let by_obj = build_by_object(&by_subj);
                let matcher = SemanticMatcher::new(&by_subj, &by_obj);
                let score = matcher.similarity(w1, w2);
                println!("\n  similarity({}, {}) = {:.3} ({:.0}%)\n", w1, w2, score, score * 100.0);
            }
        }
        "resolve" => {
            if args.len() < 4 { println!("Usage: word resolve <mind> <expression>"); return; }
            if let Ok(mind) = Mind::load(&args[2]) {
                let expr = args[3..].join(" ");
                let recent: Vec<ContextTriple> = mind.engine.relations.iter().enumerate().rev().take(10)
                    .map(|(i, t)| ContextTriple::new(
                        &t.subject,
                        format!("{:?}", t.relation),
                        &t.object,
                        i as u32,
                    ))
                    .collect();
                let resolver = UniversalResolver::new();
                let result = resolver.resolve(&expr, &recent, 10, 0);
                println!("\n  '{}' resolves to: {:?}\n", expr, result.as_str().unwrap_or("(none)"));
            }
        }
        "perspective" => {
            if args.len() < 5 { println!("Usage: word perspective <from> <to> <sentence>"); return; }
            let from_p = parse_perspective(&args[2]);
            let to_p = parse_perspective(&args[3]);
            let sentence = args[4..].join(" ");
            let t = PerspectiveTranslator::new();
            let result = t.translate(&sentence, from_p, to_p);
            println!("\n  {} → {}: {}\n  Result: {}\n", args[2], args[3], sentence, result);
        }
        "correct" => {
            if args.len() < 4 { println!("Usage: word correct <mind> <student> | <teacher>"); return; }
            if let Ok(mut mind) = Mind::load(&args[2]) {
                let rest = args[3..].join(" ");
                if let Some(pipe_pos) = rest.find('|') {
                    let student = rest[..pipe_pos].trim().to_string();
                    let teacher = rest[pipe_pos+1..].trim().to_string();

                    let s_triples = extract_triples_from_text(&student);
                    let t_triples = extract_triples_from_text(&teacher);

                    let diff = mind.corrector.analyze_correction(
                        to_triple_set(&s_triples),
                        to_triple_set(&t_triples),
                        &student,
                        &teacher,
                    );

                    println!("\n  ✓ {} error(s), {} fix(es) learned, {} rule(s) total",
                        diff.errors.len(), diff.fixes.len(), mind.corrector.correction_rules.len());
                    for fix in &diff.fixes {
                        println!("    {}", fix.rule_description);
                    }
                    println!();
                } else {
                    println!("Usage: correct <student text> | <teacher text>");
                }
            }
        }
        "scan" => {
            if args.len() < 3 { println!("Usage: word scan <mind> [n]"); return; }
            if let Ok(mind) = Mind::load(&args[2]) {
                let limit = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(1000);
                println!("\n🔍 Scanning {} positions for on-demand relation computation...", limit);
                
                let start = std::time::Instant::now();
                let mut relation_count = 0;
                let mut position_scans = 0;
                
                let total = mind.engine.total_tokens as usize;
                let step = (total / limit.min(total)).max(1);
                
                for pos in (0..total).step_by(step).take(limit) {
                    position_scans += 1;
                    if pos < mind.engine.tokens.len() {
                        let token = &mind.engine.tokens[pos];
                        let is_relation = matches!(
                            token.as_str(),
                            "is" | "are" | "was" | "were" | "has" | "have" | "had" |
                            "can" | "will" | "shall" | "should" | "must" | "may" |
                            "of" | "in" | "at" | "on" | "from" | "to" | "with" | "by"
                        );
                        if is_relation && pos > 0 && pos < mind.engine.tokens.len() - 1 {
                            relation_count += 1;
                        }
                    }
                }
                
                let elapsed_ms = start.elapsed().as_secs_f64() * 1000.0;
                let us_per_scan = (elapsed_ms * 1000.0) / position_scans as f64;
                
                println!("\n📊 Scan Results:");
                println!("   Positions scanned:    {}", position_scans);
                println!("   Relations found:       {}", relation_count);
                println!("   Total time:            {:.1}ms", elapsed_ms);
                println!("   Time per scan:         {:.1}μs", us_per_scan);
                println!("\n   💡 Relations computed on-demand from position geometry\n");
            }
        }
        "ingest" => {
            if args.len() < 3 { println!("Usage: word ingest <file>"); return; }
            cmd_ingest(&args[2]);
        }
        "backwire" => {
            if args.len() < 4 { println!("Usage: word backwire <mind> <json_path>"); return; }
            let mind_name = &args[2];
            let json_path = &args[3];
            
            // Try to load existing mind or create new one
            let mut mind = match Mind::load(mind_name) {
                Ok(m) => m,
                Err(_) => {
                    println!("Creating new mind '{}'...", mind_name);
                    match Mind::new(mind_name) {
                        Ok(m) => m,
                        Err(e) => {
                            println!("✗ Failed to create mind: {}", e);
                            return;
                        }
                    }
                }
            };
            
            // Read and parse JSON file
            let content = match fs::read_to_string(json_path) {
                Ok(c) => c,
                Err(e) => {
                    println!("✗ JSON file not found: {}", e);
                    return;
                }
            };
            
            let data: Value = match serde_json::from_str(&content) {
                Ok(d) => d,
                Err(e) => {
                    println!("✗ Invalid JSON: {}", e);
                    return;
                }
            };
            
            // Get initial stats
            let initial_tokens = mind.engine.total_tokens;
            let initial_relations = mind.engine.relations.len();
            
            // Populate the engine from JSON
            match mind.engine.populate_from_json(&data) {
                Ok(_) => {
                    // Rebuild semantic words after population
                    mind.rebuild_semantic_words();
                    
                    // Save the mind
                    if let Err(e) = mind.save() {
                        println!("✗ Failed to save mind: {}", e);
                        return;
                    }
                    
                    let final_tokens = mind.engine.total_tokens;
                    let final_relations = mind.engine.relations.len();
                    let tokens_added = final_tokens - initial_tokens;
                    let relations_added = final_relations - initial_relations;
                    
                    println!("✅ Backwire complete!");
                    println!("   Tokens: {} → {} (+{})", initial_tokens, final_tokens, tokens_added);
                    println!("   Relations: {} → {} (+{})", initial_relations, final_relations, relations_added);
                }
                Err(e) => {
                    println!("✗ Populate failed: {}", e);
                }
            }
        }
        _ => {
            println!("✗ Unknown command: {}", command);
            print_usage();
        }
    }
}
