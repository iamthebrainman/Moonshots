// WORD Engine Core - Rust Implementation
// Port of Python TheWordEngine to native Rust

use std::collections::{HashMap, HashSet};
use std::time::Instant;
use lazy_static::lazy_static;
use regex::Regex;
use serde_json::Value;
use crate::table::HashTable24;
use crate::dada_engine::{DadaEngine, RelationalTriple, KnowledgeSource, PersonPerspective};
use crate::compositional_relations::RelationExtractor;
use crate::crsl_loader;
use crate::word_engine_persistence;
use crate::adaptive_dada::AdaptiveDadaEngine;
use crate::lexer::{Lexer, TokKind};
use crate::superposition_decoder::{SuperpositionDecoder, pack_slot};
use crate::morph;

/// Synthesis method for context-aware response generation
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum SynthesisMethod {
    Definition,      // "what is", "what's" - definitional responses
    Process,         // "what do", "what does" - procedural explanations
    Capability,      // "what can", "can" - ability/permission responses
    Location,        // "where" - spatial/positional responses
    Identity,        // "who" - personal/entity identification
    Temporal,        // "when" - time-based responses
    Causal,          // "why" - reason/cause explanations
    Method,          // "how" - method/process explanations
    Quantitative,    // "how many", "how much" - numerical responses
    Instructional,   // "how to", "how do" - step-by-step guidance
    Personal,        // "what is my name", "who am i" - personal information
    Comparative,     // "how similar", comparisons
    Sequential,      // "path" - step-by-step chains
    Refusal,         // "won't", "will not" - refusal responses
    Inability,       // "can't", "cannot" - inability responses
    Disapproval,     // "shouldn't" - disapproval/caution responses
    Negation,        // "don't", "doesn't" - negative responses
    Correction,      // "no", "not" - corrective responses
    General,         // Default fallback
}

// Cached regex patterns for pronoun translation - compiled once, reused forever
lazy_static! {
    static ref PRONOUN_REGEXES: Vec<(Regex, &'static str)> = vec![
        (Regex::new(r"\bYou\s+are\b").unwrap(), "I am"),
        (Regex::new(r"\byou\s+are\b").unwrap(), "i am"),
        (Regex::new(r"\bYou\s+have\b").unwrap(), "I have"),
        (Regex::new(r"\byou\s+have\b").unwrap(), "i have"),
        (Regex::new(r"\bYou\s+can\b").unwrap(), "I can"),
        (Regex::new(r"\byou\s+can\b").unwrap(), "i can"),
        (Regex::new(r"\bYou\s+will\b").unwrap(), "I will"),
        (Regex::new(r"\byou\s+will\b").unwrap(), "i will"),
        (Regex::new(r"\bYou\s+need\b").unwrap(), "I need"),
        (Regex::new(r"\byou\s+need\b").unwrap(), "i need"),
        (Regex::new(r"\bYou\s+should\b").unwrap(), "I should"),
        (Regex::new(r"\byou\s+should\b").unwrap(), "i should"),
        (Regex::new(r"\bYou\s+must\b").unwrap(), "I must"),
        (Regex::new(r"\byou\s+must\b").unwrap(), "i must"),
        (Regex::new(r"\bYou\s+want\b").unwrap(), "I want"),
        (Regex::new(r"\byou\s+want\b").unwrap(), "i want"),
        (Regex::new(r"\bYou\s+like\b").unwrap(), "I like"),
        (Regex::new(r"\byou\s+like\b").unwrap(), "i like"),
        (Regex::new(r"\bYou\s+were\b").unwrap(), "I was"),
        (Regex::new(r"\byou\s+were\b").unwrap(), "i was"),
        (Regex::new(r"\bYour\s+").unwrap(), "My "),
        (Regex::new(r"\byour\s+").unwrap(), "my "),
        (Regex::new(r"\bYours\b").unwrap(), "Mine"),
        (Regex::new(r"\byours\b").unwrap(), "mine"),
        (Regex::new(r"\bwith\s+you\b").unwrap(), "with me"),
        (Regex::new(r"\bto\s+you\b").unwrap(), "to me"),
        (Regex::new(r"\bfrom\s+you\b").unwrap(), "from me"),
        (Regex::new(r"\bfor\s+you\b").unwrap(), "for me"),
        (Regex::new(r"\bat\s+you\b").unwrap(), "at me"),
        (Regex::new(r"\bby\s+you\b").unwrap(), "by me"),
        (Regex::new(r"\babout\s+you\b").unwrap(), "about me"),
        (Regex::new(r"\bI\s+am\b").unwrap(), "you are"),
        (Regex::new(r"\bi\s+am\b").unwrap(), "you are"),
        (Regex::new(r"\bI\s+have\b").unwrap(), "you have"),
        (Regex::new(r"\bi\s+have\b").unwrap(), "you have"),
        (Regex::new(r"\bI\s+can\b").unwrap(), "you can"),
        (Regex::new(r"\bi\s+can\b").unwrap(), "you can"),
        (Regex::new(r"\bI\s+will\b").unwrap(), "you will"),
        (Regex::new(r"\bi\s+will\b").unwrap(), "you will"),
        (Regex::new(r"\bI\s+need\b").unwrap(), "you need"),
        (Regex::new(r"\bi\s+need\b").unwrap(), "you need"),
        (Regex::new(r"\bI\s+should\b").unwrap(), "you should"),
        (Regex::new(r"\bi\s+should\b").unwrap(), "you should"),
        (Regex::new(r"\bI\s+must\b").unwrap(), "you must"),
        (Regex::new(r"\bi\s+must\b").unwrap(), "you must"),
        (Regex::new(r"\bI\s+want\b").unwrap(), "you want"),
        (Regex::new(r"\bi\s+want\b").unwrap(), "you want"),
        (Regex::new(r"\bI\s+like\b").unwrap(), "you like"),
        (Regex::new(r"\bi\s+like\b").unwrap(), "you like"),
        (Regex::new(r"\bI\s+was\b").unwrap(), "you were"),
        (Regex::new(r"\bi\s+was\b").unwrap(), "you were"),
        (Regex::new(r"\bMy\s+").unwrap(), "Your "),
        (Regex::new(r"\bmy\s+").unwrap(), "your "),
        (Regex::new(r"\bMine\b").unwrap(), "Yours"),
        (Regex::new(r"\bmine\b").unwrap(), "yours"),
        (Regex::new(r"\bwith\s+me\b").unwrap(), "with you"),
        (Regex::new(r"\bto\s+me\b").unwrap(), "to you"),
        (Regex::new(r"\bfrom\s+me\b").unwrap(), "from you"),
        (Regex::new(r"\bfor\s+me\b").unwrap(), "for you"),
        (Regex::new(r"\bat\s+me\b").unwrap(), "at you"),
        (Regex::new(r"\bby\s+me\b").unwrap(), "by you"),
        (Regex::new(r"\babout\s+me\b").unwrap(), "about you"),
    ];
}

/// Performance metrics tracking
#[derive(Debug, Default)]
pub struct Metrics {
    pub timings: HashMap<String, Vec<f64>>,
    pub counts: HashMap<String, u64>,
    start_times: HashMap<String, Instant>,
}

impl Metrics {
    pub fn start(&mut self, operation: &str) {
        self.start_times.insert(operation.to_string(), Instant::now());
    }
    
    pub fn stop(&mut self, operation: &str) -> f64 {
        if let Some(start) = self.start_times.remove(operation) {
            let duration_ms = start.elapsed().as_secs_f64() * 1000.0;
            self.timings.entry(operation.to_string())
                .or_default()
                .push(duration_ms);
            *self.counts.entry(operation.to_string()).or_default() += 1;
            duration_ms
        } else {
            0.0
        }
    }
    
    pub fn get_stats(&self, operation: &str) -> Option<MetricStats> {
        self.timings.get(operation).map(|times| {
            let total: f64 = times.iter().sum();
            let count = times.len();
            MetricStats {
                count,
                total,
                avg: total / count as f64,
                min: times.iter().copied().fold(f64::INFINITY, f64::min),
                max: times.iter().copied().fold(f64::NEG_INFINITY, f64::max),
            }
        })
    }
}

#[derive(Debug, Clone)]
pub struct MetricStats {
    pub count: usize,
    pub total: f64,
    pub avg: f64,
    pub min: f64,
    pub max: f64,
}

/// Who put a span of tokens on the tape. Distinct from `KnowledgeSource`
/// (which only distinguishes User vs. Self_/Unknown at the ingest-call
/// level): `Speaker` also separates the engine's own live chat responses
/// from bulk trained corpus, because they must rank differently at match
/// time -- an echoed answer shouldn't be able to outrank the source
/// material it was generated from (F2, "echo loop"). See
/// `WordEngine::speaker_spans` / `speaker_at`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Speaker {
    /// Something the user typed, in chat or via a correction.
    User,
    /// Something the engine itself generated and re-ingested (its own
    /// answers, echoed back into the tape as conversation history).
    SelfEngine,
    /// Bulk offline training/ingestion text -- first-person self-narrative
    /// or world knowledge fed in via `train`, not live conversation.
    Corpus,
}

impl Speaker {
    /// Encode for the .crsl v3 speaker-span section (persist.rs deals only
    /// in opaque bytes, not this type).
    pub fn to_u8(self) -> u8 {
        match self {
            Speaker::User => 0,
            Speaker::SelfEngine => 1,
            Speaker::Corpus => 2,
        }
    }

    /// Decode from the .crsl v3 speaker-span section. Unrecognized tags
    /// (a newer format read by older code, or a corrupt byte) fall back to
    /// `Corpus` -- the same permissive default `speaker_at` uses for
    /// untracked positions.
    pub fn from_u8(tag: u8) -> Speaker {
        match tag {
            0 => Speaker::User,
            1 => Speaker::SelfEngine,
            _ => Speaker::Corpus,
        }
    }
}

/// Relational triple with position and metadata
// Using RelationalTriple from dada_engine module

/// Interference field entry
#[derive(Debug, Clone)]
pub struct InterferenceEntry {
    pub amplitude: f32,
    pub distance: u32,
    pub source_positions: Vec<u32>,
}

/// Query result from WORD engine
#[derive(Debug, Clone)]
pub struct QueryResult {
    pub generated: String,
    pub source: String,
    pub method: Option<String>,
    pub facts: Vec<RelationalTriple>,
    pub variants: Option<Vec<String>>,
    pub timing_ms: f64,
}

/// Main WORD Engine struct - Rust port of Python TheWordEngine
pub struct WordEngine {
    // Core data structures
    pub table: HashTable24,
    pub metrics: Metrics,
    
    // Physics/Timeline (token positions) 
    pub tokens: Vec<String>,
    pub total_tokens: u32,
    pub token_index: HashMap<String, Vec<u32>>, // word -> positions
    pub window: usize,
    /// Provenance overlay on the tape: `(start, end, speaker)` half-open
    /// token-position ranges in ingest order, non-overlapping, covering the
    /// whole tape. Speaker is provenance, not content -- the tape itself is
    /// never rewritten to "fix" person; this is a parallel index answering
    /// "who said the token at position N" so voice-agreement checks (does
    /// this probe match something the USER said, vs. something from
    /// training/corpus, vs. the engine's own prior answers) can filter
    /// live_neighbors/cloze matches without touching self.tokens. Appended
    /// to on every ingest call; v1/v2 .crsl loads get one synthetic
    /// `Speaker::Corpus` span covering the whole restored tape for
    /// backward compatibility.
    pub speaker_spans: Vec<(u32, u32, Speaker)>,
    
    // Knowledge graph
    pub relations: Vec<RelationalTriple>,
    pub subject_index: HashMap<String, Vec<usize>>, // subject -> relation indices
    pub object_index: HashMap<String, Vec<usize>>,  // object -> relation indices
    
    // Interference field (GDA-style physics)
    pub interference_field: HashMap<u32, InterferenceEntry>, // position -> field
    pub phrase_fatigue: HashMap<String, f32>,
    pub synsets: HashMap<String, HashSet<String>>,
    
    // Intelligence engines  
    pub dada_engine: DadaEngine,
    pub relation_extractor: RelationExtractor,
    
    // Grammar patterns and function words
    pub determiners: HashSet<String>,
    pub operators: HashSet<String>,
    pub question_words: HashSet<String>,
    pub function_words: HashSet<String>,
    pub contractions: HashMap<String, String>,
    
    // Settings and flags
    pub invert_flag: bool,
    pub trace_mode: bool,
    pub auto_record_fatigue: bool,
    pub fatigue_decay_per_turn: f32,
    pub fatigue_increment_on_use: f32,
    pub turn_counter: u32,
    // Conversation context tracking for anaphora
    pub last_response: Option<String>,
    pub last_user_query: Option<String>,
    // Fibonacci slot geometry decoder (shared, zero-cost)
    pub slot_decoder: SuperpositionDecoder,
    // Guard against double-finalization
    pub finalized: bool,
    /// Radial hash query mode (Exact = standard behaviour; Cascade/Diffuse = "one bin over").
    /// Toggle with `engine.query_mode = QueryMode::Cascade { method: HashMethod::Tribonacci, radius: 1 }`.
    pub query_mode: crate::hash_methods::QueryMode,
    /// Reverse map: natural_hash_address → Vec<slot_index>.
    /// Built by `table.build_addr_index()` after load/ingest; used by `lookup_radial`
    /// to find genuine address-bucket neighbours (same semantics as bench7.rs ZoneIndex).
    pub addr_index: HashMap<u32, Vec<u32>>,
}

impl Default for WordEngine {
    fn default() -> Self {
        Self::new(8)
    }
}

impl WordEngine {
    /// Create new WORD engine with specified window size
    pub fn new(window: usize) -> Self {
        let mut engine = Self {
            table: HashTable24::new_sized(20), // 1M slots initially
            metrics: Metrics::default(),
            tokens: Vec::new(),
            total_tokens: 0,
            token_index: HashMap::new(),
            window,
            speaker_spans: Vec::new(),
            relations: Vec::new(),
            subject_index: HashMap::new(),
            object_index: HashMap::new(),
            interference_field: HashMap::new(),
            phrase_fatigue: HashMap::new(),
            synsets: HashMap::new(),
            dada_engine: DadaEngine::default(),
            relation_extractor: RelationExtractor::default(),
            determiners: HashSet::new(),
            operators: HashSet::new(),
            question_words: HashSet::new(),
            function_words: HashSet::new(),
            contractions: HashMap::new(),
            invert_flag: false,
            trace_mode: false,
            auto_record_fatigue: false,
            fatigue_decay_per_turn: 0.15,
            fatigue_increment_on_use: 1.0,
            turn_counter: 0,
            last_response: None,
            last_user_query: None,
            slot_decoder: SuperpositionDecoder::new(),
            finalized: false,
            query_mode: crate::hash_methods::QueryMode::exact(),
            addr_index: HashMap::new(),
        };
        
        engine.init_grammar_sets();
        engine.last_response = None;
        engine.last_user_query = None;
        engine
    }
    
    /// Initialize grammar sets and function words
    fn init_grammar_sets(&mut self) {
        // Determiners
        for word in ["a", "an", "the", "this", "that", "these", "those"] {
            self.determiners.insert(word.to_string());
        }
        
        // Operators/verbs - expand to include action verbs
        for word in ["is", "are", "am", "was", "were", "has", "have", "had", "does", "can", "creates", "makes", "likes", "jumps", "runs", "walks", "loves", "knows", "goes", "comes", "takes", "gives", "sees", "hears", "thinks", "says", "tells"] {
            self.operators.insert(word.to_string());
        }
        
        // Question words  
        for word in ["who", "what", "where", "when", "why", "how", "which"] {
            self.question_words.insert(word.to_string());
        }
        
        // Combine into function words
        self.function_words.extend(self.determiners.iter().cloned());
        self.function_words.extend(self.operators.iter().cloned());
        self.function_words.extend(self.question_words.iter().cloned());
        for word in ["of", "in", "on", "to", "for", "and", "or", "but", "it", "with", "as", "by", "at"] {
            self.function_words.insert(word.to_string());
        }
        
        // Contractions
        self.contractions.insert("what's".to_string(), "what is".to_string());
        self.contractions.insert("that's".to_string(), "that is".to_string());
        self.contractions.insert("it's".to_string(), "it is".to_string());
        
        // Negation contractions - critical for proper negation handling
        self.contractions.insert("isn't".to_string(), "is not".to_string());
        self.contractions.insert("wasn't".to_string(), "was not".to_string());
        self.contractions.insert("aren't".to_string(), "are not".to_string());
        self.contractions.insert("weren't".to_string(), "were not".to_string());
        self.contractions.insert("can't".to_string(), "cannot".to_string());
        self.contractions.insert("couldn't".to_string(), "could not".to_string());
        self.contractions.insert("won't".to_string(), "will not".to_string());
        self.contractions.insert("wouldn't".to_string(), "would not".to_string());
        self.contractions.insert("shouldn't".to_string(), "should not".to_string());
        self.contractions.insert("mustn't".to_string(), "must not".to_string());
        self.contractions.insert("don't".to_string(), "do not".to_string());
        self.contractions.insert("doesn't".to_string(), "does not".to_string());
        self.contractions.insert("didn't".to_string(), "did not".to_string());
        self.contractions.insert("haven't".to_string(), "have not".to_string());
        self.contractions.insert("hasn't".to_string(), "has not".to_string());
        self.contractions.insert("hadn't".to_string(), "had not".to_string());
        
        // Additional common contractions
        self.contractions.insert("i'm".to_string(), "i am".to_string());
        self.contractions.insert("you're".to_string(), "you are".to_string());
        self.contractions.insert("he's".to_string(), "he is".to_string());
        self.contractions.insert("she's".to_string(), "she is".to_string());
        self.contractions.insert("we're".to_string(), "we are".to_string());
        self.contractions.insert("they're".to_string(), "they are".to_string());
        self.contractions.insert("i've".to_string(), "i have".to_string());
        self.contractions.insert("you've".to_string(), "you have".to_string());
        self.contractions.insert("we've".to_string(), "we have".to_string());
        self.contractions.insert("they've".to_string(), "they have".to_string());
    }
    
    /// Normalize text: expand contractions, tokenize, classify mode
    pub fn normalize(&mut self, text: &str) -> (Vec<String>, Vec<String>, String) {
        self.metrics.start("normalize");
        
        // Expand contractions
        let mut expanded = text.to_string();
        for (contraction, expansion) in &self.contractions {
            expanded = expanded.replace(contraction, expansion);
        }
        
        // Simple tokenization (can be enhanced)
        let tokens: Vec<String> = expanded
            .to_lowercase()
            .split_whitespace()
            .map(|s| s.trim_matches(|c: char| c.is_ascii_punctuation() && c != '\''))
            .filter(|s| !s.is_empty())
            .map(String::from)
            .collect();
        
        let raw_tokens = tokens.clone(); // In real implementation, preserve original case
        
        // Classify mode based on content
        let mode = if text.contains('?') {
            "question"
        } else if self.question_words.iter().any(|w| tokens.contains(w)) {
            "query" 
        } else {
            "statement"
        }.to_string();
        
        self.metrics.stop("normalize");
        (tokens, raw_tokens, mode)
    }
    
    /// Ingest text: tokenize and store, then extract relations. Fast.
    /// Phase 1: tokens → hash table (ns-speed positional storage)
    /// Phase 2: relation extraction from sentence structure (post-ingest)
    ///
    /// Source defaults to Unknown for backward compatibility. Recorded as
    /// `Speaker::Corpus` -- untagged bulk text is treated as background
    /// knowledge, same as `ingest_as_self`.
    /// For provenance-tagged ingestion, use `ingest_as_self` or `ingest_as_user`.
    pub fn ingest(&mut self, text: &str) -> Result<(), String> {
        self.ingest_with_source(text, KnowledgeSource::Unknown, None, Speaker::Corpus, true)
    }

    /// Same as `ingest`, but skips the `addr_index` rebuild -- see
    /// `ingest_as_self_batch`'s doc comment for why and the calling
    /// contract (call `rebuild_addr_index()` once after the loop).
    pub fn ingest_batch(&mut self, text: &str) -> Result<(), String> {
        self.ingest_with_source(text, KnowledgeSource::Unknown, None, Speaker::Corpus, false)
    }

    /// Ingest as self-knowledge (offline training, first-person narrative).
    ///
    /// All extracted triples are tagged with `KnowledgeSource::Self_`, and
    /// the span is recorded as `Speaker::Corpus` -- this is the `train`
    /// path for bulk offline text, not a live engine response (see
    /// `ingest_as_engine_response` for that).
    /// Person perspective is auto-detected from pronouns:
    /// - "I am..." / "My name is..." → First person
    /// - "Dogs are..." → Third person
    pub fn ingest_as_self(&mut self, text: &str) -> Result<(), String> {
        let person = Self::detect_person(text);
        self.ingest_with_source(text, KnowledgeSource::Self_, Some(person), Speaker::Corpus, true)
    }

    /// Same as `ingest_as_self`, but skips the `addr_index` rebuild -- for
    /// bulk loaders calling this many times in a row (once per line/message
    /// of a training file). The caller MUST call `rebuild_addr_index()`
    /// once after the loop, or radial/cascade queries silently won't see
    /// any of the newly ingested words until something else triggers a
    /// rebuild. Plain `token_index`/`table.get_word` lookups are unaffected
    /// either way -- only `lookup_radial`'s cascade/diffuse modes read
    /// `addr_index`.
    pub fn ingest_as_self_batch(&mut self, text: &str) -> Result<(), String> {
        let person = Self::detect_person(text);
        self.ingest_with_source(text, KnowledgeSource::Self_, Some(person), Speaker::Corpus, false)
    }

    /// Ingest as user-told knowledge (chat, second-person corrections).
    ///
    /// All extracted triples are tagged with `KnowledgeSource::User`, and
    /// the span is recorded as `Speaker::User`.
    /// Person perspective is auto-detected:
    /// - "Your name is..." → Second person
    /// - "You are..." → Second person
    /// - World facts from user → Third person
    pub fn ingest_as_user(&mut self, text: &str) -> Result<(), String> {
        let person = Self::detect_person(text);
        self.ingest_with_source(text, KnowledgeSource::User, Some(person), Speaker::User, true)
    }

    /// Ingest the engine's OWN generated response, echoed back into the
    /// tape as conversation history. Tagged `Speaker::SelfEngine` --
    /// distinct from `Speaker::Corpus` -- so an answer can never outrank
    /// the trained material it was built from at match time (F2, "echo
    /// loop"). Uses `KnowledgeSource::Self_` for the (now largely
    /// vestigial) triple-tagging parameter, same as bulk self-ingest,
    /// since the only place that distinction now matters is the speaker
    /// span, not the KnowledgeSource.
    pub fn ingest_as_engine_response(&mut self, text: &str) -> Result<(), String> {
        self.ingest_with_source(text, KnowledgeSource::Self_, None, Speaker::SelfEngine, true)
    }

    /// Detect the grammatical person of a text for provenance tagging.
    fn detect_person(text: &str) -> PersonPerspective {
        let lower = text.to_lowercase();
        let words: Vec<&str> = lower.split_whitespace().collect();

        let first_person = ["i", "me", "my", "mine", "myself", "we", "us", "our"];
        let second_person = ["you", "your", "yours", "yourself"];

        for w in &words {
            let stripped = w.trim_matches(|c: char| !c.is_alphabetic());
            if first_person.contains(&stripped) { return PersonPerspective::First; }
            if second_person.contains(&stripped) { return PersonPerspective::Second; }
        }
        PersonPerspective::Third
    }

    /// Core ingest with explicit source and person tagging.
    ///
    /// `rebuild_index`: whether to rebuild `addr_index` (the radial-query
    /// reverse hash map) before returning. This is `build_addr_index()`'s
    /// full `O(table_size)` scan over every slot -- with a 1M+ slot table,
    /// paying that once per line of a training file is the actual
    /// remaining bottleneck now that Phase 2 extraction is gone (confirmed:
    /// a 6273-line file means 6273 full-table rescans). Interactive/chat
    /// call sites (one ingest per turn) should keep `true`. Bulk loaders
    /// doing many ingests back-to-back should pass `false` in the loop and
    /// call `rebuild_addr_index()` once when the loop finishes -- see
    /// `ingest_as_self_batch`.
    fn ingest_with_source(
        &mut self,
        text: &str,
        _source: KnowledgeSource,
        _person_override: Option<PersonPerspective>,
        speaker: Speaker,
        rebuild_index: bool,
    ) -> Result<(), String> {
        if text.trim().is_empty() {
            return Ok(());
        }

        self.metrics.start("ingest_total");

        // ── INGEST v2 ────────────────────────────────────────────────────
        // Lex the whole input in one pass, case intact. Two things changed
        // from the old per-sentence, lowercased-first path:
        //
        //   1. Case is preserved in `self.tokens` (the tape). The hash table
        //      (`self.table`) and `token_index` stay lowercase-keyed on
        //      purpose -- that's the existing case-insensitive lookup layer
        //      and nothing downstream needs it to change. Only the tape
        //      itself needed to stop destroying case, because the tape is
        //      what `read_hole` reads back out verbatim for an answer
        //      ("John" should come back "John", not "john"). Anywhere that
        //      matches a raw tape token against operators/function_words
        //      goes through tok_is_operator/tok_is_function_word instead of
        //      a bare `.contains()`, since those sets stay lowercase-only.
        //
        //   2. Boundary tokens (__PERIOD__, __COMMA__, __QMARK__, ...)
        //      survive into the tape instead of being discarded. The old
        //      code manually pre-split on '.'/'!'/'?'/'\n' *before* the
        //      lexer ever ran, which is exactly what threw the boundary
        //      characters away -- the lexer already emits proper Boundary
        //      tokens for all of '.','!','?',';',',','—',':' if it's given
        //      the chance to see them. So: no more manual pre-split, one
        //      lexer.lex() call on the whole text, and Boundary tokens go
        //      into self.tokens (not the hash table, not token_index --
        //      they're position markers, not searchable words). This is
        //      what lets read_hole/window scans stop at a real sentence
        //      edge instead of a heuristic token-count clamp.
        //
        // Per-sentence chunking had no other purpose here -- it only ever
        // existed to feed Phase 2's regex extractor one sentence at a time,
        // and Phase 2 is gone.
        let mut lexer = Lexer::new();
        let all_tokens = lexer.lex(text);

        let base_pos = self.total_tokens;
        for (i, tok) in all_tokens.iter().enumerate() {
            let position = base_pos + i as u32;
            self.tokens.push(tok.text.clone());

            if matches!(tok.kind, TokKind::Word) {
                self.table.insert_word(&tok.text.to_lowercase(), position as u64);
                if !self.tok_is_function_word(&tok.text) {
                    self.token_index.entry(tok.text.to_lowercase())
                        .or_default()
                        .push(position);
                }
            }
        }
        let mut ingested_len = all_tokens.len() as u32;

        // ── Utterance seal ──────────────────────────────────────────────
        // If this ingest call's text didn't end with punctuation (typical
        // for chat turns: "My name is John" or a bare "test"), the tape
        // would otherwise run this utterance directly into whatever the
        // NEXT ingest call appends -- which is exactly how "Your name is
        // John test zig is a programming language" happened: three
        // unrelated ingests fused into one unbroken run that read_hole
        // faithfully read across. Each ingest call is one utterance;
        // seal it with a synthetic __PERIOD__ so boundary-aware scans
        // (read_hole, first_content_word_after/before) stop at the edge
        // whether or not the speaker typed a period. Not indexed, not
        // hashed -- a pure position marker, same as lexer boundaries.
        let ends_with_boundary = all_tokens.last()
            .map(|t| matches!(t.kind, TokKind::Boundary))
            .unwrap_or(true);
        if !ends_with_boundary {
            self.tokens.push("__PERIOD__".to_string());
            ingested_len += 1;
        }
        self.total_tokens += ingested_len;

        // Provenance overlay: record who said this span. Adjacent spans
        // from the same speaker are merged so a long ingest doesn't
        // produce one entry per call.
        if !all_tokens.is_empty() {
            let span_end = self.total_tokens;
            match self.speaker_spans.last_mut() {
                Some((_, end, s)) if *end == base_pos && *s == speaker => {
                    *end = span_end;
                }
                _ => self.speaker_spans.push((base_pos, span_end, speaker)),
            }
        }

        // Phase 2 (regex relation extraction into self.relations) is
        // deliberately gone from ingest. That pass ran 30+ Regex::new
        // patterns from relations.rs per sentence and was train's actual
        // bottleneck -- and it pre-computed conclusions nobody had asked
        // for yet, into a store the query pipeline no longer reads for
        // its main recall paths (carousel_lookup / live_walk over
        // self.tokens+self.token_index cover those live now). Ingest is
        // back to just Phase 1: tokenize, position-index, done.
        //
        // `_person_override` is unused now that extraction is gone; kept
        // as a parameter so ingest_as_self / ingest_as_user callers don't
        // need to change, in case a typed ingest lane (self/user/comment/
        // string/trace/prose -- the IST classification discussed earlier)
        // wants it again later.

        // Rebuild addr_index so radial queries see new words immediately --
        // unless the caller is bulk-loading and will do this once at the
        // end instead (see `rebuild_index` doc comment above).
        if rebuild_index {
            self.rebuild_addr_index();
        }

        self.metrics.stop("ingest_total");
        Ok(())
    }

    /// Rebuild `addr_index`, the reverse `natural_hash_address -> slot`
    /// map radial/cascade queries use. `O(table_size)` -- scans every slot.
    /// Called automatically by the single-shot ingest methods; bulk loaders
    /// that pass `rebuild_index: false` in a loop must call this once after
    /// the loop so radial queries see the newly ingested words at all.
    pub fn rebuild_addr_index(&mut self) {
        self.addr_index = self.table.build_addr_index(self.query_mode.hash_method());
    }

    /// Rebuild the relation index from the already-populated token timeline.
    ///
    /// Called after loading a .crsl file: the token tape is restored from disk,
    /// but `relations`, `subject_index`, and `object_index` are ephemeral and
    /// must be re-derived. This runs Phase 2 (relation extraction + slot_val
    /// computation) without touching the hash table or timeline — those are
    /// already correct.
    ///
    /// The token tape is re-chunked into sentence windows (splitting on
    /// punctuation tokens), each window fed to the relation extractor, and
    /// resulting triples are indexed exactly as `ingest_with_source` does.
    pub fn rebuild_relations_from_tokens(&mut self) {
        // Clear any stale index state
        self.relations.clear();
        self.subject_index.clear();
        self.object_index.clear();
        // Reset finalization flag so re-finalization is allowed
        self.finalized = false;

        // Re-chunk the flat token tape into sentence-sized windows.
        // Sentence boundaries are punctuation tokens or implicit at 40-token
        // hard limit (avoids O(n²) worst-case on run-on text).
        // Collect all sentences first before mutably borrowing self for extraction.
        // These are the lexer's actual boundary-marker tokens now (ingest v2)
        // -- literal "." "!" "?" never appear in self.tokens anymore, they're
        // replaced by TokKind::Boundary markers at ingest time.
        let punct: &[&str] = &["__PERIOD__", "__BANG__", "__QMARK__", "__SEMICOLON__", "__COLON__", "__EMDASH__"];
        let mut sentences: Vec<Vec<String>> = Vec::new();
        let mut sentence_buf: Vec<String> = Vec::new();

        for token in self.tokens.clone() {
            let is_boundary = punct.contains(&token.as_str()) || sentence_buf.len() >= 40;
            if is_boundary {
                if !sentence_buf.is_empty() {
                    sentences.push(sentence_buf.clone());
                    sentence_buf.clear();
                }
                if !punct.contains(&token.as_str()) {
                    sentence_buf.push(token);
                }
            } else {
                sentence_buf.push(token);
            }
        }
        if !sentence_buf.is_empty() {
            sentences.push(sentence_buf);
        }

        for sentence in sentences {
            self.extract_and_index_sentence(&sentence, KnowledgeSource::Unknown, None);
        }
    }

    /// Rebuild the subject and object indices from the current relations list.
    /// Called after removing relations (e.g., to undo a rejected answer).
    pub fn rebuild_relation_indices(&mut self) {
        self.subject_index.clear();
        self.object_index.clear();

        for (idx, triple) in self.relations.iter().enumerate() {
            let subj_lower = triple.subject.to_lowercase();
            let obj_lower = triple.object.to_lowercase();
            
            self.subject_index.entry(subj_lower.clone()).or_default().push(idx);
            self.object_index.entry(obj_lower.clone()).or_default().push(idx);

            // Also index individual head nouns
            for tok in triple.subject.split_whitespace() {
                let key = tok.to_lowercase();
                if !key.is_empty() {
                    self.subject_index.entry(key).or_default().push(idx);
                }
            }
            for tok in triple.object.split_whitespace() {
                let key = tok.to_lowercase();
                if !key.is_empty() {
                    self.object_index.entry(key).or_default().push(idx);
                }
            }
        }
    }

    /// Extract relations from a token slice and push them into self.relations
    /// with full slot_val computation and subject/object indexing.
    /// Factored out of ingest_with_source so rebuild_relations_from_tokens
    /// can reuse exactly the same logic.
    fn extract_and_index_sentence(
        &mut self,
        tokens: &[String],
        source: KnowledgeSource,
        person_override: Option<PersonPerspective>,
    ) {
        let statements = self.relation_extractor.extract_from_tokens(tokens);
        for stmt in statements {
            let idx = self.relations.len();
            let person = person_override.unwrap_or_else(|| Self::detect_person(&tokens.join(" ")));

            let mut triple = RelationalTriple::with_provenance(
                stmt.subject.text(),
                stmt.relation.to_string(),
                stmt.object.text(),
                stmt.confidence,
                source,
                person,
            );

            // Classify IS-domain for this triple and attach to relation string
            // so downstream query can route by domain.
            // (Full VariantClassification available if Triple grows domain field — see EDIT_PLAN.md ARCH-3)
            {
                let triple_str = format!("{} {} {}",
                    stmt.subject.text(),
                    stmt.relation.to_string(),
                    stmt.object.text()
                );
                let triple_tokens: Vec<String> = triple_str
                 .split_whitespace()
                 .map(|s| s.to_lowercase())
                 .map(String::from)
                 .collect();

                if let Some(_c) = crate::relation_classifier::classify(&triple_tokens, &[], &[]) {
                    // TODO: once Triple gains `domain` field (EDIT_PLAN ARCH-3),
                    // assign: triple.domain = _c.variant.into();
                }
            }

            // Compute 10-bit Fibonacci slot geometry — same formula as ingest_with_source
            let a = (triple.subject.split_whitespace().count() as u8).min(31);
            let b = (triple.relation.split_whitespace().count() as u8).min(31);
            triple.slot_val = pack_slot(a, b);

            // Index by subject and object
            let subj_lower = triple.subject.to_lowercase();
            let obj_lower  = triple.object.to_lowercase();
            self.subject_index.entry(subj_lower.clone()).or_default().push(idx);
            self.object_index.entry(obj_lower.clone()).or_default().push(idx);

            // Also index individual head nouns
            for tok in triple.subject.split_whitespace() {
                let key = tok.to_lowercase();
                if !key.is_empty() { self.subject_index.entry(key).or_default().push(idx); }
            }
            for tok in triple.object.split_whitespace() {
                let key = tok.to_lowercase();
                if !key.is_empty() { self.object_index.entry(key).or_default().push(idx); }
            }

            self.dada_engine.learn_from_triple(&triple);
            self.relations.push(triple);
        }
    }

    /// Ingest an utterance coming from a *user* (speaker = human).
    ///
    /// Writes to the token stream exactly the way `train` does now --
    /// tokenize + position-index via `ingest_as_user`, nothing else. This
    /// used to also run a second, independent tokenize+regex-extract pass
    /// that canonicalized "your name is X" into a stored "(you IS X)"
    /// triple and demoted conflicting triples on corrective phrasing
    /// ("no, actually..."). Both of those were writing into `self.relations`,
    /// the store the rest of this file is moving away from, and they're
    /// gone now. What replaces them, at query time instead of write time:
    ///   - "your"/"you", "my"/"i" (and he/his, she/her, they/their) are
    ///     query-time aliases in `live_neighbors`, so a walk anchored on
    ///     "you" still finds a sentence phrased with "your".
    ///   - `live_neighbors` reads token positions most-recent-first, so a
    ///     later correction naturally outranks an earlier fact with no
    ///     demotion step needed -- recency is computed at read time.
    /// See `handle_verification` and the WH-Query "What is X" lookup in
    /// bin/word.rs for the callers that rely on this.
    pub fn ingest_user(&mut self, text: &str) -> Result<(), String> {
        self.ingest_as_user(text)
    }
    
    /// Store tokens in the hash table.
    /// Used by external callers (e.g. Mind's incremental ingest) that need
    /// to push individual token batches without running the full ingest pipeline.
    pub fn store_tokens_in_table(&mut self, tokens: &[String], base_pos: u32) -> Result<(), String> {
        for (i, token) in tokens.iter().enumerate() {
            let position = base_pos + i as u32;
            
            // Insert token in table
            let _index = self.table.insert_word(token, position as u64);
        }
        Ok(())
    }
    
    /// Phase 2: Build chain-threaded relation indexes after bulk ingestion.
    ///
    /// This is the critical step that wires relations into the hash table's
    /// intrusive linked lists, enabling O(1) + O(k) chain walks instead of
    /// O(n) Vec scans during query.
    ///
    /// Call this after all training data is ingested, before querying.
    pub fn finalize_relations(&mut self) {
        if self.finalized {
            eprintln!("⚠ finalize_relations() called twice — skipping (use rebuild_relations_from_tokens() to re-derive)");
            return;
        }
        self.finalized = true;
        
        let start = std::time::Instant::now();
        let mut threaded_count = 0;
        
        // Clear any existing relation chains (in case of re-finalization)
        // We keep the Vec but rebuild the hash table chains from it
        
        for rel in self.relations.iter() {
            // Map relation string to RelationType opcode
            let rel_type = Self::parse_relation_type(&rel.relation);
            
            // Insert into hash table with chain threading
            let rel_slot_idx = self.table.insert_relation(
                &rel.subject,
                rel_type,
                &rel.object,
                (rel.confidence * 255.0) as u8
            );
            
            // Update external indexes to point to table slot indices
            // (enables hybrid query: fast chain walks + external HashMap validation)
            let subj_lower = rel.subject.to_lowercase();
            let obj_lower = rel.object.to_lowercase();
            
            self.subject_index
                .entry(subj_lower)
                .or_default()
                .push(rel_slot_idx as usize);
                
            self.object_index
                .entry(obj_lower)
                .or_default()
                .push(rel_slot_idx as usize);
            
            threaded_count += 1;
        }
        
        let elapsed_ms = start.elapsed().as_secs_f64() * 1000.0;
        eprintln!("✓ Finalized {} relations into hash table chains ({:.1}ms)",
                 threaded_count, elapsed_ms);
        eprintln!("  Query path now uses O(1) chain walks instead of O(n) Vec scans");
    }
    
    /// Parse relation string to RelationType opcode
    #[allow(dead_code)]
    fn parse_relation_type(rel: &str) -> crate::table::RelationType {
        use crate::table::RelationType;
        
        let rel_lower = rel.to_lowercase();
        match rel_lower.as_str() {
            // Identity/isa
            s if s.contains("is a") || s == "isa" => RelationType::IS_A,
            s if s.contains("is") => RelationType::IS,
            
            // Possession
            s if s.contains("has") || s.contains("have") => RelationType::HAS,
            s if s.contains("own") || s.contains("possess") => RelationType::OWNS,
            s if s.contains("part of") || s.contains("part") => RelationType::PART_OF,
            
            // Location
            s if s.contains("in") || s.contains("inside") => RelationType::IS_IN,
            s if s.contains("at") => RelationType::IS_AT,
            s if s.contains("on") => RelationType::IS_ON,
            s if s.contains("near") || s.contains("by") => RelationType::IS_NEAR,
            
            // Action/capability
            s if s.contains("can") || s.contains("able") => RelationType::CAN,
            s if s.contains("does") || s.contains("do") => RelationType::DOES,
            s if s.contains("use") || s.contains("using") => RelationType::INSTRUMENT_FOR,
            s if s.contains("make") || s.contains("creates") => RelationType::MADE_OF,
            
            // Causality
            s if s.contains("cause") || s.contains("causes") => RelationType::CAUSES,
            s if s.contains("because") => RelationType::BECAUSE,
            s if s.contains("prevent") || s.contains("stop") || s.contains("stops") => RelationType::PREVENTS,
            s if s.contains("enable") || s.contains("allow") => RelationType::ENABLES,
            s if s.contains("require") || s.contains("need") => RelationType::REQUIRES,
            s if s.contains("from") || s.contains("comes from") => RelationType::DERIVED_FROM,
            s if s.contains("leads to") || s.contains("results in") => RelationType::EFFECT_OF,
            
            // Properties
            s if s.contains("like") || s.contains("similar") => RelationType::SIMILAR_TO,
            s if s.contains("different") || s.contains("unlike") => RelationType::IS_DIFFERENT_FROM,
            s if s.contains("opposite") => RelationType::OPPOSITE_OF,
            
            // Temporal
            s if s.contains("before") => RelationType::BEFORE,
            s if s.contains("after") => RelationType::AFTER,
            s if s.contains("during") => RelationType::DURING,
            
            // Association
            s if s.contains("with") || s.contains("and") => RelationType::ASSOCIATED_WITH,
            s if s.contains("for") => RelationType::PURPOSE_OF,
            s if s.contains("about") => RelationType::IS_DESCRIBED_BY,
            
            // Knowledge/mental
            s if s.contains("know") || s.contains("knows") => RelationType::KNOWS,
            s if s.contains("think") || s.contains("thinks") => RelationType::THINKS,
            s if s.contains("believe") => RelationType::BELIEVES,
            s if s.contains("want") || s.contains("wants") => RelationType::GOAL_OF,
            s if s.contains("need") || s.contains("needs") => RelationType::REASON_FOR,

            // IS-domain collapses
            s if s.contains("sometimes") => RelationType::IS_SOMETIMES,
            s if s.contains("normative") || s.contains("should be") => RelationType::IS_NORMATIVE,
            s if s.contains("when ") || s.contains("conditional") => RelationType::IS_CONDITIONAL,
            s if s.contains("described") || s.contains("attributed") => RelationType::IS_ATTRIBUTED,
            s if s.contains("qualified") => RelationType::IS_QUALIFIED,

            // Constraint operators
            s if s.contains("but") || s.contains("constraint") => RelationType::BUT,
            s if s.contains("despite") || s.contains("override") => RelationType::DESPITE,
            s if s.contains("unless") => RelationType::UNLESS,

            // Equivalence
            s if s.contains("or_synonym") || s.contains("synonym") => RelationType::OR_SYNONYM,

            // Emotional
            s if s.contains("feel") || s.contains("feels") => RelationType::FEELS,
            s if s.contains("fear") => RelationType::FEARS,
            s if s.contains("hope") => RelationType::HOPES,

            // Extended causal
            s if s.contains("leads to") || s.contains("lead to") => RelationType::LEADS_TO,
            s if s.contains("trigger") => RelationType::TRIGGERS,
            
            // Default: generic association
            _ => RelationType::RELATED_TO,
        }
    }
    
    /// Translate pronouns for proper perspective (simplified).
    /// Called during relation synthesis to flip pronouns before output.
    pub fn translate_pronouns(&self, text: &str) -> String {
        // Use pre-compiled, cached regex patterns for perspective flipping
        let mut result = text.to_string();
        for (regex, replacement) in PRONOUN_REGEXES.iter() {
            result = regex.replace_all(&result, *replacement).to_string();
        }
        result
    }
    
    /// COHERENT QUERY PIPELINE — semantic cluster guides all selection.
    ///
    /// Flow:
    ///   1. Normalize + extract content words
    ///   2. Expand via synsets + spelling correction → expanded_words
    ///   3. Build semantic cluster: expanded_words + 1-hop transitive neighbors
    ///   4. Gather candidates from all sources (relation index, carousel, interference, transitive)
    ///   5. Score each candidate by coherence (overlap with semantic cluster)
    ///   6. Filter low-coherence noise (< 0.1)
    ///   7. Sort by weight × coherence, synthesize top candidates
    ///
    /// Result: Every triple in the output semantically connects to the query.
    pub fn query(&mut self, input_text: &str) -> QueryResult {
        self.query_with_method(input_text, None)
    }

    /// COHERENT QUERY PIPELINE with synthesis method context
    /// Enhanced version that takes synthesis method context for more targeted responses
    pub fn query_with_method(&mut self, input_text: &str, synthesis_method: Option<SynthesisMethod>) -> QueryResult {
        self.metrics.start("query_total");
        self.advance_turn();

        // Resolve anaphora against the last response before any other processing
        let resolved_input = self.resolve_anaphora(input_text, self.last_response.as_deref());

        // ── 0. IS-variant classification (Illuminator pass) ──────────────
        // Classify how IS is being asserted before any other processing.
        // The VariantClassification drives pipeline routing decisions.
        {
            let query_tokens: Vec<String> = resolved_input
                .split_whitespace()
                .map(|s| s.to_lowercase())
                .map(String::from)
                .collect();

            // Build naive char spans (good enough for routing — exact spans
            // are only needed if callers need to slice source text).
            let mut offset = 0u32;
            let query_spans: Vec<(u32, u32)> = query_tokens.iter().map(|t| {
                let start = offset;
                let end   = offset + t.len() as u32;
                offset    = end + 1;
                (start, end)
            }).collect();

            // Materialize recent context for anaphoric chain reconstruction.
            // Pull the last 21 stored relations as ContextTriple proxies.
            // (21 covers the full Fibonacci window: 1,2,3,5,8,13,21)
            let recent_context: Vec<crate::universal_resolver::ContextTriple> = self
                .relations
                .iter()
                .rev()
                .take(21)
                .map(|t| crate::universal_resolver::ContextTriple {
                    subject:  t.subject.clone(),
                    relation: t.relation.clone(),
                    object:   t.object.clone(),
                    position: 0u32,
                    mods: Vec::new(),
                })
                .collect::<Vec<_>>()
                .into_iter()
                .rev()
                .collect();

            if let Some(classification) = crate::relation_classifier::classify(
                &query_tokens,
                &query_spans,
                &recent_context,
            ) {
                // Log the variant for tracing (remove in prod or gate behind a flag)
                eprintln!(
                    "[classifier] variant={:?} markers={:?} certainty={:.1} obligation={:.1}",
                    classification.variant,
                    classification.markers,
                    classification.conjugation.certainty,
                    classification.conjugation.obligation,
                );

                // Store for downstream use within this query turn.
                // TODO: thread `classification` into synthesis path to select
                // domain-specific response templates.
                let _classification = classification;
            }
        }

        // ── 1. Base token set ─────────────────────────────────────────────
        let (norm_tokens, _raw_tokens, _mode) = self.normalize(&resolved_input);
        let content_words: Vec<String> = norm_tokens.iter()
            .filter(|w| !self.function_words.contains(*w))
            .map(|w| w.trim_matches(|c: char| "?:!,.".contains(c)).to_string())
            .filter(|w| !w.is_empty())
            .collect();

        // Quick timeline-resolver for direct "is" style queries: prefer
        // the token-stream (recency) as source-of-truth and return early.
        if input_text.to_lowercase().contains(" is ") || input_text.to_lowercase().starts_with("what is") {
            if let Some(subject) = content_words.first() {
                if let Some(obj) = self.resolve_is_from_timeline(subject) {
                    let timing = self.metrics.stop("query_total");
                    let fact = RelationalTriple::new(subject.clone(), "is".to_string(), obj.clone(), 1.0);
                    return QueryResult {
                        generated: format!("{} is {}.", subject, obj),
                        source: "timeline_resolver".to_string(),
                        method: Some("timeline_is".to_string()),
                        facts: vec![fact],
                        variants: None,
                        timing_ms: timing,
                    };
                }
            }
        }

        if content_words.is_empty() {
            let timing = self.metrics.stop("query_total");
            return QueryResult {
                generated: "Could you rephrase that?".to_string(),
                source: "empty_query".to_string(),
                method: None,
                facts: vec![],
                variants: None,
                timing_ms: timing,
            };
        }

        // ── 2. Expand tokens (synsets + spelling correction) ──────────────
        let mut expanded_words = self.expand_query_tokens(&content_words);

        // ── 3. Build semantic cluster (expanded + 1-hop transitive) ───────
        let semantic_cluster = self.build_semantic_cluster(&expanded_words);

        // ── 4. Gather candidates (all sources) ────────────────────────────
        let mut pool: Vec<(RelationalTriple, f32)> = Vec::new();
        let mut source_tags: Vec<&str> = Vec::new();

        // Stage 1/2: Live pivot lookup (was: Stage 1 relation-index lookup
        // over self.relations, plus Stage 2 carousel_lookup as a fallback.
        // With no pre-extracted relation store, carousel_lookup's live
        // token-stream pivot scan is the primary recall path, not a
        // fallback -- weight bumped from 0.7 to 1.0 to reflect that.)
        {
            let before = pool.len();
            for triple in self.carousel_lookup(&expanded_words) {
                pool.push((triple, 1.0));
            }
            if pool.len() > before { source_tags.push("carousel"); }
        }

        // Stage 2.5: Radial hash expansion (Cascade / Diffuse modes)
        // ─────────────────────────────────────────────────────────────────
        // Uses the "one bin over" finding from bench7.rs: neighbouring hash
        // bins (especially Δ±1 with Tribonacci method 7) contain the words
        // that most often *continue* a given pivot word.  We probe those bins,
        // recover the words stored there, and inject them into `expanded_words`
        // so every later stage (Interference, Transitive) can use them.
        //
        // Guarded behind `query_mode.is_radial()` so QueryMode::Exact is a
        // zero-cost no-op — identical to pre-integration behaviour.
        if self.query_mode.is_radial() {
            let method = self.query_mode.hash_method();
            let chain_depth = self.query_mode.chain_depth;
            let probe_cap  = self.query_mode.probe_cap;
            let window     = self.query_mode.window;
            let radial_words = self.radial_hash_expand(&expanded_words, method, chain_depth, probe_cap, window);
            eprintln!("[radial] depth={} cap={} window={} seeds={:?} → neighbors={:?}",
                chain_depth, probe_cap, window, &expanded_words, &radial_words);
            if !radial_words.is_empty() {
                let before = pool.len();
                for w in &radial_words {
                    if !expanded_words.contains(w) {
                        expanded_words.push(w.clone());
                    }
                }
                // Live lookup for the radial-expanded neighbor words -- was
                // a self.relations subject/object_index pull, now the same
                // carousel_lookup pivot scan used everywhere else.
                let w = self.query_mode.relation_weight;
                for triple in self.carousel_lookup(&radial_words) {
                    pool.push((triple, w));
                }
                let added = pool.len() - before;
                eprintln!("[radial] injected {} neighbor words, +{} pool entries", radial_words.len(), added);
                if added > 0 { source_tags.push("radial_hash"); }
            } else {
                eprintln!("[radial] no neighbors found — table slots adjacent to seed words are empty or non-Word");
            }
        }

        // Stage 3: Interference
        {
            let mut positions: Vec<u32> = Vec::new();
            for word in &expanded_words {
                if let Some(ps) = self.token_index.get(word) {
                    positions.extend_from_slice(ps);
                }
            }
            if positions.len() >= 2 {
                if let Some(ipos) = self.find_interference_point(&positions) {
                    let w = self.window as u32;
                    let lo = ipos.saturating_sub(w) as usize;
                    let hi = (ipos + w).min(self.total_tokens) as usize;
                    if let Some(window_tokens) = self.tokens.get(lo..hi) {
                        let before = pool.len();
                        // Live lookup, scoped to the interfering window: was
                        // a self.relations subject/object_index pull keyed
                        // by window vocabulary, now carousel_lookup's pivot
                        // scan over that same vocabulary.
                        let window_words: Vec<String> = window_tokens.iter()
                            .filter(|tok| !self.tok_is_function_word(tok))
                            .cloned()
                            .collect();
                        for triple in self.carousel_lookup(&window_words) {
                            pool.push((triple, 0.5));
                        }
                        if pool.len() > before { source_tags.push("interference"); }
                    }
                }
            }
        }

        // Stage 4: Transitive chains -- live walk, was TransitiveReasoner
        // built fresh from self.relations on every call. live_walk does the
        // same BFS directly over the token stream instead, so there's no
        // adjacency map to rebuild and no self.relations dependency at all.
        if pool.len() < 5 {
            let before = pool.len();
            'chain_search: for i in 0..expanded_words.len().min(5) {
                for j in 0..expanded_words.len().min(5) {
                    if i == j { continue; }
                    let chain = match self.live_walk(&expanded_words[i], &expanded_words[j], 3) {
                        Some(c) if !c.is_empty() => c,
                        _ => continue,
                    };
                    let hop_n = chain.len() as f32;
                    for (k, (subj, rel, obj)) in chain.iter().enumerate() {
                        let w = 0.6 / (1.0 + k as f32) / hop_n.sqrt();
                        pool.push((RelationalTriple::new(
                            subj.clone(),
                            rel.clone(),
                            obj.clone(),
                            w,
                        ), w));
                    }
                    break 'chain_search;
                }
            }
            if pool.len() > before { source_tags.push("transitive"); }
        }

        // ── 5. Slot-geometry pre-rank (Fibonacci magnitude boost) ────────────
        // Before coherence scoring, multiply each candidate's weight by a
        // normalised magnitude score from the SuperpositionDecoder.
        // This ensures semantically heavy triples (longer subject phrases,
        // richer relation tokens) survive the coherence gate.
        // magnitude() is O(1) — just two table lookups.
        {
            // Find the max magnitude in the current pool so we can normalise
            // to [0.1, 1.0] without the absolute Fibonacci numbers dominating.
            let max_mag: u64 = pool.iter().map(|(t, _)| {
                if t.slot_val > 0 { self.slot_decoder.magnitude(t.slot_val) } else { 1 }
            }).max().unwrap_or(1).max(1);

            for (triple, weight) in &mut pool {
                if triple.slot_val == 0 {
                    // Legacy triple without geometry — small neutral boost
                    *weight *= 0.85;
                    continue;
                }
                let mag = self.slot_decoder.magnitude(triple.slot_val) as f64;
                // Normalise to [0.1, 1.0]: 0.1 + 0.9 * (mag / max_mag)
                let geo_score = 0.1 + 0.9 * (mag / max_mag as f64);
                *weight *= geo_score as f32;

                // Band similarity bonus: if the query-word band is close to this
                // triple's band, give a small extra boost (shared frequency zone).
                if !content_words.is_empty() {
                    // Use the first content word as a proxy for query band.
                    // We manufacture a query slot_val from its character count.
                    let qa = (content_words[0].len() as u8).min(31);
                    let qb = (content_words.len() as u8).min(31);
                    let query_slot = pack_slot(qa, qb);
                    let band_sim = self.slot_decoder.band_similarity(query_slot, triple.slot_val);
                    *weight *= 0.8 + 0.2 * band_sim as f32; // up to +20% band bonus
                }
            }
        }

        // ── 6. Score by coherence (must support multiple distinct query tokens) ─
        for (triple, weight) in &mut pool {
            let coherence = self.coherence_score(triple, &semantic_cluster, &content_words);
            *weight *= coherence;
        }// ── 7. Filter low-coherence noise ─────────────────────────────────
        pool.retain(|(_, w)| *w > 0.1);

        if pool.is_empty() {
            let timing = self.metrics.stop("query_total");
            return QueryResult {
                generated: Self::topic_acknowledgment(&content_words),
                source: "acknowledgment".to_string(),
                method: None,
                facts: vec![],
                variants: None,
                timing_ms: timing,
            };
        }

        // ── 8. Sort + synthesize ──────────────────────────────────────────
        pool.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        // Greedily select triples that *collectively* cover the query's content words
        let seed_set: std::collections::HashSet<String> = content_words.iter().map(|s| s.to_lowercase()).collect();
        let required_coverage = if seed_set.len() <= 2 { 1 } else { ((seed_set.len() as f32) * 0.6).ceil() as usize };

        let mut covered: std::collections::HashSet<String> = std::collections::HashSet::new();
        let mut selected: Vec<&RelationalTriple> = Vec::new();

        for (triple, _weight) in &pool {
            // tokens in triple
            let triple_tokens: std::collections::HashSet<String> = triple.subject.split_whitespace()
                .chain(triple.relation.split_whitespace())
                .chain(triple.object.split_whitespace())
                .map(|s| s.to_lowercase()).collect();

            // which seed words this triple would newly cover
            let newly: Vec<String> = seed_set.difference(&covered)
                .filter(|s| triple_tokens.contains(*s)).cloned().collect();

            if !newly.is_empty() {
                selected.push(triple);
                for n in newly { covered.insert(n); }
            }

            if covered.len() >= required_coverage || selected.len() >= 15 { break; }
        }

        // Fallback: if greedy selection found nothing, fall back to top-weight triple(s)
        let final_triples: Vec<RelationalTriple> = if selected.is_empty() {
            pool.iter().take(3).map(|(t, _)| t.clone()).collect()
        } else {
            selected.into_iter().map(|t| t.clone()).collect()
        };

        // Use DADA template system for proper response generation - NO FALLBACKS EVER
        let input_tokens: Vec<String> = content_words.iter().map(|s| s.to_lowercase()).collect();
        let mut bindings = std::collections::HashMap::new();
        
        // Add any relevant bindings from the query
        for (i, word) in content_words.iter().enumerate() {
            bindings.insert(i as u32, word.clone());
        }
        
        // ALWAYS use the learned dialogue graph templates - this is the primary method
        // Enhance synthesis with method context if provided
        let response = if let Some(method) = synthesis_method {
            self.dada_engine.synthesize_from_graph_with_method(&input_tokens, &bindings, method)
                .unwrap_or_else(|| {
                    // If graph synthesis returns None, try to construct something from available facts
                    if !final_triples.is_empty() {
                        let fact = &final_triples[0];
                        format!("{} {} {}.", fact.subject, fact.relation, fact.object)
                    } else {
                        Self::topic_acknowledgment(&content_words)
                    }
                })
        } else {
            self.dada_engine.synthesize_from_graph(&input_tokens, &bindings)
                .unwrap_or_else(|| {
                    // If graph synthesis returns None, try to construct something from available facts
                    if !final_triples.is_empty() {
                        let fact = &final_triples[0];
                        format!("{} {} {}.", fact.subject, fact.relation, fact.object)
                    } else {
                        Self::topic_acknowledgment(&content_words)
                    }
                })
        };
        // Post-process generated text: sentence-finalize (capitalize, punctuation)
        let finalized = Self::finalize_sentence(&response);

        // Track conversation context for anaphora resolution in subsequent turns
        self.last_response = Some(finalized.clone());
        self.last_user_query = Some(input_text.to_string());
        
        // Observe the user query and system response in the DADA conversation chain
        let user_tokens: Vec<String> = content_words.iter().map(|s| s.to_lowercase()).collect();
        let response_tokens: Vec<String> = finalized.split_whitespace().map(|s| s.to_string()).collect();
        
        // Learn from this conversation turn
        self.dada_engine.observe_turn(crate::dada_engine::Speaker::Human, &user_tokens);
        self.dada_engine.observe_turn(crate::dada_engine::Speaker::System, &response_tokens);

        let timing = self.metrics.stop("query_total");
        QueryResult {
            generated: finalized,
            source: source_tags.join("+"),
            method: Some("coherent_semantic".to_string()),
            facts: final_triples,
            variants: None,
            timing_ms: timing,
        }
    }

    /// Map terse relation tokens to human verbs (lowercase). Returns owned String.
    /// Used by Mind and external callers for human-readable output formatting.
    pub fn humanize_relation(&self, rel: &str) -> String {
        match rel.to_lowercase().as_str() {
            "is" | "isa" => "is".to_string(),
            "has" => "has".to_string(),
            "can" => "can".to_string(),
            "causes" | "cause" => "causes".to_string(),
            "prevents" | "prevent" => "prevents".to_string(),
            "enables" | "allow" | "allows" => "enables".to_string(),
            "requires" | "require" | "need" => "requires".to_string(),
            other => other.to_string(),
        }
    }

    /// Simple sentence finalizer: capitalize first alpha and ensure terminal punctuation.
    fn finalize_sentence(s: &str) -> String {
        if s.trim().is_empty() { return s.to_string(); }
        let mut out = s.trim().to_string();
        // Capitalize first alphabetical character
        if let Some(first) = out.chars().next() {
            if first.is_lowercase() {
                let mut chars = out.chars();
                chars.next();
                out = first.to_uppercase().collect::<String>() + chars.as_str();
            }
        }
        // Ensure punctuation at end
        if !matches!(out.chars().last().unwrap_or('.'), '.' | '!' | '?') {
            out.push('.');
        }
        out
    }

    /// Acknowledge user input by echoing back the main topic.
    /// If content_words is empty, fall back to "I understand."
    fn topic_acknowledgment(content_words: &[String]) -> String {
        if content_words.is_empty() {
            return "I understand.".to_string();
        }
        let topic = content_words
            .iter()
            .filter(|w| w.len() > 3)
            .next()
            .map(|w| w.as_str())
            .unwrap_or(content_words[0].as_str());
        format!("I understand you're asking about {}.", topic)
    }

    /// Simple anaphora resolver that rewrites leading deictic pronouns
    /// (`that`, `this`, `it`) to refer to the previous engine response
    /// when available. This prevents pronouns resolving to the last
    /// subject token in the timeline.
    /// Create a TransitiveReasoner over the current relation graph.
    /// This centralizes chain construction for use in queries, chain display, and reasoning.
    ///
    /// Note: Due to Rust lifetime restrictions, this builds a local adjacency list
    /// and returns a reasoner with static lifetime. For convenience, we keep it
    /// here for centralized chain construction.
    pub fn find_reasoning_chain(&self, start: &str, target: &str, max_depth: usize) -> Vec<crate::transitive_reasoner::ChainHop> {
        // Build outgoing adjacency list from relations
        let mut outgoing: std::collections::HashMap<String, Vec<(String, String)>> = std::collections::HashMap::new();
        
        for tr in &self.relations {
            let subj = tr.subject.to_lowercase();
            let rel = tr.relation.clone();
            let obj = tr.object.to_lowercase();
            
            outgoing
                .entry(subj)
                .or_insert_with(Vec::new)
                .push((rel, obj));
        }
        
        // Build and use reasoner
        let reasoner = crate::transitive_reasoner::TransitiveReasoner::new(&outgoing);
        reasoner.find_chain(start, target, max_depth)
    }

    /// Find all reasoning chains from start to target (up to max_depth hops).
    /// Returns sorted by length (shortest first).
    pub fn find_all_reasoning_chains(&self, start: &str, target: &str, max_depth: usize) -> Vec<Vec<crate::transitive_reasoner::ChainHop>> {
        // Build outgoing adjacency list from relations
        let mut outgoing: std::collections::HashMap<String, Vec<(String, String)>> = std::collections::HashMap::new();
        
        for tr in &self.relations {
            let subj = tr.subject.to_lowercase();
            let rel = tr.relation.clone();
            let obj = tr.object.to_lowercase();
            
            outgoing
                .entry(subj)
                .or_insert_with(Vec::new)
                .push((rel, obj));
        }
        
        // Build and use reasoner
        let reasoner = crate::transitive_reasoner::TransitiveReasoner::new(&outgoing);
        reasoner.find_all_chains(start, target, max_depth)
    }

    pub fn resolve_anaphora(&self, query: &str, last_response: Option<&str>) -> String {
        let tokens: Vec<&str> = query.split_whitespace().collect();
        if tokens.is_empty() { return query.to_string(); }

        let first = tokens[0].to_lowercase();
        match first.as_str() {
            "that" | "this" | "it" => {
                if let Some(prev) = last_response {
                    // Prefer a neutral referent ("response") rather than
                    // extracting content words like 'death' from the prior reply.
                    let referent = self.extract_main_subject(prev);
                    let rest = if tokens.len() > 1 { tokens[1..].join(" ") } else { String::new() };
                    if rest.is_empty() { return referent; }
                    return format!("{} {}", referent, rest);
                }
            }
            _ => {}
        }

        // Special-case short negation replies: "No" → attach last user query
        if query.trim().eq_ignore_ascii_case("no") {
            if let Some(last_q) = &self.last_user_query { return format!("no {}", last_q); }
        }

        // Secondary pass: resolve mid-sentence pronouns after a sentence boundary.
        // E.g. "The dog barks. It is loud." → "It" → main subject of last response.
        if let Some(prev) = last_response {
            let mut out = query.to_string();
            for pronoun in &["It is", "It was", "it is", "it was",
                             "This is", "That is", "this is", "that is"] {
                if out.contains(pronoun) {
                    let referent = self.extract_main_subject(prev);
                    if let Some(verb_pos) = pronoun.split_whitespace().nth(1) {
                        out = out.replacen(pronoun,
                            &format!("{} {}", referent, verb_pos),
                            1);
                    }
                }
            }
            if out != query { return out; }
        }

        query.to_string()
    }

    /// Heuristic to pick a neutral referent from the prior response.
    /// Returns a safe token such as "response" when no clear named
    /// entity exists to avoid mis-resolving to content words.
    fn extract_main_subject(&self, response: &str) -> String {
        // Look for an obvious title-cased token first
        for w in response.split_whitespace() {
            if w.chars().next().map(|c| c.is_uppercase()).unwrap_or(false) {
                return w.trim_matches(|c: char| c.is_ascii_punctuation()).to_string();
            }
        }

        // Fallback: return a neutral placeholder to represent the prior utterance
        "response".to_string()
    }

    /// Resolve identity/property (`is`) for `subject` using the token timeline
    /// as the source-of-truth. Strategy:
    /// - collect candidate triples where relation =~ "is"
    /// - score primarily by recency (latest token position of subject/object)
    /// - break ties by triple.confidence; if still tied, return None (ambiguous)
    pub fn resolve_is_from_timeline(&self, subject: &str) -> Option<String> {
        let subj_lower = subject.to_lowercase();

        // Collect candidates (subject match + relation contains "is")
        let mut candidates: Vec<(&crate::dada_engine::RelationalTriple, u32)> = Vec::new();
        for tr in &self.relations {
            // match subjects that *contain* the requested subject token (handles
            // leading determiners / discourse markers like "the", "now", etc.)
            let subj_l = tr.subject.to_lowercase();
            if !subj_l.split_whitespace().any(|t| t == subj_lower) { continue; }
            let rel_l = tr.relation.to_lowercase();
            if !rel_l.contains("is") { continue; }

            // Compute recency = max token position of subject/object words (if present)
            let mut recency: u32 = 0;
            for tok in tr.subject.split_whitespace().chain(tr.object.split_whitespace()) {
                let key = tok.to_lowercase();
                if let Some(poses) = self.token_index.get(&key) {
                    if let Some(&p) = poses.iter().max() { recency = recency.max(p); }
                }
            }

            candidates.push((tr, recency));
        }

        if candidates.is_empty() { return None; }

        // Pick highest recency, then highest confidence. Detect ties.
        candidates.sort_by(|a, b| {
            b.1.cmp(&a.1)
                .then_with(|| b.0.confidence.partial_cmp(&a.0.confidence).unwrap_or(std::cmp::Ordering::Equal))
        });

        let best_recency = candidates[0].1;
        let best_conf = candidates[0].0.confidence;

        // If top two are effectively tied on recency+confidence, treat as ambiguous
        let mut tied = 0usize;
        for (tr, rec) in &candidates {
            if *rec == best_recency && (tr.confidence - best_conf).abs() < 1e-6 {
                tied += 1;
            }
        }
        if tied > 1 { return None; }

        Some(candidates[0].0.object.clone())
    }

    /// Build semantic cluster: expanded words + synsets + 1-hop transitive neighbors.
    /// This defines the "topic" — every output triple must overlap with it.
    fn build_semantic_cluster(&self, seed_words: &[String]) -> std::collections::HashSet<String> {
        let mut cluster = std::collections::HashSet::new();
        
        // Start with expanded query words
        for word in seed_words {
            cluster.insert(word.to_lowercase());
        }

        // Add synset synonyms
        for word in seed_words {
            if let Some(syns) = self.synsets.get(&word.to_lowercase()) {
                for syn in syns {
                    cluster.insert(syn.to_lowercase());
                }
            }
        }

        // Add 1-hop transitive neighbors (concepts directly connected) --
        // live_neighbors walks self.tokens/self.token_index fresh, same as
        // every other stage now. Was a self.relations -> TransitiveReasoner
        // adjacency map built on every call.
        for word in seed_words {
            let w_lower = word.to_lowercase();
            for (_rel, target) in self.live_neighbors(&w_lower).into_iter().take(5) {
                cluster.insert(target.to_lowercase());
            }
        }

        cluster
    }

    /// Coherence score: how many words in this triple overlap with the semantic cluster?
    /// Returns 0.0 (no overlap) to 1.0+ (strong overlap).
    /// Coherence score: how many *distinct query tokens* does this triple support?
    /// - Counts distinct seed (content) words supported by the triple (subject/relation/object)
    /// - Requires at least two distinct seed hits for multi-word queries (prevents 1-word latch)
    /// - Returns a normalized score that still respects multi-word overlap and recency.
    fn coherence_score(&self, triple: &RelationalTriple, cluster: &std::collections::HashSet<String>, seed_words: &[String]) -> f32 {
        // Build token set for the triple (subject + relation + object)
        let mut triple_tokens: std::collections::HashSet<String> = std::collections::HashSet::new();
        for w in triple.subject.split_whitespace().chain(triple.relation.split_whitespace()).chain(triple.object.split_whitespace()) {
            triple_tokens.insert(w.to_lowercase());
        }

        // Also compute raw word-hit density (legacy behavior) to preserve signal from multi-word triples
        let mut raw_hits = 0usize;
        for tok in triple_tokens.iter() {
            if cluster.contains(tok) { raw_hits += 1; }
        }

        // Count how many *distinct seed words* the triple supports (direct match or synset match)
        let mut distinct_supported = 0usize;
        // Simple normalization for surface variants (e.g. 'emerge' ~ 'emerged')
        let normalize = |w: &str| {
            let mut s = w.to_lowercase();
            for suf in ["ing", "ed", "es", "s"] {
                if s.ends_with(suf) && s.len() > suf.len() + 1 {
                    s = s[..s.len() - suf.len()].to_string();
                }
            }
            // also drop a terminal 'e' (emerge <-> emerged)
            if s.ends_with('e') && s.len() > 2 {
                s = s[..s.len()-1].to_string();
            }
            s
        };

        for seed in seed_words {
            let seed_l = seed.to_lowercase();
            let seed_norm = normalize(&seed_l);

            // direct token match (or normalized match)
            if triple_tokens.contains(&seed_l) || triple_tokens.iter().any(|t| normalize(t) == seed_norm) {
                distinct_supported += 1;
                continue;
            }

            // also consider synonyms from synsets (if available) using normalized compare
            if let Some(syns) = self.synsets.get(&seed_l) {
                if syns.iter().any(|s| {
                    let s_l = s.to_lowercase();
                    triple_tokens.contains(&s_l) || triple_tokens.iter().any(|t| normalize(t) == normalize(&s_l))
                }) {
                    distinct_supported += 1;
                }
            }
        }

        // If the triple doesn't explicitly support any seed word, allow a small
        // fallback score when the triple strongly overlaps the semantic cluster
        // (this preserves transitive / neighbor-based signals such as the
        // `consciousness -> lightning` causal chain). Otherwise require seed
        // coverage.
        

        if distinct_supported == 0 {
            // allow a down-weighted fallback when the triple overlaps the semantic
            // cluster (including transitive neighbors). This preserves chains
            // such as `consciousness -> ... -> lightning` while still giving
            // priority to triples that explicitly support seed words.
            if raw_hits >= 1 {
                return ((raw_hits as f32).sqrt() / 2.0) * 0.35; // down-weighted fallback
            }
            return 0.0;
        }

        // Hard minimum: prefer >=2 distinct seed hits for multi-word queries
        let min_required = if seed_words.len() > 2 { 2 } else { 1 };
        if distinct_supported < min_required {
            // Soft minimum: single-seed triples get a reduced score, not zero.
            // This preserves single-pivot chains like "what causes lightning"
            // where "causes" isn't a seed and only "lightning" matches.
            return (distinct_supported as f32 / seed_words.len() as f32) * 0.25;
        }

        // Also compute raw word-hit density (legacy behavior) to preserve signal from multi-word triples
        let mut raw_hits = 0usize;
        for tok in triple_tokens.iter() {
            if cluster.contains(tok) { raw_hits += 1; }
        }

        // distinct fraction (0..1) weighted by sqrt(raw_hits) to prefer richer triples
        let distinct_fraction = (distinct_supported as f32) / (seed_words.len() as f32).max(1.0);
        let richness = (raw_hits as f32).sqrt() / 2.0; // preserves earlier scaling

        distinct_fraction * (0.2 + 0.8 * richness) // bias slightly in favor of covering more distinct seeds
    }

    /// Expand query tokens: synset synonyms first, then soft spelling correction
    /// for any token absent from the position index.  Returns deduplicated union.
    fn expand_query_tokens(&self, words: &[String]) -> Vec<String> {
        let mut out: Vec<String> = words.to_vec();

        // Synset expansion — HashMap<String, HashSet<String>>
        for word in words {
            if let Some(syns) = self.synsets.get(word) {
                for syn in syns {
                    if !out.contains(syn) { out.push(syn.clone()); }
                }
            }
        }

        // Soft spelling correction — only for unknown tokens.
        // Restrict candidates to same first-char to avoid O(vocab²).
        for word in words {
            if self.token_index.contains_key(word) || word.len() < 3 { continue; }
            let first = match word.chars().next() { Some(c) => c, None => continue };
            let mut best_dist = usize::MAX;
            let mut best_cand = String::new();
            for cand in self.token_index.keys() {
                if !cand.starts_with(first) || cand.len() < 3 { continue; }
                // Lightweight edit-distance proxy: length diff + prefix mismatch count
                let len_diff = (cand.len() as isize - word.len() as isize).unsigned_abs();
                if len_diff > 2 { continue; }
                let mismatch = word.chars().zip(cand.chars()).filter(|(a,b)| a != b).count();
                let dist = len_diff + mismatch;
                if dist < best_dist { best_dist = dist; best_cand = cand.clone(); }
            }
            if best_dist <= 2 && !best_cand.is_empty() && !out.contains(&best_cand) {
                out.push(best_cand);
            }
        }
        out
    }

    
    /// Radial hash expansion (Stage 2.5 helper).
    ///
    /// For each word in `seed_words`, probe `radius` hash bins either side of
    /// the word's hash address (using `method`).  For every occupied slot in
    /// that window, decode the stored word from the token timeline (if
    /// available) and return it as an additional expansion candidate.
    ///
    /// This is the "one bin over" mechanism: continuation words for a pivot
    /// live in adjacent hash bins, so we harvest them here and inject them
    /// into `expanded_words` before the interference and transitive stages run.
    fn radial_hash_expand(
        &self,
        seed_words: &[String],
        method: crate::hash_methods::HashMethod,
        chain_depth: u8,
        probe_cap: u16,
        window: u16,
    ) -> Vec<String> {
        let mut found: Vec<String> = Vec::new();
        let mut seen_slots: std::collections::HashSet<u32> = std::collections::HashSet::new();

        for word in seed_words {
            let hits = self.table.lookup_radial(word, method, chain_depth, probe_cap, window, &self.addr_index);
            for (slot_idx, _weight) in hits {
                if !seen_slots.insert(slot_idx) { continue; }
                // Recover the word stored in this slot via the carousel decoder.
                // word_at() decodes slot.key bytes — correct regardless of slot.value contents.
                if let Some(neighbor) = self.table.word_at(slot_idx) {
                    let neighbor = neighbor.to_lowercase();
                    if !neighbor.is_empty()
                        && !self.function_words.contains(neighbor.as_str())
                        && neighbor != *word
                    {
                        found.push(neighbor);
                    }
                }
            }
        }
        found
    }

    /// Lookup context from carousel hash table
    /// POSITIONAL FALLBACK: Build relations on-demand from token positions
    /// Used when no pre-extracted relations match the query words.
    /// Scans for operator/verb pivots near query word positions.
    fn carousel_lookup(&self, words: &[String]) -> Vec<RelationalTriple> {
        let mut inferred_relations = Vec::new();
        let mut seen_keys = std::collections::HashSet::new();
        
        for word in words {
            if let Some(positions) = self.token_index.get(&word.to_lowercase()) {
                for &pos in positions.iter().take(10) {
                    let pos_usize = pos as usize;

                    // Sentence-scoped window (same fix as live_neighbors --
                    // this was the other half of the "Hello"/"test" word-
                    // salad: a fixed ±self.window scan with no boundary
                    // check let the pivot search wander into a completely
                    // unrelated adjacent utterance, which is exactly how
                    // "cloth test is exam" / "there hello i am number 5"
                    // got assembled out of unrelated sentences that merely
                    // happened to sit within 8 tokens of each other).
                    // tok_is_sentence_end, not tok_is_boundary: a comma/
                    // semicolon/colon/emdash is still the SAME utterance
                    // ("Hello there, how are you today?" is one sentence),
                    // only __PERIOD__/__QMARK__/__BANG__ actually end it.
                    // Clamping on every clause marker cut this window down
                    // to nothing for short comma-led utterances.
                    let raw_start = pos_usize.saturating_sub(self.window);
                    let mut window_start = raw_start;
                    for i in (raw_start..pos_usize).rev() {
                        if Self::tok_is_sentence_end(&self.tokens[i]) { window_start = i + 1; break; }
                    }
                    let raw_end = (pos_usize + self.window).min(self.tokens.len());
                    let mut window_end = raw_end;
                    for i in pos_usize..raw_end {
                        if Self::tok_is_sentence_end(&self.tokens[i]) { window_end = i; break; }
                    }

                    for pivot in window_start..window_end {
                        if pivot >= self.tokens.len() { break; }

                        // Is this token an operator/verb?
                        if !self.tok_is_operator(&self.tokens[pivot]) {
                            continue;
                        }

                        // Subject/object spans stay inside the SAME sentence
                        // window found above, not just clamped to pivot±3/4 --
                        // otherwise a pivot sitting one token inside a
                        // sentence could still reach back across the
                        // boundary into the previous, unrelated one.
                        let subj_start = pivot.saturating_sub(3).max(window_start);
                        let subject_phrase = self.extract_phrase(subj_start, pivot);

                        // Relation: the operator itself
                        let relation = self.tokens[pivot].clone();

                        let obj_start = pivot + 1;
                        let obj_end = (pivot + 4).min(window_end);
                        let object_phrase = self.extract_phrase(obj_start, obj_end);
                        
                        if subject_phrase.is_empty() || object_phrase.is_empty() {
                            continue;
                        }
                        
                        // Deduplicate: don't add the same triple twice
                        let key = format!("{}|{}|{}", subject_phrase, relation, object_phrase);
                        if !seen_keys.insert(key) {
                            continue;
                        }
                        
                        inferred_relations.push(RelationalTriple {
                            subject: subject_phrase,
                            relation,
                            object: object_phrase,
                            confidence: 0.6, // Lower confidence than pre-extracted relations
                            source: KnowledgeSource::Unknown,
                            person: PersonPerspective::Third,
                            slot_val: 0,
                        });
                    }
                }
            }
        }
        
        inferred_relations
    }
    
    /// Extract a phrase from tokens, filtering out function words but keeping structure
    fn extract_phrase(&self, start: usize, end: usize) -> String {
        if start >= end || start >= self.tokens.len() {
            return String::new();
        }

        let end = end.min(self.tokens.len());
        self.tokens[start..end]
            .iter()
            .filter(|t| !self.tok_is_function_word(t) && !Self::tok_is_boundary(t))
            .map(|t| t.as_str())
            .collect::<Vec<_>>()
            .join(" ")
    }

    /// Live multi-hop reasoning walk directly over the token stream.
    ///
    /// This is `think`'s replacement for reading a pre-baked relation
    /// store. It touches `self.tokens` / `self.token_index` only -- the
    /// same position tape `carousel_lookup` already scans for single-hop
    /// answers -- and never reads or writes `self.relations` or
    /// `table.rs`'s chain-threaded Relation slots. There is nothing to
    /// finalize and nothing that can go stale: retrain the corpus and the
    /// very next call sees it, because every call re-walks the tokens
    /// from scratch.
    ///
    /// BFS frontier expansion, but each edge in the frontier is computed
    /// on demand by `live_neighbors` -- the "OP table" (self.operators)
    /// decides, at walk time, which pivot words count as a hop and which
    /// token wins as the neighbor on the far side of the pivot.
    pub fn live_think(&self, subject: &str, target: &str, max_hops: usize) -> Option<(usize, Vec<String>)> {
        if subject.eq_ignore_ascii_case(target) {
            return Some((0, Vec::new()));
        }
        let hops = self.live_walk(subject, target, max_hops)?;
        let rel_words: Vec<String> = hops.into_iter().map(|(_, rel, _)| rel).collect();
        let depth = rel_words.len();
        Some((depth, rel_words))
    }

    /// Case-insensitive membership test against `self.operators` for a
    /// token pulled straight from `self.tokens`. `self.tokens` preserves
    /// source case now (ingest v2) — the grammar-word sets (operators,
    /// function_words) stay lowercase-only, so every comparison against a
    /// raw tape token needs to go through one of these two instead of a
    /// bare `.contains(&self.tokens[i])`, or a sentence-initial "Is"/"The"
    /// silently stops matching the word it always matched before.
    pub(crate) fn tok_is_operator(&self, tok: &str) -> bool {
        self.operators.contains(&tok.to_lowercase())
    }

    /// Case-insensitive membership test against `self.function_words`.
    /// `pub`: used by `crsl_loader` (same crate) to rebuild `token_index`
    /// with the same word/function-word/boundary partitioning ingest uses,
    /// so a loaded-from-disk engine's index matches a freshly-ingested
    /// one; also used by `bin/word.rs` (a separate crate -- `pub(crate)`
    /// wasn't visible there), which needs the same partitioning to scan
    /// the live tape for interference/epicenter/last-resort fallback
    /// instead of the pre-extracted relation store.
    pub fn tok_is_function_word(&self, tok: &str) -> bool {
        self.function_words.contains(&tok.to_lowercase())
    }

    /// True if `tok` is one of the lexer's boundary markers (__PERIOD__,
    /// __COMMA__, __QMARK__, __BANG__, __SEMICOLON__, __COLON__, __EMDASH__).
    /// Ingest v2 keeps these on the tape as real tokens (see
    /// `ingest_with_source`), so any window/hole scan over `self.tokens`
    /// needs to treat them as utterance boundaries rather than content.
    /// `pub`: used by `crsl_loader`'s token_index rebuild and by
    /// `bin/word.rs`'s live-tape interference scan (separate crate, so
    /// `pub(crate)` isn't enough -- see `tok_is_function_word` above).
    pub fn tok_is_boundary(tok: &str) -> bool {
        tok.starts_with("__") && tok.ends_with("__")
    }

    /// True only for the three markers that actually end an utterance
    /// (__PERIOD__, __QMARK__, __BANG__) -- as opposed to `tok_is_boundary`,
    /// which also counts __COMMA__/__SEMICOLON__/__COLON__/__EMDASH__.
    /// The lexer's own doc comment (lexer.rs) calls the full boundary set
    /// "clause/list markers", not sentence markers -- but every window/
    /// pivot-search clamp added this session (the F6 fix, live_neighbors,
    /// carousel_lookup, interference) used `tok_is_boundary` for that
    /// clamp, meaning a comma stopped a window exactly as hard as a
    /// period. "Hello there, how are you today?" is one utterance, but
    /// its window clamped to just "Hello there" at the comma -- two
    /// tokens, nowhere near enough to find the "are" pivot a few words
    /// later, and short enough to fail the coherence check even as a raw
    /// fallback chunk. Use this instead of `tok_is_boundary` anywhere the
    /// question is "does the window/scan stay inside one utterance" --
    /// keep `tok_is_boundary` for "is this token content or punctuation"
    /// (extract_phrase and similar filtering), where a comma should still
    /// never show up as if it were a word.
    pub fn tok_is_sentence_end(tok: &str) -> bool {
        matches!(tok, "__PERIOD__" | "__QMARK__" | "__BANG__")
    }

    /// Who said the token at `pos`? Looks up `speaker_spans`, which is
    /// always sorted by start (spans are appended in ingest order and
    /// never reordered). Falls back to `Speaker::Corpus` for a position
    /// outside every recorded span -- e.g. tape restored from a
    /// pre-speaker-spans .crsl file that hasn't had a fresh ingest since;
    /// treating unknown provenance as background corpus is the permissive
    /// default so old data doesn't silently stop matching either voice.
    pub fn speaker_at(&self, pos: u32) -> Speaker {
        // Most reads are near the end of the tape (recent turns), so scan
        // back-to-front -- short-circuits fast for the common case without
        // needing a binary search over a typically-small span list.
        for &(start, end, speaker) in self.speaker_spans.iter().rev() {
            if pos >= start && pos < end {
                return speaker;
            }
        }
        Speaker::Corpus
    }

    /// Live multi-hop BFS over the token stream, returning the full chain
    /// of (subject_word, relation_word, object_word) hops from `start` to
    /// `target` -- not just the relation words. This is the general form
    /// `live_think` reports from, and it's also what the query pipeline's
    /// transitive-chain stage uses to synthesize real triples: nothing here
    /// is read from or written to `self.relations` or `table.rs`'s Relation
    /// slots. Every call re-walks `self.tokens`/`self.token_index` fresh.
    pub fn live_walk(&self, start: &str, target: &str, max_hops: usize) -> Option<Vec<(String, String, String)>> {
        let start = start.to_lowercase();
        let target = target.to_lowercase();

        if start.is_empty() || target.is_empty() || max_hops == 0 || start == target {
            return None;
        }

        let mut frontier: Vec<(String, Vec<(String, String, String)>)> = vec![(start.clone(), Vec::new())];
        let mut visited: HashSet<String> = HashSet::new();
        visited.insert(start);

        for _hop in 0..max_hops {
            let mut next_frontier: Vec<(String, Vec<(String, String, String)>)> = Vec::new();

            for (word, path) in &frontier {
                for (rel_word, neighbor) in self.live_neighbors(word) {
                    // `neighbor` comes straight off the tape and is
                    // case-preserved (Ingest v2); `target`/`visited` stay
                    // lowercase-normalized, so compare/insert lowercased.
                    let neighbor_key = neighbor.to_lowercase();
                    let hop = (word.clone(), rel_word, neighbor.clone());
                    if neighbor_key == target {
                        let mut full_path = path.clone();
                        full_path.push(hop);
                        return Some(full_path);
                    }
                    if visited.insert(neighbor_key) {
                        let mut new_path = path.clone();
                        new_path.push(hop);
                        next_frontier.push((neighbor, new_path));
                    }
                }
            }

            if next_frontier.is_empty() {
                break;
            }
            frontier = next_frontier;
        }

        None
    }

    // ═══════════════════════════════════════════════════════════════════
    // CLOZE READ — question as statement-with-a-hole, completed by the
    // token stream itself.
    //
    // "What do I like to eat?" IS "i like to eat ___". "Why am I x about
    // y?" IS "i am x about y because ___". The query's own tokens, put
    // back in declarative order, are a probe pattern; the answer is
    // whatever the stream says at the hole. No relation store, no per-word
    // tag actions — one mechanism for every question shape, because every
    // question is the same thing: an assertion the speaker already made,
    // minus one span.
    //
    // Person handling is a uniform transform, not an alias lookup: the
    // pattern is tried in the asker's own voice (matches things the user
    // said) and person-flipped (matches things the engine's corpus says in
    // first person). Whichever matched decides whether the OUTPUT gets
    // flipped, so "your name is potato chip" comes back as "my name is
    // potato chip" and the engine's own "i am number 5" comes back as-is.
    // ═══════════════════════════════════════════════════════════════════

    /// Answer a WH-question by cloze completion over the token stream.
    /// Returns None if the input isn't a WH-question or no pattern match
    /// exists — callers fall through to their other paths.
    pub fn cloze_answer(&self, query: &str) -> Option<String> {
        const WH: [&str; 6] = ["what", "who", "where", "when", "why", "how"];
        const AUX: [&str; 15] = ["is", "are", "am", "was", "were", "do", "does", "did",
                                 "can", "could", "will", "would", "have", "has", "had"];

        let toks: Vec<String> = query.to_lowercase()
            .split_whitespace()
            .map(|t| t.trim_matches(|c: char| c.is_ascii_punctuation()).to_string())
            .filter(|t| !t.is_empty())
            .collect();
        if toks.len() < 3 { return None; }
        let wh = toks[0].clone();
        if !WH.contains(&wh.as_str()) { return None; }
        let rest = &toks[1..];

        // Un-invert the question into declarative candidate patterns.
        // We don't parse — we generate the plausible declarative orders and
        // let the stream itself arbitrate, since only one will match text
        // someone actually said:
        //   "is your name"     → "your name is"        (aux to end)
        //   "am i upset about" → "i am upset about"    (aux after subject)
        //   "do i like to eat" → "i like to eat"       (do-support drops)
        let mut cands: Vec<Vec<String>> = Vec::new();
        if AUX.contains(&rest[0].as_str()) {
            let aux = rest[0].clone();
            if rest.len() >= 2 {
                let mut a = rest[1..].to_vec();
                a.push(aux.clone());
                cands.push(a);
                if rest.len() >= 3 {
                    let mut b = vec![rest[1].clone(), aux.clone()];
                    b.extend_from_slice(&rest[2..]);
                    cands.push(b);
                }
                // Aux-drop candidate (F5 guard): ONLY do-support vanishes in
                // declaratives ("do i like pizza" → "i like pizza" -- "do"
                // carries no content). For is/are/am/was/were the aux IS the
                // verb; "what is a dog" must never produce the bare 2-token
                // probe ["a","dog"], which matches any mention of a dog
                // anywhere and reads whatever happens to follow ("A dog
                // makes." came from exactly this). Tense on the dropped
                // do-aux is not lost: "did" makes the question's wanted
                // state Past, and lemma-flex matching lets the bare probe
                // ["i","make"] hit tape text "i made ..." anyway.
                if matches!(aux.as_str(), "do" | "does" | "did") {
                    cands.push(rest[1..].to_vec());
                }
            }
        } else {
            cands.push(rest.to_vec());
        }
        // "why" puts the hole after a causal marker instead of at the end.
        if wh == "why" {
            for c in cands.iter_mut() { c.push("because".to_string()); }
        }
        cands.retain(|c| c.len() >= 2);

        // The question's wanted verb state, read off its first verb-ish
        // token: "what DID i make" → Past (past truths ledger), "what DO i
        // make" / "what IS zig" → Present. This is what makes answers
        // state-dependent: past-tense evidence and present-tense evidence
        // are separate ledgers, ranked by agreement with what was asked.
        let wanted_state = rest.iter()
            .filter_map(|t| morph::verb_state(t))
            .next()
            .unwrap_or(morph::VerbState::Present);

        // ── Collect ALL voice-agreeing matches, not just the last one ────
        //
        // Voice-agreement (F1): the unflipped candidate is the question AS
        // ASKED -- a tape match can only be something the USER said. The
        // flipped candidate is the engine's own first-person phrasing -- a
        // match there can only be Self/Corpus narrative.
        //
        // Collecting everything (instead of last-match-wins) is what makes
        // evidence-based ranking possible: each match is an attestation,
        // and attestations of the same completed answer corroborate each
        // other. Authority comes from agreement across the tape, not from
        // whichever file happened to be trained last.
        struct Attest {
            j: usize,
            pat_len: usize,
            flipped: bool,
            /// The actual tape tokens the pattern matched (case-preserved,
            /// real verb forms -- may differ from the probe under lemma-flex,
            /// e.g. probe "i make" matching tape "I made").
            matched: Vec<String>,
            hole: Vec<String>,
            /// Verb state of the matched pivot (last verb in the matched
            /// slice): which truth-ledger this attestation belongs to.
            state: Option<morph::VerbState>,
            is_user: bool,
        }
        let mut attests: Vec<Attest> = Vec::new();
        for c in &cands {
            for (pat, flipped) in [(c.clone(), false), (Self::flip_person(c), true)] {
                for j in self.collect_pattern_matches_voiced(&pat, flipped) {
                    let hole = self.read_hole(j + pat.len());
                    if hole.is_empty() { continue; }
                    let matched: Vec<String> = self.tokens[j..j + pat.len()].to_vec();
                    let state = matched.iter().rev()
                        .filter_map(|t| morph::verb_state(t))
                        .next();
                    let is_user = matches!(self.speaker_at(j as u32), Speaker::User);
                    attests.push(Attest { j, pat_len: pat.len(), flipped, matched, hole, state, is_user });
                }
            }
        }
        if attests.is_empty() { return None; }

        // Ledger key: which "same completed answer" bucket an attestation
        // belongs to. Past-state and present-state attestations never share
        // a bucket -- "X made Y" is evidence about a past truth, not about
        // what X makes now.
        let ledger_key = |a: &Attest| -> (String, u8) {
            let hole_norm = a.hole.iter()
                .map(|t| t.to_lowercase())
                .collect::<Vec<_>>()
                .join(" ");
            let state_tag = match a.state {
                Some(morph::VerbState::Past) | Some(morph::VerbState::Participle) => 1u8,
                Some(morph::VerbState::Progressive) => 2u8,
                _ => 0u8,
            };
            (hole_norm, state_tag)
        };

        // ── Group attestations into distinct completed answers ───────────
        // Each group is one candidate fact the tape supports; corroboration
        // is how many independent attestations agree on it. This is what
        // lets the engine notice DISAGREEMENT instead of always collapsing
        // silently to one winner: "zig is for systems programming" (seen 4
        // times) and "zig is really helpful because it protects" (seen
        // once) become two visible groups, not one arbitrarily-chosen line.
        struct Group {
            hole_norm: String,
            state_tag: u8,
            best: usize,
            corroboration: usize,
            any_user: bool,
            max_pat_len: usize,
            latest_j: usize,
        }
        let mut groups: HashMap<(String, u8), Group> = HashMap::new();
        for (idx, a) in attests.iter().enumerate() {
            let key = ledger_key(a);
            let g = groups.entry(key.clone()).or_insert_with(|| Group {
                hole_norm: key.0.clone(), state_tag: key.1, best: idx,
                corroboration: 0, any_user: false, max_pat_len: 0, latest_j: 0,
            });
            g.corroboration += 1;
            g.any_user = g.any_user || a.is_user;
            if a.pat_len > g.max_pat_len { g.max_pat_len = a.pat_len; g.best = idx; }
            if a.j > g.latest_j { g.latest_j = a.j; }
        }
        if groups.is_empty() { return None; }

        // Ranking, in priority order -- same as before, now applied per
        // GROUP (an aggregated candidate) instead of per raw attestation:
        //  1. Pattern length (F5b) -- a long, specific probe beats a short
        //     generic one.
        //  2. User voice -- the user's own words outrank corpus text.
        //  3. State agreement -- evidence in the tense that was asked about.
        //  4. Corroboration -- more independent attestations = more
        //     authority, but only for corpus evidence (user statements are
        //     directives, not a vote; they pin to 1 and let recency decide).
        //  5. Recency -- the tie-breaker within a ledger.
        let rank_key = |g: &Group| -> (usize, bool, bool, usize, usize) {
            let a = &attests[g.best];
            let state_agrees = match a.state {
                Some(s) => {
                    let past_s = matches!(s, morph::VerbState::Past | morph::VerbState::Participle);
                    let past_w = matches!(wanted_state, morph::VerbState::Past | morph::VerbState::Participle);
                    past_s == past_w
                }
                None => false,
            };
            let corrob = if g.any_user { 1 } else { g.corroboration };
            (g.max_pat_len, g.any_user, state_agrees, corrob, g.latest_j)
        };
        let mut group_list: Vec<&Group> = groups.values().collect();
        group_list.sort_by_key(|g| std::cmp::Reverse(rank_key(g)));
        let top = group_list[0];

        // Per-attestation voice-correct rendering: matched+hole tokens,
        // flipped if this attestation matched the asker's own voice (same
        // rule the single-answer path always used). Token count is
        // preserved by flip_person, so indices into the flipped vector
        // still line up with the unflipped matched/hole split.
        let render = |a: &Attest| -> Vec<String> {
            let mut out: Vec<String> = a.matched.iter().chain(a.hole.iter()).cloned().collect();
            if !a.flipped { out = Self::flip_person(&out); }
            out
        };
        let subject_of = |a: &Attest| -> String {
            if a.matched.len() <= 1 { return String::new(); }
            render(a)[..a.matched.len() - 1].join(" ")
        };
        let hole_of = |a: &Attest| -> String {
            render(a)[a.matched.len()..].join(" ")
        };
        let finalize = |raw: String| -> Option<String> {
            let s = raw
                .replace("you am", "you are")
                .replace("i are", "i am")
                .replace("I are", "I am");
            let mut chars = s.chars();
            match chars.next() {
                Some(f) => Some(f.to_uppercase().collect::<String>() + chars.as_str()),
                None => None,
            }
        };

        // ── Temporal disagreement: "X was Z, but is now Y" ────────────────
        // Independently find the best Past-ledger and best Present-ledger
        // answer (ignoring which one the question's own tense favored) --
        // if both exist and genuinely disagree, that disagreement IS the
        // answer, not something to silently pick a side on.
        let best_in_state = |tag: u8| -> Option<&Group> {
            group_list.iter().filter(|g| g.state_tag == tag).copied().next()
        };
        if let (Some(past_g), Some(pres_g)) = (best_in_state(1), best_in_state(0)) {
            if past_g.hole_norm != pres_g.hole_norm {
                let past_a = &attests[past_g.best];
                let pres_a = &attests[pres_g.best];
                let mut subj = subject_of(pres_a);
                if subj.is_empty() { subj = subject_of(past_a); }
                if !subj.is_empty() {
                    let pres_strength = if pres_g.any_user { 2 } else { pres_g.corroboration };
                    let past_strength = if past_g.any_user { 2 } else { past_g.corroboration };
                    let raw = if pres_strength >= past_strength {
                        format!("{} was {}, but is now {}.", subj, hole_of(past_a), hole_of(pres_a))
                    } else {
                        format!("{} may be {} now, but was {}.", subj, hole_of(pres_a), hole_of(past_a))
                    };
                    if let Some(s) = finalize(raw) { return Some(s); }
                }
            }
        }

        // ── Same-tense agreement/disagreement ─────────────────────────────
        // Groups sharing the top answer's state, best-first (group_list is
        // already sorted, so filtering preserves relative order).
        let same_state: Vec<&Group> = group_list.iter()
            .filter(|g| g.state_tag == top.state_tag)
            .copied()
            .collect();

        let dominant = same_state.len() < 2 || {
            let t = same_state[0];
            let s = same_state[1];
            let t_c = if t.any_user { 2 } else { t.corroboration };
            let s_c = if s.any_user { 2 } else { s.corroboration };
            t.max_pat_len > s.max_pat_len || (t.any_user && !s.any_user) || t_c >= 2 * s_c
        };

        if dominant {
            // Clear single winner -- answer directly, then look for 1-2
            // DISTINCT supporting facts about the same subject elsewhere
            // on the tape and append them, instead of stopping cold at
            // one sentence.
            //
            // cloze's contract has always been "complete exactly one
            // matched pattern" -- correct for what it's answering, but
            // it's the reason "What is water?" always stopped at "Water
            // is the clear liquid we drink." even on a corpus that has
            // more to say about water elsewhere. This doesn't change that
            // contract, it adds a second, smaller step after it: look up
            // the subject's other live_neighbors (the same boundary-
            // clamped pivot walk carousel_lookup/read_from_epicenter use)
            // and append up to 2 that aren't just restating the primary
            // answer.
            //
            // Deliberately scoped to ONLY the dominant/single-winner
            // case. The temporal-contrast, multi-truth, and hedge shapes
            // below already say multiple things; piling elaboration on
            // top of those risks sliding back into the same low-
            // coherence multi-clause soup the Generic/interference path
            // produces.
            let a = &attests[top.best];
            let out = render(a);
            let Some(primary) = finalize(out.join(" ")).map(|s| format!("{}.", s)) else {
                return None;
            };

            let subj = subject_of(a);
            let primary_hole_lc = hole_of(a).to_lowercase();
            let subj_lc = subj.to_lowercase();
            let mut elaboration: Vec<String> = Vec::new();
            let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
            seen.insert(primary_hole_lc.clone());

            if !subj.is_empty() {
                let subj_words: Vec<&str> = subj.split_whitespace()
                    .filter(|w| w.len() >= 3 && !self.tok_is_function_word(w))
                    .collect();
                'elab: for sw in &subj_words {
                    for (rel, neighbor) in self.live_neighbors(sw) {
                        let rel_lc = rel.to_lowercase();
                        let neighbor_lc = neighbor.to_lowercase();
                        // Skip synset-style relations (same filter
                        // read_from_epicenter uses).
                        if rel_lc.contains("similar") || rel_lc.contains("same as") || rel_lc.contains("synonym") { continue; }
                        // Tautology guard -- exactly the "is now life"
                        // bug found this session: never let the
                        // elaboration's own object collapse back onto
                        // the subject itself.
                        if neighbor_lc == subj_lc { continue; }
                        if neighbor_lc.len() < 3 { continue; }
                        // Don't restate the primary answer in different
                        // words -- skip anything that substantially
                        // overlaps the hole already given.
                        if seen.contains(&neighbor_lc) { continue; }
                        if primary_hole_lc.contains(&neighbor_lc) || neighbor_lc.contains(&primary_hole_lc) { continue; }
                        seen.insert(neighbor_lc);

                        if let Some(s) = finalize(format!("{} {} {}", subj, rel, neighbor)).map(|s| format!("{}.", s)) {
                            elaboration.push(s);
                        }
                        if elaboration.len() >= 2 { break 'elab; }
                    }
                }
            }

            if elaboration.is_empty() {
                return Some(primary);
            }
            return Some(format!("{} {}", primary, elaboration.join(" ")));
        }

        // Multiple comparably-attested, DISTINCT answers in the same
        // ledger. Two shapes depending on how solid each one is:
        //  - every candidate individually corroborated (>=2, or a user
        //    statement) → assert them as simultaneously true: "X is Y, Z,
        //    and W." (P3: a subject can be several true things at once)
        //  - otherwise → hedge instead of guessing: "I'm not sure -- X
        //    could be Y, Z, or W."
        let candidates: Vec<&Group> = same_state.into_iter().take(4).collect();
        let all_solid = candidates.iter().all(|g| {
            let c = if g.any_user { 2 } else { g.corroboration };
            c >= 2
        });
        let rep = &attests[candidates[0].best];
        let subj = subject_of(rep);
        if subj.is_empty() {
            let out = render(rep);
            return finalize(out.join(" ")).map(|s| format!("{}.", s));
        }
        let holes: Vec<String> = candidates.iter()
            .map(|g| hole_of(&attests[g.best]))
            .collect();
        let join_list = |items: &[String], conj: &str| -> String {
            match items.len() {
                0 => String::new(),
                1 => items[0].clone(),
                2 => format!("{} {} {}", items[0], conj, items[1]),
                _ => {
                    let (last, init) = items.split_last().unwrap();
                    format!("{}, {} {}", init.join(", "), conj, last)
                }
            }
        };
        let raw = if all_solid {
            format!("{} is {}.", subj, join_list(&holes, "and"))
        } else {
            format!("I'm not sure -- {} could be {}.", subj, join_list(&holes, "or"))
        };
        finalize(raw)
    }

    /// Uniform person transform between speaker perspectives. `pat` (the
    /// probe half of `tokens`) is always lowercase, but `hole` (the
    /// tape-read half, since Ingest v2) is case-preserved — so this matches
    /// case-insensitively and hardcodes "I" capitalized, since English
    /// capitalizes the first-person pronoun everywhere, not just sentence-
    /// initially, and the caller's final cap step only fixes position 0.
    fn flip_person(tokens: &[String]) -> Vec<String> {
        tokens.iter().map(|t| {
            let repl: &str = match t.to_lowercase().as_str() {
                "i" => "you", "me" => "you", "my" => "your", "mine" => "yours",
                "myself" => "yourself", "am" => "are",
                "you" => "I", "your" => "my", "yours" => "mine",
                "yourself" => "myself", "are" => "am",
                _ => return t.clone(),
            };
            repl.to_string()
        }).collect()
    }

    /// Every position where `pat` occurs contiguously in the token stream
    /// with an agreeing voice, in tape order (oldest first). Each returned
    /// position is one ATTESTATION -- callers rank them (state agreement,
    /// corroboration, recency) rather than this function deciding.
    ///
    /// Token equivalence is lemma-flexible: two tokens match if they're
    /// equal case-insensitively OR are verb-states of the same lemma
    /// ("make"/"made"/"makes" -- see morph.rs). So a present-tense probe
    /// still FINDS past-tense statements; the caller's state-agreement
    /// ranking then decides which ledger the question was actually about.
    /// Case-insensitivity on both sides also makes flipped probes (which
    /// contain hardcoded-capital "I" from flip_person) match correctly.
    ///
    /// Voice-agreement (F1): `want_flipped == false` means `pat` is the
    /// question exactly as asked -- only matchable inside User spans.
    /// `want_flipped == true` means `pat` is person-swapped to the engine's
    /// own phrasing -- only matchable inside SelfEngine/Corpus spans.
    /// Untracked positions default to `Speaker::Corpus` via `speaker_at`.
    fn collect_pattern_matches_voiced(&self, pat: &[String], want_flipped: bool) -> Vec<usize> {
        let mut out = Vec::new();
        if pat.is_empty() || self.tokens.len() < pat.len() { return out; }
        for j in 0..=(self.tokens.len() - pat.len()) {
            let hit = self.tokens[j..j + pat.len()]
                .iter()
                .zip(pat.iter())
                .all(|(tape_tok, pat_tok)| morph::same_lemma(tape_tok, pat_tok));
            if !hit { continue; }
            let voice_ok = match self.speaker_at(j as u32) {
                Speaker::User => !want_flipped,
                Speaker::SelfEngine | Speaker::Corpus => want_flipped,
            };
            if voice_ok {
                out.push(j);
            }
        }
        out
    }

    /// Read the hole span starting at `start`: up to 8 tokens, stopping at
    /// a tape boundary marker (__PERIOD__, __QMARK__, ...) — Ingest v2 keeps
    /// these on the tape, so they're now a real sentence-end signal — or at
    /// what looks like the start of the next utterance (a WH word, or a
    /// pronoun subject once at least one token is collected).
    fn read_hole(&self, start: usize) -> Vec<String> {
        const WH_STOP: [&str; 6] = ["what", "who", "where", "when", "why", "how"];
        let mut out: Vec<String> = Vec::new();
        let end = (start + 8).min(self.tokens.len());
        for i in start..end {
            let raw = self.tokens[i].as_str();
            if Self::tok_is_boundary(raw) { break; }
            let t = raw.to_lowercase();
            if WH_STOP.contains(&t.as_str()) { break; }
            if !out.is_empty() && (t == "i" || t == "you") { break; }
            out.push(self.tokens[i].clone());
        }
        // Trim trailing connective debris so answers don't dangle.
        while let Some(last) = out.last() {
            if matches!(last.to_lowercase().as_str(), "and" | "but" | "the" | "a" | "an" | "to" | "of" | "because" | "so") {
                out.pop();
            } else {
                break;
            }
        }
        out
    }

    /// A small set of pronoun/possessive aliases so a live walk anchored on
    /// "you" also sees sentences phrased with "your" (and "i"/"my", etc.)
    /// without needing a separate canonicalized store. This is what lets
    /// "your name is Number 5" answer both "What is your name?" (anchors on
    /// "name" already) and "Are you Number 5?" (anchors on "you", which
    /// never literally appears in that sentence -- only "your" does).
    fn pronoun_aliases(word: &str) -> &'static [&'static str] {
        match word {
            "you" => &["your"],
            "your" => &["you"],
            "i" => &["my"],
            "my" => &["i"],
            "he" => &["his"],
            "his" => &["he"],
            "she" => &["her"],
            "her" => &["she"],
            "they" => &["their"],
            "their" => &["they"],
            _ => &[],
        }
    }

    /// For one anchor word, walk its live token positions and return every
    /// (relation_word, neighbor_word) edge visible from an operator pivot
    /// near that word. Computed fresh from `self.tokens` on every call --
    /// this is the single-hop primitive `live_think` chains through, and
    /// it is the same pivot-scan `carousel_lookup` already does, factored
    /// out so multi-hop reasoning can reuse it without duplicating the walk.
    ///
    /// `pub` because this is also the retrieval primitive for corrections
    /// made through `ingest_user` -- since those no longer write to a
    /// separate relation store, callers like `handle_verification` and the
    /// WH-Query "What is X" lookup in bin/word.rs read live off the token
    /// stream through this instead.
    pub fn live_neighbors(&self, word: &str) -> Vec<(String, String)> {
        let mut edges = Vec::new();
        let mut seen: HashSet<String> = HashSet::new();

        // `token_index` and `pronoun_aliases` are both lowercase-keyed;
        // `word` may arrive case-preserved now (e.g. a BFS hop that landed
        // on a tape token straight out of `live_neighbors` itself) — so
        // normalize once here rather than relying on every caller to do it.
        let word_lc = word.to_lowercase();
        let word = word_lc.as_str();
        let mut anchors: Vec<&str> = vec![word];
        anchors.extend(Self::pronoun_aliases(word));

        for anchor in anchors {
            let Some(positions) = self.token_index.get(anchor) else { continue };
            // Most-recent-first: positions are pushed in ingest order, so
            // reversing means a later correction ("no, actually X is Z")
            // is what a caller sees first instead of the original "X is Y"
            // -- recency-wins, computed at read time, instead of needing a
            // separate demotion/overwrite step at write time.
            for &pos in positions.iter().rev().take(20) {
                let pos_usize = pos as usize;

                // Sentence-scoped window (F6 fix, the real one this time):
                // the fixed ±self.window clamp below was never actually
                // stopped at a tape boundary, only the CONTENT-WORD reads
                // fanning out from a pivot were (first_content_word_after/
                // before). The PIVOT SEARCH itself still happily walked into
                // a completely unrelated adjacent utterance -- which is
                // exactly how "test" (one turn) and an unrelated "there has
                // someone... trust... test" fragment (a different sentence
                // entirely) got treated as if they were about each other.
                // Clamp the window to the nearest SENTENCE-END token on
                // each side before falling back to the fixed radius --
                // tok_is_sentence_end, not tok_is_boundary: a comma is
                // still the same utterance, only period/qmark/bang end
                // it. Clamping on every clause marker (the original F6
                // fix used tok_is_boundary here) cut the window down to
                // nothing for short comma-led utterances like "Hello
                // there, how are you today?".
                let raw_start = pos_usize.saturating_sub(self.window);
                let mut window_start = raw_start;
                for i in (raw_start..pos_usize).rev() {
                    if Self::tok_is_sentence_end(&self.tokens[i]) { window_start = i + 1; break; }
                }
                let raw_end = (pos_usize + self.window).min(self.tokens.len());
                let mut window_end = raw_end;
                for i in pos_usize..raw_end {
                    if Self::tok_is_sentence_end(&self.tokens[i]) { window_end = i; break; }
                }

                // Closest-pivot-first: scanning window_start..window_end in
                // order means the first operator found is whichever is
                // nearest window_start -- i.e. up to `window` tokens *before*
                // the anchor, possibly from an unrelated earlier sentence --
                // not whichever is actually nearest the anchor. That was
                // producing answers pulled from wherever an "is" happened to
                // sit up to 8 tokens away in either direction, regardless of
                // whether it had anything to do with the word being asked
                // about. Sorting by absolute distance from the anchor makes
                // an operator sitting right next to it win over one several
                // tokens off in an unrelated clause.
                let mut pivots: Vec<usize> = (window_start..window_end)
                    .filter(|&p| p < self.tokens.len() && self.tok_is_operator(&self.tokens[p]))
                    .collect();
                pivots.sort_by_key(|&p| (p as i64 - pos_usize as i64).abs());

                for pivot in pivots {
                    let rel_word = self.tokens[pivot].clone();
                    let neighbor = if pos_usize < pivot {
                        // anchor sits on the subject side of the pivot --
                        // the object-side content word is the live neighbor.
                        self.first_content_word_after(pivot)
                    } else {
                        // anchor sits on the object side -- walk back for
                        // the subject-side content word instead.
                        self.first_content_word_before(pivot)
                    };

                    if let Some(neighbor) = neighbor {
                        if neighbor.to_lowercase() != word.to_lowercase() {
                            let key = format!("{}|{}", rel_word, neighbor);
                            if seen.insert(key) {
                                edges.push((rel_word, neighbor));
                            }
                        }
                    }
                }
            }
        }

        edges
    }

    /// First non-function-word token after `pivot`, within a short reach --
    /// the live equivalent of "object" in an on-the-fly subject/verb/object read.
    fn first_content_word_after(&self, pivot: usize) -> Option<String> {
        let end = (pivot + 1 + 4).min(self.tokens.len());
        for i in (pivot + 1)..end {
            // A sentence-end marker means the utterance ended -- stop
            // rather than skip past it, so this never pulls a "neighbor"
            // out of the next, unrelated utterance. Was tok_is_boundary,
            // which also stopped at a comma mid-utterance; that's too
            // aggressive for a 4-token reach that's already short.
            if Self::tok_is_sentence_end(&self.tokens[i]) { return None; }
            if !self.tok_is_function_word(&self.tokens[i]) {
                return Some(self.tokens[i].clone());
            }
        }
        None
    }

    /// First non-function-word token before `pivot`, within a short reach --
    /// the live equivalent of "subject" in an on-the-fly subject/verb/object read.
    fn first_content_word_before(&self, pivot: usize) -> Option<String> {
        let start = pivot.saturating_sub(4);
        for i in (start..pivot).rev() {
            if Self::tok_is_sentence_end(&self.tokens[i]) { return None; }
            if !self.tok_is_function_word(&self.tokens[i]) {
                return Some(self.tokens[i].clone());
            }
        }
        None
    }

    /// Try synthesizing response from stored relations (indexed, ns lookup)
    /// Try to synthesize a response from stored relations matching the query words.
    /// Returns (response_text, source_tag, matched_triples) if found.
    /// Used by Mind's query pipeline as a direct relation-based answer path.
    pub fn try_relation_synthesis(&mut self, words: &[String]) -> Option<(String, String, Vec<RelationalTriple>)> {
        self.metrics.start("relation_synthesis");
        
        let mut matched_relations = Vec::new();
        let mut seen_indices = std::collections::HashSet::new();
        
        for word in words {
            // Find relations where this word is the subject
            if let Some(indices) = self.subject_index.get(word) {
                for &idx in indices {
                    if idx < self.relations.len() && seen_indices.insert(idx) {
                        matched_relations.push(self.relations[idx].clone());
                    }
                }
            }
            // Also check where this word is the object
            if let Some(indices) = self.object_index.get(word) {
                for &idx in indices {
                    if idx < self.relations.len() && seen_indices.insert(idx) {
                        matched_relations.push(self.relations[idx].clone());
                    }
                }
            }
        }
        
        if !matched_relations.is_empty() {
            // Apply perspective translation
            let perspective_relations: Vec<RelationalTriple> = matched_relations.iter().map(|triple| {
                RelationalTriple {
                    subject: self.translate_pronouns(&triple.subject),
                    relation: self.translate_pronouns(&triple.relation),
                    object: self.translate_pronouns(&triple.object),
                    confidence: triple.confidence,
                    source: triple.source,
                    person: triple.person,
                    slot_val: triple.slot_val,
                }
            }).collect();
            
            // Use DADA template system for intelligent synthesis - NO FALLBACKS EVER
            let input_tokens: Vec<String> = words.iter().map(|s| s.to_lowercase()).collect();
            let mut bindings = std::collections::HashMap::new();
            
            // Add any relevant bindings from the query
            for (i, word) in words.iter().enumerate() {
                bindings.insert(i as u32, word.clone());
            }
            
            // ALWAYS use the learned dialogue graph templates - this is the primary method
            let response = self.dada_engine.synthesize_from_graph(&input_tokens, &bindings)
                .unwrap_or_else(|| {
                    // If graph synthesis returns None, try to construct something from available facts
                    if !perspective_relations.is_empty() {
                        let fact = &perspective_relations[0];
                        format!("{} {} {}.", fact.subject, fact.relation, fact.object)
                    } else {
                        Self::topic_acknowledgment(&[])
                    }
                });
            
            self.metrics.stop("relation_synthesis");
            return Some((response, "relation_synthesis".to_string(), perspective_relations));
        }
        
        self.metrics.stop("relation_synthesis");
        None
    }
    
    /// Try interference-based reasoning (simplified).
    /// Uses positional co-occurrence to find answers when relation matching is sparse.
    pub fn try_interference_reasoning(&mut self, words: &[String]) -> Option<(String, String, Vec<RelationalTriple>)> {
        self.metrics.start("interference_reasoning");
        
        // Find positions of query words
        let mut positions = Vec::new();
        for word in words {
            if let Some(word_positions) = self.token_index.get(word) {
                positions.extend(word_positions);
            }
        }
        
        if positions.len() >= 2 {
            // Compute interference between positions
            if let Some(interference_pos) = self.find_interference_point(&positions) {
                // Generate response based on interference
                let response = format!("Based on position interference around {}, I found relevant connections.", interference_pos);
                
                self.metrics.stop("interference_reasoning");
                return Some((response, "interference_reasoning".to_string(), vec![]));
            }
        }
        
        self.metrics.stop("interference_reasoning");
        None
    }
    
    /// Find interference point between positions (simplified)
    fn find_interference_point(&self, positions: &[u32]) -> Option<u32> {
        if positions.len() < 2 {
            return None;
        }
        
        // Simple interference: find position that minimizes sum of distances
        let mut best_pos = positions[0];
        let mut best_score = f32::INFINITY;
        
        for &pos in positions {
            let mut score = 0.0;
            for &other_pos in positions {
                let distance = if pos > other_pos { pos - other_pos } else { other_pos - pos };
                score += self.interference_amplitude(distance as usize);
            }
            
            if score < best_score {
                best_score = score;
                best_pos = pos;
            }
        }
        
        Some(best_pos)
    }
    
    /// Compute interference amplitude based on distance (cosine decay)
    fn interference_amplitude(&self, distance: usize) -> f32 {
        if distance >= self.window {
            0.0
        } else {
            let x = distance as f32 / self.window as f32;
            (std::f32::consts::PI * x).cos().max(0.0)
        }
    }
    
    /// Advance turn counter and decay phrase fatigue
    pub fn advance_turn(&mut self) {
        self.turn_counter += 1;
        
        // Decay all phrase fatigue
        for fatigue in self.phrase_fatigue.values_mut() {
            *fatigue *= 1.0 - self.fatigue_decay_per_turn;
            if *fatigue < 0.01 {
                *fatigue = 0.0; // Effectively zero
            }
        }
    }
    
    /// Record phrase usage for fatigue tracking
    pub fn record_phrase_usage(&mut self, phrase: &str) {
        *self.phrase_fatigue.entry(phrase.to_string()).or_default() += self.fatigue_increment_on_use;
    }
    
    /// Add synonyms to synset groups
    pub fn add_synsets(&mut self, words: &[String]) {
        for word in words {
            for other_word in words {
                if word != other_word {
                    self.synsets.entry(word.clone()).or_default().insert(other_word.clone());
                }
            }
        }
    }
    
    /// Query the WORD engine with learning feedback
    pub fn query_with_feedback(&mut self, query: &str) -> (String, Box<dyn Fn(bool) + Send>) {
        let result = self.query(query);
        let generated_text = result.generated.clone();
        
        // Create feedback closure that will update learning
        let feedback_fn = Box::new(move |was_successful: bool| {
            println!("[FEEDBACK] Response '{}' was {}", 
                generated_text, 
                if was_successful { "successful" } else { "unsuccessful" });
        });
        
        (result.generated, feedback_fn)
    }

    /// Record user feedback on generated response
    pub fn record_feedback(&mut self, response: &str, was_successful: bool) {
        self.dada_engine.record_feedback(response, was_successful);
        
        // Additional learning: update phrase fatigue based on success
        if was_successful {
            // Reduce fatigue for successful phrases
            for word in response.split_whitespace() {
                if let Some(fatigue) = self.phrase_fatigue.get_mut(word) {
                    *fatigue *= 0.9; // Reduce fatigue
                }
            }
        } else {
            // Increase fatigue for unsuccessful phrases
            for word in response.split_whitespace() {
                *self.phrase_fatigue.entry(word.to_string()).or_default() += 0.5;
            }
        }
    }

    /// Learn a new synthesis pattern from user interaction
    pub fn learn_synthesis_pattern(&mut self, template: String, context_tags: HashSet<String>) {
        self.dada_engine.learn_pattern(template, context_tags);
    }

    // ═══════════════════════════════════════════════════════════════
    // Clarity Scoring — Decide what actually needs LM definition
    // ═══════════════════════════════════════════════════════════════

    /// Compute a "clarity score" for a token based on its graph topology.
    ///
    /// High clarity = well-connected, consistent relations → no definition needed.
    /// Low clarity  = few edges, conflicting relations, isolated → candidate for
    ///                post-ingest LM clarification.
    ///
    /// Score components:
    /// - **degree**: how many relations mention this token (subject or object)
    /// - **consistency**: ratio of non-conflicting relations (no IS + IS_NOT pairs)
    /// - **position density**: how many distinct positions this token appears in
    ///
    /// Returns 0.0 (completely unknown) to 1.0 (crystal clear).
    pub fn clarity_score(&self, token: &str) -> f32 {
        let token_lower = token.to_lowercase();

        // 1. Degree: how many relations involve this token?
        let subj_count = self.subject_index.get(&token_lower).map_or(0, |v| v.len());
        let obj_count = self.object_index.get(&token_lower).map_or(0, |v| v.len());
        let total_edges = subj_count + obj_count;

        if total_edges == 0 {
            // Token exists in timeline but has no relational structure
            let position_count = self.token_index.get(&token_lower).map_or(0, |v| v.len());
            if position_count == 0 { return 0.0; }
            // Purely positional — very low clarity
            return (position_count as f32 / 10.0).min(0.2);
        }

        // 2. Degree score: diminishing returns — 1 edge is foggy, 5+ is clear
        let degree_score = 1.0 - (1.0 / (1.0 + total_edges as f32));

        // 3. Consistency: check for conflicting relation pairs
        //    e.g. (token IS X) and (token IS_NOT X) → inconsistent
        let mut conflicts = 0u32;
        let mut total_pairs = 0u32;
        if let Some(subj_indices) = self.subject_index.get(&token_lower) {
            let rels: Vec<&RelationalTriple> = subj_indices.iter()
                .filter_map(|&idx| self.relations.get(idx))
                .collect();
            for i in 0..rels.len() {
                for j in (i+1)..rels.len() {
                    total_pairs += 1;
                    let ri = &rels[i].relation.to_lowercase();
                    let rj = &rels[j].relation.to_lowercase();
                    // Check for negation conflicts
                    if (ri.contains("not") && !rj.contains("not") && rels[i].object == rels[j].object)
                        || (!ri.contains("not") && rj.contains("not") && rels[i].object == rels[j].object) {
                        conflicts += 1;
                    }
                }
            }
        }
        let consistency = if total_pairs == 0 { 1.0 }
        else { 1.0 - (conflicts as f32 / total_pairs as f32) };

        // 4. Position density: how many places in the timeline?
        let position_count = self.token_index.get(&token_lower).map_or(0, |v| v.len());
        let density_score = (position_count as f32 / 5.0).min(1.0);

        // Weighted combination
        (degree_score * 0.5 + consistency * 0.3 + density_score * 0.2).clamp(0.0, 1.0)
    }

    /// Compute relational density for a token using hash table neighbors.
    /// 
    /// Strategy: Find semantic neighbors via radial hash lookup,
    /// then measure how many of those neighbors also appear in relations
    /// WITH this token (direct connections in the relation graph).
    /// 
    /// High density = token is well-connected to its semantic neighborhood
    /// Low density = token appears isolated despite having semantic neighbors
    /// 
    /// A low-density token is a prime candidate for definition because
    /// defining it would bridge disconnected relation clusters.
    pub fn relational_density_score(&self, token: &str, window: u16) -> f32 {
        let token_lower = token.to_lowercase();

        // Step 1: Get hash table neighbors via radial lookup
        let neighbors = self.table.lookup_radial(
            &token_lower,
            self.query_mode.hash_method(),
            1,  // chain_depth: follow chains once
            100, // probe_cap
            window,
            &self.addr_index,
        );

        if neighbors.is_empty() {
            return 0.0; // Token not in hash table, lowest possible density
        }

        // Step 2: For each neighbor, check if it appears in a relation WITH this token
        let mut connected_neighbors = 0u32;
        let token_rels = self.subject_index.get(&token_lower)
            .and_then(|indices| {
                let mut rels = Vec::new();
                for &idx in indices {
                    if let Some(r) = self.relations.get(idx) {
                        rels.push(r.object.to_lowercase());
                    }
                }
                Some(rels)
            })
            .unwrap_or_default();

        let obj_rels = self.object_index.get(&token_lower)
            .and_then(|indices| {
                let mut rels = Vec::new();
                for &idx in indices {
                    if let Some(r) = self.relations.get(idx) {
                        rels.push(r.subject.to_lowercase());
                    }
                }
                Some(rels)
            })
            .unwrap_or_default();

        // Check each neighbor
        for (slot_idx, _weight) in &neighbors {
            if let Some(slot) = self.table.slots.get(*slot_idx as usize) {
                if let Ok(neighbor_word) = std::str::from_utf8(&slot.key[..slot.key_len as usize]) {
                    let neighbor_lower = neighbor_word.to_lowercase();
                    // Is this neighbor in any relation with the token?
                    if token_rels.contains(&neighbor_lower) || obj_rels.contains(&neighbor_lower) {
                        connected_neighbors += 1;
                    }
                }
            }
        }

        // Step 3: Score = ratio of connected neighbors to total neighbors
        // High ratio = dense (don't define), Low ratio = sparse (do define)
        let density = connected_neighbors as f32 / neighbors.len() as f32;
        density.clamp(0.0, 1.0)
    }


    ///
    /// These are candidates for post-ingest LM definition:
    /// - Appear in subject/object positions of relations (semantically important)
    /// - Have few edges and/or conflicting relations (low clarity)
    /// - Are NOT identity tokens (names handled by correction pipeline)
    ///
    /// Returns tokens sorted by ascending clarity (foggiest first).
    pub fn find_low_clarity_tokens(&self, clarity_threshold: f32) -> Vec<(String, f32)> {
        let mut candidates: Vec<(String, f32)> = Vec::new();

        // Scan tokens that appear in relation subject/object positions
        let mut seen = HashSet::new();
        for token in self.subject_index.keys().chain(self.object_index.keys()) {
            if !seen.insert(token.clone()) { continue; }
            if self.function_words.contains(token) { continue; }
            if token.len() < 2 { continue; }

            let clarity = self.clarity_score(token);
            if clarity < clarity_threshold {
                candidates.push((token.clone(), clarity));
            }
        }

        // Sort foggiest first
        candidates.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
        candidates
    }

    /// Check if a token appears to be an identity/name token.
    ///
    /// Identity tokens should NOT be sent to the LM for definition.
    /// They are handled by the correction/possessive pipeline instead.
    pub fn is_identity_token(&self, token: &str) -> bool {
        let lower = token.to_lowercase();

        // Check if it appears as the value in a "name" relation
        if let Some(indices) = self.object_index.get(&lower) {
            for &idx in indices {
                if let Some(rel) = self.relations.get(idx) {
                    let r = rel.relation.to_lowercase();
                    if r.contains("name") || r.contains("called") || r.contains("known as") {
                        return true;
                    }
                }
            }
        }

        // Check if it appears as subject in identity patterns
        if let Some(indices) = self.subject_index.get(&lower) {
            for &idx in indices {
                if let Some(rel) = self.relations.get(idx) {
                    let subj = rel.subject.to_lowercase();
                    if subj.contains("name") || subj.contains("my name") || subj.contains("your name") {
                        return true;
                    }
                }
            }
        }

        // Heuristic: capitalized single token tied to possessive contexts
        if token.chars().next().map_or(false, |c| c.is_uppercase()) && !token.contains(' ') {
            // Check if any relation has "my" or "your" + this token
            for rel in &self.relations {
                let subj = rel.subject.to_lowercase();
                let obj = rel.object.to_lowercase();
                if (subj.contains("my") || subj.contains("your")) && (subj.contains(&lower) || obj.contains(&lower)) {
                    return true;
                }
            }
        }

        false
    }

    /// Filter low-clarity tokens, removing identity tokens that should not
    /// be sent to the definition LM. Returns only "dictionary word" candidates.
    pub fn definition_candidates(&self, clarity_threshold: f32) -> Vec<(String, f32)> {
        self.find_low_clarity_tokens(clarity_threshold)
            .into_iter()
            .filter(|(token, _)| !self.is_identity_token(token))
            .collect()
    }

    /// Get engine statistics
    pub fn get_stats(&self) -> HashMap<String, serde_json::Value> {
        use serde_json::json;
        
        let mut stats = HashMap::new();
        stats.insert("total_tokens".to_string(), json!(self.total_tokens));
        stats.insert("total_relations".to_string(), json!(self.relations.len()));
        stats.insert("vocabulary_size".to_string(), json!(self.token_index.len()));
        stats.insert("memory_usage_mb".to_string(), json!(self.estimate_memory_usage_mb()));
        stats.insert("turn_counter".to_string(), json!(self.turn_counter));
        
        stats
    }

// unit tests placed at module scope (below impl)
    
    /// Estimate memory usage in MB
    fn estimate_memory_usage_mb(&self) -> f64 {
        // Rough estimation
        let token_memory = self.tokens.len() * 20; // avg 20 bytes per token
        let relation_memory = self.relations.len() * 200; // avg 200 bytes per relation  
        let index_memory = self.token_index.len() * 50; // avg 50 bytes per index entry
        let table_stats = self.table.stats();
        // Estimate memory usage: each slot is probably around 128 bytes
        let table_memory = table_stats.capacity * 128;
        
        (token_memory + relation_memory + index_memory + table_memory) as f64 / (1024.0 * 1024.0)
    }
    
    /// Handle simple commands
    pub fn handle_command(&mut self, cmd: &str) -> bool {
        match cmd.trim().to_lowercase().as_str() {
            "invert" => {
                self.invert_flag = !self.invert_flag;
                println!("Backward traversal {}", if self.invert_flag { "ENABLED" } else { "DISABLED" });
                true
            }
            "trace" => {
                self.trace_mode = !self.trace_mode;
                println!("Trace mode {}", if self.trace_mode { "ENABLED" } else { "DISABLED" });
                true
            }
            _ => false
        }
    }

    /// Load a .crsl file into the engine using memory mapping
    pub fn load_crsl(&mut self, path: impl AsRef<std::path::Path>) -> Result<(), Box<dyn std::error::Error>> {
        crsl_loader::load_crsl_into_engine(self, path)
    }

    /// Load multiple .crsl files from a directory
    pub fn load_crsl_directory(&mut self, dir_path: impl AsRef<std::path::Path>) -> Result<usize, Box<dyn std::error::Error>> {
        crsl_loader::load_crsl_directory(self, dir_path)
    }

    /// Save complete engine state to a binary file
    pub fn save_state(&self, path: impl AsRef<std::path::Path>) -> Result<(), Box<dyn std::error::Error>> {
        word_engine_persistence::save_word_engine(self, path).map_err(|e| Box::new(e) as Box<dyn std::error::Error>)
    }

    /// Load complete engine state from a binary file
    pub fn load_state(&mut self, path: impl AsRef<std::path::Path>) -> Result<(), Box<dyn std::error::Error>> {
        let loaded_engine = word_engine_persistence::load_word_engine(path)?;
        *self = loaded_engine;
        Ok(())
    }

    /// Create an adaptive Dada engine for enhanced learning
    pub fn create_adaptive_dada(&self) -> AdaptiveDadaEngine {
        AdaptiveDadaEngine::default()
    }

    /// Query with adaptive Dada engine for enhanced responses
    pub fn query_adaptive(&mut self, input_text: &str) -> QueryResult {
        let mut adaptive_engine = self.create_adaptive_dada();
        
        // Extract relations for the adaptive engine
        let content_words: Vec<String> = {
            let (norm_tokens, _, _) = self.normalize(input_text);
            norm_tokens.iter()
                .filter(|w| !self.function_words.contains(*w))
                .map(|w| w.trim_matches(|c: char| "?:!,.".contains(c)).to_string())
                .filter(|w| !w.is_empty())
                .collect()
        };

        let mut matched_relations = Vec::new();
        for word in &content_words {
            if let Some(indices) = self.subject_index.get(word) {
                for &idx in indices {
                    if idx < self.relations.len() {
                        matched_relations.push(self.relations[idx].clone());
                    }
                }
            }
        }

        // Use adaptive engine for synthesis
        adaptive_engine.synthesize_adaptive(self, input_text, &matched_relations)
    }

    /// Populate the engine directly from a JSON dump of conversations.
    /// This method extracts messages from the JSON structure, tokenizes them,
    /// indexes tokens, and extracts relational triples using the multi-word verb extractor.
    pub fn populate_from_json(&mut self, data: &Value) -> Result<(), String> {
        self.metrics.start("populate_from_json");
        
        let messages = self.extract_messages_from_json(data);
        let mut _processed_count = 0;
        
        for (i, (role, text)) in messages.iter().enumerate() {
            // Add boundary marker like in Mind::train_json
            let boundary = format!("<MSG:{}:{}>", role, i);
            let _ = self.ingest(&boundary);
            
            // Ingest the actual message text
            if self.ingest(text).is_ok() {
                _processed_count += 1;
            }
        }
        
        // Add end marker
        let _ = self.ingest("<MSG:END>");
        
        self.metrics.stop("populate_from_json");
        Ok(())
    }

    /// Extract messages from JSON data - mirrors Mind::extract_messages logic
    fn extract_messages_from_json(&self, value: &Value) -> Vec<(String, String)> {
        let mut out = Vec::new();
        self.search_msgs(value, &mut out);
        if out.is_empty() {
            self.flatten_extract(value, &mut out);
        }
        out
    }

    /// Search for messages in JSON arrays and objects
    fn search_msgs(&self, v: &Value, found: &mut Vec<(String, String)>) {
        match v {
            Value::Array(arr) => {
                if arr.len() >= 2 && arr.iter().take(3).any(|i| self.extract_msg(i).is_some()) {
                    for i in arr {
                        if let Some(m) = self.extract_msg(i) {
                            found.push(m);
                        }
                    }
                } else {
                    for i in arr {
                        self.search_msgs(i, found);
                    }
                }
            }
            Value::Object(obj) => {
                for (_, v) in obj {
                    self.search_msgs(v, found);
                }
            }
            _ => {}
        }
    }

    /// Flatten extract messages from any JSON structure
    fn flatten_extract(&self, v: &Value, found: &mut Vec<(String, String)>) {
        match v {
            Value::Array(arr) => {
                for i in arr {
                    self.flatten_extract(i, found);
                }
            }
            Value::Object(obj) => {
                if let Some(m) = self.extract_msg(v) {
                    found.push(m);
                }
                for (_, v) in obj {
                    self.flatten_extract(v, found);
                }
            }
            _ => {}
        }
    }

    /// Extract a single message from a JSON object
    fn extract_msg(&self, v: &Value) -> Option<(String, String)> {
        let obj = v.as_object()?;
        let role = ["role", "speaker", "author", "name"]
            .iter()
            .find_map(|k| obj.get(*k)?.as_str().map(String::from))
            .unwrap_or_else(|| "user".to_string());
        
        let text = ["content", "message", "text", "body"]
            .iter()
            .find_map(|k| obj.get(*k)?.as_str().filter(|s| s.len() > 2).map(String::from))
            .or_else(|| {
                obj.get("content")?.get("parts")?.as_array()?
                   .first()?.as_str().map(String::from)
            })?;
        
        Some((role, text))
    }
}