//! # Word Engine State Persistence
//!
//! Comprehensive persistence for the Word Engine state including:
//! - Token timeline (physics positions)
//! - Knowledge graph (relations)
//! - Interference field state
//! - Dada engine learning patterns
//! - Fatigue tracking
//!
//! Uses efficient binary serialization with optional compression.

use std::collections::{HashMap, HashSet};
use std::fs::File;
use std::io::{self, Read, Write, BufReader, BufWriter};
use std::path::Path;
use serde::{Serialize, Deserialize};
use crate::word_engine::{WordEngine, InterferenceEntry};
use crate::dada_engine::{RelationalTriple, SynthesisRule};
use crate::persist::MappedTable;
use crate::table::SlotKind;

/// Magic bytes for Word Engine state files: "WENG" + 0x00 + 0x01 (v1)
const WENG_MAGIC: [u8; 8] = [b'W', b'E', b'N', b'G', 0x00, 0x01, 0x00, 0x01];

/// Word Engine state header
#[derive(Debug, Clone, Serialize, Deserialize)]
struct WengHeader {
    magic: [u8; 8],
    version: u32,
    timestamp: u64,
    total_tokens: u32,
    relation_count: u32,
    token_index_size: u32,
    interference_size: u32,
    fatigue_size: u32,
    dada_rules_count: u32,
    checksum: u32,
}

/// Serializable token index entry
#[derive(Debug, Clone, Serialize, Deserialize)]
struct TokenIndexEntry {
    token: String,
    positions: Vec<u32>,
}

/// Serializable interference field entry
#[derive(Debug, Clone, Serialize, Deserialize)]
struct InterferenceFieldEntry {
    position: u32,
    amplitude: f32,
    distance: u32,
    source_positions: Vec<u32>,
}

/// Serializable fatigue entry
#[derive(Debug, Clone, Serialize, Deserialize)]
struct FatigueEntry {
    phrase: String,
    fatigue: f32,
}

/// Serializable Dada engine rule
#[derive(Debug, Clone, Serialize, Deserialize)]
struct DadaRuleEntry {
    pattern: String,
    usage_count: u32,
    success_count: u32,
    failure_count: u32,
}

/// Complete Word Engine state
#[derive(Debug, Clone, Serialize, Deserialize)]
struct WordEngineState {
    header: WengHeader,
    tokens: Vec<String>,
    total_tokens: u32,
    token_index: Vec<TokenIndexEntry>,
    relations: Vec<RelationalTriple>,
    subject_index: HashMap<String, Vec<usize>>,
    object_index: HashMap<String, Vec<usize>>,
    interference_field: Vec<InterferenceFieldEntry>,
    phrase_fatigue: Vec<FatigueEntry>,
    synsets: HashMap<String, HashSet<String>>,
    dada_rules: Vec<DadaRuleEntry>,
    dada_fatigue_map: HashMap<String, f32>,
    metrics: HashMap<String, Vec<f64>>,
    counts: HashMap<String, u64>,
    turn_counter: u32,
    window: usize,
    invert_flag: bool,
    trace_mode: bool,
    auto_record_fatigue: bool,
    fatigue_decay_per_turn: f32,
    fatigue_increment_on_use: f32,
}

/// Save complete Word Engine state to a binary file
pub fn save_word_engine(engine: &WordEngine, path: impl AsRef<Path>) -> io::Result<()> {
    let path = path.as_ref();
    
    // Build the state structure
    let state = WordEngineState {
        header: WengHeader {
            magic: WENG_MAGIC,
            version: 1,
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
            total_tokens: engine.total_tokens,
            relation_count: engine.relations.len() as u32,
            token_index_size: engine.token_index.len() as u32,
            interference_size: engine.interference_field.len() as u32,
            fatigue_size: engine.phrase_fatigue.len() as u32,
            dada_rules_count: engine.dada_engine.learned_rules.len() as u32,
            checksum: 0, // Will be calculated
        },
        tokens: engine.tokens.clone(),
        total_tokens: engine.total_tokens,
        token_index: engine.token_index.iter()
            .map(|(token, positions)| TokenIndexEntry {
                token: token.clone(),
                positions: positions.clone(),
            })
            .collect(),
        relations: engine.relations.clone(),
        subject_index: engine.subject_index.clone(),
        object_index: engine.object_index.clone(),
        interference_field: engine.interference_field.iter()
            .map(|(position, entry)| InterferenceFieldEntry {
                position: *position,
                amplitude: entry.amplitude,
                distance: entry.distance,
                source_positions: entry.source_positions.clone(),
            })
            .collect(),
        phrase_fatigue: engine.phrase_fatigue.iter()
            .map(|(phrase, fatigue)| FatigueEntry {
                phrase: phrase.clone(),
                fatigue: *fatigue,
            })
            .collect(),
        synsets: engine.synsets.clone(),
        dada_rules: engine.dada_engine.learned_rules.iter()
            .map(|(pattern, rule)| DadaRuleEntry {
                pattern: pattern.clone(),
                usage_count: rule.usage_count,
                success_count: rule.success_count,
                failure_count: rule.failure_count,
            })
            .collect(),
        dada_fatigue_map: engine.dada_engine.fatigue_map.clone(),
        metrics: engine.metrics.timings.clone(),
        counts: engine.metrics.counts.clone(),
        turn_counter: engine.turn_counter,
        window: engine.window,
        invert_flag: engine.invert_flag,
        trace_mode: engine.trace_mode,
        auto_record_fatigue: engine.auto_record_fatigue,
        fatigue_decay_per_turn: engine.fatigue_decay_per_turn,
        fatigue_increment_on_use: engine.fatigue_increment_on_use,
    };
    
    // Calculate checksum over the serialized state blob
    let state_bytes = bincode::serialize(&state).map_err(|e| {
        io::Error::new(io::ErrorKind::InvalidData, format!("Serialization failed: {}", e))
    })?;
    let checksum = calculate_checksum(&state_bytes);

    // Serialize header after stamping checksum into it
    let mut header_for_file = state.header.clone();
    header_for_file.checksum = checksum;
    let header_bytes = bincode::serialize(&header_for_file).map_err(|e| {
        io::Error::new(io::ErrorKind::InvalidData, format!("Header serialization failed: {}", e))
    })?;
    
    // Write to file: prefix header with its length so loader can deserialize
    let file = File::create(path)?;
    let mut writer = BufWriter::with_capacity(1 << 20, file);

    let header_len = header_bytes.len() as u32;
    writer.write_all(&header_len.to_le_bytes())?;
    writer.write_all(&header_bytes)?;
    writer.write_all(&state_bytes)?;
    writer.flush()?;
    
    Ok(())
}

/// Load complete Word Engine state from a binary file
pub fn load_word_engine(path: impl AsRef<Path>) -> io::Result<WordEngine> {
    let path = path.as_ref();
    let file = File::open(path)?;
    let mut reader = BufReader::with_capacity(1 << 20, file);
    
    // Read and validate header (header length prefix -> header bytes)
    let mut header_len_buf = [0u8; 4];
    reader.read_exact(&mut header_len_buf)?;
    let header_len = u32::from_le_bytes(header_len_buf) as usize;

    let mut header_bytes = vec![0u8; header_len];
    reader.read_exact(&mut header_bytes)?;

    let header: WengHeader = bincode::deserialize(&header_bytes).map_err(|e| {
        io::Error::new(io::ErrorKind::InvalidData, format!("Header deserialization failed: {}", e))
    })?;
    
    // Validate magic
    if header.magic != WENG_MAGIC {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "Not a Word Engine state file (bad magic bytes)",
        ));
    }
    
    // Read state data
    let mut state_bytes = Vec::new();
    reader.read_to_end(&mut state_bytes)?;
    
    // Validate checksum
    let stored_checksum = header.checksum;
    let computed_checksum = calculate_checksum(&state_bytes);
    if stored_checksum != computed_checksum {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "Checksum mismatch: stored=0x{:08X}, computed=0x{:08X}",
                stored_checksum, computed_checksum
            ),
        ));
    }
    
    // Deserialize state
    let state: WordEngineState = bincode::deserialize(&state_bytes).map_err(|e| {
        io::Error::new(io::ErrorKind::InvalidData, format!("State deserialization failed: {}", e))
    })?;
    
    // Reconstruct the Word Engine
    let mut engine = WordEngine::new(state.window);
    
    // Restore basic properties
    engine.total_tokens = state.total_tokens;
    engine.turn_counter = state.turn_counter;
    engine.invert_flag = state.invert_flag;
    engine.trace_mode = state.trace_mode;
    engine.auto_record_fatigue = state.auto_record_fatigue;
    engine.fatigue_decay_per_turn = state.fatigue_decay_per_turn;
    engine.fatigue_increment_on_use = state.fatigue_increment_on_use;
    
    // Restore tokens
    engine.tokens = state.tokens;
    
    // Restore token index
    for entry in state.token_index {
        engine.token_index.insert(entry.token, entry.positions);
    }
    
    // Restore relations
    engine.relations = state.relations;
    engine.subject_index = state.subject_index;
    engine.object_index = state.object_index;
    
    // Restore interference field
    for entry in state.interference_field {
        engine.interference_field.insert(
            entry.position,
            InterferenceEntry {
                amplitude: entry.amplitude,
                distance: entry.distance,
                source_positions: entry.source_positions,
            }
        );
    }
    
    // Restore fatigue
    for entry in state.phrase_fatigue {
        engine.phrase_fatigue.insert(entry.phrase, entry.fatigue);
    }
    
    // Restore synsets
    engine.synsets = state.synsets;
    
    // Restore Dada engine state
    for rule_entry in state.dada_rules {
        let mut rule = SynthesisRule::new(rule_entry.pattern.clone());
        rule.usage_count = rule_entry.usage_count;
        rule.success_count = rule_entry.success_count;
        rule.failure_count = rule_entry.failure_count;
        engine.dada_engine.learned_rules.insert(rule_entry.pattern, rule);
    }
    
    engine.dada_engine.fatigue_map = state.dada_fatigue_map;
    
    // Restore metrics
    engine.metrics.timings = state.metrics;
    engine.metrics.counts = state.counts;
    
    Ok(engine)
}

/// Calculate a simple checksum for data validation
fn calculate_checksum(data: &[u8]) -> u32 {
    let mut checksum: u32 = 0;
    for chunk in data.chunks_exact(4) {
        let word = u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
        checksum = checksum.wrapping_add(word);
    }
    
    // Handle remaining bytes
    let remainder = data.chunks_exact(4).remainder();
    for (i, &byte) in remainder.iter().enumerate() {
        checksum = checksum.wrapping_add((byte as u32) << (i * 8));
    }
    
    checksum
}

/// Save only the hash table portion (for compatibility with existing .crsl files)
pub fn save_hash_table_only(engine: &WordEngine, path: impl AsRef<Path>) -> io::Result<()> {
    let _ = crate::persist::save(&engine.table, path)?;
    Ok(())
}

/// Load hash table from .crsl file and integrate with existing engine
pub fn load_hash_table_only(engine: &mut WordEngine, path: impl AsRef<Path>) -> io::Result<()> {
    let mapped_table = MappedTable::open(path)?;
    
    // Copy slots from the mapped table to the engine's table
    for i in 0..mapped_table.slot_count() {
        let slot = mapped_table.slot(i);
        if !slot.is_empty() {
            let key_len = slot.key_len as usize;
            let key = &slot.key[..key_len];
            let kind = SlotKind::from_u8(slot.kind).unwrap_or(SlotKind::Empty);
            let value = slot.value;
            let next_pos = slot.next_pos;
            let score = slot.score;
            
            engine.table.insert(key, kind, value, next_pos, score);
        }
    }
    
    Ok(())
}

/// Merge multiple Word Engine states into a new engine
pub fn merge_word_engine_states(states: &[WordEngine]) -> WordEngine {
    if states.is_empty() {
        return WordEngine::new(8);
    }
    
    let mut merged = WordEngine::new(8);
    
    for state in states {
        // Merge tokens (avoiding duplicates)
        for token in &state.tokens {
            if !merged.tokens.contains(token) {
                merged.tokens.push(token.clone());
            }
        }
        
        // Merge token index
        for (token, positions) in &state.token_index {
            merged.token_index.entry(token.clone()).or_default().extend(positions);
        }
        
        // Merge relations
        for relation in &state.relations {
            if !merged.relations.contains(relation) {
                merged.relations.push(relation.clone());
            }
        }
        
        // Merge interference field
        for (position, entry) in &state.interference_field {
            merged.interference_field.insert(*position, entry.clone());
        }
        
        // Merge fatigue
        for (phrase, fatigue) in &state.phrase_fatigue {
            let current = merged.phrase_fatigue.entry(phrase.clone()).or_insert(0.0);
            *current = (*current).max(*fatigue);
        }
        
        // Merge Dada rules
        for (pattern, rule) in &state.dada_engine.learned_rules {
            let existing = merged.dada_engine.learned_rules.entry(pattern.clone()).or_insert_with(|| {
                SynthesisRule::new(pattern.clone())
            });
            existing.usage_count += rule.usage_count;
            existing.success_count += rule.success_count;
            existing.failure_count += rule.failure_count;
        }
        
        // Update total tokens
        merged.total_tokens += state.total_tokens;
    }
    
    merged
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::NamedTempFile;
    
    #[test]
    fn test_save_load_word_engine() {
        let mut engine = WordEngine::new(8);
        
        // Add some test data
        engine.ingest("The quick brown fox jumps over the lazy dog").unwrap();
        engine.ingest("Alice loves Bob").unwrap();
        engine.record_feedback("Alice loves Bob", true);
        
        // Save state
        let temp_file = NamedTempFile::new().unwrap();
        let result = save_word_engine(&engine, temp_file.path());
        assert!(result.is_ok());
        
        // Load state
        let loaded_engine = load_word_engine(temp_file.path());
        assert!(loaded_engine.is_ok());
        
        let loaded = loaded_engine.unwrap();
        
        // Verify data was preserved
        assert_eq!(loaded.total_tokens, engine.total_tokens);
        assert_eq!(loaded.relations.len(), engine.relations.len());
        assert_eq!(loaded.turn_counter, engine.turn_counter);
        
        // Clean up
        let _ = fs::remove_file(temp_file.path());
    }
    
    #[test]
    fn test_merge_states() {
        let mut engine1 = WordEngine::new(8);
        let mut engine2 = WordEngine::new(8);
        
        engine1.ingest("Hello world").unwrap();
        engine2.ingest("Goodbye world").unwrap();
        
        let merged = merge_word_engine_states(&[engine1, engine2]);
        
        assert!(merged.total_tokens > 0);
        // Sentence ingestion for simple phrases populates tokens/token_index
        assert!(merged.token_index.len() > 0, "merged token index should contain entries");
    }
}